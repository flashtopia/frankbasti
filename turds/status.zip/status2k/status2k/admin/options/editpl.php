<?php
require_once("../includes/header.php");
$save = $_POST['save'];

ob_start(); include("../../templates/".$config['templaten']."/windows.tpl"); $winpage = ob_get_contents(); ob_end_clean();

ob_start(); include("../../templates/".$config['templaten']."/linux.tpl"); $linuxpage = ob_get_contents(); ob_end_clean();

ob_start(); include("../../templates/".$config['templaten']."/multi.tpl"); $multipage = ob_get_contents(); ob_end_clean();

if ($save) {
foreach ($save as $filename => $value) {
$value = stripslashes($value);
// Let's make sure the file exists and is writable first.
if (is_writable("../../templates/".$config['templaten']."/".$filename)) {

    // In our example we're opening $filename in append mode.
    // The file pointer is at the bottom of the file hence
    // that's where $somecontent will go when we fwrite() it.
    if (!$handle = fopen("../../templates/".$config['templaten']."/".$filename, 'w')) {
         echo "Cannot open file (../../templates/".$config['templaten']."/".$filename.")";
         exit;
    }

    // Write $somecontent to our opened file.
    if (fwrite($handle, $value) === FALSE) {
        echo "Cannot write to file (../../templates/".$config['templaten']."/".$filename.")";
        exit;
    } else {
echo "Success, $filename updated!";
}

    fclose($handle);

} else {
    echo "The file $filename is not writable";
}
}
}
$key = $_SESSION['csrf'];
echo "
<form action=\"editpl.php\" method=\"post\">
<B>Linux Template:</B><BR>
<textarea name=\"save[linux.tpl]\" rows=\"30\" cols=\"120\">".$linuxpage."</textarea>
<BR><BR><B>Windows Template:</B><BR>
<textarea name=\"save[windows.tpl]\" rows=\"30\" cols=\"120\">".$winpage."</textarea>
<BR><BR><B>MultiServers Template:</B><BR>
<textarea name=\"save[multi.tpl]\" rows=\"30\" cols=\"120\">".$multipage."</textarea>
<BR><BR><input type=\"hidden\" name=\"csrf\" value=\"$key\"><input type=\"submit\" value=\"Save Templates >>\">
</form>
";

require_once("../includes/footer.php");
?>
