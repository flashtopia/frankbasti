<?php

include("../../../config.php");
include("graphit.php");

$lgtrue = 0;
$q = mysql_query("SELECT * FROM ".$prefix."users");
while($res = mysql_fetch_array($q)){
$adminuser = $res['adminuser']; // Login Database
$adminpass = $res['adminpass']; // Pass Database
$adminper = $res['adminper']; // Admin Permissions
if ( isset($_COOKIE["S2KUser"]) && isset($_COOKIE["S2KPass"]) ) {
$cusername = $_COOKIE["S2KUser"];
$cpassword = $_COOKIE["S2KPass"];
if ( ($cusername == $adminuser) && ($cpassword == $adminpass) ) { $lgtrue = 1; }
} // End Cookie
} // End While
if (!$lgtrue) { header("Location: ../login.php"); die(); }

if ($_GET['day'] && $_GET['month'] && $_GET['year']) {
$day = $_GET['day'];
$month = $_GET['month'];
$year = $_GET['year'];
} else {
$day = date("j");
$month = date("n");
$year = date("Y");
}

$query = mysql_query("SELECT * FROM ".$prefix."history WHERE day = '$day' AND month = '$month' AND year = '$year'");
while($results = mysql_fetch_array($query)){
$hour = $results['hour'];
if ($hour == 0) { $m1 = $m1+$results['mem']; $c1++; }
if ($hour == 1) { $m2 = $m2+$results['mem']; $c2++; }
if ($hour == 2) { $m3 = $m3+$results['mem']; $c3++; }
if ($hour == 3) { $m4 = $m4+$results['mem']; $c4++; }
if ($hour == 4) { $m5 = $m5+$results['mem']; $c5++; }
if ($hour == 5) { $m6 = $m6+$results['mem']; $c6++; }
if ($hour == 6) { $m7 = $m7+$results['mem']; $c7++; }
if ($hour == 7) { $m8 = $m8+$results['mem']; $c8++; }
if ($hour == 8) { $m9 = $m9+$results['mem']; $c9++; }
if ($hour == 9) { $m10 = $m10+$results['mem']; $c10++; }
if ($hour == 10) { $m11 = $m11+$results['mem']; $c11++; }
if ($hour == 11) { $m12 = $m12+$results['mem']; $c12++; }
if ($hour == 12) { $m13 = $m13+$results['mem']; $c13++; }
if ($hour == 13) { $m14 = $m14+$results['mem']; $c14++; }
if ($hour == 14) { $m15 = $m15+$results['mem']; $c15++; }
if ($hour == 15) { $m16 = $m16+$results['mem']; $c16++; }
if ($hour == 16) { $m17 = $m17+$results['mem']; $c17++; }
if ($hour == 17) { $m18 = $m18+$results['mem']; $c18++; }
if ($hour == 18) { $m19 = $m19+$results['mem']; $c19++; }
if ($hour == 19) { $m20 = $m20+$results['mem']; $c20++; }
if ($hour == 20) { $m21 = $m21+$results['mem']; $c21++; }
if ($hour == 21) { $m22 = $m22+$results['mem']; $c22++; }
if ($hour == 22) { $m23 = $m23+$results['mem']; $c23++; }
if ($hour == 23) { $m24 = $m24+$results['mem']; $c24++; }
}

function convt($numb,$total) {
$numb = $numb/$total;
$numb = $numb/1024;
$numb = round($numb,2);
return $numb;
}

if ($m1) { $mem1 = convt($m1,$c1); }
if ($m2) { $mem2 = convt($m2,$c2); }
if ($m3) { $mem3 = convt($m3,$c3); }
if ($m4) { $mem4 = convt($m4,$c4); }
if ($m5) { $mem5 = convt($m5,$c5); }
if ($m6) { $mem6 = convt($m6,$c6); }
if ($m7) { $mem7 = convt($m7,$c7); }
if ($m8) { $mem8 = convt($m8,$c8); }
if ($m9) { $mem9 = convt($m9,$c9); }
if ($m10) { $mem10 = convt($m10,$c10); }
if ($m11) { $mem11 = convt($m11,$c11); }
if ($m12) { $mem12 = convt($m12,$c12); }
if ($m13) { $mem13 = convt($m13,$c13); }
if ($m14) { $mem14 = convt($m14,$c14); }
if ($m15) { $mem15 = convt($m15,$c15); }
if ($m16) { $mem16 = convt($m16,$c16); }
if ($m17) { $mem17 = convt($m17,$c17); }
if ($m18) { $mem18 = convt($m18,$c18); }
if ($m19) { $mem19 = convt($m19,$c19); }
if ($m20) { $mem20 = convt($m20,$c20); }
if ($m21) { $mem21 = convt($m21,$c21); }
if ($m22) { $mem22 = convt($m22,$c22); }
if ($m23) { $mem23 = convt($m23,$c23); }
if ($m24) { $mem24 = convt($m24,$c24); }

$mem = $mem1.",".$mem2.",".$mem3.",".$mem4.",".$mem5.",".$mem6.",".$mem7.",".$mem8.",".$mem9.",".$mem10.",".$mem11.",".$mem12.",".$mem13.",".$mem14.",".$mem15.",".$mem16.",".$mem17.",".$mem18.",".$mem19.",".$mem20.",".$mem21.",".$mem22.",".$mem23.",".$mem24;

$title = "Memory Usage Over 24 Hours - ($day/$month/$year)";
$y = "Hour";
$x = "Memory (GB / 1GB = 1024MB)";
$data = explode(",",$mem);

$graph = new PostGraph(800,400);

$graph->setGraphTitles($title, $y, $x);

$graph->setData($data);
$graph->yValueMode = 3;
$graph->drawImage();
$graph->printImage();

?>
