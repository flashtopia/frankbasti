<?php

include("../../../config.php");
include("graphit.php");

$lgtrue = 0;
$q = mysql_query("SELECT * FROM ".$prefix."users");
while($res = mysql_fetch_array($q)){
$adminuser = $res['adminuser']; // Login Database
$adminpass = $res['adminpass']; // Pass Database
$adminper = $res['adminper']; // Admin Permissions
if ( isset($_COOKIE["S2KUser"]) && isset($_COOKIE["S2KPass"]) ) {
$cusername = $_COOKIE["S2KUser"];
$cpassword = $_COOKIE["S2KPass"];
if ( ($cusername == $adminuser) && ($cpassword == $adminpass) ) { $lgtrue = 1; }
} // End Cookie
} // End While
if (!$lgtrue) { header("Location: ../login.php"); die(); }

if ($_GET['day'] && $_GET['month'] && $_GET['year']) {
$day = $_GET['day'];
$month = $_GET['month'];
$year = $_GET['year'];
} else {
$day = date("j");
$month = date("n");
$year = date("Y");
}

$query = mysql_query("SELECT * FROM ".$prefix."history WHERE day = '$day' AND month = '$month' AND year = '$year'");
while($results = mysql_fetch_array($query)){
$hour = $results['hour'];
if ($hour == 0) { $l1 = $l1+$results['load']; $c1++; }
if ($hour == 1) { $l2 = $l2+$results['load']; $c2++; }
if ($hour == 2) { $l3 = $l3+$results['load']; $c3++; }
if ($hour == 3) { $l4 = $l4+$results['load']; $c4++; }
if ($hour == 4) { $l5 = $l5+$results['load']; $c5++; }
if ($hour == 5) { $l6 = $l6+$results['load']; $c6++; }
if ($hour == 6) { $l7 = $l7+$results['load']; $c7++; }
if ($hour == 7) { $l8 = $l8+$results['load']; $c8++; }
if ($hour == 8) { $l9 = $l9+$results['load']; $c9++; }
if ($hour == 9) { $l10 = $l10+$results['load']; $c10++; }
if ($hour == 10) { $l11 = $l11+$results['load']; $c11++; }
if ($hour == 11) { $l12 = $l12+$results['load']; $c12++; }
if ($hour == 12) { $l13 = $l13+$results['load']; $c13++; }
if ($hour == 13) { $l14 = $l14+$results['load']; $c14++; }
if ($hour == 14) { $l15 = $l15+$results['load']; $c15++; }
if ($hour == 15) { $l16 = $l16+$results['load']; $c16++; }
if ($hour == 16) { $l17 = $l17+$results['load']; $c17++; }
if ($hour == 17) { $l18 = $l18+$results['load']; $c18++; }
if ($hour == 18) { $l19 = $l19+$results['load']; $c19++; }
if ($hour == 19) { $l20 = $l20+$results['load']; $c20++; }
if ($hour == 20) { $l21 = $l21+$results['load']; $c21++; }
if ($hour == 21) { $l22 = $l22+$results['load']; $c22++; }
if ($hour == 22) { $l23 = $l23+$results['load']; $c23++; }
if ($hour == 23) { $l24 = $l24+$results['load']; $c24++; }
}

if ($l1) { $load1 = round($l1/$c1,2); }
if ($l2) { $load2 = round($l2/$c2,2); }
if ($l3) { $load3 = round($l3/$c3,2); }
if ($l4) { $load4 = round($l4/$c4,2); }
if ($l5) { $load5 = round($l5/$c5,2); }
if ($l6) { $load6 = round($l6/$c6,2); }
if ($l7) { $load7 = round($l7/$c7,2); }
if ($l8) { $load8 = round($l8/$c8,2); }
if ($l9) { $load9 = round($l9/$c9,2); }
if ($l10) { $load10 = round($l10/$c10,2); }
if ($l11) { $load11 = round($l11/$c11,2); }
if ($l12) { $load12 = round($l12/$c12,2); }
if ($l13) { $load13 = round($l13/$c13,2); }
if ($l14) { $load14 = round($l14/$c14,2); }
if ($l15) { $load15 = round($l15/$c15,2); }
if ($l16) { $load16 = round($l16/$c16,2); }
if ($l17) { $load17 = round($l17/$c17,2); }
if ($l18) { $load18 = round($l18/$c18,2); }
if ($l19) { $load19 = round($l19/$c19,2); }
if ($l20) { $load20 = round($l20/$c20,2); }
if ($l21) { $load21 = round($l21/$c21,2); }
if ($l22) { $load22 = round($l22/$c22,2); }
if ($l23) { $load23 = round($l23/$c23,2); }
if ($l24) { $load24 = round($l24/$c24,2); }

$load = $load1.",".$load2.",".$load3.",".$load4.",".$load5.",".$load6.",".$load7.",".$load8.",".$load9.",".$load10.",".$load11.",".$load12.",".$load13.",".$load14.",".$load15.",".$load16.",".$load17.",".$load18.",".$load19.",".$load20.",".$load21.",".$load22.",".$load23.",".$load24;

$title = "Server Load Over 24 Hours - ($day/$month/$year)";
$y = "Hour";
$x = "Load";
$data = explode(",",$load);

$graph = new PostGraph(800,400);

$graph->setGraphTitles($title, $y, $x);

$graph->setData($data);
$graph->yValueMode = 3;
$graph->drawImage();
$graph->printImage();

?>
