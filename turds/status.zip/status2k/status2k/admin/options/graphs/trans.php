<?php

include("../../../config.php");
include("graphit.php");

$lgtrue = 0;
$q = mysql_query("SELECT * FROM ".$prefix."users");
while($res = mysql_fetch_array($q)){
$adminuser = $res['adminuser']; // Login Database
$adminpass = $res['adminpass']; // Pass Database
$adminper = $res['adminper']; // Admin Permissions
if ( isset($_COOKIE["S2KUser"]) && isset($_COOKIE["S2KPass"]) ) {
$cusername = $_COOKIE["S2KUser"];
$cpassword = $_COOKIE["S2KPass"];
if ( ($cusername == $adminuser) && ($cpassword == $adminpass) ) { $lgtrue = 1; }
} // End Cookie
} // End While
if (!$lgtrue) { header("Location: ../login.php"); die(); }

if ($_GET['day'] && $_GET['month'] && $_GET['year']) {
$day = $_GET['day'];
$month = $_GET['month'];
$year = $_GET['year'];
} else {
$day = date("j");
$month = date("n");
$year = date("Y");
}

$query = mysql_query("SELECT * FROM ".$prefix."history WHERE day = '$day' AND month = '$month' AND year = '$year'");
while($results = mysql_fetch_array($query)){
$hour = $results['hour'];
if ($hour == 0) { $t1 = $t1+$results['trans']; }
if ($hour == 1) { $t2 = $t2+$results['trans']; }
if ($hour == 2) { $t3 = $t3+$results['trans']; }
if ($hour == 3) { $t4 = $t4+$results['trans']; }
if ($hour == 4) { $t5 = $t5+$results['trans']; }
if ($hour == 5) { $t6 = $t6+$results['trans']; }
if ($hour == 6) { $t7 = $t7+$results['trans']; }
if ($hour == 7) { $t8 = $t8+$results['trans']; }
if ($hour == 8) { $t9 = $t9+$results['trans']; }
if ($hour == 9) { $t10 = $t10+$results['trans']; }
if ($hour == 10) { $t11 = $t11+$results['trans']; }
if ($hour == 11) { $t12 = $t12+$results['trans']; }
if ($hour == 12) { $t13 = $t13+$results['trans']; }
if ($hour == 13) { $t14 = $t14+$results['trans']; }
if ($hour == 14) { $t15 = $t15+$results['trans']; }
if ($hour == 15) { $t16 = $t16+$results['trans']; }
if ($hour == 16) { $t17 = $t17+$results['trans']; }
if ($hour == 17) { $t18 = $t18+$results['trans']; }
if ($hour == 18) { $t19 = $t19+$results['trans']; }
if ($hour == 19) { $t20 = $t20+$results['trans']; }
if ($hour == 20) { $t21 = $t21+$results['trans']; }
if ($hour == 21) { $t22 = $t22+$results['trans']; }
if ($hour == 22) { $t23 = $t23+$results['trans']; }
if ($hour == 23) { $t24 = $t24+$results['trans']; }
}

function convt($numb) {
$numb = $numb/1024/1024/1024;
$numb = round($numb,2);
return $numb;
}

if ($t1) { $trans1 = convt($t1); }
if ($t2) { $trans2 = convt($t2); }
if ($t3) { $trans3 = convt($t3); }
if ($t4) { $trans4 = convt($t4); }
if ($t5) { $trans5 = convt($t5); }
if ($t6) { $trans6 = convt($t6); }
if ($t7) { $trans7 = convt($t7); }
if ($t8) { $trans8 = convt($t8); }
if ($t9) { $trans9 = convt($t9); }
if ($t10) { $trans10 = convt($t10); }
if ($t11) { $trans11 = convt($t11); }
if ($t12) { $trans12 = convt($t12); }
if ($t13) { $trans13 = convt($t13); }
if ($t14) { $trans14 = convt($t14); }
if ($t15) { $trans15 = convt($t15); }
if ($t16) { $trans16 = convt($t16); }
if ($t17) { $trans17 = convt($t17); }
if ($t18) { $trans18 = convt($t18); }
if ($t19) { $trans19 = convt($t19); }
if ($t20) { $trans20 = convt($t20); }
if ($t21) { $trans21 = convt($t21); }
if ($t22) { $trans22 = convt($t22); }
if ($t23) { $trans23 = convt($t23); }
if ($t24) { $trans24 = convt($t24); }

$trans = $trans1.",".$trans2.",".$trans3.",".$trans4.",".$trans5.",".$trans6.",".$trans7.",".$trans8.",".$trans9.",".$trans10.",".$trans11.",".$trans12.",".$trans13.",".$trans14.",".$trans15.",".$trans16.",".$trans17.",".$trans18.",".$trans19.",".$trans20.",".$trans21.",".$trans22.",".$trans23.",".$trans24;

$title = "Outgoing Data Over 24 Hours - ($day/$month/$year)";
$y = "Hour";
$x = "Data (GB/Per Hour)";
$data = explode(",",$trans);

$graph = new PostGraph(800,400);

$graph->setGraphTitles($title, $y, $x);

$graph->setData($data);
$graph->yValueMode = 3;
$graph->drawImage();
$graph->printImage();

?>
