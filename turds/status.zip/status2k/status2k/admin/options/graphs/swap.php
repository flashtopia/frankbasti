<?php

include("../../../config.php");
include("graphit.php");

$lgtrue = 0;
$q = mysql_query("SELECT * FROM ".$prefix."users");
while($res = mysql_fetch_array($q)){
$adminuser = $res['adminuser']; // Login Database
$adminpass = $res['adminpass']; // Pass Database
$adminper = $res['adminper']; // Admin Permissions
if ( isset($_COOKIE["S2KUser"]) && isset($_COOKIE["S2KPass"]) ) {
$cusername = $_COOKIE["S2KUser"];
$cpassword = $_COOKIE["S2KPass"];
if ( ($cusername == $adminuser) && ($cpassword == $adminpass) ) { $lgtrue = 1; }
} // End Cookie
} // End While
if (!$lgtrue) { header("Location: ../login.php"); die(); }

if ($_GET['day'] && $_GET['month'] && $_GET['year']) {
$day = $_GET['day'];
$month = $_GET['month'];
$year = $_GET['year'];
} else {
$day = date("j");
$month = date("n");
$year = date("Y");
}

$query = mysql_query("SELECT * FROM ".$prefix."history WHERE day = '$day' AND month = '$month' AND year = '$year'");
while($results = mysql_fetch_array($query)){
$hour = $results['hour'];
if ($hour == 0) { $s1 = $s1+$results['swap']; $c1++; }
if ($hour == 1) { $s2 = $s2+$results['swap']; $c2++; }
if ($hour == 2) { $s3 = $s3+$results['swap']; $c3++; }
if ($hour == 3) { $s4 = $s4+$results['swap']; $c4++; }
if ($hour == 4) { $s5 = $s5+$results['swap']; $c5++; }
if ($hour == 5) { $s6 = $s6+$results['swap']; $c6++; }
if ($hour == 6) { $s7 = $s7+$results['swap']; $c7++; }
if ($hour == 7) { $s8 = $s8+$results['swap']; $c8++; }
if ($hour == 8) { $s9 = $s9+$results['swap']; $c9++; }
if ($hour == 9) { $s10 = $s10+$results['swap']; $c10++; }
if ($hour == 10) { $s11 = $s11+$results['swap']; $c11++; }
if ($hour == 11) { $s12 = $s12+$results['swap']; $c12++; }
if ($hour == 12) { $s13 = $s13+$results['swap']; $c13++; }
if ($hour == 13) { $s14 = $s14+$results['swap']; $c14++; }
if ($hour == 14) { $s15 = $s15+$results['swap']; $c15++; }
if ($hour == 15) { $s16 = $s16+$results['swap']; $c16++; }
if ($hour == 16) { $s17 = $s17+$results['swap']; $c17++; }
if ($hour == 17) { $s18 = $s18+$results['swap']; $c18++; }
if ($hour == 18) { $s19 = $s19+$results['swap']; $c19++; }
if ($hour == 19) { $s20 = $s20+$results['swap']; $c20++; }
if ($hour == 20) { $s21 = $s21+$results['swap']; $c21++; }
if ($hour == 21) { $s22 = $s22+$results['swap']; $c22++; }
if ($hour == 22) { $s23 = $s23+$results['swap']; $c23++; }
if ($hour == 23) { $s24 = $s24+$results['swap']; $c24++; }
}

function convts($numb,$total) {
$numb = $numb/$total;
$numb = $numb/1024;
$numb = round($numb,1);
return $numb;
}

if ($s1) { $swap1 = convts($s1,$c1); }
if ($s2) { $swap2 = convts($s2,$c2); }
if ($s3) { $swap3 = convts($s3,$c3); }
if ($s4) { $swap4 = convts($s4,$c4); }
if ($s5) { $swap5 = convts($s5,$c5); }
if ($s6) { $swap6 = convts($s6,$c6); }
if ($s7) { $swap7 = convts($s7,$c7); }
if ($s8) { $swap8 = convts($s8,$c8); }
if ($s9) { $swap9 = convts($s9,$c9); }
if ($s10) { $swap10 = convts($s10,$c10); }
if ($s11) { $swap11 = convts($s11,$c11); }
if ($s12) { $swap12 = convts($s12,$c12); }
if ($s13) { $swap13 = convts($s13,$c13); }
if ($s14) { $swap14 = convts($s14,$c14); }
if ($s15) { $swap15 = convts($s15,$c15); }
if ($s16) { $swap16 = convts($s16,$c16); }
if ($s17) { $swap17 = convts($s17,$c17); }
if ($s18) { $swap18 = convts($s18,$c18); }
if ($s19) { $swap19 = convts($s19,$c19); }
if ($s20) { $swap20 = convts($s20,$c20); }
if ($s21) { $swap21 = convts($s21,$c21); }
if ($s22) { $swap22 = convts($s22,$c22); }
if ($s23) { $swap23 = convts($s23,$c23); }
if ($s24) { $swap24 = convts($s24,$c24); }

$swap = $swap1.",".$swap2.",".$swap3.",".$swap4.",".$swap5.",".$swap6.",".$swap7.",".$swap8.",".$swap9.",".$swap10.",".$swap11.",".$swap12.",".$swap13.",".$swap14.",".$swap15.",".$swap16.",".$swap17.",".$swap18.",".$swap19.",".$swap20.",".$swap21.",".$swap22.",".$swap23.",".$swap24;

$title = "Swap Usage Over 24 Hours - ($day/$month/$year)";
$y = "Hour";
$x = "Swap (MB / 1MB = 1024KB)";
$data = explode(",",$swap);

$graph = new PostGraph(800,400);

$graph->setGraphTitles($title, $y, $x);

$graph->setData($data);
$graph->yValueMode = 3;
$graph->drawImage();
$graph->printImage();

?>
