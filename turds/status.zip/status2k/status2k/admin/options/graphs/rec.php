<?php

include("../../../config.php");
include("graphit.php");

$lgtrue = 0;
$q = mysql_query("SELECT * FROM ".$prefix."users");
while($res = mysql_fetch_array($q)){
$adminuser = $res['adminuser']; // Login Database
$adminpass = $res['adminpass']; // Pass Database
$adminper = $res['adminper']; // Admin Permissions
if ( isset($_COOKIE["S2KUser"]) && isset($_COOKIE["S2KPass"]) ) {
$cusername = $_COOKIE["S2KUser"];
$cpassword = $_COOKIE["S2KPass"];
if ( ($cusername == $adminuser) && ($cpassword == $adminpass) ) { $lgtrue = 1; }
} // End Cookie
} // End While
if (!$lgtrue) { header("Location: ../login.php"); die(); }

if ($_GET['day'] && $_GET['month'] && $_GET['year']) {
$day = $_GET['day'];
$month = $_GET['month'];
$year = $_GET['year'];
} else {
$day = date("j");
$month = date("n");
$year = date("Y");
}

$query = mysql_query("SELECT * FROM ".$prefix."history WHERE day = '$day' AND month = '$month' AND year = '$year'") or die(mysql_error());
while($resultss = mysql_fetch_array($query)){
$hour = $resultss['hour'];
if ($hour == 0) { $r1 = $r1+$resultss['rec']; }
if ($hour == 1) { $r2 = $r2+$resultss['rec']; }
if ($hour == 2) { $r3 = $r3+$resultss['rec']; }
if ($hour == 3) { $r4 = $r4+$resultss['rec']; }
if ($hour == 4) { $r5 = $r5+$resultss['rec']; }
if ($hour == 5) { $r6 = $r6+$resultss['rec']; }
if ($hour == 6) { $r7 = $r7+$resultss['rec']; }
if ($hour == 7) { $r8 = $r8+$resultss['rec']; }
if ($hour == 8) { $r9 = $r9+$resultss['rec']; }
if ($hour == 9) { $r10 = $r10+$resultss['rec']; }
if ($hour == 10) { $r11 = $r11+$resultss['rec']; }
if ($hour == 11) { $r12 = $r12+$resultss['rec']; }
if ($hour == 12) { $r13 = $r13+$resultss['rec']; }
if ($hour == 13) { $r14 = $r14+$resultss['rec']; }
if ($hour == 14) { $r15 = $r15+$resultss['rec']; }
if ($hour == 15) { $r16 = $r16+$resultss['rec']; }
if ($hour == 16) { $r17 = $r17+$resultss['rec']; }
if ($hour == 17) { $r18 = $r18+$resultss['rec']; }
if ($hour == 18) { $r19 = $r19+$resultss['rec']; }
if ($hour == 19) { $r20 = $r20+$resultss['rec']; }
if ($hour == 20) { $r21 = $r21+$resultss['rec']; }
if ($hour == 21) { $r22 = $r22+$resultss['rec']; }
if ($hour == 22) { $r23 = $r24+$resultss['rec']; }
if ($hour == 23) { $r24 = $r24+$resultss['rec']; }
}

function convr($numb) {
$numb = $numb/1024/1024/1024;
$numb = round($numb,2);
return $numb;
}

if ($r1) { $rec1 = convr($r1); }
if ($r2) { $rec2 = convr($r2); }
if ($r3) { $rec3 = convr($r3); }
if ($r4) { $rec4 = convr($r4); }
if ($r5) { $rec5 = convr($r5); }
if ($r6) { $rec6 = convr($r6); }
if ($r7) { $rec7 = convr($r7); }
if ($r8) { $rec8 = convr($r8); }
if ($r9) { $rec9 = convr($r9); }
if ($r10) { $rec10 = convr($r10); }
if ($r11) { $rec11 = convr($r11); }
if ($r12) { $rec12 = convr($r12); }
if ($r13) { $rec13 = convr($r13); }
if ($r14) { $rec14 = convr($r14); }
if ($r15) { $rec15 = convr($r15); }
if ($r16) { $rec16 = convr($r16); }
if ($r17) { $rec17 = convr($r17); }
if ($r18) { $rec18 = convr($r18); }
if ($r19) { $rec19 = convr($r19); }
if ($r20) { $rec20 = convr($r20); }
if ($r21) { $rec21 = convr($r21); }
if ($r22) { $rec22 = convr($r22); }
if ($r23) { $rec23 = convr($r23); }
if ($r24) { $rec24 = convr($r24); }



$rec = $rec1.",".$rec2.",".$rec3.",".$rec4.",".$rec5.",".$rec6.",".$rec7.",".$rec8.",".$rec9.",".$rec10.",".$rec11.",".$rec12.",".$rec13.",".$rec14.",".$rec15.",".$rec16.",".$rec17.",".$rec18.",".$rec19.",".$rec20.",".$rec21.",".$rec22.",".$rec23.",".$rec24;
$title = "Incoming Data Over 24 Hours - ($day/$month/$year)";
$y = "Hour";
$x = "Data (GB/Per Hour)";
$data = explode(",",$rec);

$graph = new PostGraph(800,400);

$graph->setGraphTitles($title, $y, $x);

$graph->setData($data);
$graph->yValueMode = 3;
$graph->drawImage();
$graph->printImage();

?>
