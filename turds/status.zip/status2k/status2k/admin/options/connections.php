<?php
function is_digit($port)
{
    return !preg_match ("/[^0-9]/", $port);
}
$port = $_GET['port'];
if (!$port) { die("No Port Selected"); }
if (is_digit($port) == 0) { die("Port must be a digit"); }
require_once("../includes/header.php");
if ($os['windows']) { die("<font face=\"Verdana\" size=\"2\">Sorry this feature is not currently available in Windows Status2k.</font>"); }
if ($port) {
echo "<pre>";
echo "<B>Proto Recv-Q Send-Q Local Address               Foreign Address             State</B><BR>";
echo cmdrun("netstat -ntu | grep ESTABLISHED | grep :".$port);
echo "</pre>";
}
require_once("../includes/footer.php");
?>
