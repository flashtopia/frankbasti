<?php
require_once("../includes/header.php");
$type = $_GET['type'];
$key = $_SESSION['csrf'];
if (!isset($type)) { $type = $_POST['type']; }

if ($type == "add") {
  $name = $_POST['name'];
  $host = $_POST['host'];
  $services = $_POST['services'];
  $statusurl = $_POST['statusurl'];
  $mstatusurl = $_POST['mstatusurl'];
  $query = "INSERT INTO ".$prefix."multiservers (name, host, services, statusurl, mstatusurl, sortnumb) VALUES ('$name', '$host', '$services', '$statusurl', '$mstatusurl', '0')";
  mysql_query($query) or die('Error! Inserting New Service Failed.');
}

if ($type == "delete") {
  $id = $_GET['id'];
  $query = "DELETE FROM ".$prefix."multiservers WHERE id = '$id'";
  mysql_query($query) or die('Error! Deleting Service Failed.');
}

if ($type == "saveedit") {
  $id = $_POST['id'];
  $name = $_POST['name'];
  $host = $_POST['host'];
  $services = $_POST['services'];
  $statusurl = $_POST['statusurl'];
  $mstatusurl = $_POST['mstatusurl'];
  $query = "UPDATE ".$prefix."multiservers SET name = '$name', host = '$host', services = '$services', statusurl = '$statusurl', mstatusurl = '$mstatusurl' WHERE id = '$id'";
  mysql_query($query) or die('Error! Editing Multiservers Failed.');
}

if ($type == "edit") {
  $id = $_GET['id'];

  $query = mysql_query("SELECT * FROM ".$prefix."multiservers WHERE id = '$id'") or die('Unable To Find MULTISERVERS Table.');
  $results = mysql_fetch_array($query);

  $name = $results['name'];
  $host = $results['host'];
  $services = $results['services'];
  $statusurl = $results['statusurl'];
  $mstatusurl = $results['mstatusurl'];

  echo "

    <form method=\"POST\" action=\"multiservers.php\">
    <input type=\"hidden\" name=\"type\" value=\"saveedit\">
    <input type=\"hidden\" name=\"id\" value=\"$id\">
    <input type=\"hidden\" name=\"csrf\" value=\"$key\">

    <table border=\"1\" cellpadding=\"4\">
    <tr>
    <td class=\"top\">Display Name:</font></td>
    </tr>
    <tr>
    <td height=\"1\"><input type=\"text\" value=\"$name\" name=\"name\" size=\"30\"></td>
    </tr>
    <tr>
    <td class=\"top\">Host Address:</td>
    </tr>
    <tr>
    <td height=\"22\"><input type=\"text\" value=\"$host\" name=\"host\" size=\"30\"></td>
    </tr>
    <tr>
    <td class=\"top\">Services (SERVICE:PORT|SERVICE:PORT) 4 Max:</td>
    </tr>
    <tr>
    <td height=\"22\"><input type=\"text\" value=\"$services\" name=\"services\" size=\"60\"></td>
    </tr>
    <tr>
    <td class=\"top\">URL To Status2k On Remote Server (Example: http://yourdoamin.com/status/) *Optional:</td>
    </tr>
    <tr>
    <td height=\"22\"><input type=\"text\" value=\"$statusurl\" name=\"statusurl\" size=\"55\"></td>
    </tr>
    <tr>
    <td class=\"top\">URL To multiserv.php On Remote Server (Example: http://yourdomain.com/multiservers/multiserv.php):</td>
    </tr>
    <tr>
    <td height=\"22\"><input type=\"text\" value=\"$mstatusurl\" name=\"mstatusurl\" size=\"55\"></td>
    </tr>
    <tr>
    <td align=\"right\"><input type=\"submit\" class=\"btn primary\" value=\"Edit Multi-Server &gt;&gt;\"></td>
    </tr>
    </form>
    </table>
    ";

} else {

  echo "
    <form method=\"POST\" action=\"multiservers.php\">
    <input type=\"hidden\" name=\"csrf\" value=\"$key\">
    <input type=\"hidden\" name=\"type\" value=\"add\">
    <table border=\"1\" cellpadding=\"4\" style=\"border-collapse: collapse\" width=\"100%\" bordercolor=\"#808080\" height=\"293\">
    <tr>
    <td class=\"top\">Display Name:</td>
    </tr>
    <tr>
    <td height=\"1\"><input type=\"text\" name=\"name\" size=\"30\"></td>
    </tr>
    <tr>
    <td class=\"top\">Host Address:</td>
    </tr>
    <tr>
    <td height=\"22\"><input type=\"text\" name=\"host\" size=\"30\"></td>
    </tr>
    <tr>
    <td class=\"top\">Services (SERVICE:PORT|SERVICE:PORT) 4 Max:</td>
    </tr>
    <tr>
    <td height=\"22\"><input type=\"text\" value=\"HTTP:80|FTP:21|MYSQL:3306\" name=\"services\" size=\"60\"></td>
    </tr>
    <tr>
    <td class=\"top\">URL To Status2k On Remote Server (Example: http://yourdoamin.com/status/) *Optional:</td>
    </tr>
    <tr>
    <td height=\"22\"><input type=\"text\" name=\"statusurl\" size=\"55\"></td>
    </tr>
    <tr>
    <td class=\"top\">URL To multiserv.php On Remote Server (Example: http://yourdomain.com/multiservers/multiserv.php):</td>
    </tr>
    <tr>
    <td height=\"22\"><input type=\"text\" name=\"mstatusurl\" size=\"55\"></td>
    </tr>
    <tr>
    <td align=\"right\"><input type=\"submit\" class=\"btn primary\" value=\"Add Multi-Server &gt;&gt;\"></td>
    </tr>
    </form>
    </table><P>
    <font face=\"Verdana\" size=\"2\"><B>Current Multi-Servers:</P></font>
    <table border=\"1\" cellpadding=\"4\" style=\"border-collapse: collapse\" width=\"100%\" bordercolor=\"#808080\">
    <tr>
    <td class=\"top\">Order:</td>
    <td class=\"top\">Server Name:</td>
    <td class=\"top\">Host:</td>
    <td class=\"top\">Services:</td>
    <td class=\"top\">URL:</td>
    <td class=\"top\">Options:</td>
    </tr>
    ";

  $query = mysql_query("SELECT * FROM ".$prefix."multiservers ORDER BY sortnumb") or die('Unable To Find MULTISERVERS Table.');

  while($results = mysql_fetch_array($query)){

    $id = $results['id'];
    $name = $results['name'];
    $host = $results['host'];
    $services = $results['services'];
    $statusurl = $results['statusurl'];
    $numb = $results['sortnumb'];

    echo "
      <form method=\"POST\" action=\"multiorder.php\"><input type=\"hidden\" name=\"csrf\" value=\"$key\">
      <tr>
      <td><font face=\"Verdana\" size=\"2\"><input type=\"text\" name=\"sorder[".$id."]\" value=\"$numb\" size=\"3\"></font></td>
      <td><font face=\"Verdana\" size=\"1\">$name</font></td>
      <td><font face=\"Verdana\" size=\"1\">$host</font></td>
      <td><font face=\"Verdana\" size=\"1\">$services</font></td>
      <td><font face=\"Verdana\" size=\"1\">$statusurl</font></td>
      <td align=\"center\"><font face=\"Verdana\" size=\"1\"><a href=\"multiservers.php?type=delete&id=$id\">Delete</a><BR><a href=\"multiservers.php?type=edit&id=$id\">Edit</a></font></td>
      </tr>
      ";
  }
  echo "</table><BR><input type=\"submit\" class=\"btn primary\" value=\"Re-Order Multiservers >>\"></form>";
}
require_once("../includes/footer.php");
?>
