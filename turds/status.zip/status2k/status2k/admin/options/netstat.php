<?php
require_once("../includes/header.php");
echo "<pre>";
if ($os['windows']) {
echo system("netstat");
} else {
echo cmdrun("netstat -an");
}
echo "</pre>";
require_once("../includes/footer.php");
?>
