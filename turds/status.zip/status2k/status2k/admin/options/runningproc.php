<?php
require_once("../includes/header.php");
if ($os['windows']) { die("<font face=\"Verdana\" size=\"2\">Sorry this feature is not currently available in Windows Status2k.</font>"); }
echo "<pre>";
if ($os['freebsd']) {
$highestrunning = cmdrun("ps -a -H -r -o pcpu,cputime,args");
$pieces = explode("\n", $highestrunning);
} else {
$highestrunning = cmdrun("ps -e -o pcpu,cputime,args --sort pcpu");
$pieces = explode("\n", $highestrunning);
$pieces = array_reverse($pieces);
}
foreach ($pieces as $piece) { echo $piece."\n"; }
echo "</pre>";
require_once("../includes/footer.php");
?>
