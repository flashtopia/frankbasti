<?php
require_once("../includes/header.php");
$type = $_GET['type'];
if (!isset($type)) { $type = $_POST['type']; }

if ($type == "doedit") {
  $send = $_POST['send'];
  $name = $_POST['name'];
  $host = $_POST['host'];
  $port = $_POST['port'];
  $email = $_POST['email'];
  $id = $_POST['id'];
  $query = "UPDATE ".$prefix."ports SET name = '$name', host = '$host', port = '$port', send = '$send', email = '$email' WHERE id = '$id'";
  mysql_query($query) or die('Error! Editing Service Failed. '.mysql_error());
}

if ($type == "edit") {
  $id = $_GET['id'];

  $query = mysql_query("SELECT * FROM ".$prefix."ports WHERE id = '$id'");
  $result = mysql_fetch_array($query);

  $name = $result['name'];
  $host = $result['host'];
  $port = $result['port'];
  $email = $result['email'];
  $send = $result['send'];
  $key = $_SESSION['csrf'];
  echo "
    <table border=\"1\" cellpadding=\"4\">
    <tr>
    <td class=\"top\">Service Name:</td>
    <td class=\"top\">Host:</td>
    <td class=\"top\">Port:</td>
    <td class=\"top\">Alert E-Mail:</td>
    <td class=\"top\">Send:</td>
    <td class=\"top\">Edit:</td>
    </tr>
    <form method=\"POST\" action=\"services.php\">
    <input type=\"hidden\" name=\"type\" value=\"doedit\">
    <input type=\"hidden\" name=\"id\" value=\"$id\">
    <input type=\"hidden\" name=\"csrf\" value=\"$key\">
    <tr>
    <td><input type=\"text\" name=\"name\" size=\"20\" value=\"$name\"></td>
    <td><input type=\"text\" name=\"host\" size=\"20\" value=\"$host\"></td>
    <td><input type=\"text\" name=\"port\" size=\"20\" value=\"$port\"></td>
    <td><input type=\"text\" name=\"email\" size=\"20\" value=\"$email\"></td>
    <td><input type=\"text\" name=\"send\" size=\"20\" value=\"$send\"></td>
    <td><input type=\"submit\" class=\"btn primary\" value=\"Edit &gt;&gt;\"></td>
    </tr>
    </form>
    </table>
    ";

} else {

  if ($type == "add") {
    $name = $_POST['name'];
    $host = $_POST['host'];
    $port = $_POST['port'];
    $email = $_POST['email'];



    $query = "INSERT INTO ".$prefix."ports VALUES (NULL, '$name', '$host', '$port', '$email', '1', '0', '0', '0', '')";
    mysql_query($query) or die('Error! Inserting New Service Failed. '.mysql_error());
  }

  if ($type == "delete") {
    $id = $_GET['id'];
    $query = "DELETE FROM ".$prefix."ports WHERE id = '$id'";
    mysql_query($query) or die('Error! Deleting Service Failed.');
  }


  $key = $_SESSION['csrf'];
  echo "
    <table border=\"1\" cellpadding=\"4\">
    <tr>
    <td width=\"25%\" class=\"top\">Service Name:</td>
    <td width=\"25%\" class=\"top\">Host:</td>
    <td width=\"25%\" class=\"top\">Port:</td>
    <td width=\"25%\" class=\"top\">Alert E-Mail:</td>
    <td width=\"25%\" class=\"top\">Add:</td>
    </tr>
    <form method=\"POST\" action=\"services.php\">
    <input type=\"hidden\" name=\"type\" value=\"add\">
    <input type=\"hidden\" name=\"csrf\" value=\"$key\">

    <tr>
    <td width=\"25%\"><input type=\"text\" name=\"name\" size=\"20\"></td>
    <td width=\"25%\"><input type=\"text\" name=\"host\" size=\"20\"></td>
    <td width=\"25%\"><input type=\"text\" name=\"port\" size=\"20\"></td>
    <td width=\"25%\"><input type=\"text\" name=\"email\" size=\"20\"></td>
    <td width=\"25%\"><input type=\"submit\" class=\"btn primary\" value=\"Add &gt;&gt;\"></td>
    </tr>
    </form>
    </table><BR>

    <form method=\"POST\" action=\"serviceorder.php\">
    <input type=\"hidden\" name=\"csrf\" value=\"$key\">
    <table border=\"1\" cellpadding=\"4\">
    <tr>
    <td class=\"top\">Order:</td>
    <td class=\"top\">Service Name:</td>
    <td class=\"top\">Host:</td>
    <td class=\"top\">Port:</td>
    <td class=\"top\">Alert E-Mail:</td>
    <td class=\"top\">Options:</td>
    </tr>
    ";

  $query = mysql_query("SELECT * FROM ".$prefix."ports ORDER BY sortnumb") or die('Unable To Find PORTS Table.');

  while($results = mysql_fetch_array($query)){

    $id = $results['id'];
    $name = $results['name'];
    $host = $results['host'];
    $port = $results['port'];
    $email = $results['email'];
    $numb = $results['sortnumb'];

    if (!$email) { $email = "Default"; }
    echo "
      <tr>
      <td><font face=\"Verdana\" size=\"2\"><input type=\"text\" name=\"sorder[".$id."]\" value=\"$numb\" size=\"3\"></font></td>
      <td><font face=\"Verdana\" size=\"2\">$name</font></td>
      <td><font face=\"Verdana\" size=\"2\">$host</font></td>
      <td><font face=\"Verdana\" size=\"2\">$port</font></td>
      <td><font face=\"Verdana\" size=\"2\">$email</font></td>
      <td><font face=\"Verdana\" size=\"2\"><a href=\"services.php?type=delete&id=$id\">Delete</a> / <a href=\"services.php?type=edit&id=$id\">Edit</a></font></td>
      </tr>

      ";
  }
  echo "</table><BR><input type=\"submit\" class=\"btn primary\" value=\"Re-Order Services >>\"></form>";

}

require_once("../includes/footer.php");
?>
