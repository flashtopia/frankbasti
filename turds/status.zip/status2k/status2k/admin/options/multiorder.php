<?php
require_once("../../config.php");
require_once("../../includes/functions.php");

$lgtrue = 0;
$q = mysql_query("SELECT * FROM ".$prefix."users");
while($res = mysql_fetch_array($q)){
$adminuser = $res['adminuser']; // Login Database
$adminpass = $res['adminpass']; // Pass Database
$adminper = $res['adminper']; // Admin Permissions
if ( isset($_COOKIE["S2KUser"]) && isset($_COOKIE["S2KPass"]) ) {
$cusername = $_COOKIE["S2KUser"];
$cpassword = $_COOKIE["S2KPass"];
if ( ($cusername == $adminuser) && ($cpassword == $adminpass) ) { $lgtrue = 1; }
} // End Cookie
} // End While
if (!$lgtrue) { header("Location: ../login.php"); die(); }

$query = mysql_query("SELECT * FROM ".$prefix."multiservers");
while ($result = mysql_fetch_array($query)) {
$id = $result['id'];
$sor = $_POST['sorder'];
$or = $sor[$id];
mysql_query("UPDATE ".$prefix."multiservers SET sortnumb = '".$or."' WHERE id = '$id'") or die(mysql_error());
}

header("Location: multiservers.php");
?>
