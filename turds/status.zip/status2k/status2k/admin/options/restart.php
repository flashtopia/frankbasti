<?php
require_once("../../config.php");
require_once("../../includes/functions.php");

if ($os['windows']) { die("<font face=\"Verdana\" size=\"2\">Sorry this feature is not currently available in Windows Status2k.</font>"); }

echo "<SCRIPT LANGUAGE=\"JavaScript\">
redirURL = \"main.php\";
self.setTimeout(\"self.location.href = redirURL;\",5000);
</script><center>";

$data['ip'] = $_SERVER["SERVER_ADDR"];
if (!$data['ip']) { $data['ip'] = $_SERVER["LOCAL_ADDR"]; }
if (!$data['ip']) { $data['ip'] = gethostbyname($data['host']); }

$serv = $_GET['serv'];

if ($config['cpuser']) { $cpuser = $config['cpuser']; } else { echo "<font face=\"Verdana\" color=\"#FF0000\" size=\"2\">No Username In Config!</font><BR><BR>"; }
if ($config['cppass']) { $cppass = $config['cppass']; } else { echo "<font face=\"Verdana\" color=\"#FF0000\" size=\"2\">No Password In Config!</font><BR><BR>"; }

$rurl = "index.php";

if (fsockopen("localhost", 2086, $errno, $errstr, 2)) {
fopen("http://$cpuser:$cppass@".$data['ip'].":2086/scripts/res$serv?confirm=1", "r");
$cpname = "CPanel";
} else if (fsockopen("localhost", 2222, $errno, $errstr, 2)) {
if ($serv == "mysql") { $serv = "mysqld"; }
if ($serv == "cppop") { $serv = "vm-pop3d"; }
fopen("http://$cpuser:$cppass@".$data['ip'].":2222/CMD_SERVICE?action=restart&service=$serv", "r");
$cpname = "DirectAdmin";
}



echo "<b><font face=\"Verdana\" color=\"#FF0000\" size=\"2\">$cpname Service (<B>$serv</B>) Restarted!</font></b><BR>";
echo "<b><font face=\"Verdana\" size=\"2\">You will be redirected in 5 seconds.</font></b><BR>";
echo "<img src=\"../../images/loading.gif\"><BR>";
echo "</center>";

?>
