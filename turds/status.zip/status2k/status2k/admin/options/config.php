<?php 

require("../includes/header.php");

if (isset($_GET['sent'])) { echo "<b><font face=\"Verdana\" color=\"red\" size=\"2\">Config Saved Successfully!</font><BR><BR>"; }

echo '
<form method="POST" action="saveconfig.php">
<table border="1" cellpadding="4" cellspacing="0" width="90%">
<tr>
<td class="top">Option Name:</td>
<td class="top">Value:</td>
<td class="top">Description:</td>
</tr>
';
if (substr(PHP_OS,0,3)=='WIN') {
  $query = mysql_query("SELECT * FROM ".$prefix."config WHERE os = 'win' OR os = 'all' ORDER BY id");
} else {
  $query = mysql_query("SELECT * FROM ".$prefix."config WHERE os = 'linux' OR os = 'all' ORDER BY id");
}
while($results = mysql_fetch_array($query)){
  $id = $results['id'];
  $name = $results['name'];
  $value = $results['value'];
  $dname = $results['dname'];
  $description = $results['description'];
  $type = $results['type'];
  $options = $results['options'];
  $size = $results['size'];

  echo "
    <tr>
    <td align=\"left\">$dname:</td>
    <td align=\"left\">
    ";

  if ($type == "text") {
    echo "<input type=\"text\" value=\"$value\" name=\"$name\" size=\"$size\">";
  }

  if ($type == "password") {
    echo "<input type=\"password\" value=\"$value\" name=\"$name\" size=\"$size\">";
  }

  if ($type == "option") {
    echo "<select name=\"$name\">";

    $querysql = mysql_query("SELECT * FROM ".$prefix."options WHERE opid = '$options' AND value = '$value' LIMIT 1");
    $result = mysql_fetch_array($querysql);
    $thevalue = $result['value'];
    $thename = $result['name'];
    echo "<option selected value=\"$thevalue\">$thename</option><option>----------</option>";

    $querysql = mysql_query("SELECT * FROM ".$prefix."options WHERE opid = '$options'");
    while($result = mysql_fetch_array($querysql)){
      $theovalue = $result['value'];
      $theoname = $result['name'];
      echo "<option value=\"$theovalue\">$theoname</option>";
    }

    echo "</select>";
  } // If Option

  echo"
    </td>
    <td align=\"left\">$description</td>
    </tr>
    ";



} // While
$key = $_SESSION['csrf'];
echo "<tr><td align=\"right\" colspan=\"3\"><input type=\"hidden\" name=\"csrf\" value=\"$key\"><input type=\"submit\" class=\"btn primary\" value=\"Save Config >>\"></form></td></tr></table>";
require("../includes/footer.php");

?>
