<?php
require_once("../includes/header.php");
if ($os['windows']) { die("<font face=\"Verdana\" size=\"2\">Sorry this feature is not currently available in Windows Status2k.</font>"); }

$min = date("i");
$hour = date("G");
$day = date("j");
$month = date("n");
$year = date("Y");
$key = $_SESSION['csrf'];
echo "
<center>
<form method=\"POST\" action=\"graph1.php\">
  <p>
  <font face=\"Verdana\" size=\"4\">Day: <select size=\"1\" name=\"day\">
  <option selected value=\"$day\">$day</option>
  <option value=\"$day\">------</option>
  <option value=\"1\">1</option>
  <option value=\"2\">2</option>
  <option value=\"3\">3</option>
  <option value=\"4\">4</option>
  <option value=\"5\">5</option>
  <option value=\"6\">6</option>
  <option value=\"7\">7</option>
  <option value=\"8\">8</option>
  <option value=\"9\">9</option>
  <option value=\"10\">10</option>
  <option value=\"11\">11</option>
  <option value=\"12\">12</option>
  <option value=\"13\">13</option>
  <option value=\"14\">14</option>
  <option value=\"15\">15</option>
  <option value=\"16\">16</option>
  <option value=\"17\">17</option>
  <option value=\"18\">18</option>
  <option value=\"19\">19</option>
  <option value=\"20\">20</option>
  <option value=\"21\">21</option>
  <option value=\"22\">22</option>
  <option value=\"23\">23</option>
  <option value=\"24\">24</option>
  <option value=\"25\">25</option>
  <option value=\"26\">26</option>
  <option value=\"27\">27</option>
  <option value=\"28\">28</option>
  <option value=\"29\">29</option>
  <option value=\"30\">30</option>
  <option value=\"31\">31</option>
  </select> Month: <select size=\"1\" name=\"month\">
  <option selected value=\"$month\">$month</option>
  <option value=\"$month\">------</option>
  <option value=\"1\">1</option>
  <option value=\"2\">2</option>
  <option value=\"3\">3</option>
  <option value=\"4\">4</option>
  <option value=\"5\">5</option>
  <option value=\"6\">6</option>
  <option value=\"7\">7</option>
  <option value=\"8\">8</option>
  <option value=\"9\">9</option>
  <option value=\"10\">10</option>
  <option value=\"11\">11</option>
  <option value=\"12\">12</option>
  </select></font><font face=\"Verdana\" size=\"4\"> Year:
  <select size=\"1\" name=\"year\">
  <option selected value=\"$year\">$year</option>
  <option value=\"$year\">------</option>
  <option value=\"2007\">2007</option>
  <option value=\"2008\">2008</option>
  </select> </font><input type=\"hidden\" name=\"csrf\" value=\"$key\" ><input type=\"submit\" value=\"Submit &gt;&gt;\"></p>
</form><BR>
";

echo "<center><BR>";
if ($_POST['day'] && $_POST['month'] && $_POST['year']) {
echo "<img src=\"graphs/load.php?day=".$_POST['day']."&month=".$_POST['month']."&year=".$_POST['year']."\"><BR><BR>";
echo "<img src=\"graphs/memory.php?day=".$_POST['day']."&month=".$_POST['month']."&year=".$_POST['year']."\"><BR><BR>";
echo "<img src=\"graphs/swap.php?day=".$_POST['day']."&month=".$_POST['month']."&year=".$_POST['year']."\">";
} else {
echo "<img src=\"graphs/load.php\"><BR><BR>";
echo "<img src=\"graphs/memory.php\"><BR><BR>";
echo "<img src=\"graphs/swap.php\">";
}
echo "</center><BR>";

require_once("../includes/footer.php");
?>
