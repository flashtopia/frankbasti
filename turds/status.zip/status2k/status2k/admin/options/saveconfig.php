<?php
session_start();
require_once("../../config.php");
require_once("../../includes/functions.php");

$lgtrue = 0;
$q = mysql_query("SELECT * FROM ".$prefix."users");
while($res = mysql_fetch_array($q)){
$adminuser = $res['adminuser']; // Login Database
$adminpass = $res['adminpass']; // Pass Database
$adminper = $res['adminper']; // Admin Permissions
if ( isset($_COOKIE["S2KUser"]) && isset($_COOKIE["S2KPass"]) ) {
$cusername = $_COOKIE["S2KUser"];
$cpassword = $_COOKIE["S2KPass"];
if ( ($cusername == $adminuser) && ($cpassword == $adminpass) ) { $lgtrue = 1; }
} // End Cookie
} // End While
if (!$lgtrue) { header("Location: ../login.php"); die(); }

if(!isset($_SESSION['csrf']) || $_SESSION['csrf'] !== $_POST['csrf'])
  throw new RuntimeException('CSRF Attack' . $_POST['csrf'] . '::' . $_SESSION['csrf']);

if (substr(PHP_OS,0,3)=='WIN') {
$query = mysql_query("SELECT * FROM ".$prefix."config WHERE os = 'win' OR os = 'all'");
} else {
$query = mysql_query("SELECT * FROM ".$prefix."config WHERE os = 'linux' OR os = 'all'");
}
while($results = mysql_fetch_array($query)){
$id = $results['id'];
$name = $results['name'];
$confvalue = $_POST[$name];
$qu = "UPDATE ".$prefix."config SET value = '$confvalue' WHERE id = '$id'";
mysql_query($qu) or die('Error! Updating Failed.');
}

header("Location: config.php?sent=true");

?>
