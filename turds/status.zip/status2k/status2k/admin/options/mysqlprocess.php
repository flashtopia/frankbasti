<?php
require_once("../includes/header.php");
$result = mysql_query("SHOW PROCESSLIST");
echo "
<TABLE CELLPADDING=\"4\" CELLSPACING=\"0\" border=\"1\">
<TR class=\"top\">
<TD>ID</TD>
<TD>User @ Host</TD>
<TD>Database</TD>
<TD>Command</TD>
<TD>State</TD>
<TD>Info</TD>
<TD>Time</TD>
</TR>\n";
while ($row = mysql_fetch_array($result)) {
$process_id=$row["Id"];
$User=$row["User"];
$Host=$row["Host"];
$db=$row["db"];
$Command=$row["Command"];
$State=$row["State"];
$Info=$row["Info"];
$time=$row["Time"];
echo "
<TR>
<TD>$process_id</TD>
<TD>$User@$Host</TD>
<TD>$db</TD>
<TD>$Command</TD>
<TD>$State</TD>
<TD>$Info</TD>
<TD>$time</TD>
</TR>";
}
echo "</TABLE>\n";
require_once("../includes/footer.php");
?>
