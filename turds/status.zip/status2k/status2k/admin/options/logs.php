<?php

$l = $_GET['log'];

if (isset($_GET['d'])) {
  require_once("../../config.php");

  $lgtrue = 0;
  $q = mysql_query("SELECT * FROM ".$prefix."users");
  while($res = mysql_fetch_array($q)){
    $adminuser = $res['adminuser']; // Login Database
    $adminpass = $res['adminpass']; // Pass Database
    $adminper = $res['adminper']; // Admin Permissions
    if ( isset($_COOKIE["S2KUser"]) && isset($_COOKIE["S2KPass"]) ) {
      $cusername = $_COOKIE["S2KUser"];
      $cpassword = $_COOKIE["S2KPass"];
      if ( ($cusername == $adminuser) && ($cpassword == $adminpass) ) { $lgtrue = 1; }
    } // End Cookie
  } // End While
  if (!$lgtrue) { header("Location: ../login.php"); die(); }

  $query = mysql_query("SELECT * FROM ".$prefix."logs WHERE id = '".$l."'");
  $result = mysql_fetch_array($query) or die(mysql_error());
  $text = file_get_contents($result['location']);
  $name = $result['name'].".txt";
  $name = str_replace(" ", "_", $name);
  header('Content-disposition: attachment; filename="'.$name.'"');
  header('Content-Type: application/force-download');
  header('Content-Transfer-Encoding: binary');
  header('Content-Length: '.strlen( $text ));
  header('Pragma: no-cache');
  header('Expires: 0');

  echo $text;

} else {

  require_once("../includes/header.php");

  if ($os['windows']) {
    echo "<pre>";
    $query = mysql_query("SELECT * FROM ".$prefix."logs WHERE id = '".$l."'");
    $result = mysql_fetch_array($query) or die(mysql_error());
    $log = @file_get_contents($result['location']);
    echo "<b>Log File (".$result['location'].") - <a href=\"logs.php?d=1&log=".$l."\">Download Log</a></b><BR>";
    if ($log) { echo $log; } else { echo "Unable to open (".$result['location'].") check file permissions."; }
    echo "</pre>";
  } else {
    echo "<pre>";
    $query = mysql_query("SELECT * FROM ".$prefix."logs WHERE id = '".$l."'");
    $result = mysql_fetch_array($query) or die(mysql_error());
    $logc = cmdrun($config['logcmd'].$result['location']);
    $log = explode("\n", $logc);
    $log = array_reverse($log);
    if ($logc) {
      echo "<b>Log File (".$result['location'].") - <a href=\"logs.php?d=1&log=".$l."\">Download Log</a></b><BR>";
      foreach ($log as $line) { echo $line."\n"; }
    } else {
      echo "Log (".$config['logcmd'].$result['location'].") fetch failed, please CHMOD log file to 644."; }
    echo "</pre>";
  }
  require_once("../includes/footer.php");

}

?>
