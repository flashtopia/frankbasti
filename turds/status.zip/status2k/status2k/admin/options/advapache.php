<?php
require_once("../includes/header.php");
if ($os['windows']) { die("<font face=\"Verdana\" size=\"2\">Sorry this feature is not currently available in Windows Status2k.</font>"); }

echo '
<table border="1" cellpadding="4" cellspacing="0">
  <tr>
    <td class="top">Process ID:</td>
    <td class="top">Host:</td>
    <td class="top">Request:</td>
    <td class="top">CPU%:</td>
    <td class="top">MEM%:</td>
  </tr>
';

$proc = array();
$status = file_get_contents($config['astatusurl']."?notable"); // Fetch Apache status, using no table.
$status = ereg_replace("\n", '', $status);
$status = trim($status);
$status = ereg_replace('<br>', "\n", $status); // Support for Apache 1
$status = ereg_replace('<br />', "\n", $status); // Fix for Apache 2
$status = strip_tags($status);
$proc = explode("\n", $status);

foreach ($proc as $stat) {
if ($stat) {
// Remove un-needed data, replace with str_replace and array of removals.
$stat = ereg_replace ("\[Keepalive\]", "", $stat);
$stat = ereg_replace ("\[Write\]", "", $stat);
$stat = ereg_replace ("\[Ready\]", "", $stat);
$stat = ereg_replace ("\[Read\]", "", $stat);
$stat = ereg_replace ("\[Dead\]", "", $stat);
$stat = ereg_replace ("GET ", "", $stat);
preg_match('/\(([0-9]+)\):/', $stat, $result);
preg_match('/\[(.*?)\]/', $stat, $res);
preg_match('/\{(.*?)\}/', $stat, $reslt);
$host[$result[1]] = $res[1];
$req[$result[1]] = $reslt[1];
}
}

$prc = cmdrun("ps -e -o pid,pcpu,pmem --sort pcpu | tail -100");
$prcs = explode("\n", $prc); // Put PS Into Array.
$prcs = array_reverse($prcs);
foreach ($prcs as $pr) { // For each PS line.
$pr = trim($pr);
if ($pr) {
$pre = explode(' ', $pr); // Explode By space PID CPU

if ($host[$pre[0]]) {
echo "
  <tr>
    <td><font face=\"Verdana\" size=\"2\">".$pre[0]."</font></td>
    <td><font face=\"Verdana\" size=\"2\">".$host[$pre[0]]."</font></td>
    <td><font face=\"Verdana\" size=\"2\"><font face=\"Verdana\" size=\"2\">".$req[$pre[0]]."</font></td>
    <td><font face=\"Verdana\" size=\"2\">".$pre[2]."</font></td>
    <td><font face=\"Verdana\" size=\"2\">".$pre[4]."</font></td>
  </tr>
";
}

}
}

echo '</table>';
require_once("../includes/footer.php");

?>
