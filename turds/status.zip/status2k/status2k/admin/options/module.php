<?php
require_once("../includes/header.php");
$id = $_GET['id'];
$query = mysql_query("SELECT * FROM ".$prefix."modules WHERE id = '".$id."'");
$result = mysql_fetch_array($query) or die(mysql_error());
$file = $result['location'];
if (file_exists("../modules/".$file)) {
    include("../modules/".$file);
} else {
    echo "The file <B>".$file."</B> does not exist in the /admin/modules/ directory.";
}

require_once("../includes/footer.php");
?>
