<?php
require_once("../includes/header.php");
$type = $_GET['type'];
if (!isset($type)) { $type = $_POST['type']; }

if ($type == "doedit") {
  $name = $_POST['name'];
  $location = $_POST['location'];
  $id = $_POST['id'];
  $query = "UPDATE ".$prefix."logs SET location = '$location', name = '$name' WHERE id = '$id'";
  mysql_query($query) or die('Error! Inserting New Log Failed.');
}

if ($type == "edit") {
  $id = $_GET['id'];

  $query = mysql_query("SELECT * FROM ".$prefix."logs WHERE id = '$id'");
  $result = mysql_fetch_array($query);

  $name = $result['name'];
  $location = $result['location'];
  $key = $_SESSION['csrf'];
  echo "
    <table border=\"1\" cellpadding=\"4\">
    <tr>
    <td width=\"25%\" class=\"top\">Name:</td>
    <td width=\"25%\" class=\"top\">Location:</td>
    <td width=\"25%\" class=\"top\">Edit:</td>
    </tr>
    <form method=\"POST\" action=\"addlog.php\">
    <input type=\"hidden\" name=\"type\" value=\"doedit\">
    <input type=\"hidden\" name=\"id\" value=\"$id\">
    <input type=\"hidden\" name=\"csrf\" value=\"$key\">

    <tr>
    <td width=\"25%\"><input type=\"text\" name=\"name\" size=\"20\" value=\"$name\"></td>
    <td width=\"25%\"><input type=\"text\" name=\"location\" size=\"40\" value=\"$location\"></td>
    <td width=\"25%\"><input type=\"submit\" class=\"btn primary\" value=\"Edit &gt;&gt;\"></td>
    </tr>
    </form>
    </table>
    ";

} else {

  if ($type == "add") {
    $name = $_POST['name'];
    $location = $_POST['location'];
    $query = "INSERT INTO ".$prefix."logs (id, name, location) VALUES ('', '$name', '$location')";
    mysql_query($query) or die('Error! Inserting New Log Failed.');

    echo "
      <script type=\"text/javascript\">
      <!--
      window.location = \"addlog.php\"
      //-->
      </script>
      ";

  }

  if ($type == "delete") {
    $id = $_GET['id'];
    $query = "DELETE FROM ".$prefix."logs WHERE id = '$id'";
    mysql_query($query) or die('Error! Deleting Log Failed.');

    echo "
      <script type=\"text/javascript\">
      <!--
      window.location = \"addlog.php\"
      //-->
      </script>
      ";

  }


  $key = $_SESSION['csrf'];
  echo "
    <table border=\"1\" cellpadding=\"4\">
    <tr>
    <td width=\"25%\" class=\"top\">Name:</td>
    <td width=\"25%\" class=\"top\">Location:</td>
    <td width=\"25%\" class=\"top\">Add:</td>
    </tr>
    <form method=\"POST\" action=\"addlog.php\">
    <input type=\"hidden\" name=\"type\" value=\"add\">
    <tr>
    <td width=\"25%\"><input type=\"text\" name=\"name\" size=\"20\"></td>
    <td width=\"25%\"><input type=\"text\" name=\"location\" size=\"40\">
    <input type=\"hidden\" name=\"csrf\" value=\"$key\"></td>
    <td width=\"25%\"><input type=\"submit\" class=\"btn primary\" value=\"Add &gt;&gt;\"></td>
    </tr>
    </form>
    </table><BR>

    <table border=\"1\" cellpadding=\"4\">
    <tr>
    <td class=\"top\">Name:</td>
    <td class=\"top\">Location:</td>
    <td class=\"top\">Options:</td>
    </tr>
    ";

  $query = mysql_query("SELECT * FROM ".$prefix."logs") or die('Unable To Find LOGS Table.');

  while($results = mysql_fetch_array($query)){

    $id = $results['id'];
    $name = $results['name'];
    $location = $results['location'];

    echo "
      <tr>
      <td><font face=\"Verdana\" size=\"2\">$name</font></td>
      <td><font face=\"Verdana\" size=\"2\">$location</font></td>
      <td><font face=\"Verdana\" size=\"2\"><a href=\"addlog.php?type=delete&id=$id\">Delete</a> / <a href=\"addlog.php?type=edit&id=$id\">Edit</a></font></td>
      </tr>

      ";
  }
  echo "</table>";

}

require_once("../includes/footer.php");
?>
