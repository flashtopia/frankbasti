<?php
require_once("../includes/header.php");
echo "<pre>";
echo file_get_contents($config['astatusurl']);
echo "</pre>";
require_once("../includes/footer.php");
?>
