<?php
require_once("../includes/header.php");
$type = $_GET['type'];
if (!$type) { $type = $_POST['type']; }

if ($type == "add") {
  $adminuser = $_POST['adminuser'];
  $adminpass = $_POST['adminpass'];
  $adminpass = sha1($adminpass);
  $query = "INSERT INTO ".$prefix."users (adminuser, adminpass) VALUES ('$adminuser', '$adminpass')";
  mysql_query($query) or die('Error! Inserting New User Failed.');
}

if ($type == "delete") {
  $id = $_GET['id'];
  if ($id !== 1) {
    $query = "DELETE FROM ".$prefix."users WHERE id = '$id'";
    mysql_query($query) or die('Error! Deleting User Failed.');
  }
}

if ($type == "saveedit") {
  $id = $_POST['id'];
  $adminuser = $_POST['adminuser'];
  $adminpass = $_POST['adminpass'];
  if ($adminpass) {
    $adminpass = sha1($adminpass);
    $query = "UPDATE ".$prefix."users SET adminuser = '$adminuser', adminpass = '$adminpass' WHERE id = '$id'";
    mysql_query($query) or die('Error! Editing User Failed.');
  } else {
    $query = "UPDATE ".$prefix."users SET adminuser = '$adminuser' WHERE id = '$id'";
    mysql_query($query) or die('Error! Editing User Failed.');
  }
}

if ($type == "edit") {
  $id = $_GET['id'];

  $query = mysql_query("SELECT * FROM ".$prefix."users WHERE id = '$id'") or die('Unable To Find users Table.');
  $results = mysql_fetch_array($query);

  $adminuser = $results['adminuser'];
  $key = $_SESSION['csrf'];
  echo "

    <form method=\"POST\" action=\"users.php\">
    <input type=\"hidden\" name=\"type\" value=\"saveedit\">
    <input type=\"hidden\" name=\"id\" value=\"$id\">
    <input type=\"hidden\" name=\"csrf\" value=\"$key\">
    <table border=\"1\" cellpadding=\"4\">
    <tr>
    <td class=\"top\">Username:</font></td>
    </tr>
    <tr>
    <td height=\"1\"><input type=\"text\" value=\"$adminuser\" name=\"adminuser\" size=\"30\"></td>
    </tr>
    <tr>
    <td class=\"top\">Password:</td>
    </tr>
    <tr>
    <td height=\"22\"><input type=\"text\" name=\"adminpass\" size=\"30\"></td>
    </tr>
    <tr>
    <td height=\"22\" align=\"right\"><input type=\"submit\" class=\"btn primary\" value=\"Edit User &gt;&gt;\"></td>
    </tr>

    </form>
    </table>
    ";

} else {

  $key = $_SESSION['csrf'];
  echo "
    <form method=\"POST\" action=\"users.php\">
    <input type=\"hidden\" name=\"type\" value=\"add\">
    <input type=\"hidden\" name=\"csrf\" value=\"$key\">
    <table border=\"1\" cellpadding=\"4\" style=\"border-collapse: collapse\" width=\"100%\" bordercolor=\"#808080\">
    <tr>
    <td class=\"top\">Username:</td>
    </tr>
    <tr>
    <td height=\"1\"><input type=\"text\" name=\"adminuser\" size=\"30\"></td>
    </tr>
    <tr>
    <td class=\"top\">Password:</td>
    </tr>
    <tr>
    <td height=\"22\"><input type=\"password\" name=\"adminpass\" size=\"30\"></td>
    </tr>
    <tr>
    <td align=\"right\"><input type=\"submit\" class=\"btn primary\" value=\"Add User &gt;&gt;\"></td>
    </tr>
    </form>
    </table>

    <P>
    <font face=\"Verdana\" size=\"2\"><B>Admin-Users:</P></font>
    <table border=\"1\" cellpadding=\"4\" style=\"border-collapse: collapse\" width=\"100%\" bordercolor=\"#808080\">
    <tr>
    <td class=\"top\">ID#:</td>
    <td class=\"top\">User:</td>
    <td class=\"top\">Edit/Del</td>
    </tr>
    ";

  $query = mysql_query("SELECT * FROM ".$prefix."users") or die('Unable To Find users Table.');

  while($results = mysql_fetch_array($query)){

    $id = $results['id'];
    $adminuser = $results['adminuser'];
    $adminpass = $results['adminpass'];

    if ($id == 1) {
      $adminuser = $adminuser."*";
      echo "
        <tr>
        <td><font face=\"Verdana\" size=\"1\">$id</font></td>
        <td><font face=\"Verdana\" size=\"1\">$adminuser</font></td>
        <td align=\"center\"><font face=\"Verdana\" size=\"1\">(* Cannot Be Deleted) / <a href=\"users.php?type=edit&id=$id\">Edit User</a></font></td>
        </tr>
        ";
    } else {
      echo "
        <tr>
        <td><font face=\"Verdana\" size=\"1\">$id</font></td>
        <td><font face=\"Verdana\" size=\"1\">$adminuser</font></td>
        <td align=\"center\"><font face=\"Verdana\" size=\"1\"><a href=\"users.php?type=delete&id=$id\">Delete User</a> / <a href=\"users.php?type=edit&id=$id\">Edit User</a></font></td>
        </tr>
        ";
    }

  }
  echo "</table>";
}
require_once("../includes/footer.php");
?>
