<?php require_once("../includes/header.php"); ?>
<div id="live" align="center">
<BR>
<B>Loading, Please Wait ...</B>
</div>
<?php require_once("../includes/footer.php"); ?>
