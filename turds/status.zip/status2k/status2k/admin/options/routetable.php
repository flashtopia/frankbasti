<?php
require_once("../includes/header.php");
if ($os['windows']) { die("<font face=\"Verdana\" size=\"2\">Sorry this feature is not currently available in Windows Status2k.</font>"); }
echo "<pre>";
echo cmdrun("netstat -rn");
echo "</pre>";
require_once("../includes/footer.php");
?>
