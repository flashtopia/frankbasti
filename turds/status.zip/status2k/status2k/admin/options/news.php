<?php
require_once("../includes/header.php");
$save = $_POST['save'];
$del = $_GET['del'];
$news = $_POST['news'];
$edit = $_GET['edit'];
$saveedit = $_POST['saveedit'];
$key = $_SESSION['csrf'];
if ($del) {
  $query = "DELETE FROM ".$prefix."news WHERE id = '$del'";
  mysql_query($query);
}

if ($save) {
  $query = "INSERT INTO ".$prefix."news (news, date) VALUES ('$news', '".date($config['timesd'])."')";
  mysql_query($query) or die('Error! Updating News Failed.');
}

if ($saveedit) {
  $query = "UPDATE ".$prefix."news SET news = '".$news."' WHERE id = '".$saveedit."'";
  mysql_query($query) or die('Error! Updating News Failed.');
}

if ($edit) {

  $query = mysql_query("SELECT * FROM ".$prefix."news WHERE id = '".$edit."'") or die ('News data unavailable, check install.');
  $result = mysql_fetch_array($query);
  $news = $result['news'];

  echo "<p align=\"center\"><font face=\"Verdana\" size=\"2\"><BR>Add the news here you want displayed on the main page of the status script.</font></p>
    <center>
    <form method=\"POST\" action=\"news.php\">
    <textarea id=\"elm1\" name=\"news\" style=\"width: 200px; height: 200px;\">".$news."</textarea>
    <input type=\"hidden\" name=\"saveedit\" value=\"".$edit."\">
    <input type=\"hidden\" name=\"csrf\" value=\"".$key."\">
    </center>
    <p align=\"center\"><input type=\"submit\" class=\"btn primary\" value=\"Edit News &gt;&gt;\"></p>
    </form><center>";

} else {

  echo "<p align=\"center\"><font face=\"Verdana\" size=\"2\"><BR>Add the news here you want displayed on the main page of the status script.</font></p>
    <center>
    <form method=\"POST\" action=\"news.php\">
    <textarea id=\"elm1\" name=\"news\" style=\"width:450px; height:250px\"></textarea>
    <input type=\"hidden\" name=\"save\" value=\"true\">
    <input type=\"hidden\" name=\"csrf\" value=\"".$key."\">
    </center>
    <p><input type=\"submit\" class=\"btn primary\" value=\"Add News &gt;&gt;\"></p>
    </form><center>";

  $query = mysql_query("SELECT * FROM ".$prefix."news") or die ('News data unavailable, check install.');
  while($results = mysql_fetch_array($query)){
    $id = $results['id'];
    $news = $results['news'];
    $date = $results['date'];

    echo "
      <BR>
      <table border=\"1\" cellpadding=\"4\" style=\"border-collapse: collapse\" width=\"100%\" bordercolor=\"#808080\">
      <tr>
      <td class=\"top\">News:</td>
      <td class=\"top\">Date:</td>
      <td class=\"top\">Options:</td>
      </tr>
      <tr>
      <td><font face=\"Verdana\" size=\"2\">$news</font></td>
      <td><font face=\"Verdana\" size=\"2\">$date</font></td>
      <td><font face=\"Verdana\" size=\"2\"><a href=\"news.php?del=$id\">Delete</a> - <a href=\"news.php?edit=$id\">Edit</a></font></td>
      </tr>
      </table>";


  } // End While
  echo "</center>";

}

require_once("../includes/footer.php");
?>
