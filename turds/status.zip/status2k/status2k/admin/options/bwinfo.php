<?php
require_once("../includes/header.php");
if ($os['windows']) { die("<font face=\"Verdana\" size=\"2\">Sorry this feature is not currently available in Windows Status2k.</font>"); }

function size_bwbytes($size) {
if ($size > 1024) { $size = round($size/1024,0); $type = "MB"; }
if ($size > 1024) { $size = round($size/1024,0); $type = "GB"; }
if ($size > 1024) { $size = round($size/1024,0); $type = "TB"; }
return $size.' '.$type;
}

$day = date('j');
$month = date('n');
$year = date('Y');

$m = array();
$qu = mysql_query("SELECT * FROM ".$prefix."history WHERE year = '$year'");
while($re = mysql_fetch_array($qu)){
$month = $re['month'];
$mout[$month] = ($mout[$month] + $re['trans']);
$min[$month] = ($min[$month] + $re['rec']);
}


// Monthly Out
if ($mout) {
foreach($mout as $key => $value){
$mout[$key] = $value/1024;
}
}

// Monthly In
if ($min) {
foreach($min as $key => $value){
$min[$key] = $value/1024;
}
}

$i = 0;
while($i < 12) {
$i++;
if (!$min[$i]) { $min[$i] = "0"; }
if (!$mout[$i]) { $mout[$i] = "0"; }
}

$in = array();
$out = array();
$query = mysql_query("SELECT * FROM ".$prefix."history WHERE month = '$month' AND year = '$year'");
while($results = mysql_fetch_array($query)){
$day = $results['day'];
$out[$day] = ($out[$day] + $results['trans']);
$in[$day] = ($in[$day] + $results['rec']);
}

function tot($a,$b) {
$tot = size_bwbytes($a+$b);
return $tot;
}

echo "<B>Monthly Bandwidth Usage (".date('Y')."):</B><BR><BR>";

echo "
<table border=\"1\" cellpadding=\"3\" cellspacing=\"0\" style=\"border-collapse: collapse\" width=\"100%\">
  <tr class=\"top\">
  	<td></td>
    <td>Jan</td>
    <td>Feb</td>
    <td>Mar</td>
    <td>Apr</td>
    <td>May</td>
    <td>Jun</td>
    <td>Jul</td>
    <td>Aug</td>
    <td>Sep</td>
    <td>Oct</td>
    <td>Nov</td>
    <td>Dec</td>
  </tr>
";

echo "
<tr>
<td><B>IN:</B></td>
<td>".size_bwbytes($min['1'])."</td>
<td>".size_bwbytes($min['2'])."</td>
<td>".size_bwbytes($min['3'])."</td>
<td>".size_bwbytes($min['4'])."</td>
<td>".size_bwbytes($min['5'])."</td>
<td>".size_bwbytes($min['6'])."</td>
<td>".size_bwbytes($min['7'])."</td>
<td>".size_bwbytes($min['8'])."</td>
<td>".size_bwbytes($min['9'])."</td>
<td>".size_bwbytes($min['10'])."</td>
<td>".size_bwbytes($min['11'])."</td>
<td>".size_bwbytes($min['12'])."</td>
</tr>
";

echo "
<tr>
<td><B>OUT:</B></td>
<td>".size_bwbytes($mout['1'])."</td>
<td>".size_bwbytes($mout['2'])."</td>
<td>".size_bwbytes($mout['3'])."</td>
<td>".size_bwbytes($mout['4'])."</td>
<td>".size_bwbytes($mout['5'])."</td>
<td>".size_bwbytes($mout['6'])."</td>
<td>".size_bwbytes($mout['7'])."</td>
<td>".size_bwbytes($mout['8'])."</td>
<td>".size_bwbytes($mout['9'])."</td>
<td>".size_bwbytes($mout['10'])."</td>
<td>".size_bwbytes($mout['11'])."</td>
<td>".size_bwbytes($mout['12'])."</td>
</tr>
";

echo "
<tr>
<td><i><B>TOTAL:</B></i></td>
<td><i>".tot($mout['1'],$min['1'])."</i></td>
<td><i>".tot($mout['2'],$min['2'])."</i></td>
<td><i>".tot($mout['3'],$min['3'])."</i></td>
<td><i>".tot($mout['4'],$min['4'])."</i></td>
<td><i>".tot($mout['5'],$min['5'])."</i></td>
<td><i>".tot($mout['6'],$min['6'])."</i></td>
<td><i>".tot($mout['7'],$min['7'])."</i></td>
<td><i>".tot($mout['8'],$min['8'])."</i></td>
<td><i>".tot($mout['9'],$min['9'])."</i></td>
<td><i>".tot($mout['10'],$min['10'])."</i></td>
<td><i>".tot($mout['11'],$min['11'])."</i></td>
<td><i>".tot($mout['12'],$min['12'])."</i></td>
</tr>
";

echo "<table><BR>";

echo "<B>Daily Bandwidth Usage (".date('F')." ".date('Y')."):</B><BR><BR>";

echo "
<table border=\"1\" cellpadding=\"3\" cellspacing=\"0\" style=\"border-collapse: collapse\" width=\"100%\">
  <tr class=\"top\">
    <td>Day</td>
    <td>Avg Mbps Out</td>
    <td>Bandwidth Out</td>
    <td>Avg Mbps In</td>
    <td>Bandwidth In</td>
  </tr>
";

$total = 0;
foreach($out as $key => $value){
$count++;

$totalout = ($totalout + $value);
$totalin = ($totalin + $in[$key]);

// OUT MBPS
$mbpsout = ($value/1024/1024);
$mbpsout = round($mbpsout/86400*8,2);
$tmbpsout = $tmbpsout + $mbpsout; // Total

// IN MBPS
$mbpsin = ($in[$key]/1024/1024);
$mbpsin = round($mbpsin/86400*8,2);
$tmbpsin = $tmbpsin + $mbpsin; // Total

$gbout = size_bwbytes($value/1024);
$gbin = size_bwbytes($in[$key]/1024);

echo "
<tr>
<td>".$key."</td>
<td>".$mbpsout." Mbps</td>
<td>".$gbout."</td>
<td>".$mbpsin." Mbps</td>
<td>".$gbin."</td>
</tr>
";
}

$totalgbout = $totalout/1024;
$totalgbin = $totalin/1024;

if ($tmbpsout) { $tmbpsout = round($tmbpsout/$count,2); }
if ($tmbpsin) { $tmbpsin = round($tmbpsin/$count,2); }

$ptio = size_bwbytes($totalgbout+$totalgbin);
$ptiospeed = round($tmbpsout+$tmbpsin,2);

echo "
<tr>
<td><B>TOTAL:</B></td>
<td><B>".$tmbpsout." Mbps</B></td>
<td><B>".size_bwbytes($totalgbout)."</B></td>
<td><B>".$tmbpsin." Mbps</B></td>
<td><B>".size_bwbytes($totalgbin)."</B></td>
</tr>
";

echo "</table><BR>";

echo "<B>Totals (".date('F')." ".date('Y')."):</B><BR><BR>";

echo "
<table border=\"1\" cellpadding=\"3\" cellspacing=\"0\" style=\"border-collapse: collapse\" width=\"100%\">
  <tr class=\"top\">
    <td>Bandwidth Total (In + Out)</td>
    <td>Avg Mbps Total (In + Out)</td>
  </tr>
";

echo "
<tr>
<td>".$ptio."</td>
<td>".$ptiospeed." Mbps</td>
</tr>
";

echo "</table>";

require_once("../includes/footer.php");
?>
