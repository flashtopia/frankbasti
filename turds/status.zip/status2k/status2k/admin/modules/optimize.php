<?php

$time = microtime();
$time = explode(' ', $time);
$time = $time[1] + $time[0];
$start = $time;

$res = mysql_db_query($db, "SHOW TABLE STATUS FROM `" . $db . "`") or die('Query : ' . mysql_error());
$to_optimize = array();
while ( $rec = mysql_fetch_array($res) )
{
if ( $rec['Data_free'] > 0 )
{
$to_optimize [] = $rec['Name'];
echo "<font color=\"red\">".$rec['Name'] . ' Needs Optimization' . "</font><BR>";
}
}
if ( count ( $to_optimize ) > 0 ) {
foreach ( $to_optimize as $tbl ) {
mysql_db_query($db, "OPTIMIZE TABLE `" . $tbl ."`");
echo $tbl." Was Optmized!<BR><BR>";
}
} else {
echo "<B>No Tables Need Optimization.</B><BR><BR>";
}

$time = microtime();
$time = explode(' ', $time);
$time = $time[1] + $time[0];
$finish = $time;
$total_time = round(($finish - $start), 6);
echo 'Parsed in ' . $total_time . ' seconds' . "\n\n";
?>
