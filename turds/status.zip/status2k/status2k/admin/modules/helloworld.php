<?php

// This is an example Status2k Module.
echo "Hello World";

?>
