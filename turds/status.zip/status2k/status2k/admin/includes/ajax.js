/********************************************************/
/* Status 2K - ScribbyTech                              */
/* By: Richard Simpson                                  */
/* scribby@scribbytech.net                              */
/* http://www.scribbytech.net                           */
/* Copyright � 2006 by Richard Simpson                  */
/*                                                      */
/* Code By http://yaldex.com/                           */
/********************************************************/

var request = createRequest();

function createRequest() {
try {
request = new XMLHttpRequest();
} catch (trymicrosoft) {
try {
request = new ActiveXObject("Msxml2.XMLHTTP");
} catch (othermicrosoft) {
try {
request = new ActiveXObject("Microsoft.XMLHTTP");
} catch (failed) {
request = false;
}
}
}
return request;
}

function SetUpdTime(UpdT) {
UpdTime = UpdT;
}

function UpdateRequ(updtTime) {
var element = document.getElementById("live");
if (request.readyState == 4){
var output = request.responseText;
element.innerHTML = output;
setTimeout('UpdateLoad()', UpdTime);
}  
}

function UpdateLoad() {   
var url = "../includes/live.php?"+ new Date().getTime();
request.open("GET", url, true);
request.onreadystatechange = UpdateRequ;
request.send("");  
}
