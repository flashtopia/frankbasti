$lgtrue = 0;

$q = mysql_query("SELECT * FROM ".$prefix."users");
while($res = mysql_fetch_array($q)){
$adminuser = $res['adminuser']; // Login Database
$adminpass = $res['adminpass']; // Pass Database
$adminper = $res['adminper']; // Admin Permissions

if ( isset($_COOKIE["S2KUser"]) && isset($_COOKIE["S2KPass"]) ) {

$cusername = $_COOKIE["S2KUser"];
$cpassword = $_COOKIE["S2KPass"];

if ( ($cusername == $adminuser) && ($cpassword == $adminpass) ) { $lgtrue = 1; }

} // End Cookie

} // End While

if (!$lgtrue) { header("Location: ../login.php"); }
