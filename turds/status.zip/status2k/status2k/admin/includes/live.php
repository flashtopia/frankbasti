<?php

require("../../config.php");
require("../../includes/functions.php");

function size_bwbytes($size) {
if ($size > 1024) { $size = round($size/1024,0); $type = "MB"; }
if ($size > 1024) { $size = round($size/1024,0); $type = "GB"; }
if ($size > 1024) { $size = round($size/1024,0); $type = "TB"; }
return $size.' '.$type;
}

if (isset($enablegzip) && $enablegzip == 1) { ob_start('ob_gzhandler'); }

// Check OS
$os = checkos();
if (isset($os['linux'])) { require_once("../../includes/linux-functions.php"); }
if (isset($os['windows'])) {

require('../../includes/win-functions.php');

$count = 0;
$query = mysql_query("SELECT host, name, port FROM ".$prefix."ports") or die('Query failed: ' . mysql_error());
while($results = mysql_fetch_array($query)){

$ip =  $results['host'];
$name = $results['name'];
$portnum = $results['port'];

$status = @fsockopen($ip, $portnum, $errno, $errstr, $config['timeout']);
$firsttd .= "<td align=\"center\">".$name." (".$portnum.")<BR><font size=\"1\">".$ip."</font></td>";
if ($status) {
$secondtd .= "<td align=\"center\"><img src=\"../images/online.gif\"></td>";
} else {
$secondtd .= "<td align=\"center\"><img src=\"../images/offline.gif\"></td>";
}
$count++;
}

$swapmemorypercent = percent($swap_used,$swap_total);

echo '
<table cellpadding="5" border="1"><tr>
<td colspan="3" align="center" class="top">Server Stats:</td></tr><tr>
<td width="25%" align="center">Load:</td>
<td width="25%" align="center">Memory Used:</td>
<td width="25%" align="center">Swap Used:</td>
</tr><tr><td width="25%" align="center">'.$load_total.'%</td>
<td width="25%" align="center">'.$memorypercent.'%</td>
<td width="25%" align="center">'.$swapmemorypercent.'%</td>
</tr><tr><td width="25%" align="center">
<table border="1" cellpadding="0" width="100%" height="9">
<tr><td bgcolor="#FF5050" width="'.$load_total.'%"></td>
<td bgcolor="#99FF66" width="100%"></td></tr>
</table></div></td><td width="25%" align="center">
<table border="1" cellpadding="0" width="100%" height="9"><tr>
<td bgcolor="#FF5050" width="'.$memorypercent.'%"></td>
<td bgcolor="#99FF66" width="100%"></td>
</tr></table></td>
<td width="25%" align="center">
<table border="1" cellpadding="0" width="100%" height="9">
<tr><td bgcolor="#FF5050" width="'.$swapmemorypercent.'%"></td>
<td bgcolor="#99FF66" width="100%"></td>
</tr></table></td></tr></table><BR>';

echo '
<table border="1" cellpadding="5" width="100%">
<tr>
<td  align="center" class="top" colspan="'.$count.'">Service Stats:</td>
</tr>
<tr>'.$firsttd.'</tr>
<tr>'.$secondtd.'</tr>
</table>';

} else {

if (isset($os['freebsd'])) { require_once("../../includes/bsd-functions.php"); }

$load = load();
$memory = memory();
$cpuinf = cpuinfo();
$loadbar = percent($load['0'],$cpuinf['total']);
$memorypercent = percent($memory['used'],$memory['total']);
$swapmemorypercent = percent($memory['swapused'],$memory['swaptotal']);

echo '
<table cellpadding="5" border="1"><tr>
<td colspan="3" align="center" class="top">Server Stats:</td></tr><tr>
<td width="25%" align="center">Load:</td>
<td width="25%" align="center">Memory Used:</td>
<td width="25%" align="center">Swap Used:</td>
</tr><tr><td width="25%" align="center">'.$loadbar.'% ( <B>'.$load['0'].', '.$load['1'].', '.$load['2'].'</B> )</td>
<td width="25%" align="center">'.$memorypercent.'%</td>
<td width="25%" align="center">'.$swapmemorypercent.'%</td>
</tr><tr><td width="25%" align="center">
<table border="1" cellpadding="0"  width="100%" height="9">
<tr><td bgcolor="#FF5050" width="'.$loadbar.'%"></td>
<td bgcolor="#99FF66" width="100%"></td></tr>
</table></div></td><td width="25%" align="center">
<table border="1" cellpadding="0"  width="100%" height="9"><tr>
<td bgcolor="#FF5050" width="'.$memorypercent.'%"></td>
<td bgcolor="#99FF66" width="100%"></td>
</tr></table></td>
<td width="25%" align="center">
<table border="1" cellpadding="0"  width="100%" height="9">
<tr><td bgcolor="#FF5050" width="'.$swapmemorypercent.'%"></td>
<td bgcolor="#99FF66" width="100%"></td>
</tr></table></td></tr></table>';

$hour = date("G");
$day = date("j");
$month = date("n");
$year = date("Y");

$rec = 0;
$tra = 0;
$query = mysql_query("SELECT trans, rec FROM ".$prefix."history WHERE year = '$year' AND month = '$month'") or die(mysql_error());
while ($results = mysql_fetch_array($query)) {
$rec = $rec+$results['rec'];
$tra = $tra+$results['trans'];
}

$rec = size_bwbytes($rec/1024);
$tra = size_bwbytes($tra/1024);

$query = mysql_query("SELECT trans, rec FROM ".$prefix."history WHERE year = '$year' AND month = '$month' AND day = '$day'") or die(mysql_error());
while ($results = mysql_fetch_array($query)) {
$rectoday = $rectoday+$results['rec'];
$tratoday = $tratoday+$results['trans'];
}
$rectoday = size_bwbytes($rectoday/1024);
$tratoday = size_bwbytes($tratoday/1024);

$sshlog = cmdrun("/usr/bin/who");
if (!$sshlog) { $sshlog = "No Users Currently Logged In."; }

$netstat = cmdrun("netstat -n | grep ESTABLISHED");

$httpds = 0;
$sshd = 0;
$ftpds = 0;
$mysqld = 0;
$mails = 0;

$pieces = explode("\n", $netstat);
foreach ($pieces as $piece) {
if ( eregi($sdata['ip'].":80", $piece) ) {$httpds++;}
if ( eregi($sdata['ip'].":".$config['sshport'], $piece) ) {$sshd++;}
if ( eregi($sdata['ip'].":21", $piece) ) {$ftpds++;}
if ( eregi($sdata['ip'].":3306", $piece) ) {$mysqld++;}
if ( eregi($sdata['ip'].":110", $piece) ) {$mails++;}
}

echo "
<BR>
<table border=\"1\" cellpadding=\"5\"><tr>
<td align=\"center\" colspan=\"6\" class=\"top\">Services/Port Connection Stats:</td>
</tr><tr><td  align=\"center\"><a href=\"../options/connections.php?port=80\">HTTP (Port 80):</a></td>
<td align=\"center\"><a href=\"../options/connections.php?port=21\">FTP (Port 21):</a></td>
<td align=\"center\"><a href=\"../options/connections.php?port=110\">Mail (Port 110):</a></td>
<td align=\"center\"><a href=\"../options/connections.php?port=3306\">MySQL (Port 3306):</a></td>
<td align=\"center\"><a href=\"../options/connections.php?port=".$config['sshport']."\">SSH (Port ".$config['sshport']."):</a></td>
</tr>
<tr>
<td align=\"center\">$httpds</td>
<td align=\"center\">$ftpds</td>
<td align=\"center\">$mails</td>
<td align=\"center\">$mysqld</td>
<td align=\"center\">$sshd</td>
</tr>";

$data['ip'] = $_SERVER["SERVER_ADDR"];
if (!$data['ip']) { $data['ip'] = $_SERVER["LOCAL_ADDR"]; }
if (!$data['ip']) { $data['ip'] = gethostbyname($data['host']); }

if ($config['cpuser'] && $config['cppass']) {

$cppanel = @fsockopen($data['ip'], "2086", $errno, $errstr, $timeout);
if ($cppanel) {
echo '
<tr>
<td  align="center"><a href="restart.php?serv=httpd"><img src="../images/restart.gif" border="0"></a></td>
<td  align="center"><a href="restart.php?serv=proftpd"><img src="../images/restart.gif" border="0"></a></td>
<td  align="center"><a href="restart.php?serv=cppop"><img src="../images/restart.gif" border="0"></a></td>
<td  align="center"><a href="restart.php?serv=mysql"><img src="../images/restart.gif" border="0"></a></td>
<td  align="center"><a href="restart.php?serv=sshd"><img src="../images/restart.gif" border="0"></a></td>
</tr>';
}

}

echo "</table><BR>";

if ($os['freebsd']) {
$highestrunning = cmdrun("ps -a -H -r -o pcpu,cputime,args | tail -5");
} else {
$highestrunning = cmdrun("ps -e -o pcpu,cputime,args --sort pcpu | tail -5");
}
$pieces = explode("\n", $highestrunning);
$pieces = array_reverse($pieces);

echo '
<table border="1" cellpadding="5" width="100%">
<tr>
<td  align="center" class="top">Users Loged Into SSH:</td>
</tr>

<tr>
<td align="center">'.$sshlog.'</td>
</tr>
</table>
<BR>

<table border="1" cellpadding="5" width="100%">
<tr>
<td align="center" class="top">5 Highest CPU Processes:</td>
<td  align="center" class="top">Server Bandwidth:</td>
</tr>

<tr>
<td align="center" rowspan="2"><B>CPU% | CPU TIME | PROCESS NAME</B>';

foreach($pieces as $piece) {
if(strlen($piece) > 74) { echo substr($piece,0,75)."...<BR>"; } else { echo "$piece<BR>"; }
}

echo "</td>
<td align=\"center\">
<I>Bandwith Used ".date('F')."</I><BR><B>Transfered:</B> $tra<BR><B>Recieved:</B> $rec
</td></tr>
<tr><td align=\"center\">
<I>Bandwith Used Today</I><BR>
<B>Transfered:</B> $tratoday<BR><B>Recieved:</B> $rectoday
</td>
</tr></table>
<BR>";

$count = 0;
$firsttd = NULL;
$secondtd = NULL;
$query = mysql_query("SELECT host, name, port FROM ".$prefix."ports") or die('Query failed: ' . mysql_error());
while($results = mysql_fetch_array($query)){

$ip =  $results['host'];
$name = $results['name'];
$portnum = $results['port'];

$status = @fsockopen($ip, $portnum, $errno, $errstr, $config['timeout']);
$firsttd .= '<td align="center">'.$name.' ('.$portnum.')<BR><font size="1">'.$ip.'</font></td>';
if ($status) {
$secondtd .= '<td align="center"><img src="../images/online.gif"></td>';
} else {
$secondtd .= '<td align="center"><img src="../images/offline.gif"></td>';
}
$count++;
}
echo '
<table border="1" cellpadding="5" width="100%">
<tr><td  align="center" class="top" colspan="'.$count.'">Service Stats:</td></tr>
<tr>'.$firsttd.'</tr>
<tr>'.$secondtd.'</tr>
</table>';

}

?>
