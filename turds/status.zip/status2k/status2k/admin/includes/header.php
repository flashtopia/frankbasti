<?php
session_start();
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
  if(!isset($_SESSION['csrf']) || $_SESSION['csrf'] !== $_POST['csrf'])
    throw new RuntimeException('CSRF Attack' . $_POST['csrf'] . '::' . $_SESSION['csrf']);
}
$_SESSION['csrf'] = sha1(microtime());

// Licence Check And File Check
require_once("../../config.php");
require_once("../../includes/functions.php");

$lgtrue = 0;

$q = mysql_query("SELECT * FROM ".$prefix."users");
while($res = mysql_fetch_array($q)){
  $adminuser = $res['adminuser']; // Login Database
  $adminpass = $res['adminpass']; // Pass Database
  $adminper = $res['adminper']; // Admin Permissions

  if ( isset($_COOKIE["S2KUser"]) && isset($_COOKIE["S2KPass"]) ) {

    $cusername = $_COOKIE["S2KUser"];
    $cpassword = $_COOKIE["S2KPass"];

    if ( ($cusername == $adminuser) && ($cpassword == $adminpass) ) { $lgtrue = 1; }

  } // End Cookie

} // End While

if (!$lgtrue) { header("Location: ../login.php"); die(); }

$logs = NULL;

$qu = mysql_query("SELECT id, name FROM ".$prefix."logs");
while($resu = mysql_fetch_array($qu)){
  $logs .= "<li><a href=\"../options/logs.php?log=".$resu['id']."\">".$resu['name']."</a></li>";
}

$que = mysql_query("SELECT id, name FROM ".$prefix."modules");
while($resul = mysql_fetch_array($que)){
  $modules .= "<li><a href=\"../options/module.php?id=".$resul['id']."\">".$resul['name']."</a></li>";
}

$ver = "Version ".$config['ver'];

if (isset($enablegzip) && $enablegzip == 1 && !eregi('logs.php',$_SERVER['PHP_SELF'])) { ob_start('ob_gzhandler'); }

// Check OS
$os = checkos();
if (isset($os['linux'])) { require_once("../../includes/linux-functions.php"); }
if (isset($os['windows'])) { require_once("../../includes/win-functions.php"); }
if (isset($os['freebsd'])) { require_once("../../includes/bsd-functions.php"); }

if (eregi("news.php", $_SERVER['PHP_SELF'])) { 
  echo "
    <!DOCTYPE html>
    <html>
    <head>
    <link rel=\"stylesheet\" href=\"http://twitter.github.com/bootstrap/1.3.0/bootstrap.min.css\" />
    <title>Status2k - Admin</title>

    <!-- tinyMCE -->
    <script language=\"javascript\" type=\"text/javascript\" src=\"../tiny_mce/tiny_mce.js\"></script>
    <script language=\"javascript\" type=\"text/javascript\" src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js\"></script>
    <script language=\"javascript\" type=\"text/javascript\" src=\"http://twitter.github.com/bootstrap/1.3.0/bootstrap-dropdown.js\"></script>
    <script language=\"javascript\" type=\"text/javascript\">
    // Notice: The simple theme does not use all options some of them are limited to the advanced theme
    tinyMCE.init({
mode : \"textareas\",
theme : \"advanced\",
extended_valid_elements : \"a[href|target|name]\",
plugins : \"table\",
theme_advanced_buttons3_add_before : \"tablecontrols,separator\"
});
</script>
<!-- End tinyMCE -->
";
} else {
  echo "
    <!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml2/DTD/xhtml1-strict.dtd\">
    <html>
    <head>
    <link rel=\"stylesheet\" href=\"http://twitter.github.com/bootstrap/1.3.0/bootstrap.min.css\" />
    <script language=\"javascript\" type=\"text/javascript\" src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js\"></script>
    <script language=\"javascript\" type=\"text/javascript\" src=\"http://twitter.github.com/bootstrap/1.3.0/bootstrap-dropdown.js\"></script>
    <title>Status2k - Admin</title>
    ";
}
if (eregi("main.php", $_SERVER['PHP_SELF'])) { echo '<script language="javascript" src="../includes/ajax.js" type="text/javascript"></script>'; }
echo "</head>";
if (eregi("main.php", $_SERVER['PHP_SELF'])) { echo '<body onload="SetUpdTime('.($config['liveadmin']*1000).'); UpdateLoad();">'; } else { echo '<body>'; }
?>
<div class="topbar" data-dropdown="dropdown">       
<div class="topbar-inner">         
<div class="container">           
<h3><a href="#">Status2K Admin</a></h3>            
<ul class="nav">             
<li class="dropdown">
<a href='#' class="dropdown-toggle">Admin</a>
<ul class="dropdown-menu">
<li><a href="../options/main.php">Admin Home</a></li>
<li><a href="../../">Script Home</a></li>
<li><a href="../logout.php">Logout</a></li>
</ul>
</li>
<li class="dropdown">
<a href='#' class="dropdown-toggle">Config</a>
<ul class="dropdown-menu">
<li><a href="../options/config.php">General Config</a></li>
<li><a href="../options/multiservers.php">Multi-Servers</a></li>
<li><a href="../options/editpl.php">Edit Templates</a></li>
<li><a href="../options/services.php">Services</a></li>
<li><a href="../options/users.php">Users</a></li>
<li><a href="../options/news.php">News</a></li>
</ul>
</li>
<li class="dropdown">
<a href='#' class="dropdown-toggle">Logs</a>
<ul class="dropdown-menu">
<li><a href="../options/addlog.php">Add Logs</a></li>
<?php echo $logs; ?>
</ul>
</li>
<li class="dropdown">
<a href='#' class="dropdown-toggle">System</a>
<ul class="dropdown-menu">
<?php
if (isset($os['windows'])) {
  echo "
    <li><a href=\"../options/mysqlprocess.php\">MySQL Processes</a></li>
    <li><a href=\"../options/apstats.php\">Apache Stats</a></li>
    <li><a href=\"../options/netstat.php\">NetStat</a></li>
    ";
} else {
  echo "
    <li><a href=\"../options/runningproc.php\">Running Processes</a></li>
    <li><a href=\"../options/advapache.php\">Apache Processes</a></li>
    <li><a href=\"../options/apstats.php\">Apache Stats</a></li>
    <li><a href=\"../options/mysqlprocess.php\">MySQL Processes</a></li>
    <li><a href=\"../options/mystats.php\">MySQL Stats</a></li>
    <li><a href=\"../options/ptree.php\">Process Tree</a></li>
    <li><a href=\"../options/netstat.php\">NetStat</a></li>
    <li><a href=\"../options/routetable.php\">Routing Table</a></li>
    <li><a href=\"../options/sshlog.php\">Last SSH Logins</a></li>
    <li><a href=\"../options/ftplog.php\">Last FTP Logins</a></li>
    <li><a href=\"../options/bwinfo.php\">Bandwidth Info</a></li>
    ";
}
?>
</ul>
</li>
<li class="dropdown">
<a href='#' class="dropdown-toggle">Graphs</a>
<ul class="dropdown-menu">
<li><a href="graph1.php">24 Hour Graphs</a></li>
<li><a href="bandwidth.php">Bandwidth</a></li>
</ul>
</li>
</ul>
<ul class="nav secondary-nav" style="color:#ddd;padding-top: 4px">             
<?php if (isset($os['windows'])) { 
  echo "Status2k - ".$ver."<br />".winosname()." - ".php_uname('a'); 
} else { 
  echo "Status2k - ".$ver."<br />".distro()." - ".php_uname('m')." - ".php_uname('r'); 
} ?>
</ul>
</div>
</div><!-- /topbar-inner -->     
</div><!-- /topbar -->   



<div class="container" style="padding-top: 60px">
