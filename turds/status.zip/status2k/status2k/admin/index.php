<?php
header("Location: options/main.php");
?>
