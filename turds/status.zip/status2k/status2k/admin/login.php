<?php

// Licence Check And File Check
require_once("../config.php");
require_once("../includes/functions.php");

$lgtrue = 0;
$useren = NULL;
$passen = NULL;

if (isset($_GET['password'])) { $passen = sha1($_GET['password']); }
if (isset($_GET['username'])) { $useren = $_GET['username']; }
if (isset($_POST['password'])) { $passen = sha1($_POST['password']); }
if (isset($_POST['password'])) { $useren = $_POST['username']; }

$q = mysql_query("SELECT * FROM ".$prefix."users");
while($res = mysql_fetch_array($q)){
$adminuser = $res['adminuser']; // Login Database
$adminpass = $res['adminpass']; // Pass Database

if ( isset($_COOKIE["S2KUser"]) && isset($_COOKIE["S2KPass"]) ) {

$cusername = $_COOKIE["S2KUser"];
$cpassword = $_COOKIE["S2KPass"];

if ( ($cusername == $adminuser) && ($cpassword == $adminpass) ) { $lgtrue = 1; }

} // End Cookie

if ( ($useren == $adminuser) && ($passen == $adminpass) ) {
setcookie("S2KUser", $useren);
setcookie("S2KPass", $passen);
$lgtrue = 1;
}

} // End While

if ($lgtrue) { header("Location: index.php"); }

?>

<?php
if ($passen && $useren) {
if ($useren !== $adminuser) { echo '<div class="alert-message error">Username ('.$useren.') Incorrect.</div>'; }
if ($passen !== $adminpass) { echo '<div class="alert-message error">Password Incorrect.</div>'; }
}
?>

<!DOCTYPE html>
<html>

<head>
  <meta http-equiv="Content-Language" content="en-us">
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
  <title>Status2k Install - <?php echo $pagename; ?></title>
  <link rel="stylesheet" href="http://twitter.github.com/bootstrap/1.3.0/bootstrap.min.css">
</head>

<body>
<div class="content">
<div style="width: 600px;margin: 60px auto">
<form method="post" action="login.php">
  <fieldset>
    <legend>Log In</legend>
    <div class="clearfix">
      <label>Username</label>
      <div class="input">
        <input type="text" name="username" size="25" >
      </div>
    </div>
    <div class="clearfix">
      <label>Password</label>
      <div class="input">
        <input type="password" name="password" size="25">
      </div>
    </div>
  </fieldset>
  <div class="actions">
    <input type="submit" class="btn primary" name="Submit" value="Login >>" >
  </div>
</form>

</div></div><body></html>
