<?php
setcookie("S2KUser", "0", time()-999999);
setcookie("S2KPass", "0", time()-999999);
echo "<SCRIPT LANGUAGE=\"JavaScript\">
redirURL = \"login.php\";
self.setTimeout(\"self.location.href = redirURL;\",2000);
</script>";

echo "<center>";
echo "<b><font face=\"Verdana\" color=\"#FF0000\" size=\"2\">You are now logged out!</font></b><BR>";
echo "<b><font face=\"Verdana\" size=\"2\">You will be redirected in 2 seconds.</font></b><BR>";
echo "<img src=\"../images/loading.gif\"><BR>";
echo "</center>";
die();
?>
