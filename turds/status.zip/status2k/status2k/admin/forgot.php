<?php

require_once("../config.php");
require_once("../includes/functions.php");

function code() {
$nc = "8";
$a = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
$l=strlen($a)-1; $r='';
while($nc-->0) $r.=$a{mt_rand(0,$l)};
return $r;
}

?>


<div align="center">
<table border="0" cellpadding="0" style="border-collapse: collapse" width="100%" height="100%">
<tr><td><div align="center">
<table border="1" cellpadding="0" style="border-collapse: collapse" width="45%" bordercolor="#000000">
<tr><td><p align="center">
<img border="0" src="../images/logo.gif"></td>
</tr><tr><td><div align="center">
<table border="0" cellpadding="5" style="border-collapse: collapse" width="100%">
<form method="post" action="forgot.php">
<tr><td colspan="2">
<p align="center">
<font face="Verdana" size="2">Please enter your username.</font>

<?php

$q = mysql_query("SELECT * FROM ".$prefix."users");
while($res = mysql_fetch_array($q)){
$adminuser = $res['adminuser']; // Login Database
$useren = $_POST['username']; // Login Post

if ($useren == $adminuser) {
$newpasd = code();
$newpass = sha1($newpasd);
$qu = "UPDATE ".$prefix."users SET adminpass = '".$newpass."' WHERE adminuser = '".$useren."'";
mysql_query($qu) or die('Error! Updating Failed.');
$ip = $_SERVER['REMOTE_ADDR'];
$message = 'New Password: '.$newpasd."\nRequested By: ".$ip;
mail($config['emailaddress'], 'Password Request', $message, 'From: ' . $config['fromaddy']);
echo '<BR><font face="Verdana" size="2" color="#FF0000"><B>New Password Have Been Sent!</B></font>';
}
}

?>
</td></tr><tr>
<td width="37%"><p align="right"><b><font face="Verdana" size="2">Username:</font></b></td>
<td width="58%"><font face="Verdana">
<input type="textbox" name="username" size="25" style="border: 1px solid #000000; float:left"></font></td>
</tr><tr><td colspan="2" align="center">
<font face="Verdana">
<input type="submit" name="Submit" value="Submit >>" style="border:1px solid #000000; float: right"></font></td>
</tr></form></table></div></td></tr>
<tr><td>
<div align="center">
<table border="0" cellpadding="3" style="border-collapse: collapse" width="100%" id="table1">
<tr><td>
<p align="center"><font face="Verdana" size="1">Copyright 2005 - 2006 <font color="#000000">Status2K.com</font> | <a href="forgot.php"><font color="#000000">Forgot Password</font></a></font></td>
</tr>
</table>
</div>
</td></tr>

</table></div>
</td></tr>

</table></div>
