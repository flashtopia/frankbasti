<?php
include('config.php');
include('includes/functions.php');

if ($config['multiservers']) { echo multiservers(); } else { echo 'Multi-Servers Disabled'; }
?>
