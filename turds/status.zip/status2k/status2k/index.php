<?php

// ==========================================
// Main START
// ==========================================

function microtime_float() {
list($usec, $sec) = explode(' ', microtime());
return ((float)$usec + (float)$sec);
}

$time_start = microtime_float();

// Page Requirements
require('config.php');

if (isset($enablegzip) && $enablegzip == 1) { ob_start('ob_gzhandler'); }
if (!$config['langfile']) { $config['langfile'] = 'english'; }

require('includes/functions.php');
require('language/'.$config['langfile'].'/lang.php');

if ($config['skipclient']) { header('Location: ./admin/'); }

$version = versions(); // Zend, MySQL, PHP, CompName, WinVer, ServerSoft, Server Date.
$os = checkos(); // Check The Operating System.

// Check If Action Equals PHPInfo
if (isset($_GET['action']) && ($_GET['action'] == 'phpinfo')) { phpinfo(); die(); }

// ==========================================
// Main END
// ==========================================

// ==========================================
// Language START
// ==========================================

foreach ($LANG as $key => $value) {
$tags['lang.'.$key] = $value;
}

// ==========================================
// Language END
// ==========================================

// ==========================================
// Linux START
// ==========================================

if (isset($os['linux'])) {
require('includes/linux-functions.php');
ob_start(); require('templates/'.$config['templaten'].'/linux.tpl'); $page = ob_get_contents(); ob_end_clean();
$load = load();
$memory = memory();
$cpuinf = cpuinfo();
$cpus = $cpuinf['total'];
if ($config['multiservers']) { $multiservers = multiservers(); }
$ldcpu = ($config['extraload'] + $cpuinf['total']);
$loadpercent = percent($load['0'],$ldcpu);
$memorypercent = percent($memory['used'],$memory['total']);
$swapmemorypercent = percent($memory['swapused'],$memory['swaptotal']);

$time_end = microtime_float();
$finishtime = $time_end - $time_start;
$finishtime = round($finishtime,5);
$distro = distro();

$tags["footer"] = "$finishtime";
$tags["thedate"] = date("F j, Y");
$tags["swapmemorypercent"] = "$swapmemorypercent";
$tags["multiservers"] = $multiservers;
$tags["hddss"] = drives();
$tags["news"] = news();
$tags["services"] = services();
$tags["distroimg"] = distroimage($distro);
$tags["platform"] = php_uname('m');
$tags["kernelver"] = php_uname('r');
$tags["distro"] = $distro;
$tags["cpuinfo"] = $cpuinf['name'];
$tags["cpuimg"] = cpuimage($cpuinf['name']);
$tags["cpus"] = $cpus;
$tags["cpumhz"] = $cpuinf['mhz'].'MHz';
$tags["servername"] = $config['sname'];
$tags["uptime"] = uptime($LANG,uptimeseconds());
$tags["avgload"] = $load[0].", ".$load[1].", ".$load[2];
$tags["upsecs"] = uptimeseconds();
$tags["loadlive"] = $config['liveloadt']*1000;
$tags["memoryused"] = size_bytes($memory['used']);
$tags["totalmemory"] = size_bytes($memory['total']);
if ($config['liveload']) {
$tags["loadbar"] = '<div id="currentload">'.bar($loadpercent,$load['0'].' / '.$cpuinf['total'].'.00',$LANG['curlod'],$LANG['loadtip'],$config['templaten']).'</div>';
} else {
$tags["loadbar"] = bar($loadpercent,$load['0'].' / '.$cpuinf['total'].'.00',$LANG['curlod'],$LANG['loadtip'],$config['templaten']);
}
$tags["memorybar"] = bar($memorypercent,size_bytes($memory['used']).' / '.size_bytes($memory['total']),$LANG['memused'],$LANG['memtip'],$config['templaten']);
$tags["swapbar"] = bar($swapmemorypercent,size_bytes($memory['swapused']).' / '.size_bytes($memory['swaptotal']),$LANG['swapused'],$LANG['swaptip'],$config['templaten']);
$tags["webver"] = $version['apache'];
$tags["mysqlversion"] = $version['mysql'];
$tags["phpversion"] = $version['php'];

// ==========================================
// Linux END
// ==========================================

// ==========================================
// Windows START
// ==========================================
} elseif (isset($os['windows'])) {
require("includes/win-functions.php");
ob_start(); require("templates/".$config['templaten']."/windows.tpl"); $page = ob_get_contents(); ob_end_clean();
if ($config['multiservers']) { $multiservers = multiservers(); }

$time_end = microtime_float();
$finishtime = $time_end - $time_start;
$finishtime = round($finishtime,4);

$tags["footer"] = "$finishtime";
$tags["multiservers"] = $multiservers;
$tags["news"] = news();
$tags["services"] = services();
$tags["distroimg"] = '<img src="images/distros/windows.gif" alt="Windows">';
$tags["os"] = winosname();
$tags["cp"] = $theconp;
$tags["compname"] = $version['compname'];
$tags["cpuinfo"] = $cpu_name;
$tags["cpus"] = $cpu_num;
$tags["cpumhz"] = round($cpu_mhz/1000,4).'GHz';
$tags["cpuimg"] = cpuimage($cpu_name);
$tags["servername"] = $config['sname'];
$tags["webver"] = $version['webver'];
$tags["mysqlversion"] = $version['mysql'];
$tags["phpversion"] = $version['php'];
$tags["uptime"] = uptime($LANG,$uptimesec);
$tags["upsecs"] = $uptimesec;
$tags["loadlive"] = $config['liveloadt']*1000;
$tags["loadbar"] = '<span id="currentload">'.bar($load_total,$load_total.' / 100',$LANG['curlod'],$LANG['loadtip'],$config['templaten']).'</span>';
$tags["memorybar"] = bar($memorypercent,size_bytes($mem_used)." / ".size_bytes($mem_total),$LANG['memused'],$LANG['memtip'],$config['templaten']);
$tags["memoryused"] = size_bytes($mem_used);
$tags["totalmemory"] = size_bytes($mem_total);
$tags["hddss"] = $diskspace;
$tags["swapbar"] = bar(percent($swap_used,$swap_total),size_bytes($swap_used)." / ".size_bytes($swap_total),$LANG['swapused'],$LANG['swaptip'],$config['templaten']);
$tags["swapused"] = size_bytes($swap_used);
$tags["totalswap"] = size_bytes($swap_total);

// ==========================================
// Windows END
// ==========================================

// ==========================================
// FreeBSD START
// ==========================================

} elseif (isset($os['freebsd'])) {
require("includes/bsd-functions.php");
ob_start(); require("templates/".$config['templaten']."/linux.tpl"); $page = ob_get_contents(); ob_end_clean();
$load = load();
$cpuinf = cpuinfo();
$memory = memory();
$cpus = "".$cpuinf['total']."";
if ($config['multiservers']) { $multiservers = multiservers(); }
$loadpercent = percent($load['0'],$cpuinf['total']);
$swapmemorypercent = percent($memory['swapused'],$memory['swaptotal']);
$memorypercent = percent($memory['used'],$memory['total']);
$tuptime = uptimeseconds();

$time_end = microtime_float();
$finishtime = $time_end - $time_start;
$finishtime = round($finishtime,5);

$tags["apacheversion"] = $version['apache'];
$tags["mysqlversion"] = $version['mysql'];
$tags["phpversion"] = $version['php'];
$tags["footer"] = "$finishtime";
$tags["multiservers"] = $multiservers;
$tags["hddss"] = drives();
$tags["swapbar"] = bar($swapmemorypercent,size_bytes($memory['swapused']).' / '.size_bytes($memory['swaptotal']),$LANG['swapused'],$LANG['swaptip'],$config['templaten']);
$tags["news"] = news();
$tags["services"] = services();
$tags["distroimg"] = '<img src="images/distros/freebsd.gif" alt="FreeBSD">';
$tags["memorybar"] = bar($memorypercent,size_bytes($memory['used']).' / '.size_bytes($memory['total']),$LANG['memused'],$LANG['memtip'],$config['templaten']);
$tags["platform"] = php_uname(m);
$tags["kernelver"] = php_uname(r);
$tags["distro"] = 'FreeBSD';
$tags["cpuinfo"] = $cpuinf['name'];
$tags["cpuimg"] = cpuimage($cpuinf['name']);
$tags["cpus"] = $cpus;
$tags["cpumhz"] = $cpuinf['mhz'].'MHz';
$tags["servername"] = $config['sname'];
$tags["uptime"] = uptime($LANG,$tuptime);
$tags["avgload"] = $load[0].', '.$load[1].', '.$load[2];
$tags["upsecs"] = "$tuptime";
$tags["memoryused"] = size_bytes($memory['used']);
$tags["totalmemory"] = size_bytes($memory['total']);
$tags["loadlive"] = $config['liveloadt']*1000;
$tags["upsecs"] = "$tuptime";
$tags["loadbar"] = '<span id="currentload">'.bar($loadpercent,$load['0'].' / '.$cpuinf['total'].'.00',$LANG['curlod'],$LANG['loadtip'],$config['templaten']).'</span>';

} else {
die("OS Not Supported!");
}

// ==========================================
// FreeBSD END
// ==========================================


// ==========================================
// Template Process START
// ==========================================

foreach ($tags as $tag => $data) {
$page = str_replace('{' . $tag . '}', $data, $page);
if (preg_match('/\<php\>(.*?)\<\/php\>/', $page, $php)) {
ob_start(); eval($php[1]); $ev = ob_get_contents(); ob_end_clean();
$page = str_replace('<php>'.$php[1].'</php>', $ev, $page);
}
}

echo $page;

ob_end_flush();

// ==========================================
// Template Process END
// ==========================================

$mysql->close();

?>
