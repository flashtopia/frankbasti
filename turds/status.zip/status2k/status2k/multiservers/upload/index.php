<?php

include("config.php");

// ==================
// FUNCTIONS
// ==================

if ($ssh2) {
$connection = ssh2_connect("localhost", $ssh2port);
ssh2_auth_password($connection, $ssh2user, $ssh2pass);
}

function cmdrun($cmd) {
global $connection,$ssh2;
if ($ssh2) {
ob_start();
$stream = ssh2_exec($connection, $cmd);
stream_set_blocking($stream, 1);
echo stream_get_contents($stream);
$result = ob_get_contents();
fclose($stream);
ob_end_clean();
} else { $result = shell_exec($cmd); }
return $result;
}

function bsdsys($key) {
return cmdrun("/sbin/sysctl -n ".$key);
}

function load() {
$reguptime = cmdrun("cat /proc/loadavg");
$piece = explode(" ", $reguptime);
$loadnow = $piece[0];
$load15 = $piece[1];
$load30 = $piece[2];
return $piece;
}

function uptimeseconds() {
$uptimel = cmdrun("cat /proc/uptime");
$uptimel = split(" ",$uptimel);
return $uptimel[0];
}

function bsdload() {
$exec = bsdsys("vm.loadavg");
$exec = ereg_replace('{ ', '', $exec);
$exec = ereg_replace(' }', '', $exec);
$exec = explode(" ",$exec);
$piece[0] = $exec[0];
$piece[1] = $exec[1];
$piece[2] = $exec[2];
return $piece;
}

function bsduptimeseconds() {
$s = bsdsys("kern.boottime | awk '{print \$4}'");
$uptime = time() - $s;
return $uptime;
}

function checkos() {
$windows = 0;
$linux = 0;
$freebsd = 0;
if (substr(PHP_OS,0,3)=='WIN') { $os['windows'] = 1; }
if (PHP_OS=='FreeBSD') { $os['freebsd'] = 1; }
if (PHP_OS=='Linux') { $os['linux'] = 1; }
return $os;
}

function percent($value,$total) {
if ($value && $total) { $percent = round(($value / $total * 100), 1); } else { $percent = 0; }
return $percent;
}

// ==================
// END FUNCTIONS
// ==================

if (isset($_GET["action"])) {
$action = $_GET["action"];
if ($action == "stat") { // START
$os = checkos();

// ==================
// WINDOWS
// ==================
if (isset($os['windows'])) {
$osimg = "win";

$expfile = $_SERVER["SystemRoot"]."\SYSTEM32\KERNEL32.DLL";
if (file_exists($expfile)) {
$upsince = fileatime($expfile);
if ($upsince) { $gettime = (time() - $upsince); }
}


if (!$gettime) {
$expfile = $_SERVER["SystemRoot"]."\SYSTEM32\KERNEL.DLL";
if (file_exists($expfile)) {
$upsince = fileatime($expfile);
if ($upsince) { $gettime = (time() - $upsince); }
}
}

if (!$gettime) {
$winstats = @shell_exec("net statistics server");
if ($winstats) {
preg_match("(\d{1,2}/\d{1,2}/\d{4}\s+\d{1,2}\:\d{2}\s+\w{2})", $winstats, $matches);
if ($matches[0]) { $gettime = time() - strtotime($matches[0]); }
}
}

if (!$gettime && @dl("php_w32api.dll")) {
$api = new win32;
$api->registerfunction("bool QueryPerformanceCounter (float &lpPerformanceCount) From kernel32.dll");
$api->registerfunction("bool QueryPerformanceFrequency (float &lpPerformanceFrequency) From kernel32.dll");
$api->QueryPerformanceCounter($a);
$api->QueryPerformanceFrequency($b);
if ($a && $b) { $gettime = $a/$b; }
}

if (!$gettime && file_exists($config['pagefile'])) {
$upsince = @filemtime($config['pagefile']);
if ($upsince) { $gettime = (time() - $upsince); }
}

$days = floor($gettime/60/60/24);
$hours = round($gettime/60/60/24);
$mins = round($gettime/60/60);
$secs = round($gettime/60);

echo "<os>".$osimg."</os>\n";
if ($days <= 1) { $day = "Day"; } else { $day = "Days"; }
echo "<uptime>$days $day $hours:$mins:$secs</uptime>\n";

}
// ==================
// END WINDOWS
// ==================


// ==================
// LINUX
// ==================
if ($os['linux']) {
$osimg = "linux";
$uptime = uptimeseconds();
$days = floor($uptime/60/60/24);
$hours = $uptime/60/60%24;
$mins = $uptime/60%60;
$secs = $uptime%60;
$load = load();
if ($days <= 1) { $day = "Day"; } else { $day = "Days"; }
echo "<os>".$osimg."</os>\n";
echo "<load>".$load['0']."</load>\n";
echo "<load15>".$load['1']."</load15>\n";
echo "<load30>".$load['2']."</load30>\n";
echo "<uptime>$days $day $hours:$mins:$secs</uptime>\n";
}
// ==================
// END LINUX
// ==================


// ==================
// FREEBSD
// ==================
if (isset($os['freebsd'])) {
$osimg = "freebsd";

$uptime = bsduptimeseconds();
$days = floor($uptime/60/60/24);
$hours = $uptime/60/60%24;
$mins = $uptime/60%60;
$secs = $uptime%60;
$load = bsdload();

if ($days <= 1) { $day = "Day"; } else { $day = "Days"; }
echo "<os>".$osimg."</os>\n";
echo "<load>".$load['0']."</load>\n";
echo "<load15>".$load['1']."</load15>\n";
echo "<load30>".$load['2']."</load30>\n";
echo "<uptime>".$days." ".$day." ".$hours.":".$mins.":".$secs."</uptime>\n";
}
// ==================
// END FREEBSD
// ==================

} // END

// ==================
// PHPINFO ==========
// ==================
$action = $_GET["action"];
if ($action == "phpinfo") { phpinfo(); die(); }
// ==================
// END PHPINFO ======
// ==================

} // End ISSET

// ==================
// NO ACTION ========
// ==================
if (!isset($_GET["action"])) {
echo "<p align=\"center\"><font face=\"Verdana\" color=\"#FF0000\"><B>This File Cannot Be Viewed Directly!</B></font></p>";
}
// ==================
// END NO ACTION ====
// ==================

?>
