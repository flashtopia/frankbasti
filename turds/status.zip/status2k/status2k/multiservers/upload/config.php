<?

// Windows Settings ::
$config = array();
$config['pagefile'] == "C:/pagefile.sys"; // Windows Pagefile.

// SSH2 Settings ::
$ssh2 = 0; // 1 To Enable, 0 To Disable
$ssh2user = "sshuser"; // SSH User
$ssh2pass = "sshpass"; // SSH Pass
$ssh2port = "22"; // SSH Port

?>
