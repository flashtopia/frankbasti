<?php

header('Content-Type: text/xml');

require('config.php');

echo <<<XML
<?xml version="1.0" encoding="iso-8859-1" ?>\n
<rss version="2.0">\n
<channel>\n
<title>Status2k News Feed</title>\n
XML;

$query = mysql_query("SELECT news, date FROM ".$prefix."news") or die ('News data unavailable, check install.');
while($results = mysql_fetch_array($query)){
$news = $results['news'];
$date = $results['date'];
echo "
<item>
<title>$date</title>
<description>$news</description>
<language>en-us</language>
</item>
";
}

echo '</channel></rss>';

?>
