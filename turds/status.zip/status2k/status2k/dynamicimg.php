<?php
require('config.php');
require('language/'.$config['langfile'].'/lang.php');

$urlto = $config['urlto'];
if ($config['dimgext']) { $ext = 'php'; } else { $ext = 'png'; }
?>

<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
</head>

<body>

<p align="center">
<img border="0" src="images/logo.gif"><BR>
<font face="Verdana" size="2"><a href="index.php"><?php echo $LANG['back']; ?></a> | <a href="admin/index.php">Admin Panel</a></font></p>
<div align="center">
	<table border="1" cellpadding="5" style="border-collapse: collapse" bordercolor="#C0C0C0">
		<tr>
			<td bgcolor="#EAEAEA"><b><font face="Verdana" size="2"><?php echo $LANG['orig']; ?></font></b></td>
			<td bgcolor="#EAEAEA">
			<p align="center"><b><font face="Verdana" size="2"><?php echo $LANG['htmcode']; ?></font></b></td>
		</tr>
		<tr>
			<td>
			<p align="center"><img border="0" src="images/dynamic/image.<?php echo $ext; ?>"></td>
			<td>
			<textarea rows="4" cols="33"><img src="<?php echo $urlto; ?>/images/dynamic/image.<?php echo $ext; ?>"></textarea></td>
		</tr>
		<tr>
			<td bgcolor="#EAEAEA"><b><font face="Verdana" size="2"><?php echo $LANG['smload']; ?></font></b></td>
			<td bgcolor="#EAEAEA">
			<p align="center"><b><font face="Verdana" size="2"><?php echo $LANG['htmcode']; ?></font></b></td>
		</tr>
		<tr>
			<td>
			<p align="center"><img border="0" src="images/dynamic/small.<?php echo $ext; ?>"></td>
			<td>
			<textarea rows="4" cols="33"><img src="<?php echo $urlto; ?>/images/dynamic/small.<?php echo $ext; ?>"></textarea></td>
		</tr>
		<tr>
			<td bgcolor="#EAEAEA">
			<b><font face="Verdana" size="2"><?php echo $LANG['smuptime']; ?></font></b></td>
			<td bgcolor="#EAEAEA">
			<p align="center"><b><font face="Verdana" size="2"><?php echo $LANG['htmcode']; ?></font></b></td>
		</tr>
		<tr>
			<td>
			<p align="center">
			<img border="0" src="images/dynamic/small.<?php echo $ext; ?>?type=uptime"></td>
			<td>
			<textarea rows="4" cols="33"><img src="<?php echo $urlto; ?>/images/dynamic/small.<?php echo $ext; ?>?type=uptime"></textarea></td>
		</tr>
		
		
		<tr>
			<td bgcolor="#EAEAEA">
			<b><font face="Verdana" size="2"><?php echo $LANG['smuptime']; ?></font></b></td>
			<td bgcolor="#EAEAEA">
			<p align="center"><b><font face="Verdana" size="2"><?php echo $LANG['htmcode']; ?></font></b></td>
		</tr>
		<tr>
			<td>
			<p align="center">
			<img border="0" src="images/dynamic/uptime.<?php echo $ext; ?>?type=1"></td>
			<td>
			<textarea rows="4" cols="33"><img src="<?php echo $urlto; ?>/images/dynamic/uptime.<?php echo $ext; ?>?type=1"></textarea></td>
		</tr>
		
		
		<tr>
			<td bgcolor="#EAEAEA">
			<b><font face="Verdana" size="2"><?php echo $LANG['smuptime']; ?></font></b></td>
			<td bgcolor="#EAEAEA">
			<p align="center"><b><font face="Verdana" size="2"><?php echo $LANG['htmcode']; ?></font></b></td>
		</tr>
		<tr>
			<td>
			<p align="center">
			<img border="0" src="images/dynamic/uptime.<?php echo $ext; ?>"></td>
			<td>
			<textarea rows="4" cols="33"><img src="<?php echo $urlto; ?>/images/dynamic/uptime.<?php echo $ext; ?>"></textarea></td>
		</tr>
		
		
		<tr>
			<td bgcolor="#EAEAEA">
			<b><font size="2" face="Verdana"><?php echo $LANG['smonline']; ?></font></b></td>
			<td bgcolor="#EAEAEA">
			<p align="center"><b><font face="Verdana" size="2"><?php echo $LANG['htmcode']; ?></font></b></td>
		</tr>
		<tr>
			<td>
			<p align="center">
			<img border="0" src="images/dynamic/small.<?php echo $ext; ?>?type=service&port=80&name=HTTP"><br>
			<br>
			<font size="1" face="Verdana" color="#FF0000">/small.<?php echo $ext; ?>?type=service&amp;port=80&amp;name=HTTP</font></td>
			<td>
			<textarea rows="4" cols="33"><img src="<?php echo $urlto; ?>/images/dynamic/small.<?php echo $ext; ?>?type=service&port=80&name=HTTP"></textarea></td>
		</tr>
		<tr>
			<td bgcolor="#EAEAEA">
			<b><font size="2" face="Verdana"><?php echo $LANG['smoffline']; ?></font></b></td>
			<td bgcolor="#EAEAEA">
			<p align="center"><b><font face="Verdana" size="2"><?php echo $LANG['htmcode']; ?></font></b></td>
		</tr>
		<tr>
			<td>
			<p align="center">
			<img border="0" src="images/dynamic/small.<?php echo $ext; ?>?type=service&port=123&name=Down"><br>
			<br>
			<font size="1" face="Verdana" color="#FF0000">/small.<?php echo $ext; ?>?type=service&amp;port=123&amp;name=Down</font></td>
			<td>
			<textarea rows="4" cols="33"><img src="<?php echo $urlto; ?>/images/dynamic/small.<?php echo $ext; ?>?type=service&port=123&name=Down"></textarea></td>
		</tr>
	</table>
</div>

</body>
</html>
