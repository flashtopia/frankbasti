DROP TABLE IF EXISTS `prefix_antiflood`;
CREATE TABLE `prefix_antiflood` (
  `ip_addr` varchar(48) NOT NULL,
  `time` varchar(14) NOT NULL,
  KEY `ip_addr` (`ip_addr`),
  KEY `time` (`time`)
);

DROP TABLE IF EXISTS `prefix_bandwidth`;
CREATE TABLE `prefix_bandwidth` (
  `rec` varchar(50) NOT NULL,
  `trans` varchar(50) NOT NULL
);

DROP TABLE IF EXISTS `prefix_config`;
CREATE TABLE `prefix_config` (
  `id` int(5) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `dname` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `type` varchar(255) NOT NULL,
  `options` varchar(255) NOT NULL,
  `size` varchar(5) NOT NULL,
  `os` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) AUTO_INCREMENT=31;

INSERT INTO `prefix_config` VALUES(1, 'pagefile', 'C:/pagefile.sys', 'PageFile', 'The location of your pagefile.sys file.', 'text', '0', '35', 'win');
INSERT INTO `prefix_config` VALUES(2, 'langfile', 'english', 'Language File', 'The language file you would like to use.', 'text', '0', '35', 'all');
INSERT INTO `prefix_config` VALUES(3, 'sname', 'Test Server', 'Server Name', 'Server name that appears on status2k main page.', 'text', '0', '35', 'all');
INSERT INTO `prefix_config` VALUES(4, 'urlto', 'http://www.yourdomain.com/status2k', 'URL', 'The full url to the status script.', 'text', '0', '40', 'all');
INSERT INTO `prefix_config` VALUES(5, 'liveloadt', '4', 'Load Refresh Time', 'Live load refresh time. (Reccomend: 3-5)', 'option', '1', '0', 'all');
INSERT INTO `prefix_config` VALUES(6, 'timeout', '2', 'Port Timeout', 'Time given to each service to respond, we recommend 1 or 2 seconds.', 'option', '1', '0', 'all');
INSERT INTO `prefix_config` VALUES(7, 'templaten', 'gecko', 'Template', 'Template you want to use.', 'text', '0', '30', 'all');
INSERT INTO `prefix_config` VALUES(8, 'emailaddress', 'email@yourdomain.com', 'E-Mail Address', 'E-Mail address you want reports sent to.', 'text', '0', '40', 'all');
INSERT INTO `prefix_config` VALUES(9, 'multiservers', '1', 'Enable Multiservers', 'Enable multiservers.', 'option', '3', '0', 'all');
INSERT INTO `prefix_config` VALUES(10, 'liveload', '1', 'Enable Liveload', 'Enable live load.', 'option', '3', '0', 'linux');
INSERT INTO `prefix_config` VALUES(11, 'liveadmin', '5', 'Admin Refresh Time', 'Refresh time for admin page.', 'option', '1', '0', 'all');
INSERT INTO `prefix_config` VALUES(12, 'dimgext', '1', 'Dynamic Images Ext', 'Dynamic images as php(true) or png(false) file.', 'option', '3', '0', 'linux');
INSERT INTO `prefix_config` VALUES(13, 'loadwarn', '5', 'Load Warn Level', 'Send warning e-mail when load is this amount or over.', 'text', '0', '10', 'all');
INSERT INTO `prefix_config` VALUES(14, 'fromaddy', 'you@yourdomain.com', 'From Address', 'The address report e-mails are sent from.', 'text', '0', '40', 'all');
INSERT INTO `prefix_config` VALUES(15, 'wnpro', '5', 'Warn Num Processes', 'Number of processes to send with warning e-mail.', 'text', '0', '10', 'all');
INSERT INTO `prefix_config` VALUES(16, 'newsnumb', '2', 'News Number', 'Number of news articles you want displayed on the main page.', 'text', '0', '2', 'all');
INSERT INTO `prefix_config` VALUES(17, 'cpuser', '', 'CP User', 'Directadmin/CPanel username with restart permissions.', 'text', '0', '8', 'linux');
INSERT INTO `prefix_config` VALUES(18, 'cppass', '', 'CP Pass', 'Password for above user.', 'password', '0', '14', 'linux');
INSERT INTO `prefix_config` VALUES(19, 'sshport', '22', 'SSH Port', 'The port your ssh service runs on.', 'text', '0', '6', 'linux');
INSERT INTO `prefix_config` VALUES(20, 'astatusurl', 'http://127.0.0.1/whm-server-status', 'Apache Status URL', 'The URL to Apache extended status.', 'text', '0', '45', 'all');
INSERT INTO `prefix_config` VALUES(21, 'ddrives', '/dev/shm,/var/tmp,/tmp', 'Disabled Drives', 'Drives you dont want displayed seperated by a comma.', 'text', '0', '35', 'linux');
INSERT INTO `prefix_config` VALUES(22, 'extraload', '0', 'ExtraLoad', 'Extra amount of load allowed before 100% load.', 'text', '0', '5', 'linux');
INSERT INTO `prefix_config` VALUES(23, 'skipclient', '0', 'SkipClient', 'Skip client page when viewing Status2k.', 'option', '3', '0', 'all');
INSERT INTO `prefix_config` VALUES(24, 'processtreecmd', '/usr/bin/env LANG=C pstree -c', 'ProcessTreeCMD', 'Command Used For Viewing Process Tree.', 'text', '0', '45', 'linux');
INSERT INTO `prefix_config` VALUES(25, 'eth', 'eth0', 'Network Int', 'Network Interface For Bandwidth Monitoring (Linux = eth0, BSD = em0).', 'text', '0', '5', 'linux');
INSERT INTO `prefix_config` VALUES(26, 'timesd', 'F j, Y, g:i a', 'Time Format', 'News Date & Time Format.', 'text', '0', '30', 'all');
INSERT INTO `prefix_config` VALUES(27, 'logcmd', '/usr/bin/tail -n 125 ', 'Log Tail', 'Command Used To View Logs.', 'text', '0', '45', 'all');
INSERT INTO `prefix_config` VALUES(28, 'logcmdlong', 'cat  ', 'Log Full', 'Command Used To View Full Logs.', 'text', '0', '30', 'all');
INSERT INTO `prefix_config` VALUES(30 , 'ver', '3.0', '', '', '', '', '', '');

DROP TABLE IF EXISTS `prefix_history`;
CREATE TABLE `prefix_history` (
  `min` int(2) NOT NULL,
  `hour` int(2) NOT NULL,
  `day` int(2) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(4) NOT NULL,
  `load` varchar(6) NOT NULL,
  `mem` int(12) NOT NULL,
  `swap` int(12) NOT NULL,
  `trans` varchar(50) NOT NULL,
  `rec` varchar(50) NOT NULL,
  KEY `date` (`day`,`month`,`year`)
);

DROP TABLE IF EXISTS `prefix_logs`;
CREATE TABLE `prefix_logs` (
  `id` int(5) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) AUTO_INCREMENT=7;

INSERT INTO `prefix_logs` VALUES(1, 'Error Log', '/usr/local/apache/logs/error_log');
INSERT INTO `prefix_logs` VALUES(2, 'Access Log', '/usr/local/apache/logs/access_log');
INSERT INTO `prefix_logs` VALUES(3, 'SuEXEC Log', '/usr/local/apache/logs/suexec_log');
INSERT INTO `prefix_logs` VALUES(4, 'SSL Log', '/usr/local/apache/logs/ssl_engine_log');
INSERT INTO `prefix_logs` VALUES(5, 'Dmesg Log', '/var/log/dmesg');
INSERT INTO `prefix_logs` VALUES(6, 'Mod Security', '/usr/local/apache/logs/audit_log');

DROP TABLE IF EXISTS `prefix_modules`;
CREATE TABLE `prefix_modules` (
  `id` int(5) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) AUTO_INCREMENT=3;

INSERT INTO `prefix_modules` VALUES(1, 'Hello World', 'helloworld.php');
INSERT INTO `prefix_modules` VALUES(2, 'Optimize MySQL', 'optimize.php');

DROP TABLE IF EXISTS `prefix_multiservers`;
CREATE TABLE `prefix_multiservers` (
  `id` int(5) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `host` varchar(255) NOT NULL default '',
  `services` varchar(255) NOT NULL default '',
  `statusurl` varchar(255) NOT NULL default '',
  `mstatusurl` varchar(255) NOT NULL default '',
  `sortnumb` int(3) NOT NULL,
  PRIMARY KEY  (`id`)
) AUTO_INCREMENT=3;

DROP TABLE IF EXISTS `prefix_news`;
CREATE TABLE `prefix_news` (
  `id` int(5) NOT NULL auto_increment,
  `news` varchar(255) NOT NULL default '',
  `date` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) AUTO_INCREMENT=4;

INSERT INTO `prefix_news` VALUES(3, 'Test News', '1st of January 2008');

DROP TABLE IF EXISTS `prefix_options`;
CREATE TABLE `prefix_options` (
  `id` int(5) NOT NULL auto_increment,
  `opid` int(5) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` int(5) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

INSERT INTO `prefix_options` VALUES(1, 1, '1 Second', '1');
INSERT INTO `prefix_options` VALUES(2, 1, '2 Seconds', '2');
INSERT INTO `prefix_options` VALUES(3, 1, '3 Seconds', '3');
INSERT INTO `prefix_options` VALUES(4, 1, '4 Seconds', '4');
INSERT INTO `prefix_options` VALUES(5, 1, '5 Seconds', '5');
INSERT INTO `prefix_options` VALUES(6, 1, '10 Seconds', '10');
INSERT INTO `prefix_options` VALUES(7, 1, '15 Seconds', '15');
INSERT INTO `prefix_options` VALUES(8, 1, '30 Seconds', '30');
INSERT INTO `prefix_options` VALUES(9, 1, '60 Seconds', '60');
INSERT INTO `prefix_options` VALUES(10, 3, 'True', '1');
INSERT INTO `prefix_options` VALUES(11, 3, 'False', '0');

DROP TABLE IF EXISTS `prefix_ports`;
CREATE TABLE `prefix_ports` (
  `id` int(5) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `host` varchar(255) NOT NULL default '',
  `port` int(10) NOT NULL default '0',
  `email` VARCHAR( 255 )NOT NULL,
  `up` int(25) NOT NULL default '0',
  `down` int(25) NOT NULL default '0',
  `trig` int(5) NOT NULL default '0',
  `sortnumb` int(3) NOT NULL default '0',
  `send` VARCHAR( 255 )NOT NULL,
  PRIMARY KEY  (`id`)
) AUTO_INCREMENT=11;

INSERT INTO `prefix_ports` VALUES(1, 'HTTP', 'localhost', 80, '', 0, 0, 0, 1, '');
INSERT INTO `prefix_ports` VALUES(2, 'FTP', 'localhost', 21, '', 0, 0, 0, 2, '');
INSERT INTO `prefix_ports` VALUES(3, 'POP3', 'localhost', 110, '', 0, 0, 0, 3, '');
INSERT INTO `prefix_ports` VALUES(4, 'SMTP', 'localhost', 25, '', 0, 0, 0, 4, '');
INSERT INTO `prefix_ports` VALUES(5, 'MySQL', 'localhost', 3306, '', 0, 0, 0, 5, '');
INSERT INTO `prefix_ports` VALUES(6, 'CPanel', 'localhost', 2082, '', 0, 0, 0, 6, '');
INSERT INTO `prefix_ports` VALUES(7, 'DNS', 'localhost', 53, '', 0, 0, 0, 7, '');
INSERT INTO `prefix_ports` VALUES(8, 'HTTPS', 'localhost', 443, '', 0, 0, 0, 8, '');

DROP TABLE IF EXISTS `prefix_users`;
CREATE TABLE `prefix_users` (
  `id` int(5) NOT NULL auto_increment,
  `adminuser` varchar(255) NOT NULL,
  `adminpass` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) AUTO_INCREMENT=2;

INSERT INTO `prefix_users` VALUES(1, 'useradmin', 'passadmin');
