DROP TABLE IF EXISTS `prefix_antiflood`;
CREATE TABLE `prefix_antiflood` (
`ip_addr` varchar(48) NOT NULL,
`time` varchar(14) NOT NULL,
KEY `ip_addr` (`ip_addr`),
KEY `time` (`time`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `prefix_modules`;
CREATE TABLE `prefix_modules` (
`id` int(5) NOT NULL auto_increment,
`name` VARCHAR( 255 ) NOT NULL ,
`location` VARCHAR( 255 ) NOT NULL,
PRIMARY KEY  (`id`)
) ENGINE = MYISAM AUTO_INCREMENT=1;

INSERT INTO `prefix_modules` VALUES (1, 'Hello World', 'helloworld.php');

DROP TABLE IF EXISTS `prefix_logs`;
CREATE TABLE `prefix_logs` (
`id` int(5) NOT NULL auto_increment,
`name` VARCHAR( 255 ) NOT NULL ,
`location` VARCHAR( 255 ) NOT NULL,
PRIMARY KEY  (`id`)
) ENGINE = MYISAM AUTO_INCREMENT=6;

INSERT INTO `prefix_logs` VALUES (1, 'Error Log', '/usr/local/apache/logs/error_log');
INSERT INTO `prefix_logs` VALUES (2, 'Access Log', '/usr/local/apache/logs/access_log');
INSERT INTO `prefix_logs` VALUES (3, 'SuEXEC Log', '/usr/local/apache/logs/suexec_log');
INSERT INTO `prefix_logs` VALUES (4, 'SSL Log', '/usr/local/apache/logs/ssl_engine_log');
INSERT INTO `prefix_logs` VALUES (5, 'Dmesg Log', '/var/log/dmesg');
INSERT INTO `prefix_logs` VALUES (6, 'Mod Security', '/usr/local/apache/logs/audit_log');

CREATE TABLE `prefix_bandwidth` (
`rec` VARCHAR( 50 ) NOT NULL ,
`trans` VARCHAR( 50 ) NOT NULL
) ENGINE = MYISAM ;

ALTER TABLE `prefix_history` ADD `trans` VARCHAR( 50 ) NOT NULL, ADD `rec` VARCHAR( 50 ) NOT NULL ;

ALTER TABLE `prefix_multiservers` ADD `sortnumb` INT(3) NOT NULL ;

INSERT INTO `prefix_config` (`id`, `name`, `value`, `dname`, `description`, `type`, `options`, `size`, `os`) VALUES ('', 'skipclient', 'false', 'SkipClient', 'Skip client page when viewing Status2k.', 'option', '3', '0', 'all');
