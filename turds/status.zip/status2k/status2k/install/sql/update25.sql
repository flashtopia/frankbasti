ALTER TABLE `prefix_multiservers` DROP `phpinfo`;
ALTER TABLE `prefix_ports` ADD `email` VARCHAR( 255 ) NOT NULL AFTER `port`;
ALTER TABLE `prefix_ports` ADD `send` VARCHAR( 255 ) NOT NULL;

DROP TABLE IF EXISTS `prefix_options`;
CREATE TABLE `prefix_options` (
  `id` int(5) NOT NULL auto_increment,
  `opid` int(5) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` int(5) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

INSERT INTO `prefix_options` VALUES(1, 1, '1 Second', '1');
INSERT INTO `prefix_options` VALUES(2, 1, '2 Seconds', '2');
INSERT INTO `prefix_options` VALUES(3, 1, '3 Seconds', '3');
INSERT INTO `prefix_options` VALUES(4, 1, '4 Seconds', '4');
INSERT INTO `prefix_options` VALUES(5, 1, '5 Seconds', '5');
INSERT INTO `prefix_options` VALUES(6, 1, '10 Seconds', '10');
INSERT INTO `prefix_options` VALUES(7, 1, '15 Seconds', '15');
INSERT INTO `prefix_options` VALUES(8, 1, '30 Seconds', '30');
INSERT INTO `prefix_options` VALUES(9, 1, '60 Seconds', '60');
INSERT INTO `prefix_options` VALUES(10, 3, 'True', '1');
INSERT INTO `prefix_options` VALUES(11, 3, 'False', '0');

DROP TABLE IF EXISTS `prefix_config`;
CREATE TABLE `prefix_config` (
  `id` int(5) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `dname` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `type` varchar(255) NOT NULL,
  `options` varchar(255) NOT NULL,
  `size` varchar(5) NOT NULL,
  `os` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) AUTO_INCREMENT=31;

INSERT INTO `prefix_config` VALUES(1, 'pagefile', 'C:/pagefile.sys', 'PageFile', 'The location of your pagefile.sys file.', 'text', '0', '35', 'win');
INSERT INTO `prefix_config` VALUES(2, 'langfile', 'english', 'Language File', 'The language file you would like to use.', 'text', '0', '35', 'all');
INSERT INTO `prefix_config` VALUES(3, 'sname', 'Test Server', 'Server Name', 'Server name that appears on status2k main page.', 'text', '0', '35', 'all');
INSERT INTO `prefix_config` VALUES(4, 'urlto', 'http://www.yourdomain.com/status2k', 'URL', 'The full url to the status script.', 'text', '0', '40', 'all');
INSERT INTO `prefix_config` VALUES(5, 'liveloadt', '4', 'Load Refresh Time', 'Live load refresh time. (Reccomend: 3-5)', 'option', '1', '0', 'all');
INSERT INTO `prefix_config` VALUES(6, 'timeout', '2', 'Port Timeout', 'Time given to each service to respond, we recommend 1 or 2 seconds.', 'option', '1', '0', 'all');
INSERT INTO `prefix_config` VALUES(7, 'templaten', 'original', 'Template', 'Template you want to use.', 'text', '0', '30', 'all');
INSERT INTO `prefix_config` VALUES(8, 'emailaddress', 'email@yourdomain.com', 'E-Mail Address', 'E-Mail address you want reports sent to.', 'text', '0', '40', 'all');
INSERT INTO `prefix_config` VALUES(9, 'multiservers', '1', 'Enable Multiservers', 'Enable multiservers.', 'option', '3', '0', 'all');
INSERT INTO `prefix_config` VALUES(10, 'liveload', '1', 'Enable Liveload', 'Enable live load.', 'option', '3', '0', 'linux');
INSERT INTO `prefix_config` VALUES(11, 'liveadmin', '5', 'Admin Refresh Time', 'Refresh time for admin page.', 'option', '1', '0', 'all');
INSERT INTO `prefix_config` VALUES(12, 'dimgext', '1', 'Dynamic Images Ext', 'Dynamic images as php(true) or png(false) file.', 'option', '3', '0', 'linux');
INSERT INTO `prefix_config` VALUES(13, 'loadwarn', '5', 'Load Warn Level', 'Send warning e-mail when load is this amount or over.', 'text', '0', '10', 'all');
INSERT INTO `prefix_config` VALUES(14, 'fromaddy', 'you@yourdomain.com', 'From Address', 'The address report e-mails are sent from.', 'text', '0', '40', 'all');
INSERT INTO `prefix_config` VALUES(15, 'wnpro', '5', 'Warn Num Processes', 'Number of processes to send with warning e-mail.', 'text', '0', '10', 'all');
INSERT INTO `prefix_config` VALUES(16, 'newsnumb', '2', 'News Number', 'Number of news articles you want displayed on the main page.', 'text', '0', '2', 'all');
INSERT INTO `prefix_config` VALUES(17, 'cpuser', '', 'CP User', 'Directadmin/CPanel username with restart permissions.', 'text', '0', '8', 'linux');
INSERT INTO `prefix_config` VALUES(18, 'cppass', '', 'CP Pass', 'Password for above user.', 'password', '0', '14', 'linux');
INSERT INTO `prefix_config` VALUES(19, 'sshport', '22', 'SSH Port', 'The port your ssh service runs on.', 'text', '0', '6', 'linux');
INSERT INTO `prefix_config` VALUES(20, 'astatusurl', 'http://127.0.0.1/whm-server-status', 'Apache Status URL', 'The URL to Apache extended status.', 'text', '0', '45', 'all');
INSERT INTO `prefix_config` VALUES(21, 'ddrives', '/dev/shm,/var/tmp,/tmp', 'Disabled Drives', 'Drives you dont want displayed seperated by a comma.', 'text', '0', '35', 'linux');
INSERT INTO `prefix_config` VALUES(22, 'extraload', '0', 'ExtraLoad', 'Extra amount of load allowed before 100% load.', 'text', '0', '5', 'linux');
INSERT INTO `prefix_config` VALUES(23, 'skipclient', '0', 'SkipClient', 'Skip client page when viewing Status2k.', 'option', '3', '0', 'all');
INSERT INTO `prefix_config` VALUES(24, 'processtreecmd', '/usr/bin/env LANG=C pstree -c', 'ProcessTreeCMD', 'Command Used For Viewing Process Tree.', 'text', '0', '45', 'linux');
INSERT INTO `prefix_config` VALUES(25, 'eth', 'eth0', 'Network Int', 'Network Interface For Bandwidth Monitoring (Linux = eth0, BSD = em0).', 'text', '0', '5', 'linux');
INSERT INTO `prefix_config` VALUES(26, 'timesd', 'jS \\of F Y', 'Time Format', 'News Date & Time Format.', 'text', '0', '30', 'all');
INSERT INTO `prefix_config` VALUES(27, 'logcmd', '/usr/bin/tail -n 125 ', 'Log Tail', 'Command Used To View Logs.', 'text', '0', '45', 'all');
INSERT INTO `prefix_config` VALUES(28, 'logcmdlong', 'cat  ', 'Log Full', 'Command Used To View Full Logs.', 'text', '0', '30', 'all');
INSERT INTO `prefix_config` VALUES(30 , 'ver', '2.5', '', '', '', '', '', '');