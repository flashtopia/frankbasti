<p style="margin: 60px auto">
Copyright 2005 - <?php date_default_timezone_set('Europe/London'); echo date("Y"); ?> Status2K - All Rights Reserved
</p>
</div>
</div>
</body>

</html>
