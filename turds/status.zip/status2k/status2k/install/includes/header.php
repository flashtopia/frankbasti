<?

// Declare Variables
$pagename = NULL;
$page = NULL;

$page = $_GET['page'];
if (!isset($page)) { $pagename = "Start"; $img1 = "start.gif"; }
else if ($page == 1) { $pagename = "Info"; $img2 = "info.gif"; }
else if ($page == 2) { $pagename = "Update Info"; $img2 = "info.gif"; }
else if ($page == 3) { $pagename = "Run SQL"; $img3 = "runsql.gif"; }
else if ($page == 4) { $pagename = "Finish"; $img4 = "finish.gif"; }
else { die(); }
?>

<html>

<head>
  <meta http-equiv="Content-Language" content="en-us">
  <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
  <title>Status2k Install - <?php echo $pagename; ?></title>
  <link rel="stylesheet" href="http://twitter.github.com/bootstrap/1.3.0/bootstrap.min.css">
</head>

<body>
<div class="content">
<div style="width: 600px;margin: 60px auto">

<ul class="breadcrumb">
  <li><a href="/install">Start</a></li>
  <span class="divider">/</span>
  <?php if ($page > 0) { ?>
    <li><a href="/install?page=1">Information</a></li>
    <span class="divider">/</span>
  <?php } ?>
  <?php if ($page > 1) { ?>
    <li><a href="/install?page=1">Run SQL</a></li>
    <span class="divider">/</span>
  <?php } ?>
  <?php if ($page > 2) { ?>
    <li><a href="/install?page=1">Finished</a></li>
    <span class="divider">/</span>
  <?php } ?>
</ul>
