<?php

// Status2k v3.0 Install File

include("includes/header.php");

$page = $_GET['page'];

if (!isset($page)) {
echo '
<h3>New Installation of Status2K (recommended)</h3>
<p>If this is your first time installing then please select the option above as this will install all tables and SQL data needed to run the script. Also select this option if you are updating from version 1.9.</p>
<div class="btn success">
  <a href="index.php?page=1" style="color: white">Install Status2K</a>
</div>

<h3>Status2K Upgrade</h3>
<p>If you have previously installed Status2k and wish to update please select this option, please note that if you are updating from version 1.9 or earlier then you must perform a fresh install.</p>
<div class="btn info">
  <a href="index.php?page=2" style="color: white">Upgrade Status2K</a>
</div>
';
} else if ($page == "1") {
echo '
<form method="POST" action="index.php?page=3" class="form-stacked">
  <input type="hidden" name="sql" value="install.sql">
  <fieldset>
    <legend>Information</legend>
    <div class="clearfix">
      <label>Administrator Username</label>
      <div class="input">
        <input type="text" class="xlarge" name="user" size="20">
      </div>
    </div>
    <div class="clearfix">
      <label>Administrator Email</label>
      <div class="input">
        <input type="text" name="emil" class="xlarge" size="20">
      </div>
    </div>
    <div class="clearfix">
      <label>Administrator Password</label>
      <div class="input">
        <input type="password" name="pass" class="xlarge" size="20">
      </div>
    </div>
  </fieldset>
  <div class="actions">
    <button type="submit" class="btn primary" value="Continue &gt;&gt;">Continue &gt;&gt;</button>
  </div>
</form>
';
} else if ($page == "2") {
echo '
<form method="POST" action="index.php?page=3" class="form-stacked">
  <input type="hidden" name="sql" value="install.sql">
  <fieldset>
    <legend>Please select the correct update from below.</legend>
    <div class="clearfix">
      <label>Version</label>
      <div class="input">
        <select size="1" name="sql">
          <option value="update25.sql" selected>Update v2.4 To v2.5</option>
          <option value="update24.sql" selected>Update v2.3 To v2.4</option>
        </select>
      </div>
    </div>
  </fieldset>
  <div class="actions">
    <button type="submit" class="btn primary" value="Continue &gt;&gt;">Continue &gt;&gt;</button>
  </div>
</form>
';
} else if ($page == "3") {
$install = 1;
require_once("../config.php");
$sql = $_POST['sql'];

if ($sql == "install.sql") {
$sqlfile = file("sql/".$sql);
$dump = "";

$user = $_POST['user'];
$pass = sha1($_POST['pass']);
$emp = $_POST['emil'];

foreach ($sqlfile as $line) {
if (trim($line)!='' && substr(trim($line),0,1)!='#') {
$line = str_replace("useradmin", $user, $line);
$line = str_replace("passadmin", $pass, $line);
$line = str_replace("prefix_", $prefix, $line);
$line = str_replace("email@yourdomain.com", $emp, $line);
$dump .= trim($line);
}
}

$dump = trim($dump,';');
$tables = explode(';',$dump);

foreach ($tables as $sql) {
mysql_query($sql) or die('Error! Install Failed: ' . mysql_error());
}

$host = $_SERVER["SERVER_ADDR"];
$address = $_SERVER["HTTP_HOST"];
$address .= $_SERVER["PHP_SELF"];
$address = ereg_replace("/install/sql.php", "", $address);

$msg = "
Status Script Installed:
Address: http://$address
Host IP: $host
";

$msg = stripslashes($msg);

} else if ($sql) {

$sqlfile = file("sql/".$sql);
$dump = "";

foreach ($sqlfile as $line) {
if (trim($line)!='' && substr(trim($line),0,1)!='#') {
$line = str_replace("prefix_", $prefix, $line);
$dump .= trim($line);
}
}

$dump = trim($dump,';');
$tables = explode(';',$dump);

foreach ($tables as $sql) {
mysql_query($sql) or die('Error! Update Failed: ' . mysql_error());
}

} else if (!$sql) {
echo "No SQL File Selected!";
}
echo '
<h3>If no errors appeared above the script was installed successfully!</h3>

<a href="index.php?page=4" class="btn success" style="color:white">Continue >></a>
';
} else if ($page == "4") {
echo '
<h3>Thanks for choosing Status2k for your server monitoring solution.</h3>
<p>Please remove the <code>/install/</code> directory before continuing!</p>
';
}

include("includes/footer.php");

?>
