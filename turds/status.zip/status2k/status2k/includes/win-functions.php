<?php

$wmi = new COM("WinMgmts:\\\\.") or die("WMI Failed!");

// ==========================================
// System Control Panel
// ==========================================
if (file_exists('c:/program files/webhost automation/helm')) { $theconp = 'Helm'; }
elseif ($_SERVER['plesk_dir']) { $theconp = 'Plesk'; }
else { $theconp = $LANG['notav']; }
// ==========================================
// System Control Panel End
// ==========================================

// ==========================================
// CPU Info
// ==========================================
$cpu_load = 0;
$cpu_num = getenv('NUMBER_OF_PROCESSORS');
$cpus = $wmi->ExecQuery("Select Name, MaxClockSpeed, LoadPercentage from Win32_Processor");

if(version_compare('4.50.0', PHP_VERSION) == 1) {
// PHP 4
while ($cpu = $cpus->Next()) {
$cpu_name = $cpu->Name;
$cpu_mhz = $cpu->MaxClockSpeed;
$cpu_load = $cpu_load+$cpu->LoadPercentage;
}
} else {
// PHP 5
foreach($cpus as $cpu) {
$cpu_name = $cpu->Name;
$cpu_mhz = $cpu->MaxClockSpeed;
$cpu_load = $cpu_load+$cpu->LoadPercentage;
}
}

$load_total = round($cpu_load/$cpu_num,2);

// ==========================================
// CPU Info End
// ==========================================

// ==========================================
// Uptime
// ==========================================

$winos = $wmi->ExecQuery("Select LastBootUpTime, LocalDateTime, Name, TotalVisibleMemorySize, FreePhysicalMemory from Win32_OperatingSystem");

if(version_compare('4.50.0', PHP_VERSION) == 1) {
// PHP 4
while ($win = $winos->Next()) {
$lastboot = $win->LastBootUpTime;
$localtime = $win->LocalDateTime;
$compname = $win->Name;
$mem_total = $win->TotalVisibleMemorySize/1024;
$mem_free = $win->FreePhysicalMemory/1024;
}
} else {
// PHP 5
foreach ($winos as $win) {
$lastboot = $win->LastBootUpTime;
$localtime = $win->LocalDateTime;
$compname = $win->Name;
$mem_total = $win->TotalVisibleMemorySize/1024;
$mem_free = $win->FreePhysicalMemory/1024;
}
}

$mem_used = $mem_total - $mem_free;
$memorypercent = percent($mem_used,$mem_total);

$byear = intval(substr($lastboot, 0, 4));
$bmonth = intval(substr($lastboot, 4, 2));
$bday = intval(substr($lastboot, 6, 2));
$bhour = intval(substr($lastboot, 8, 2));
$bminute = intval(substr($lastboot, 10, 2));
$bseconds = intval(substr($lastboot, 12, 2));

$lyear = intval(substr($localtime, 0, 4));
$lmonth = intval(substr($localtime, 4, 2));
$lday = intval(substr($localtime, 6, 2));
$lhour = intval(substr($localtime, 8, 2));
$lminute = intval(substr($localtime, 10, 2));
$lseconds = intval(substr($localtime, 12, 2));
$boottime = mktime($bhour, $bminute, $bseconds, $bmonth, $bday, $byear);
$localtime = mktime($lhour, $lminute, $lseconds, $lmonth, $lday, $lyear);

$uptimesec = $localtime - $boottime;

$allswap = $wmi->ExecQuery("Select AllocatedBaseSize, CurrentUsage from Win32_PageFileUsage");

if(version_compare('4.50.0', PHP_VERSION) == 1) {
// PHP 4
while ($swap = $allswap->Next()) {
$swap_total = $swap->AllocatedBaseSize;
$swap_used = $swap->CurrentUsage;
}
} else {
// PHP 5
foreach ($allswap as $swap) {
$swap_total = $swap->AllocatedBaseSize;
$swap_used = $swap->CurrentUsage;
}
}

// ==========================================
// Uptime End
// ==========================================



// ==========================================
// Hard Drives
// ==========================================

if (!$skip) {
$drives = array('C','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X');

foreach ($drives as $drive) {
$disksp = @(int)(disk_total_space("$drive:") / 1073741824);
if ($disksp) {
$diskspu = @(int)(disk_free_space("$drive:") / 1073741824);
$diskspuc = ($disksp - $diskspu);
$diskcper = percent($diskspuc,$disksp);

$diskspace .= "
<tr><td width=\"70%\" colspan=\"3\">
<div align=\"center\">
<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse: collapse\" bordercolor=\"#111111\" width=\"100%\">
<tr><td width=\"20%\"><b>$drive:\ :</b></td>
<td width=\"60%\">
<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse: collapse\" bordercolor=\"#111111\" width=\"100%\">
<tr><td width=\"1\"><img border=\"0\" src=\"templates/original/images/sides.png\" width=\"1\"></td>
<td width=\"$diskcper%\"><img border=\"0\" src=\"templates/original/images/red.png\" width=\"100%\" height=\"10\"></td>
<td width=\"100%\"><img border=\"0\" src=\"templates/original/images/green.png\" width=\"100%\" height=\"10\"></td>
<td width=\"1\"><img border=\"0\" src=\"templates/original/images/sides.png\" width=\"1\"></td>
</tr></table></td>
<td width=\"8%\" align=\"center\"><B>$diskcper%</B></td>
<td width=\"12%\">$diskspuc GB / $disksp GB</td>
</tr></table></div></td></tr>";
}
}

}
// ==========================================
// Hard Drives End
// ==========================================

// Get Windows Name
function winosname() {

$buildnum = php_uname('v');
$vernum = php_uname('r');

$buildnum = str_replace('build ', '', $buildnum);

if ($vernum == '5.0' && $buildnum = '2195') {
$os = 'Windows 2000';
} elseif ($vernum == '5.1' && $buildnum = '2600') {
$os = 'Windows XP';
} elseif ($vernum == '5.2' && $buildnum = '3790') {
$os = 'Windows Server 2003';
} elseif ($vernum == '6.0') {
$os = 'Windows Vista';
} else {
$os = $LANG['notav'];
}
return $os;
}

// Webserver Version
$version['webver'] = str_replace('/',' ',getenv('SERVER_SOFTWARE'));

?>
