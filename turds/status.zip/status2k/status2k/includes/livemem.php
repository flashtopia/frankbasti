<?php

require('../config.php');

if (isset($enablegzip) && $enablegzip == 1) { ob_start('ob_gzhandler'); }

require('functions.php');
require('../language/'.$config['langfile'].'/lang.php');

// Check OS
$os = checkos();

if (isset($os['linux'])) { require('linux-functions.php'); }
if (isset($os['freebsd'])) { require('bsd-functions.php'); }

if (isset($os['windows'])) {
require('win-functions.php');

echo '<div class="main-text">' . $mem_used . '</div>
<div><span class="main-text-label">/ ' . $mem_total .'</span></div>';
} else {


// Get Memory.
$memory = memory();

echo '<div class="main-text">' . size_bytes($memory['used']) . '</div>
<div><span style="padding-left: 20px" class="main-text-label">/ ' . size_bytes($memory['total']) .'</span></div>';

}

?>
