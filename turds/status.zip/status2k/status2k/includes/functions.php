<?php
/*
   $past = time()-1;
   $mysql->query("DELETE FROM ".$prefix."antiflood WHERE time < '".$past."'");
   $mysql->query("INSERT INTO ".$prefix."antiflood (ip_addr, time) VALUES ('".$_SERVER['REMOTE_ADDR']."', '".time()."')");
   $sql = $mysql->query("SELECT ip_addr FROM ".$prefix."antiflood WHERE ip_addr = '".$_SERVER['REMOTE_ADDR']."'");
   $numrow = $mysql->numrows($sql);
   if ($numrow > 5) { die('<br><br><center><font face=\"Verdana\" size=\"3\" color=\"red\"><b>Possible Denial Of Service Attack Detected!</b></font><BR><font face=\"Verdana\" size=\"1\">Please wait 3 seconds before reloading the page.</font></center>'); }
 */
// Check The OS Function
function checkos() {
  if (PHP_OS=='Linux') { $os['linux'] = 1; }
  if (substr(PHP_OS,0,3)=='WIN') { $os['windows'] = 1; }
  if (PHP_OS=='FreeBSD') { $os['freebsd'] = 1; }
  return $os;
}

// ==========================================
// Functions For All Operating Systems
// ==========================================

// CPU Image
function cpuimage($model) {
  if ( eregi('AMD Opteron', $model) ) {
    $cpuimg = '<img src="images/cpus/amdopteron.gif" alt="AMD Opteron">';
  } elseif ( eregi("Xeon", $model) ) {
    $cpuimg = '<img src="images/cpus/xeon.gif" alt="Xeon">';
  } elseif ( eregi('Intel\(R\) Core', $model) ) {
    $cpuimg = '<img src="images/cpus/core2.gif" alt="Intel Core2 Duo">';
  } elseif ( eregi('Pentium\(R\) D', $model) ) {
    $cpuimg = '<img src="images/cpus/pd.gif" alt="Pentium D">';
  } elseif ( eregi('Pentium\(R\) 4', $model) ) {
    $cpuimg = '<img src="images/cpus/p4.gif" alt="Pentium 4">';
  } elseif ( eregi('Pentium III', $model) ) {
    $cpuimg = '<img src="images/cpus/p3.gif" alt="Pentium 3">';
  } elseif ( eregi('Pentium 2', $model) ) {
    $cpuimg = '<img src="images/cpus/p2.gif" alt="Pentium 2">';
  } elseif ( eregi('AMD Duron', $model) ) {
    $cpuimg = '<img src="images/cpus/amdduron.gif" alt="AMD Duron">';
  } elseif ( eregi('AMD Sempron', $model) ) {
    $cpuimg = '<img src="images/cpus/amdsempron.gif" alt="AMD Sempron">';
  } elseif ( eregi('AMD Athlon', $model) ) {
    $cpuimg = '<img src="images/cpus/amdathlon.gif" alt="AMD Athlon">';
  } elseif ( eregi('Celeron', $model) ) {
    $cpuimg = '<img src="images/cpus/celeron.gif" alt="Celeron">';
  } else {
    $cpuimg = 'Unknown';
  }
  return $cpuimg;
}

// Process Services
function services() {
  global $prefix, $config, $LANG, $mysql;
  $count = 0;
  $services = NULL;
  $query = $mysql->query("SELECT host, name, port, up, down, sortnumb FROM ".$prefix."ports ORDER BY sortnumb");
  while($results = mysql_fetch_array($query)){
    $ip =  $results['host'];
    $name = $results['name'];
    $portnum = $results['port'];
    $up = $results['up'];
    $down = $results['down'];
    if (!empty($results['send'])) { $send = $results['send']; }

    if ($down == "0") {
      $uptime = 100;
    } else {
      $downtime = ($down / $up * 100);
      $uptime = round((100 - $downtime), 2);
    }

    ++$count;
    $services .= check($ip,$portnum,$count,$name,$uptime,$send);

    if($count == 2){$count = 0;}
  }
  return $services;
} // End Function

function multiservers() {
  global $prefix, $config, $LANG, $mysql;
  $query = $mysql->query("SELECT host, name, services, statusurl, mstatusurl FROM ".$prefix."multiservers ORDER BY sortnumb");
  if (!$mysql->numrows($query)) { // If No Servers
    return '<div style="padding-left: 15px">No Other Servers.</div>';
  } else {

    // Get Template
    ob_start();
    include("templates/".$config['templaten']."/multi.tpl");
    $mpage = ob_get_contents();
    ob_end_clean();

    // Cleanup Template
    $remove = array("\r\n", "\n", "\r");
    $mpage = str_replace($remove, '', $mpage);

    // Seperate Template
    preg_match('/\<!--TOP--\>(.*?)\<!--END_TOP--\>/', $mpage, $status_top);
    preg_match('/\<!--MAIN--\>(.*?)\<!--END_MAIN--\>/', $mpage, $status_main);

    while($result = mysql_fetch_array($query)){

      // Set Data
      $status_top_new = NULL;
      $status_main_new = NULL;

      // MySQL Data
      $serveraddy = $result['host'];
      $server = $result['name'];
      $services = $result['services'];
      $statusurl = $result['statusurl'];
      $q = $result['mstatusurl']."?action=stat";

      // Fetch Remote Data
      if ($result['mstatusurl']) {
        if (function_exists('curl_version')) {
          $newch = curl_init();
          curl_setopt($newch, CURLOPT_URL, $q);
          curl_setopt($newch, CURLOPT_HEADER, 0);
          curl_setopt($newch, CURLOPT_USERAGENT, 'Status2k');
          curl_setopt($newch, CURLOPT_RETURNTRANSFER, 1);
          curl_setopt($newch, CURLOPT_CONNECTTIMEOUT, 10);
          $filecontents = @curl_exec($newch);
          curl_close($newch);
        } else { $filecontents = @file_get_contents($q); }

        preg_match('/\<load\>(.*?)\<\/load\>/', $filecontents, $load);
        preg_match('/\<uptime\>(.*?)\<\/uptime\>/', $filecontents, $uptime);
        preg_match('/\<os\>(.*?)\<\/os\>/', $filecontents, $os);
        $load = $load[1];
        $uptime = $uptime[1];
        $os = $os[1];
      }

      if (!$load) { $load = $LANG['notav']; }
      if (!$uptime) { $uptime = $LANG['notav']; }
      if (!$os) { $os = 'na'; }

      // Start Services HTTP:80|FTP:21
      if ($services) {
        $service = explode("|", $services);
        foreach ($service as $port) {
          $serv = explode(":", $port);
          $name = $serv[0];
          $port = $serv[1];

          $status_top_new .= str_replace('{name}', $name, $status_top[1]);

          $status = @fsockopen($serveraddy, $port, $errno, $errstr, $config['timeout']);
          if ($status) { 
            $status = '<span class="label success">UP</span>'; 
          } else { 
            $status = '<span class="label important">DOWN</span>'; 
          }

          $status_main_new .= str_replace('{status}', $status, $status_main[1]);

        } // End Foreach
      } // End Services

      // Put Template Together
      ++$num;
      $multiserver[$num] = $mpage;
      $multiserver[$num] = str_replace($status_top[0], $status_top_new, $multiserver[$num]);
      $multiserver[$num] = str_replace($status_main[0], $status_main_new, $multiserver[$num]);
      $multiserver[$num] = str_replace("{muptime}", $uptime, $multiserver[$num]);
      $multiserver[$num] = str_replace("{load}", $load, $multiserver[$num]);
      $multiserver[$num] = str_replace("{os}", $os, $multiserver[$num]);
      if ($statusurl) {
        $multiserver[$num] = str_replace("{server}", "<a href=\"$statusurl\">".$server."</a>", $multiserver[$num]);
      } else {
        $multiserver[$num] = str_replace("{server}", $server, $multiserver[$num]);
      }
      $mpage = str_replace('class="multi-header"', 'class="multi-header" style="display: none"', $mpage);

    } // End MySQL While

    // Put Multiservers Together
    foreach ($multiserver as $multi) {
      $multiservers .= $multi;
    }

    return $multiservers;
  } // End If
} // End Function


function news() {
  global $prefix, $config, $mysql;
  $thenews = NULL;
  if ($config['newsnumb'] == 0) {
    $thenews = '<img border="0" src="images/logo.gif" alt="Status2k">';
  } else {
    $query = $mysql->query("SELECT news, date FROM ".$prefix."news ORDER BY id DESC LIMIT ".$config['newsnumb']);
    while($results = mysql_fetch_array($query)){
      $news =  $results['news'];
      $date = $results['date'];
      if (!$thenews) { $thenews = '<BR><img src="images/news.gif" alt="News"><BR><BR>'; }
      $thenews .= "$news - <B>$date</B><BR><BR>";
    } // End While
  } // End Else
  return $thenews;
} // End Function

function check($iph,$portnum,$count,$name,$uptime,$send) {
  global $config;
  $status = @fsockopen($iph, $portnum, $errno, $errstr, $config['timeout']);

  if ($send) {
    include('servicechecks.php');
    $status = checkservice($send, $iph, $portnum);
  }

  if ($count == 1) { $colour = " class=\"servicestd\""; } else { $colour = " class=\"servicestdbg\""; }
  if ($status) { $type = "success"; $salt = "UP"; } else { $type = "important"; $salt = "DOWN"; }
  $services = "
    <tr".$colour.">
    <td width='25%' style='padding-left: 15px'><strong>$name</strong></td>
    <td width='50%'>$portnum</td>
    <td>$uptime%</td>
    <td><span class='label $type'>$salt</span></td>
    </tr>";
  @fclose($status);
  return $services;
}

// Percent Function
function percent($value,$total) {
  if ($value && $total) { $percent = round(($value / $total * 100), 1); } else { $percent = 0; }
  return $percent;
}

// Bar Function
function bar($percent,$display,$name,$tip,$template) {
  $thebar = '<tr><td width="25%" style="padding-left: 20px"><strong>'.$name.'</strong><td width="50%">';
  $thebar .= '<div class="meter orange"><span style="width: '.$percent.'%"></span></div>';
  $thebar .= '</td><td><span class="drv-percent">'.$percent.'%</span><strong>&nbsp;'.$display.'</strong></td></tr>';
  return $thebar;
}

// Uptime Function
function uptime($LANG,$uptime) {
  $days = floor($uptime/60/60/24);
  $hours = ($uptime/60/60%24);
  $minutes = ($uptime/60%60);
  $secs = ($uptime%60);
  if ($days == 1) {$writeDays = $LANG['day'];} else {$writeDays = $LANG['days'];}
  if ($hours == 1) {$writeHours = $LANG['hour']; } else {$writeHours = $LANG['hours'];}
  if ($minutes == 1) {$writeMins = $LANG['min'];} else {$writeMins = $LANG['mins'];}
  if ($secs == 1) {$writeSecs = $LANG['sec'];} else {$writeSecs = $LANG['secs'];}
  $timeup = "$days $writeDays, $hours $writeHours, $minutes $writeMins, $secs $writeSecs";
  return $timeup;
}

// Versions Function
function versions() {
  global $LANG;
  $version = array();
  if (function_exists('apache_get_version')) {
    $apver = @apache_get_version();
    $apverexp = explode(' ', $apver);
    $version['apache'] = str_replace('Apache/', '', $apverexp[0]);
  }
  $version['mysql'] = mysql_get_server_info();
  $version['php'] = phpversion();
  if (getenv('COMPUTERNAME')) { $version['compname'] = getenv('COMPUTERNAME'); } else { $version['compname'] = str_replace('www.', '', $_SERVER['SERVER_NAME']); $version['compname'] = strtoupper($version['compname']); }
  if ($_ENV['OS']) { $version['winver'] = str_replace ('_', ' ', $_ENV['OS']); } else { $version['winver'] = $LANG['notav']; }
  $version['serversoft'] = str_replace('/', ' ', $_SERVER["SERVER_SOFTWARE"]);
  $version['serverdate'] = date('r');
  return $version;
}

function cmdrun($cmd) {
  global $connection,$ssh2;

  if (!$ssh2) {
    $result = shell_exec($cmd);
  } else if ($ssh2 && function_exists('ssh2_exec')) {
    ob_start();
    $stream = ssh2_exec($connection, $cmd);
    stream_set_blocking($stream, 1);
    echo stream_get_contents($stream);
    $result = ob_get_contents();
    fclose($stream);
    ob_end_clean();
  }

  return $result;
}

function size_bytes($size) {
  $bytes = array('MB','GB','TB');
  foreach($bytes as $val) {
    if($size >= 1024){ $size = $size / 1024; } else { break; }
  }
  return round($size,0)." ".$val;
}

function check_login()
{
  $lgtrue = 0;

  $q = mysql_query("SELECT * FROM ".$prefix."users");
  while($res = mysql_fetch_array($q)){
    $adminuser = $res['adminuser']; // Login Database
    $adminpass = $res['adminpass']; // Pass Database
    $adminper = $res['adminper']; // Admin Permissions

    if ( isset($_COOKIE["S2KUser"]) && isset($_COOKIE["S2KPass"]) ) {

      $cusername = $_COOKIE["S2KUser"];
      $cpassword = $_COOKIE["S2KPass"];

      if ( ($cusername == $adminuser) && ($cpassword == $adminpass) ) { $lgtrue = 1; }

    } // End Cookie

  } // End While

  if (!$lgtrue) { header("Location: ../login.php"); }
}
?>
