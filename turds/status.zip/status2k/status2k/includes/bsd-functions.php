<?php

function bsdsys($key) {
return cmdrun("/sbin/sysctl -n ".$key);
}

function drives() {
global $config;
$ddrives = explode(",", $config['ddrives']);

$x = cmdrun("df -h");
$drives = explode("\n", $x);

$count = 0;
foreach ($drives as $drivea) {

foreach ($ddrives as $ddrive) {
if ($drivea && eregi($ddrive, $drivea)) { $drivea=0; }
} // End Foreach

list($drive[$count], $size[$count], $used[$count], $avail[$count], $percent[$count], $mount[$count]) = split(" +", $drivea);

if ($count > 0 && $percent[$count]) {
$display = $used[$count] . "B / " . $size[$count] . "B"; // Add B for Bytes.
$percent[$count] = eregi_replace("%", "", $percent[$count]); // Add Percentage
$hdds .= "<tr><td align=\"center\" colspan=\"3\">";
$hdds .= bar($percent[$count],$display,$mount[$count] . ":",$mount[$count].": = ".$percent[$count]."%",$config['templaten']);
$hdds .= "</td></tr>";
}

$count++;
} // End Foreach									
return $hdds;
}

function load() {
$piece = bsdsys("vm.loadavg");
$piece = ereg_replace('{ ', '', $piece);
$piece = ereg_replace(' }', '', $piece);
$piece = explode(" ",$piece);
return $piece;
}

function uptimeseconds() {
$s = bsdsys("kern.boottime | awk '{print \$4}'");
$uptime = time() - $s;
return $uptime;
}

// CPU Info Function
function cpuinfo() {

$cpuinfo = file("/var/run/dmesg.boot");
for ($i = 0; $i < count($cpuinfo); $i++) {
list($item, $data) = split(":", $cpuinfo[$i], 2);
$item = chop($item);
$data = chop($data);
if ($item == "CPU") { $cpu_info = $data; }
if ($item == "cpu0") { $total_cpus = "1"; }
if ($item == "cpu1") { $total_cpus = "2"; }
if ($item == "cpu2") { $total_cpus = "3"; }
if ($item == "cpu3") { $total_cpus = "4"; }
}

$preg = preg_match('/(.*) CPU (.*)GHz \((.*)-MHz (.*)\)/', $cpu_info, $result);
$cpuinf['name'] = $result[1];
$cpuinf['mhz'] = $result[3];
$cpuinf['total'] = $total_cpus;

return $cpuinf;
}

function memory() {

$totalmem = bsdsys('hw.physmem'); //in bytes

$top = cmdrun('top');
$split = split("\n", $top);
for ($i = 0, $max = sizeof($split); $i < $max; $i++) {
$bu = preg_split("/\s+/", $split[$i], 19);

$p = 1024;

if ($i == 3) {
$active = ereg_replace("M", "", $bu[1]); $active = ($active*$p*$p); // Active
$inact = ereg_replace("M", "", $bu[3]); $inact = ($inact*$p*$p); // Inactive
$wired = ereg_replace("M", "", $bu[5]); $wired = ($wired*$p*$p); // Kernel
$cache = ereg_replace("M", "", $bu[7]); $cache = ($cache*$p*$p); // From Disk
$buf = ereg_replace("M", "", $bu[9]); $buf = ($buf*$p*$p); // From Disk
$free = ereg_replace("M", "", $bu[11]); $free = ($free*$p*$p); // Unused Memory
}

}

$memused = ($totalmem - $inact - $cache - $free);

$memory['used'] = $memused/$p;
$memory['total'] = $totalmem/$p;

$memory['swaptotal'] = 0;
$memory['swapused'] = 0;
$stat = cmdrun("/usr/sbin/swapinfo -k");
$lines = split("\n", $stat);

for ($i = 1, $max = sizeof($lines); $i < $max; $i++) {
$arbuf = preg_split("/\s+/", $lines[$i], 6);
if ($arbuf[0] != 'Total') {
$memory['swaptotal'] = $memory['swaptotal'] + $arbuf[1];
$memory['swapused'] = $memory['swapused'] + $arbuf[2];
}
} 

$memory['swapused'] = $memory['swapused']/1024;
$memory['swaptotal'] = $memory['swaptotal']/1024;

return $memory;
}


function distro() {
$distro = "FreeBSD";
return $distro;
}

?>
