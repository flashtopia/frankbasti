<?php

class mysql_class {
var $connection;
var $select;
var $query;
var $config;
var $fetch;

function connect() {
global $dbhost, $dbuser, $dbpass,$db;
$connection = mysql_connect($dbhost,$dbuser,$dbpass);
$select = mysql_select_db($db,$connection);
}

function query($query) {
$result = mysql_query($query);
if (!$result) { echo 'Could not run query: ' . mysql_error(); exit; }
return $result;
}

function numrows($query) {
$result = mysql_num_rows($query);
return $result;
}

function close() {
if ($connection) { mysql_close($connection); }
}

function fetchconfig() {
global $prefix, $install;
if (!isset($install)) {
$query = $this->query("SELECT name, value FROM ".$prefix."config");
while($results = mysql_fetch_array($query)){
$config[$results['name']] = $results['value'];
}
}
return $config;
}

} // End Class

// Start Class
$mysql = new mysql_class();

// Connect To Database
$mysql->connect();

// Fetch Config Data
$config = $mysql->fetchconfig();

?>
