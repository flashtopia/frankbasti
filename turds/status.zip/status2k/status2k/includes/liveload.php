<?php

require('../config.php');

if (isset($enablegzip) && $enablegzip == 1) { ob_start('ob_gzhandler'); }

require('functions.php');
require('../language/'.$config['langfile'].'/lang.php');

// Check OS
$os = checkos();

if (isset($os['linux'])) { require('linux-functions.php'); }
if (isset($os['freebsd'])) { require('bsd-functions.php'); }

if (isset($os['windows'])) {
require('win-functions.php');

echo'<div class="main-text">' . $load_total . '<span class="main-text-label">/' . $load_total . '</span></div></div>';
} else {

// Number Of CPUs.
$cpuinf = cpuinfo();

// Get Load.
$loadnow = load();

echo'<div class="main-text">' . $loadnow[0] . '<span class="main-text-label">/' . $cpuinf['total'] . '</span></div>
<div style="padding: 0 20px">
<div style="float: left"><span><strong>' . $loadnow[1] . '</strong></span><br />5 mins.</div>
<div style="float: right"><span><strong>' . $loadnow[2] . '</strong></span><br />15 mins.</div>
</div>';

}

?>
