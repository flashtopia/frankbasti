<?php

function checkservice($check, $ip, $port) {
global $config, $LANG;

// =====================================
// Check Half-Life
// =====================================
if ($check == "HL") {
$fp = fsockopen('udp://' . $ip, $port, $errno, $errstr, $config['timeout']);
if ($fp) {
$ServerinfoCommand = "\377\377\377\377infostring\0";
fwrite($fp, $ServerinfoCommand);
$JunkHead = fread($fp,24);
$CheckStatus = socket_get_status($fp);
if ($CheckStatus["unread_bytes"] == 0) { return 0; } else { return 1; }
}
}

// =====================================
// Check SAMP
// =====================================
if ($check == "SAMP") {
$fp = fsockopen('udp://' . $ip, $port, $errno, $errstr, $config['timeout']);
if ($fp) {
$packet = 'SAMP';
$packet .= chr(strtok($ip, '.'));
$packet .= chr(strtok('.'));
$packet .= chr(strtok('.'));
$packet .= chr(strtok('.'));
$packet .= chr($port & 0xFF);
$packet .= chr($port >> 8 & 0xFF);
$packet = ";s";
fwrite($fp, $packet);
$samponline = fread($fp, 8);
if ($samponline) { return 1; } else { return 0; }
}
}

// =====================================
// Check For Text On Webpage
// =====================================
if (eregi('TEXT:', $check)) {
$check = str_replace('TEXT:', '', $check);
$exploded = explode('|', $check);
$url = $exploded[0];
$text = $exploded[1];
if (function_exists('curl_version')) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, 'Status2k');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $config['timeout']);
curl_setopt($ch, CURLOPT_TIMEOUT, $config['timeout']);
$value = curl_exec($ch);
curl_close($ch);
} else {
$value = file_get_contents($url); if (!$value) { $value = implode('', file($url)); }
}
if (eregi($text, $value)) { return 1; } else { return 0; }
}

// =====================================
// IP Ping Check
// =====================================
if ($check == "PING") {
$handle = @fsockopen('udp://'.$ip, 7, $errno, $errstr, $config['timeout']);
if ($handle) {
stream_set_timeout($handle, $config['timeout']);
$write = fwrite($handle,"echo this\n");
if(!$write){ return 0; }
fread($handle,1024);
list($usec, $sec) = explode(" ", microtime(true));
$laptime=((float)$usec + (float)$sec)-$start;
if($laptime>$config['timeout']) { return 0; } else { return 1; }
fclose($handle);
}
}

} // End Function

?>
