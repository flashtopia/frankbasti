<?php

// ==========================================
// HardDrive/Partion Usage Info
// ==========================================
function drives() {
  global $config;
  $ddrives = explode(',', $config['ddrives']);

  $x = cmdrun('df -h');
  $drives = explode("\n", $x);

  $count = 0;
  $hdds = NULL;
  $drivea = NULL;
  $drive = array();
  foreach ($drives as $drivea) {

    foreach ($ddrives as $ddrive) {
      if ($ddrive && $drivea && eregi($ddrive, $drivea)) { $drivea=NULL; }
    } // End Foreach

    $drive = split(" +", $drivea);
    if ($count > 0 && isset($drive[4])) {
      $display = $drive[2] . 'B / ' . $drive[1] . 'B'; // Add B for Bytes.
      $drive[4] = str_replace('%', '', $drive[4]);
      $hdds .= bar($drive[4],$display,$drive[5] . ':',$drive[5].': = '.$drive[4],$config['templaten']);
    }

    ++$count;

  } // End Foreach
  return $hdds;
}

// ==========================================
// Load Function
// ==========================================
function load() {
  $reguptime = cmdrun('cat /proc/loadavg');
  $piece = explode(' ', $reguptime);
  return $piece;
}

// ==========================================
// Uptime In Seconds
// ==========================================
function uptimeseconds() {
  $uptimel = cmdrun('cat /proc/uptime');
  $uptimel = split(' ',$uptimel);
  return $uptimel[0];
}

// ==========================================
// Distro Image Function
// ==========================================
function distroimage($distro) {
  $distro = strtolower($distro);
  if ( eregi('centos', $distro) ) {
    $distroimg = '<img src="images/distros/centos.gif" alt="CentOS">';
  } elseif ( eregi('debian', $distro) ) {
    $distroimg = '<img src="images/distros/debian.gif" alt="Debian">';
  } elseif ( eregi('fedora', $distro) ) {
    $distroimg = '<img src="images/distros/fedora.gif" alt="Fedora">';
  } elseif ( eregi('freebsd', $distro) ) {
    $distroimg = '<img src="images/distros/freebsd.gif" alt="FreeBSD">';
  } elseif ( eregi('gentoo', $distro) ) {
    $distroimg = '<img src="images/distros/gentoo.gif" alt="Gentoo">';
  } elseif ( eregi('mandrake', $distro) ) {
    $distroimg = '<img src="images/distros/mandrake.gif" alt="Mandrake">';
  } elseif ( eregi('redhat', $distro) ) {
    $distroimg = '<img src="images/distros/redhat.gif" alt="RedHat">';
  } elseif ( eregi('slackware', $distro) ) {
    $distroimg = '<img src="images/distros/slackware.gif" alt="Slackware">';
  } elseif ( eregi('suse', $distro) ) {
    $distroimg = '<img src="images/distros/suse.gif" alt="SuSe">';
  } else {
    $distroimg = '<img src="images/distros/linux.gif" alt="Linux">';
  }
  return $distroimg;
}

// ==========================================
// Find Distro Name
// ==========================================
function distro() {
  $distro = NULL;
  $distros = array('/etc/debian_release','/etc/debian_version','/etc/SuSE-release','/etc/UnitedLinux-release','/etc/mandrake-release','/etc/gentoo-release','/etc/redhat_version','/etc/redhat-release','/etc/fedora-release','/etc/slackware-release','/etc/slackware-version','/etc/trustix-release','/etc/trustix-version','/etc/eos-version','/etc/arch-release','/etc/lsb-release','/etc/gentoo-release','/etc/cobalt-release','/etc/lfs-release','/etc/rubix-version');

  foreach ($distros as $file) {
    if (file_exists($file) && !$distro) {
      $distro = file_get_contents($file);
    } // End If
  } // End Foreach

  if (!$distro) {
    foreach ($distros as $file) {
      if (!$distro) {
        $distro = cmdrun('cat '.$file);
      } // End If
    } // End Foreach
  } // End If

  if (!$distro) { $distro = 'Unknown'; } // No Distro Found

  return $distro;
}

// ==========================================
// Memory Function
// ==========================================
function memory() {
  $meminf = cmdrun('cat /proc/meminfo');

  $meminfo = explode("\n", $meminf);
  foreach ($meminfo as $memin) {
    $memin = str_replace(' kB', '', $memin);
    $memor = explode(':', $memin);
    if (isset($memor[0])) { $item = rtrim($memor[0]); }
    if (isset($memor[1])) { $data = rtrim($memor[1]); }

    if ($item == 'MemTotal') { $total_mem =$data;	}
    if ($item == 'MemFree') { $free_mem = $data; }
    if ($item == 'SwapTotal') { $total_swap = $data; }
    if ($item == 'SwapFree') { $free_swap = $data; }
    if ($item == 'Buffers') { $buffer_mem = $data; }
    if ($item == 'Cached') { $cache_mem = $data; }
    if ($item == 'MemShared') {$shared_mem = $data; }
  }

  $memused = ($total_mem - $free_mem - $cache_mem - $buffer_mem);
  $swapused = ($total_swap - $free_swap);

  $memory['used'] = $memused/1024;
  $memory['total'] = $total_mem/1024;

  $memory['swapused'] = $swapused/1024;
  $memory['swaptotal'] = $total_swap/1024;

  return $memory;
}

// ==========================================
// CPU Info Function
// ==========================================
function cpuinfo() {
  global $config;
  $cpuinfoo = cmdrun('cat /proc/cpuinfo');
  $cpuinfo = explode("\n", $cpuinfoo);
  $cpuinf = array();
  $cpuinf['total'] = 0;
  foreach ($cpuinfo as $cpuin) {
    $cpui = explode(':', $cpuin);
    if (isset($cpui[0])) { $item = rtrim($cpui[0]); }
    if (isset($cpui[1])) { $data = rtrim($cpui[1]); }
    if ($item == 'processor') { ++$cpuinf['total']; }
    if ($item == 'model name') { $cpuinf['name'] = $data; }
    if ($item == 'cpu MHz') { $cpuinf['mhz'] = $data; }
  }
  return $cpuinf;
}

?>
