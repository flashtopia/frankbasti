<?php
require('config.php');
require('language/'.$config['langfile'].'/lang.php');

// ==========================================
// CRON FUNCTIONS
// ==========================================

// Check OS Function
function checkos() {
  $windows = 0;
  $linux = 0;
  $freebsd = 0;
  if (substr(PHP_OS,0,3)=='WIN') { $os['windows'] = 1; }
  if (PHP_OS=='FreeBSD') { $os['freebsd'] = 1; }
  if (PHP_OS=='Linux') { $os['linux'] = 1; }
  return $os;
}

// Percent Function
function percent($value,$total) {
  if ($value && $total) { $percent = round(($value / $total * 100), 1); } else { $percent = 0; }
  return $percent;
}

// Command Run Function
function cmdrun($cmd) {
  global $connection,$ssh2;

  if (!$ssh2) {
    $result = shell_exec($cmd);
  } else if ($ssh2 && function_exists('ssh2_exec')) {
    ob_start();
    $stream = ssh2_exec($connection, $cmd);
    stream_set_blocking($stream, 1);
    echo stream_get_contents($stream);
    $result = ob_get_contents();
    fclose($stream);
    ob_end_clean();
  }

  return $result;
}

// BSD Network Function
function network () {
  $netstat = cmdrun('netstat -nibd | grep Link');
  $lines = split("\n", $netstat);
  $results = array();
  for ($i = 0, $max = sizeof($lines); $i < $max; $i++) {
    $ar_buf = preg_split("/\s+/", $lines[$i]);
    if (!empty($ar_buf[0])) {
      $results[$ar_buf[0]] = array();

      if (strlen($ar_buf[3]) < 15) {
        $results[$ar_buf[0]]['rx_bytes'] = $ar_buf[5];
        $results[$ar_buf[0]]['tx_bytes'] = $ar_buf[8];
      } else {
        $results[$ar_buf[0]]['rx_bytes'] = $ar_buf[6];
        $results[$ar_buf[0]]['tx_bytes'] = $ar_buf[9];
      }

    } 
  } 
  return $results;
}

// Multiple E-Mail Addresses Function
function mmail ($subject, $msg, $email) {
  global $config, $LANG;
  if (!$email) { $email = $config['emailaddress']; }
  if (eregi(',', $email)) {
    $emails = explode(',', $email);
    foreach ($emails as $email) { mail($email, $subject, $msg, 'From: '.$config['fromaddy']); }
  } else {
    mail($email, $subject, $msg, 'From: '.$config['fromaddy']);
  }
}

// ==========================================
// CRON PROCESS
// ==========================================

// Check OS
$os = array();
$os = checkos();
if ($os['windows']) { $skip = 1; include("includes/win-functions.php"); }
if ($os['linux']) { include("includes/linux-functions.php"); $load = load(); $memoryinfo = memory(); }
if ($os['freebsd']) { include("includes/bsd-functions.php"); $load = load(); $memoryinfo = memory(); }

// Service Stats
$queryyy = $mysql->query("SELECT * FROM ".$prefix."ports");
while($resultss = mysql_fetch_array($queryyy)){
  $id = $resultss['id'];
  $ip = $resultss['host'];
  $name = $resultss['name'];
  $portnum = $resultss['port'];
  $up = $resultss['up'];
  $down = $resultss['down'];
  $trigger = $resultss['trig'];
  $send = $resultss['send'];
  $status = @fsockopen($ip, $portnum, $errno, $errstr, $config['timeout']);

  if (!empty($send)) {
    include('includes/servicechecks.php');
    $status = checkservice($send, $ip, $portnum);
  }

  if ($status) {
    $up = ($up + 1);
    $mysql->query("UPDATE ".$prefix."ports SET up = '$up', trig = '0' WHERE id = '$id' LIMIT 1");
  } else {
    if ($up > $down) { $down = ($down + 1); }
    $mysql->query("UPDATE ".$prefix."ports SET down = '$down', trig = '1' WHERE id = '$id' LIMIT 1");
    if (!$trigger) {
      mmail($name.' '.$LANG['sdown'], date("l, jS \of F Y h:i:s A")."\n".$name.' '.$LANG['sdown'].'! On '.$config['sname'].' ('.$ip.')', $resultss['email']);
          }
          } // End Else
          } // End While

          // Check For High Load
          if ($load[0] > $config['loadwarn']) {
          $highestrunning = cmdrun("ps -e -o pcpu,cputime,args --sort pcpu | tail -" . $config['wnpro']);
          $pieces = explode("\n", $highestrunning);
          $pieces = array_reverse($pieces);
          foreach ($pieces as $piece) { $processes .= $piece . "\n"; }
          $timesd = date("l jS \of F Y @ h:i:s A");
          $message = "$timesd\n".$LANG['loadwar']."\n".$LANG['loadmail']." ".$load['0']."\n".$config['sname']." (".$ip.")\n\nHigh Processes:\n$processes";
          mmail($LANG['loadwar'], $message, 0);
          }

          // Process Multiserver Services
          $query = $mysql->query("SELECT host, name, services FROM ".$prefix."multiservers");
          while($results = mysql_fetch_array($query)){
          $serveraddy = $results['host'];
          $server = $results['name'];
          $portss = $results['services'];
          $portss = explode("|", $portss);
          foreach ($portss as $portt) {
            $portt = explode(":", $portt);
            $servicenamee = $portt[0];
            $serviceipp = $portt[1];

            $theservice = @fsockopen($serveraddy, $serviceipp, $errno, $errstr, $config['timeout']);

            if (!$theservice && $config['emailaddress']) {
              $timesd = date("l jS \of F Y h:i:s A");
              $message = "$timesd\n$servicenamee ".$LANG['sdown'].' On '.$server. '!';
              mmail("$server - $servicenamee ".$LANG['sdown'], $message, 0);
            } // End If
          } // End Foreach
          } // End While

// History Data Collection
if ($os['linux'] || $os['freebsd']) {
  $min = date("i");
  $hour = date("G");
  $day = date("j");
  $month = date("n");
  $year = date("Y");
  $currentload = $load['0'];
  $usedmem = $memoryinfo['used'];
  $usedswap = $memoryinfo['swapused'];
} else {
  $min = date("i");
  $hour = date("G");
  $day = date("j");
  $month = date("n");
  $year = date("Y");
  $currentload = $load_total;
  $usedmem = $mem_used;
  $usedswap = $swap_used;
}

// Calculating Bandwidth LINUX
if ($os['linux']) {
  /*$net = cmdrun("netstat -n -i | grep '".$config['eth']."' | awk '{ print $4, $8 }'");
  //$net = cmdrun("ifconfig -a ".$config['eth']." | grep 'RX bytes' | awk '{ print $2, $6 }'");
  $remstr = array("\r\n", "\n", "\r", '-', 'bytes:');
  $net = str_replace($remstr, '', $net);
  $pts = explode(' ',$net);
  $recvd = $pts[0]; // RX
  $trans = $pts[1]; // TX
   */
  $net = cmdrun("netstat -i | grep \"^".$config['eth']."\" | awk '{ print $4, $8 }'");
  $remstr = array("\r\n", "\n", "\r", '-');
  $net = str_replace($remstr, '', $net);
  $pts = explode(' ',$net);
  $trans = $pts[0]; // RX
  $recvd = $pts[1]; // TX
}

// Calculating Bandwidth BSD
if ($os['freebsd']) {
  $net = network();
  $recvd = $net[$config['eth']]['rx_bytes'];
  $trans = $net[$config['eth']]['tx_bytes'];
}

// Work Out Bandwidth Stats
$query = $mysql->query("SELECT * FROM ".$prefix."bandwidth");
$results = mysql_fetch_array($query);
$dbr = $results['rec'];
$dbt = $results['trans'];
if (!$dbr && !$dbt) {
  $mysql->query("INSERT INTO ".$prefix."bandwidth VALUES ('".$recvd."', '".$trans."')");
} else {
  if ($recvd < $dbr && $trans < $dbt) {
    $rech = $recvd;
    $transh = $trans;
    $mysql->query("UPDATE ".$prefix."bandwidth SET rec = '".$recvd."', trans = '".$trans."'");
  } else {
    $rech = ($recvd - $dbr);
    $transh = ($trans - $dbt);
    $mysql->query("UPDATE ".$prefix."bandwidth SET rec = '".$recvd."', trans = '".$trans."'");
  }
}

// If Bandwidth Empty
if ($transh < 0) { $transh = $trans; }
if ($rech < 0) { $rech = $recvd; }

// ================================================
// Add Data To Database
// ================================================

$mysql->query("INSERT INTO ".$prefix."history VALUES ('$min', '$hour', '$day', '$month', '$year', '$currentload', '$usedmem', '$usedswap', '$transh', '$rech')");

?>
