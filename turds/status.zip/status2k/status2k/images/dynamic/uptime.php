<?php 

if (isset($_GET['type'])) { $type = $_GET['type']; }

require_once("../../config.php");
require_once("../../language/".$config['langfile']."/lang.php");

$queryy = mysql_query("SELECT * FROM ".$prefix."ports WHERE port = '80'");
$resultss = mysql_fetch_array($queryy);

$up = $resultss['up'];
$down = $resultss['down'];

if ($up >= 1) {
$downtime = ($down / $up * 100);
$uptime = (100 - $downtime);
$uptime = round($uptime, 2);
} else {
$uptime = 100;
}

if (!$type) { // START TYPE 2
$font = "../../includes/fonts/slkscr.ttf";
$text = $uptime."%";
$image = @imagecreatefromgif("bgs/uptime.gif");
$clr_white = imagecolorallocate($image, 255, 255, 255);
if (function_exists('imagettftext')) { imagettftext($image, 7, 0, 44, 10, $clr_white, $font, $text); } else { imagestring($image, 2, 31, 9, $text, $clr_white); }

} else { // START TYPE 1
$font = "../../includes/fonts/verdana.ttf";
$text = $LANG['uptim']." $uptime%";
$image = imagecreatefromgif("bgs/smalluptime.gif");
$clr_white = imagecolorallocate($image, 0, 0, 0);
if (function_exists('imagettftext')) { imagettftext ($image, 8, 0, 30, 19, $clr_white, $font, $text); } else { imagestring($image, 2, 31, 9, $text, $clr_white); }
}

// Failed Image
if (!$image) {
$image = imagecreatetruecolor (165, 28);
$bgc = imagecolorallocate ($image, 255, 255, 255);
$tc = imagecolorallocate ($image, 0, 0, 0);
imagefilledrectangle ($image, 0, 0, 165, 28, $bgc);
imagestring ($image, 4, 5, 5, "Error Loading Image!", $tc);
}

if (function_exists("imagepng")) {
header("Content-type: image/png");
imagepng($image);
} elseif (function_exists("imagejpeg")) {
header("Content-type: image/jpeg");
imagejpeg($image, "", 100);
} elseif (function_exists("imagegif")) {
header("Content-type: image/gif");
imagegif($image);
} else {
die("No image support in this PHP server");
}
imagedestroy($image); 
?>
