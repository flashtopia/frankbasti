<?php 

require("../../config.php");
require("../../language/".$config['langfile']."/lang.php");
require("../../includes/functions.php");

$os = checkos(); // Check The Operating System.

if (isset($os['linux'])) {
require("../../includes/linux-functions.php");
$load = load();
$theload = $load[0];
$uptime = uptimeseconds();
} else if (isset($os['windows'])) {
require("../../includes/win-functions.php");
$theload = $load_total."%";
$uptime = $uptimesec;
} else if (isset($os['freebsd'])) {
require("../../includes/bsd-functions.php");
$load = load();
$theload = $load[0];
$uptime = uptimeseconds();
}

// Check Uptime
$days = floor($uptime/60/60/24);
$hours = $uptime/60/60%24;
$mins = $uptime/60%60;
$secs = $uptime%60;

// Check Services Function
function serviceup($port) {
$service = @fsockopen('localhost', $port, $e, $er, 2);
$status = NULL;
if (isset($service)) { $status = 'Online'; } else { $status = 'Offline'; }
return $status;
}

// Check Services
$httpstat = serviceup(80);
$ftpstat = serviceup(21);
$popstat = serviceup(110);
$sqlstat = serviceup(3306);

$image = @imagecreatefromgif("bgs/bg.gif");

$clr_black = imagecolorallocate($image, 0, 0, 0);
$sname = $config['sname'];
$text1 = "SERVER NAME: $sname";
$text2 = "HTTP : $httpstat";
$text3 = "FTP : $ftpstat";
$text4 = "POP3 : $popstat";
$text7 = "MYSQL : $sqlstat";
$text5 = "$days Days $hours:$mins:$secs";
$text6 = $theload;

imagestring($image, 2, 69, 5, $text1, $clr_black); 
imagestring($image, 2, 326, 32, $text2, $clr_black); 
imagestring($image, 2, 326, 44, $text3, $clr_black); 
imagestring($image, 2, 326, 56, $text4, $clr_black); 
imagestring($image, 2, 326, 68, $text7, $clr_black); 
imagestring($image, 2, 120, 68, $text6, $clr_black); 
imagestring($image, 2, 140, 28, $text5, $clr_black); 

if (!$image) {
$image = imagecreatetruecolor (165, 28);
$bgc = imagecolorallocate ($image, 255, 255, 255);
$tc = imagecolorallocate ($image, 0, 0, 0);
imagefilledrectangle ($image, 0, 0, 165, 28, $bgc);
imagestring ($image, 4, 5, 5, "Error Loading Image!", $tc);
}

if (function_exists("imagepng")) {
header("Content-type: image/png");
imagepng($image);
} else if (function_exists("imagejpeg")) {
header("Content-type: image/jpeg");
imagejpeg($image, "", 100);
} else if (function_exists("imagegif")) {
header("Content-type: image/gif");
imagegif($image);
} else {
die("No image support in this PHP server");
}

imagedestroy($image); 

?>
