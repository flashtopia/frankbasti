<?php 

require("../../config.php");
require("../../language/".$config['langfile']."/lang.php");
require("../../includes/functions.php");

$font = "../../includes/fonts/verdana.ttf"; // Font To Use
$os = checkos(); // Check The Operating System.
$type = $_GET['type']; // Get Type

if (!$type || $type == "uptime") {
if (isset($os['linux'])) {
require("../../includes/linux-functions.php");
$load = load();
$theload = $load[0];
$uptime = uptimeseconds();
} else if (isset($os['windows'])) {
require("../../includes/win-functions.php");
$theload = $load_total."%";
$uptime = $uptimesec;
} else if (isset($os['freebsd'])) {
require("../../includes/bsd-functions.php");
$load = load();
$theload = $load[0];
$uptime = uptimeseconds();
}
}

// =====================================
// Check Load
// =====================================
if (!$type) {
$text = $LANG['curlod']." ".$theload;
$image = imagecreatefromgif("bgs/smallload.gif");
$clr_white = imagecolorallocate($image, 0, 0, 0);
if (function_exists('imagettftext')) { imagettftext($image, 8, 0, 30, 19, $clr_white, $font, $text); } else { imagestring($image, 2, 31, 9, $text, $clr_white); }
} // End Load

// =====================================
// Check Uptime
// =====================================
if ($type == "uptime") {
$days = floor($uptime/60/60/24);
$hours = $uptime/60/60%24;
$mins = $uptime/60%60;
$secs = $uptime%60;
$text = $LANG['uptim']." $days ".$LANG['days']." $hours:$mins:$secs";
$image = imagecreatefromgif("bgs/smalluptime.gif");
$clr_white = imagecolorallocate($image, 0, 0, 0);
if (function_exists('imagettftext')) {
imagettftext ($image, 8, 0, 30, 19, $clr_white, $font, $text); } else { imagestring($image, 2, 31, 9, $text, $clr_white); }
} // End Uptime

// =====================================
// Check Service
// =====================================
if ($type == "service") {
if (!$_GET["ip"]) { $shost = "localhost"; } else { $shost = $_GET["ip"]; }
$service = @fsockopen($shost, $_GET["port"], $errno, $errstr, 5);
if ($service) { $service = $LANG['onlin']; } else { $service = $LANG['offlin']; }
$text = $_GET["name"]." ".$LANG['sev']." ".$service;
if ($service == $LANG['onlin']) { $image = imagecreatefromgif("bgs/service.gif"); } else if ($service == $LANG['offlin']) { $image = imagecreatefromgif("bgs/servicedown.gif"); }
$clr_white = imagecolorallocate($image, 0, 0, 0);
if (function_exists('imagettftext')) { imagettftext ($image, 8, 0, 31, 19, $clr_white, $font, $text); } else { imagestring($image, 2, 30, 9, $text, $clr_white); }
}

// Check If Image Loaded
if (!$image) {
$image = imagecreatetruecolor (165, 28);
$bgc = imagecolorallocate ($image, 255, 255, 255);
$tc = imagecolorallocate ($image, 0, 0, 0);
imagefilledrectangle ($image, 0, 0, 165, 28, $bgc);
imagestring ($image, 4, 5, 5, "Error Loading Image!", $tc);
}

// Create Image
if (function_exists("imagepng")) {
header("Content-type: image/png");
imagepng($image);
} elseif (function_exists("imagejpeg")) {
header("Content-type: image/jpeg");
imagejpeg($image, '', 100);
} elseif (function_exists("imagegif")) {
header("Content-type: image/gif");
imagegif($image);
} else {
die("No image support in this PHP server");
}

// Destroy Image
imagedestroy($image);

?>
