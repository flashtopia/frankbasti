<?php

// -----------------------------------------------------------------------//
// CONFIG HERE
// -----------------------------------------------------------------------//

/* Database Settings */
$dbhost = 'localhost'; // MySQL Host
$dbuser = 'dbuser'; // Database User
$dbpass = 'dbpass'; // Database Password
$db = 'dbname'; // Database Name
$prefix = 's2k_'; // Database Prefix

/* SSH2 Settings */
$ssh2 = 0; // 1 To Enable, 0 To Disable
$ssh2user = 'sshuser'; // SSH User
$ssh2pass = 'sshpass'; // SSH Pass
$ssh2port = '22'; // SSH Port

/* Alert Settings */
$msnaccount = ''; // http://www.status2k.com/forum/index.php?showtopic=955
$clickatelluser = ''; // Clickatell User
$clickatellpass = ''; // Clickatell Pass
$clickatellid = ''; // Clickatell ID
$smsnumber = ''; // SMS Number

/* Other Settings */
$dev = 1; // Development Mode
$enablegzip = 0; // Enable GZip Page Compression

// -----------------------------------------------------------------------//
// DO NOT EDIT PAST THIS POINT!!!
// -----------------------------------------------------------------------//

if ($dev) { error_reporting(E_ERROR | E_WARNING | E_PARSE); } else { error_reporting(0); }
if ($ssh2) { $connection = ssh2_connect('localhost', $ssh2port); ssh2_auth_password($connection, $ssh2user, $ssh2pass); }
require 'includes/db.php';

?>
