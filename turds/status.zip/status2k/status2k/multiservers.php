<?php

include('config.php');
include('includes/functions.php');
include('language/'.$config['langfile'].'/lang.php');

$reload = 30000;
if(isset($_GET['reload'])) {
  $reload = $_GET['reload'];
}

echo '
<!DOCTYPE html>
<html><head>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="templates/'.$config['templaten'].'/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="templates/'.$config['templaten'].'/css/style.css">
<title>Status 2k - MultiServers</title>
<script type="text/javascript" src="templates/'.$config['templaten'].'/javascript/jquery.min.js"></script>
<script type="text/javascript">
  $(function() {

    setInterval(function() {       
      $("#multi-table").load("livemulti.php");    
    }, ' . $reload . ');    
  });
</script>
</head><body><div class="container"><div class="info-box"><table id="multi-table">
';

if ($config['multiservers']) { echo multiservers(); } else { echo 'Multi-Servers Disabled'; }

echo '<table></div></div></body></html>';

?>
