/********************************************************/
/* Status 2K - ScribbyTech                              */
/* By: Richard Simpson                                  */
/* scribby@scribbytech.net                              */
/* http://www.scribbytech.net                           */
/* Copyright � 2006 by Richard Simpson                  */
/*                                                      */
/* Code By Tony Bhimani                                 */
/* http://www.xenocafe.com/                             */
/********************************************************/

function doUptime(upSeconds) {
var uptimeString = "";
var secs = parseInt(upSeconds % 60);
var mins = parseInt(upSeconds / 60 % 60);
var hours = parseInt(upSeconds / 3600 % 24);
var days = parseInt(upSeconds / 86400);
if (days > 0) {
  uptimeString += days;
  uptimeString += ((days == 1) ? " Day" : " Days");
}
if (hours > 0) {
  uptimeString += ((days > 0) ? ", " : "") + hours;
  uptimeString += ((hours == 1) ? " Hour" : " Hours");
}
if (mins > 0) {
  uptimeString += ((days > 0 || hours > 0) ? ", " : "") + mins;
  uptimeString += ((mins == 1) ? " Minute" : " Minutes");
}
if (secs > 0) {
  uptimeString += ((days > 0 || hours > 0 || mins > 0) ? ", " : "") + secs;
  uptimeString += ((secs == 1) ? " Second" : " Seconds");
}
var span_el = document.getElementById("uptime");
var replaceWith = document.createTextNode(uptimeString);
span_el.replaceChild(replaceWith, span_el.childNodes[0]);
upSeconds++;
setTimeout("doUptime("+upSeconds+")",1000);
}
