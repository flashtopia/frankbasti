function doUptime(upSeconds) {
  var uptimeString = "";
  var secs = parseInt(upSeconds % 60);
  var mins = parseInt(upSeconds / 60 % 60);
  var hours = parseInt(upSeconds / 3600 % 24);
  var days = parseInt(upSeconds / 86400);

  $('#day').text(days);
  $('#days-label').text(((days == 1) ? " Day" : " Days"));

  if (hours > 0) {
    uptimeString += hours;
    uptimeString += ((hours == 1) ? " Hour" : " Hours");
  }
  if (mins > 0) {
    uptimeString += ((hours > 0) ? ", " : "") + mins;
    uptimeString += ((mins == 1) ? " Minute" : " Minutes");
  }
  if (secs > 0) {
    uptimeString += ((days > 0 || hours > 0 || mins > 0) ? ", " : "") + secs;
    uptimeString += ((secs == 1) ? " Sec" : " Secs");
  }

  $('#uptime').text(uptimeString);

  upSeconds++;

  setTimeout("doUptime("+upSeconds+")",1000);
}
