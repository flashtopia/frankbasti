<?php

$LANG = array();

// Main Language
$LANG['days'] = 'Days';
$LANG['hours'] = 'Hours';
$LANG['mins'] = 'Minutes';
$LANG['secs'] = 'Seconds';
$LANG['day'] = 'Day';
$LANG['hour'] = 'Hour';
$LANG['min'] = 'Min';
$LANG['sec'] = 'Second';
$LANG['memtip'] = 'Memory is the amount of RAM (random access memory) that is currently being used on the system.';
$LANG['swaptip'] = 'Swap memory is the use of space on a hard disk drive (HDD) to simulate additional main memory.';
$LANG['loadtip'] = 'Load is the number of processes running over a one minute period.<BR>(<B>1CPU\, LOAD 0.50 = 50% Load</B>)';
$LANG['sdown'] = 'Service Down';
$LANG['other'] = 'Other Servers';
$LANG['notav'] = 'N/A';
$LANG['phpinfo'] = 'PHPInfo';
$LANG['memused'] = 'Memory Used:';
$LANG['swapused'] = 'Swap Used:';
$LANG['server'] = 'Server';
$LANG['uptime'] = 'Uptime';
$LANG['load'] = 'Load';
$LANG['oac'] = 'Outages / Checks:';

// Tempalte Language
$LANG['curview'] = 'Currently Viewing';
$LANG['drivespace'] = 'Server Drive Space:';
$LANG['tservice'] = 'Service:';
$LANG['tport'] = 'Port:';
$LANG['tstatus'] = 'Status:';
$LANG['phpver'] = 'PHP Version:';
$LANG['mysql'] = 'MYSQL Version:';
$LANG['webserver'] = 'Webserver Version:';
$LANG['distro'] = 'Linux Distro:';
$LANG['tuptime'] = 'Uptime:';
$LANG['tcpu'] = 'CPU:';
$LANG['tload'] = 'Avg Load:';
$LANG['tmemory'] = 'Memory:';
$LANG['phpinfolink'] = 'PHPInfo';
$LANG['adminpanel'] = 'Admin Panel';
$LANG['dsp'] = 'Dynamic Server Images';
$LANG['servinfom'] = 'Server Load/Memory:';
$LANG['cpusnum'] = 'Number Of CPU(s):';
$LANG['ker'] = 'Kernel:';
$LANG['conp'] = 'Control Panel:';
$LANG['speed'] = 'Speed:';
$LANG['platform'] = 'Platform:';
$LANG['os'] = 'Operating System:';

// Dynamic Image Page Language
$LANG['orig'] = 'Original Image:';
$LANG['htmcode'] = 'HTML Code:';
$LANG['smload'] = 'Small Load:';
$LANG['smuptime'] = 'Small Uptime:';
$LANG['smonline'] = 'Small Service Online:';
$LANG['smoffline'] = 'Small Service Offline:';
$LANG['back'] = 'Back Home';

// Dynamic Image Language
$LANG['unavi'] = 'Unavailable';
$LANG['curlod'] = 'Current Load:';
$LANG['uptim'] = 'Uptime:';
$LANG['onlin'] = 'Online';
$LANG['offlin'] = 'Offline';
$LANG['sev'] = 'Service:';

// Mail Language
$LANG['mhead'] = 'TEST E-Mail!';
$LANG['subh'] = 'Test';
$LANG['tmsuc'] = 'Test E-Mail Sent!';
$LANG['loadwar'] = 'Load Warning!';
$LANG['loadmail'] = 'Load:';
$LANG['nonset'] = 'No E-Mail Address Set';

?>
