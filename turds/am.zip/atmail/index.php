<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

//apd_set_pprof_trace();

//session_cache_limiter('private'); //IE7 https file download work around
/* rather implimented.
TODO: try to find a way to have normal caching on if detected as https IE7 or other FAILER
header("Pragma: ");
header("Cache-Control: ");
*/

include_once('bootloader.php');
 
if($frontController)
{
	$frontController->dispatch();   

	Zend_Session::writeClose();
	Zend_Registry::get('log')->info('Hit closing down. Hit time: ' . round( ( microtime(true) - DEBUG_START_MT ),3 ) . ' seconds');
}

