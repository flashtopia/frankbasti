<?php
// +----------------------------------------------------------------+
// | step3.php														|
// |																|
// | Function: Setup Calendar Server			                    |
// +----------------------------------------------------------------+
// | Source-code (C) CalaCode.com 1998-2009 . All rights reserved	|
// | See http://calacode.com/license.ehtml for license agreement	|
// +----------------------------------------------------------------+
// | Date: May 2009													|
// +----------------------------------------------------------------+


// Make sure we are included from install/index.php, exit if not
if (!defined('ATMAIL_INSTALL_SCRIPT')) {
	// link to installer
	die("You cannot request this file directly, please use <a href=\"index.php\">the installer</a>");
}

$errors = array();

// If the form from Step 3 has been submitted
// we need to process it
if (isset($_POST['submit'])) 
{

    unset($errors);
	// $errors = new array();
	$_SESSION['pref']['calendarenable'] = $_POST['calendarenable'];
	if($_SESSION['pref']['calendarenable'] != '' )
		$_SESSION['pref']['calendarenable'] = true;
	else
		$_SESSION['pref']['calendarenable'] = false;
	
	if($_POST['calendarenable'] != '')
	{
		// Verify the submitted data
		$calendarHost = $_SESSION['pref']['CalDavUrl'] = $_POST['CalDavUrl'];
		//	$calendarAdminPass = $_POST['calendaradmin_pass'];
		$webmailDir = realpath('../');

		if (empty($calendarHost))
			$calendarHost = 'http://localhost:8008/calendars/users/'; 		

		// Try to connect to calendar host port	
		/*list($address, $port) = split(":", $calendarHost);
	
		try
		{

			$checkport = fsockopen($address, $port, $errnum, $errstr, 4); //The 2 is the time of ping in secs
			//? port is closed
			if($checkport)
			{
				fclose($checkport);
				$checkport = true;
				$vars['calendarhost'] = $calendarHost;
				$vars['calendaradmin_pass'] = $calendarAdminPass;
			}
			else
			{
				$errors['calendar_error'] .= "The Calendar server host details provided are incorrect. Please verify you have the correct calendar server configuration or use an calendar server which you have IP relay permissions.";    		
	//			$errors['smtp_error'] = $e->getMessage();
				$vars['bad_calendar_host'] = $calendarHost;
				$vars['calendarhost'] = $calendarHost;
				$vars['calendaradmin_pass'] = $calendarAdminPass;
			}
		}
		catch (Zend_Exception $e) {
				$errors['calendar_error'] .= "The Calendar server host details provided are incorrect. Please verify you have the correct calendar server configuration or use an calendar server which you have permissions.";    		
	//			$errors['smtp_error'] = $e->getMessage();
				$vars['bad_calendar_host'] = $calendarHost;
				$vars['calendarhost'] = $calendarHost;
				$vars['calendaradmin_pass'] = $calendarAdminPass;
		}*/
		$vars['calendarhost'] = $calendarHost;
		$vars['calendaradmin_pass'] = $calendarAdminPass;
	}
	
	$_SESSION['pref']['allow_Push'] = $_POST['allow_Push'];

	if (!count($errors))
	{
	
			$vars['calendarhost'] = 'http://' . $calendarHost . $calendarUrl; //?looks like these go missing cos not added to $_SESSION before header redirect
			$vars['calendarenable'] = $_POST['calendarenable'];
	    gotoStep(4);
	
	}
	
}

// Print the Step 3 page if no data submitted yet
// or there were errors in submitted data

// Find aspell binary
//$paths = exec('whereis aspell');
//list($trash, $bin) = explode(' ', $location);
//if (checkAspellBinary($bin))
//	$_SESSION['pref']['aspell_path'] = $bin;

//if (!$_SESSION['pref']['aspell_path'] || $errors['aspell_path_error'])
//	$vars['aspell_path'] = $bin;

// Create some default values
if(!$vars['CalDavUrl'])
$vars['CalDavUrl'] = 'http://localhost:8008/calendars/users/';

if(!$vars['calendar_enable_check'])
$vars['calendar_enable_check'] = "checked";

//get supported OS version
Zend_Loader::loadFile('Atmail/General.php', null, true);

$vars['hostOperatingSystemInfo'] = getOperatingSystemInfo();

// merge any pref values into $vars so if we are
// returning from a latter step the values are auto
// completed
if (isset($_SESSION['pref']['CalDavUrl']) && !count($errors))
	$vars = array_merge($vars, $_SESSION['pref']);

$vars['calserver_dir'] = dirname(dirname(dirname(__FILE__))) . '/server_source/calendar_server';

$vars['output'] = parse("$htmlPath/step3.phtml", array_merge($vars, $errors));
