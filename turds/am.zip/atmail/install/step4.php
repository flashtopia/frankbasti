<?php
// +----------------------------------------------------------------+
// | step4.php														|
// |																|
// | Function: Setup SMTP host and admin email 						|
// +----------------------------------------------------------------+
// | Source-code (C) CalaCode.com 1998-2009 . All rights reserved	|
// | See http://calacode.com/license.ehtml for license agreement	|
// +----------------------------------------------------------------+
// | Date: May 2009													|
// +----------------------------------------------------------------+

// Make sure we are included from install/index.php, exit if not
if (!defined('ATMAIL_INSTALL_SCRIPT')) {
	// link to installer
	die("You cannot request this file directly, please use <a href=\"index.php\">the installer</a>");
}

$errors = array();

// If the form from Step 4 has been submitted
// we need to process it
if (isset($_POST['submit'])) {
    
	// Verify the submitted data
	$smtpHost = $_SESSION['pref']['smtphost'] = $_POST['smtphost'];
	$adminEmail = $_SESSION['pref']['admin_email'] = $_POST['admin_email'];
	$webmailDir = realpath('../');

	//$_SESSION['pref']['allow_Push'] = $_POST['allow_Push'];

	if($_POST['allow_Push'] == 1)
		$vars['allow_Push_check'] = 'checked';
	if (empty($smtpHost))
		$smtpHost = 'localhost';
		
	// Try to connect to SMTP host
	require_once('Zend/Mail/Protocol/Smtp/Auth/Login.php');
	require_once('Zend/Mail/Protocol/Smtp.php');

	if (isset($_POST['smtp_auth']))
	{
    	$protocol = new Zend_Mail_Protocol_Smtp_Auth_Login($smtpHost, null, array('username' => $_POST['smtpauth_username'], 'password' => $_POST['smtpauth_password']));
	} else {
	    $protocol = new Zend_Mail_Protocol_Smtp($smtpHost);
	}

    try {
        $protocol->connect();    	

		if(PHP_OS == "Darwin")
		{
			// darwin
			$protocol->helo(php_uname('n'));
		}
		else
		{
			$protocol->helo($smtpHost);
		}
        try
        {
	        $protocol->mail('root');
    	    $protocol->rcpt('root');
    	}
    	catch (Zend_Exception $e)
    	{
    		if(strpos($e->getMessage(), 'need fully-qualified hostname') != FALSE)
    		{
    			throw($e);
    		}
    	}
    } catch (Zend_Exception $e) {
		$errors['smtp_error'] = $e->getMessage();		
		$vars['bad_smtp_host'] = $smtpHost;
		$vars['smtphost'] = $smtpHost;
		$vars['admin_email'] = $adminEmail;
		
		if(isset($_POST['smtp_auth'])) {
			$errors['smtp_error'] .= "The SMTP authentication details provided are incorrect. Please verify you have the correct username and password. Check your SMTP configuration for further details, or use an SMTP server which you have IP relay permissions.";
       		$vars['smtphost'] = $_SESSION['pref']['smtphost'];
       		$vars['smtpauth_username'] = $_SESSION['pref']['smtpauth_username'];
       		$vars['smtpauth_password'] = $_SESSION['pref']['smtpauth_password'];
       		$vars['admin_email'] = $_SESSION['pref']['admin_email'];
       		$vars['smtp_auth_error'] = '1';
       		$vars['smtp_auth_check'] = 'checked';
		}
		
		if(strpos($errors['smtp_error'], 'need fully-qualified hostname') != FALSE)
		{
			// fully qualified domain name for helo required (probably osx)
			// so lets tell the user in a human readable way
			$errors['smtp_error'] .= "<br><br>The SMTP authentication details provided are incorrect for this server. Please verify you are using the fully qualified hostname for the smtp server. I.e. 'example.hostname' rather then 'localhost'.<br><br>It appears that your machines hostname is : " . php_uname('n');
			$vars['smtphost'] = php_uname('n');
		}
	}
	
	if (!preg_match('/[a-zA-Z0-9\-\.]+@[a-zA-Z0-9\-\.]+\.[a-zA-Z]+/', $adminEmail))
		$errors['admin_email_error'] = true;

	if (!count($errors)){
	    gotoStep(5);
	}
}

// Print the Step 4 page if no data submitted yet
// or there were errors in submitted data

// Find aspell binary
//$paths = exec('whereis aspell');
//list($trash, $bin) = explode(' ', $location);
//if (checkAspellBinary($bin))
//	$_SESSION['pref']['aspell_path'] = $bin;

//if (!$_SESSION['pref']['aspell_path'] || $errors['aspell_path_error'])
//	$vars['aspell_path'] = $bin;

// Create some default values
if(!$vars['smtphost'])
$vars['smtphost'] = 'localhost';

// merge any pref values into $vars so if we are
// returning from a latter step the values are auto
// completed
if (isset($_SESSION['pref']['smtphost']) && !count($errors))
	$vars = array_merge($vars, $_SESSION['pref']);

$vars['output'] = parse("$htmlPath/step4.phtml", array_merge($vars, $errors));
