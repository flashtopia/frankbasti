<?php
// +----------------------------------------------------------------+
// | step0.php														|
// |																|
// | Function: Check all dependencies								|
// +----------------------------------------------------------------+
// | Source-code (C) CalaCode.com 1998-2009 . All rights reserved	|
// | See http://calacode.com/license.ehtml for license agreement	|
// +----------------------------------------------------------------+
// | Date: May 2009													|
// +----------------------------------------------------------------+


// Make sure we are included from install/index.php, exit if not
if (!defined('ATMAIL_INSTALL_SCRIPT')) {
	// link to installer
	die("You cannot request this file directly, please use <a href=\"index.php\">the installer</a>");
}

if ( !function_exists('sys_get_temp_dir') ) {
    
    // Based on http://www.phpit.net/
    // article/creating-zip-tar-archives-dynamically-php/2/
    function sys_get_temp_dir()
    {
        // Try to get from environment variable
        if ( !empty($_ENV['TMP']) ) {
            return realpath( $_ENV['TMP'] );
        } elseif ( !empty($_ENV['TMPDIR']) ) {
            return realpath( $_ENV['TMPDIR'] );
        } elseif ( !empty($_ENV['TEMP']) ) {
            return realpath( $_ENV['TEMP'] );
        }

        // Detect by creating a temporary file
        else {
            // Try to use system's temporary directory
            // as random name shouldn't exist
            $temp_file = tempnam( md5(uniqid(rand(), TRUE)), '' );
            if ( $temp_file ) {
                $temp_dir = realpath( dirname($temp_file) );
                unlink( $temp_file );
                return $temp_dir;
            } else {
                return FALSE;
            }
        }
    }
}

$errors = array();

// If the form from Stage 1 has been submitted
// we need to process it
if (isset($_POST['submit'])) {
	header('Location: index.php?step=1');
}

$vars = array();
$vars['error'] = 0;


// Check for required php extensions

$requiredExtensions = array(
    'session',
    'pcre',
    'PDO',
    'pdo_mysql',
    'ctype',
    'iconv',
    'hash',
    'Reflection',
    'SPL',
    'standard',
    'mbstring',
    'xml'
);

$optionalExtensions = array(
    'ldap',
    'openssl',
    'dom',
    'gd',
	'imap'
);
            
$ext = array('req' => array(), 'opt' => array());

foreach ($requiredExtensions as $e) {
    
    // Check for extension support
    if (!extension_loaded($e)) {
        $ext['req'][] = $e;
    }
}

//check if at lease one of db servers is installed
if( !extension_loaded('mysql') && !extension_loaded('sqlite_disabled') )
{
	
	$ext['req'][] = 'mysql';
	
}

$_SESSION['pref']['allow_Push'] = 1;
$_SESSION['pref']['mail_type_ssl'] = 'allow';

foreach ($optionalExtensions as $e) {
    
    // Check for session support
    if (!extension_loaded($e)) {
        $ext['opt'][] = $e;
        if ($e == 'openssl') {
            $_SESSION['pref']['mail_type_ssl'] = 'deny';
        }
    }
}

// Check if ImageMagick is installed
$ext['opt']['ImageMagick'] = 'ImageMagick';

$convert = findBinary(array('convert'));

if(is_executable($convert)) {
    $res = `$convert --version`;
    
    if (preg_match("/ImageMagick/", $res)) {
        $_SESSION['pref']['convertPath'] = $convert;
        $_SESSION['plugins']['Atmail_FilePreview'] = 1;
        unset($ext['opt']['ImageMagick']) ;// = '';
    }
}

if (ini_get('safe_mode'))	{
	$ext['req'][] = 'safe_mode';
}

if (!ini_get('register_globals'))
	$ext['ini'][] = 'register_globals';

if (!ini_get('file_uploads'))
	$ext['ini'][] = 'file_uploads';

if (!get_magic_quotes_gpc())
	$ext['ini'][] = 'magic_quotes_gpc';

// Get the filesize
$size = ini_get('upload_max_filesize');
$size = str_replace('M', '', $size);

if (ini_get('upload_max_filesize') < 16)	{
	$ext['ini'][] = 'upload_max_filesize';
	$vars['upload_max_filesize'] = ini_get('upload_max_filesize');
}

// Get the post max size
$size = ini_get('post_max_size');
$size = str_replace('M', '', $size);

if (ini_get('post_max_size') < 16)	{
	$ext['ini'][] = 'post_max_size';
	$vars['post_max_size'] = ini_get('post_max_size');
}

//Check we can mod include_path
$incPath = get_include_path();

if (!set_include_path(dirname(__FILE__))) {
    echo get_include_path();
    $ext['req'][] = 'set_include_path';
} else {
    set_include_path($incPath);
}

if (count($ext['req']) || in_array('mysql', $ext['opt']) && in_array('sqlite', $ext['opt'])) {

    // Don't let the user proceed
    if ((!$var['version'] == 'demo' && !in_array('ioncube', $ext['req'])) || ($vars['version'] == 'demo')) {
        $vars['error'] = '1';
    }

   //$var['output'] = parse('html/extensions_required.html', $ext);
   //echo parse('html/english/template.html', $var);
   //exit;
}

if (ini_get('open_basedir') == '') {
    $ext['ini'][] = 'open_basedir';
}

$vars['output'] = parse("$htmlPath/step0.phtml", array_merge($errors, $vars, $ext));

// Preselect the language if already known e.g. we have
// returned from a later step
if ($lang)
	$vars['output'] = str_replace("<option value=\"$lang\">", "<option value=\"$lang\" selected>", $vars['output']);
