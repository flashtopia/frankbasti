
-- SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


--
-- Table structure for table `Abook`
--

CREATE TABLE `Abook` (
  `UserEmail` varchar(255) default NULL,
  `UserEmail2` varchar(255) default NULL,
  `UserEmail3` varchar(255) default NULL,
  `UserEmail4` varchar(255) default NULL,
  `UserEmail5` varchar(255) default NULL,
  `UserFirstName` varchar(128) character set utf8 default NULL,
  `UserMiddleName` varchar(128) character set utf8 default NULL,
  `UserLastName` varchar(128) character set utf8 default NULL,
  `UserTitle` varchar(128) character set utf8 default NULL,
  `UserGender` char(1) default NULL,
  `UserDOB` datetime default NULL,
  `UserHomeAddress` varchar(128) character set utf8 default NULL,
  `UserHomeCity` varchar(128) character set utf8 default NULL,
  `UserHomeState` varchar(128) character set utf8 default NULL,
  `UserHomeZip` varchar(128) character set utf8 default NULL,
  `UserHomeCountry` varchar(128) character set utf8 default NULL,
  `UserHomePhone` varchar(128) default NULL,
  `UserHomeMobile` varchar(128) default NULL,
  `UserHomeFax` varchar(128) default NULL,
  `UserURL` varchar(128) default NULL,
  `UserWorkCompany` varchar(128) character set utf8 default NULL,
  `UserWorkTitle` varchar(128) character set utf8 default NULL,
  `UserWorkDept` varchar(128) character set utf8 default NULL,
  `UserWorkOffice` varchar(128) character set utf8 default NULL,
  `UserWorkAddress` varchar(128) character set utf8 default NULL,
  `UserWorkCity` varchar(128) character set utf8 default NULL,
  `UserWorkState` varchar(128) character set utf8 default NULL,
  `UserWorkZip` varchar(128) character set utf8 default NULL,
  `UserWorkCountry` varchar(128) character set utf8 default NULL,
  `UserWorkPhone` varchar(128) default NULL,
  `UserWorkMobile` varchar(128) default NULL,
  `UserWorkFax` varchar(128) default NULL,
  `UserType` varchar(16) default NULL,
  `UserInfo` varchar(128) character set utf8 default NULL,
  `Account` varchar(128) NOT NULL default '',
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `DateAdded` datetime default NULL,
  `DateModified` varchar(12) default NULL,
  `EntryID` varchar(64) default NULL,
  `UserPhoto` mediumtext,
  `UserFileAs` varchar(255) default NULL,
  `Global` tinyint(1) not null default 0,
  `Shared` tinyint(1) not null default 0,
  `Favourite` tinyint(1) default NULL,
  `UsageCount` int(11) not null default 0,
  PRIMARY KEY  (`id`),
  KEY `iAccount` (`Account`),
  KEY `iGlobal` (`Global`),
  KEY `iShared` (`Shared`),
  KEY `UserEmail` (`UserEmail`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `AbookGroup`
--

CREATE TABLE `AbookGroup` (
  `GroupName` varchar(128) character set utf8 default NULL,
  `GroupEmail` varchar(128) default NULL,
  `Account` varchar(128) default NULL,
  `id` mediumint(12) NOT NULL auto_increment,
  `AbookID` bigint(10) unsigned default NULL,
  `GroupID` mediumint(12) default NULL,
  PRIMARY KEY  (`id`),
  KEY `iAccount` (`Account`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `AbookGroupNames`
--

CREATE TABLE `AbookGroupNames` (
  `GroupName` varchar(128) character set utf8 default NULL,
  `Account` varchar(128) character set latin1 default NULL,
  `id` mediumint(12) NOT NULL auto_increment,
  PRIMARY KEY  (`id`),
  KEY `iAccount` (`Account`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `AbookPermissions`
--

CREATE TABLE `AbookPermissions` (
  `AbookID` mediumint(8) unsigned default NULL,
  `Account` varchar(96) NOT NULL default '',
  `Permissions` smallint(1) default NULL,
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `Type` varchar(6) default NULL,
  `Domain` varchar(64) default NULL,
  PRIMARY KEY  (`id`),
  KEY `iAccount` (`Account`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `Accounts`
--

CREATE TABLE `Accounts` (
  `UserAccount` varchar(32) default NULL,
  `Account` varchar(128) NOT NULL default '',
  `Type` varchar(4) default NULL,
  `MailServer` varchar(64) default NULL,
  `UseSSL` tinyint(1) default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `AdminGroup`
--

CREATE TABLE `AdminGroup` (
  `UserName` varchar(128) character set utf8 default NULL,
  `Ugroup` varchar(64) character set utf8 default NULL,
  `Domain` varchar(64) default NULL,
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`id`),
  KEY `iUsername` (`UserName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `AdminUsers`
--

CREATE TABLE `AdminUsers` (
  `Username` varchar(128) character set utf8 default NULL,
  `Password` varchar(128) character set utf8 default NULL,
  `sessionData` text,
  `UAdd` tinyint(1) default NULL,
  `UDelete` tinyint(1) default NULL,
  `UModify` tinyint(1) default NULL,
  `UPurge` tinyint(1) default NULL,
  `USearch` tinyint(1) default NULL,
  `UList` tinyint(1) default NULL,
  `UMigrate` tinyint(1) default NULL,
  `ULogs` tinyint(1) default NULL,
  `UAlias` tinyint(1) default NULL,
  `UArchiveVault` tinyint(1) NULL default '0',
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `NumUsers` mediumint(6) unsigned default NULL,
  `Company` varchar(128) character set utf8 default NULL,
  `Fullname` varchar(128) character set utf8 default NULL,
  `EmailAddress` varchar(128) default NULL,
  `DateCreate` datetime default NULL,
  `SessionID` varchar(32) default NULL,
  `LastLogin` int(10) unsigned default NULL,
  `modified` int(11) default NULL,
  `ipAddress` varchar(15) default NULL,
  `NumQuota` mediumint(6) unsigned default NULL,
  `UBrand` tinyint(1) default NULL,
  `BrandDomain` varchar(128) default NULL,
  `UGroupAssign` tinyint(1) default NULL,
  `UAll` tinyint(1) default NULL,
  `UMasterAdmin` tinyint(1) default NULL,
  `Language` varchar(5) NULL, 
  PRIMARY KEY  (`id`),
  KEY `iUsername` (`Username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `CalAddresses`
--

CREATE TABLE `CalAddresses` (
  `Address` varchar(255) default NULL,
  `ShortName` varchar(255) default NULL,
  UNIQUE KEY `ADDRESS` (`Address`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `CalDav`
--

CREATE TABLE `CalDav` (
  `KEY` varchar(60) default NULL,
  `VALUE` varchar(60) default NULL,
  `EXTRA` varchar(255) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `CalDavService`
--

CREATE TABLE `CalDavService` (
  `Realm` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `CalGroups`
--

CREATE TABLE `CalGroups` (
  `ShortName` varchar(255) default NULL,
  `MemberRecordType` text,
  `MemberShortName` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `Config`
--

CREATE TABLE `Config` (
  `configId` int(11) NOT NULL auto_increment,
  `section` varchar(100) character set utf8 NOT NULL,
  `keyName` varchar(100) character set utf8 NOT NULL,
  `keyValue` varchar(256) character set utf8 default NULL,
  `keyType` varchar(8) default NULL,
  PRIMARY KEY  (`configId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `Domains`
--

CREATE TABLE `Domains` (
  `Hostname` varchar(255) NOT NULL default '',
  `Enable` char(1) NOT NULL default '1',
  PRIMARY KEY  (`Hostname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `Groups`
--

CREATE TABLE `Groups` (
  `GroupName` varchar(255) character set utf8 NOT NULL default '',
  `GroupDescription` varchar(255) character set utf8 default NULL,
  `GroupPrice` varchar(5) default NULL,
  `GroupQuota` mediumint(8) unsigned default NULL,
  `MailForwarding` int(1) default NULL,
  `SMSSupport` int(1) default NULL,
  `POP3Support` int(1) default NULL,
  `IMAPSupport` int(1) default NULL,
  `MultiSupport` int(1) default NULL,
  `PersonalSpam` int(1) default NULL,
  `GroupwareZone` varchar(6) character set utf8 NOT NULL DEFAULT 'Domain',
  `Webmail` int(1) NOT NULL DEFAULT '1',
  `Calendar` int(1) NOT NULL DEFAULT '1',
  `SharedAbook` int(1) NOT NULL DEFAULT '1',
  `GlobalAbookRead` int(1) default NULL,
  `AV` int(1) default NULL,
  `SpamSupport` int(1) default NULL,
  `Sync` int(1) default NULL,
  `WebSyncShared` int(1) NOT NULL DEFAULT '1',
  `WebSyncGlobal` int(1) NOT NULL DEFAULT '1',
  `PushSupport` int(1) default NULL,
  `Carddav` int(1) default 1,
  PRIMARY KEY  (`GroupName`),
  KEY `POP3Support` (`POP3Support`),
  KEY `IMAPSupport` (`IMAPSupport`),
  KEY `Webmail` (`Webmail`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Table structure for table `Log_Error`
--

CREATE TABLE `Log_Error` (
  `LogMsg` varchar(255) default NULL,
  `LogDate` datetime default NULL,
  `Account` varchar(128) NOT NULL default '',
  `id` bigint(12) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`id`),
  KEY `iAccount` (`Account`),
  KEY `LogDate` (`LogDate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `Log_Login`
--

CREATE TABLE `Log_Login` (
  `LogDate` datetime default NULL,
  `LogType` tinyint(1) default NULL,
  `LogIP` varchar(15) default NULL,
  `Account` varchar(128) default NULL,
  `id` bigint(12) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`id`),
  KEY `iAccount` (`Account`),
  KEY `iLogType` (`LogType`),
  KEY `iLogIP` (`LogIP`),
  KEY `LogDate` (`LogDate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `Log_RecvMail`
--

CREATE TABLE `Log_RecvMail` (
  `LogDate` datetime default NULL,
  `LogIP` varchar(15) default NULL,
  `EmailFrom` varchar(128) default NULL,
  `MessageID` varchar(16) default NULL,
  `Account` varchar(128) NOT NULL default '',
  `id` bigint(12) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`id`),
  KEY `iAccount` (`Account`),
  KEY `iLogIP` (`LogIP`),
  KEY `LogDate` (`LogDate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `Log_SendMail`
--

CREATE TABLE `Log_SendMail` (
  `LogDate` datetime default NULL,
  `LogIP` varchar(15) default NULL,
  `EmailTo` varchar(128) default NULL,
  `MessageID` varchar(16) default NULL,
  `Account` varchar(128) NOT NULL default '',
  `id` bigint(12) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`id`),
  KEY `iAccount` (`Account`),
  KEY `iLogIP` (`LogIP`),
  KEY `LogDate` (`LogDate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `Log_Spam`
--

CREATE TABLE `Log_Spam` (
  `LogDate` datetime default NULL,
  `LogType` tinyint(1) default NULL,
  `LogIP` varchar(15) default NULL,
  `SpamPoints` smallint(2) default NULL,
  `EmailFrom` varchar(128) default NULL,
  `Account` varchar(128) NOT NULL default '',
  `id` bigint(12) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`id`),
  KEY `iAccount` (`Account`),
  KEY `iLogIP` (`LogIP`),
  KEY `LogDate` (`LogDate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `Log_Virus`
--

CREATE TABLE `Log_Virus` (
  `LogDate` datetime default NULL,
  `LogIP` varchar(15) default NULL,
  `EmailFrom` varchar(128) default NULL,
  `VirusName` varchar(128) default NULL,
  `Account` varchar(128) NOT NULL default '',
  `id` bigint(12) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`id`),
  KEY `iAccount` (`Account`),
  KEY `LogDate` (`LogDate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `MailAliases`
--

CREATE TABLE `MailAliases` (
  `AliasName` varchar(200) default NULL,
  `AliasTo` varchar(200) default NULL,
  `Domain` varchar(128) default NULL,
  `DateCreate` datetime default NULL,
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `AliasMailDir` varchar(200) default NULL,
  PRIMARY KEY  (`id`),
  KEY `iAliasName` (`AliasName`),
  KEY `iAliasTo` (`AliasTo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `MailRelay`
--

CREATE TABLE `MailRelay` (
  `IPaddress` varchar(16) NOT NULL default '',
  `DateAdded` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `Account` varchar(128) default NULL,
  PRIMARY KEY  (`IPaddress`),
  KEY `DateAdded` (`DateAdded`),
  KEY `IPaddress` (`IPaddress`),
  KEY `Account` (`Account`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `SerialConf`
--

CREATE TABLE `SerialConf` (
  `Name` varchar(64) default NULL,
  `Value` longtext,
  `Account` varchar(128) default NULL,
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `DateAdded` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `iAccount` (`Account`),
  KEY `iName` (`Name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Table structure for table `SharedLookup`
--

CREATE TABLE `SharedLookup` (
  `Type` varchar(8) default NULL,
  `EntryID` varchar(64) default NULL,
  `LookupID` varchar(255),
  `id` bigint(10) unsigned NOT NULL auto_increment,
  `Account` varchar(128) default NULL,
  `DateModified` varchar(12) default NULL,
  PRIMARY KEY  (`id`),
  KEY `LookupID` (`LookupID`),
  KEY `Account` (`Account`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `SpamSettings`
--

CREATE TABLE `SpamSettings` (
  `username` varchar(255) default NULL,
  `preference` varchar(30) NOT NULL default '',
  `value` varchar(100) NOT NULL default '',
  `prefid` int(11) NOT NULL auto_increment,
  `domain` varchar(128) default NULL,
  PRIMARY KEY  (`prefid`),
  KEY `username` (`username`),
  KEY `preference` (`preference`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

--
-- Table structure for table `UserSession`
--

CREATE TABLE `UserSession` (
  `Account` varchar(128) NOT NULL default '',
  `Password` varchar(64) character set utf8 default NULL,
  `SessionID` varchar(64) NOT NULL default '',
  `LastLogin` datetime default NULL,
  `PasswordMD5` varchar(64) default NULL,
  `SessionData` mediumtext character set utf8,
  `ChangePass` int(1) default NULL,
  `modified` int(11) default NULL,
  `lifetime` int(11) NOT NULL,
  `CalUser` int(1) default NULL,
  `CalendarUserStatus` int(1) NOT NULL default '0',
  PRIMARY KEY  (`Account`),
  KEY `iAccount` (`SessionID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `UserSettings`
--

CREATE TABLE `UserSettings` (
  `Account` varchar(128) NOT NULL default '',
  `RealName` varchar(128) character set utf8 default NULL,
  `Refresh` smallint(5) default NULL,
  `TimeZone` varchar(32) default NULL,
  `MsgNum` varchar(4) default NULL,
  `HtmlEditor` smallint(1) default NULL,
  `ViewThreads` smallint(1) default NULL,
  `ReplyTo` varchar(128) character set utf8 default NULL,
  `Signature` text character set utf8,
  `MailType` varchar(4) default NULL,
  `Language` varchar(5) default NULL,
  `AutoTrash` tinyint(1) default NULL,
  `MailServer` varchar(64) default NULL,
  `MailAuth` tinyint(1) default NULL,
  `AbookTrusted` smallint(1) default NULL,
  `DateFormat` varchar(8) default NULL,
  `TimeFormat` varchar(8) default NULL,
  `AutoComplete` smallint(1) default NULL,
  `EmailEncoding` varchar(16) default NULL,
  `DisplayImages` smallint(1) default NULL,
  `UseSSL` tinyint(1) default '0',
  `CalDavUrl` varchar(256) default NULL,
  `CalDavUser` varchar(64) default NULL,
  `CalDavPass` varchar(32) default NULL,
  `DefaultView` varchar(2) default NULL,
  `CalDavType` varchar(2) default NULL,
  `ThreadLimit` tinyint(4) default '6',
  `SieveSupport` smallint(1) NOT NULL default '0',
  `cssStyleTheme` varchar(64) character set utf8 NOT NULL default "Blue-Steel",
  PRIMARY KEY  (`Account`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `Account` varchar(128) NOT NULL default '',
  `PasswordQuestion` varchar(256) character set utf8 default NULL,
  `DateModified` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `DateCreate` timestamp NOT NULL default '0000-00-00 00:00:00',
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `Ugroup` varchar(255) character set utf8 default 'default',
  `UserStatus` int(1) NOT NULL default '0',
  `MailDir` varchar(255) default NULL,
  `Forward` varchar(128) character set utf8 default NULL,
  `AutoReply` text character set utf8,
  `UserQuota` mediumint(8) unsigned default NULL,
  PRIMARY KEY  (`id`),
  KEY `iAccount` (`Account`),
  KEY `iUgroup` (`Ugroup`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `awl`
--

CREATE TABLE `awl` (
  `username` varchar(100) NOT NULL default '',
  `email` varchar(200) NOT NULL default '',
  `ip` varchar(10) NOT NULL default '',
  `count` int(11) default '0',
  `totscore` float default '0',
  `IndexDate` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`username`,`email`,`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

create table `calendarExtendedData` ( 
	`Account` varchar(128) character set latin1 default NULL, 
	`EntryID` varchar(64) default NULL, 
	`ObjectId` varchar(64) default NULL, 
	`id` mediumint(12) NOT NULL auto_increment, 
	PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE `Plugins` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(8) NOT NULL,
  `settings` text,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(64) NOT NULL,
  `company` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `module` (`module`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- add details for default plugins
-- 
INSERT IGNORE INTO `Plugins` (`module`, `status`, `name`, `company`) values
('mail', '1', 'FilePreview', 'Atmail'),
('mail', '1', 'Test', 'Atmail');

--
-- carddav servers lists
--

CREATE TABLE `AbookServers` (
  `Account` varchar(128) NOT NULL default '',
  `username` varchar(128) character set utf8 default NULL,
  `password` varchar(128) character set utf8 default NULL,
  `server` varchar(256) character set utf8 default NULL,
  `port` int(6) NOT NULL default '8800',
  `url` text character set utf8 default NULL,
  `protocol` varchar(7) NOT NULL default 'carddav',
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  PRIMARY KEY  (`id`),
  KEY `iAccount` (`Account`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

