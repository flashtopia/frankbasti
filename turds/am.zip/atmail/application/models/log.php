<?php
/**
 * @category   Atmail
 * @package    Log model
 * @author     Ben Duncan ben@staff.atmail.com
 * @license    Copyrighted by Atmail 2009
 */

class logEntry
{
    public $Account = '';
	private $_namespaceName = 'log';

	public function __construct($account)
	{
		// check to make sure we have valid arguments!
		if( empty($account) )
		throw new Atmail_Exception('Log constructor required Account field in arguments array');

		$this->Account = $account;

	}

    public static function insert($log, $arr)
    {
        $dbTables = new dbTables();
		$dbAdapter = Zend_Registry::get('dbAdapter');

		//$arr['Account'] = $this->Account;
		$arr['LogDate'] = new Zend_Db_Expr('NOW()');

		$dbAdapter->insert($log, $arr );

    }

}
