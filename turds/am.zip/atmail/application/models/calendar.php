<?php
/**
* @category   Atmail
* @package    calendar model
* @author     Brett Embery brett@staff.atmail.com
* @license    Copyright Atmail 2009
*/

require_once 'library/Atmail/CalDav/caldav-client.php';
require_once 'library/Atmail/CalDav/caldav-support.php';
require_once 'library/Atmail/CalDav/json.php';

function cmp($a, $b)
{
	if($a['shared'] == "0" && $a['name'] == 'calendar')
	{
		return 1;
	}
		
	return strcmp($a['shared'], $b['shared']) && strcmp($a['name'], $b['name']) ;
}

class calendar
{
	private $_account;
	private $_tableNames;
	private $_namespaceName 	= 'calendar';
	private $_caldav_server;
	private $_server_type		= 'at';
	private $_server_auth_failed	= false;
	private $_migration		= false;
	private $_local = false;
	
	private $time1;
	private $time2;
	private $calDebug 		= 0;

	private $ICAL_TIME		= 1;
	private $ICAL_VERSION 		= "2.0";
	private $ICAL_PRODID 		= "-//Atmail//6.0//EN";
	private $ICAL_CALSCALE		= "GREGORIAN";
	private $ICAL_TRANS		= "OPAQUE";
	private $load_failed		= false;
	private $calNamesCache;

	public function __construct(Array $args)
	{
		// check to make sure we have valid arguments!
		if( !isset($args['Account']) )
		{
			throw new Atmail_Exception('Calendar constructor required Account field in arguments array');
		}
		
		if( !isset($args['Type']) )
		{
			$args['Type'] = 'at';	
		}

		if( isset($args['migration']) )
			$this->_migration = true;
		
		$this->_account = $args['Account'];
		$this->_server_type = $args['Type'];

		if( isset($args['namespaceName']) )
		{
			$this->_namespaceName = $args['namespaceName'];
		}
		
		require_once 'application/models/dbTables.php';
		$tableNames = new dbTables();

		// we need to cache the database information for later..
		$this->CalendarTableName = $tableNames->Calendar;

		$this->dbAdapter = Zend_Registry::get('dbAdapter');

		list($username, $pop3host) = explode('@', $this->_account);
		
		if( !isset($args['URL']) )
		{
			// retrieve the users settings and grab the url
			try
			{
				$user_data = users::getAllUserData($this->_account);
				$args['URL'] = $user_data['UserSettings']['CalDavUrl'];
			}
			catch(Exception $e)
			{
				// something went wrong with the db connection, lets assume default
				$args['URL'] = "http://localhost:8008/calendars/users/";
			}
		}
		$this->caldav_URL = $args['URL'];
		$this->username = $this->_account;

		try
		{
			$this->_caldav_server = new CalDAVClient( $args['URL'], $this->username, $args['Password'], $args['Calendar'] );
			$this->_caldav_server->SetUserAgent("Atmail 6.0");
		}
		catch(Exception $e)
		{
			$this->load_failed = true;
		}
		$this->_local = ((strpos($args['URL'], "localhost") != FALSE) || (strpos($args['URL'], "127.0.0.1") != FALSE));
		$this->calNames = null;
	}
	
	function getDirectorySize($arg, $arg2)
	{
		return $this->_caldav_server->getDirectorySize($arg, $arg2);
	}
	
	function setUserDetails($args)
	{
		$this->_account = $args['Account'];
		$this->_server_type = $args['Type'];
	
		list($username, $pop3host) = explode('@', $this->_account);

		if( !isset($args['URL']) )
		{
			// retrieve the users settings and grab the url
			$user_data = users::getAllUserData($this->_account);
			$args['URL'] = $user_data['UserSettings']['CalDavUrl'];
		}
		$this->caldav_URL = $args['URL'];
		$this->username = $this->_account;
		$this->_local = ((strpos($args['URL'], "localhost") != FALSE) || (strpos($args['URL'], "127.0.0.1") != FALSE));
		$this->_caldav_server->user = $this->username;
	    $this->_caldav_server->pass = $args['Password'];
		$this->calNames = null;
	}
	
	function GetCurrentPrincipal($args)
	{
		return $this->_caldav_server->GetCurrentPrincipal($args);
	}

	function checkAlarms($start_in, $end_in)
	{
		$entries = array();
		
		// caldav requires different date formatting
		// yyyymmddThhmmssZ
		// so lets massage
		list($startdate_text, $starttime_text) 			= explode(" ", $start_in);
		list($enddate_text, $endtime_text)			= explode(" ", $end_in);
		list($start['year'], $start['month'], $start['day']) 	= explode("-", $startdate_text);
		list($end['year'], $end['month'], $end['day']) 		= explode("-", $enddate_text);
		list($start['hour'], $start['min']) 			= explode(":", $starttime_text);
		list($end['hour'], $end['min']) 			= explode(":", $endtime_text);

		$caldav_start = sprintf("%04d%02d%02dT%02d%02d%02dZ",$start['year'],$start['month'],$start['day'], $start['hour'], $start['min'], 0);
		$caldav_end = sprintf("%04d%02d%02dT%02d%02d%02dZ",$end['year'],$end['month'],$end['day'], $end['hour'], $end['min'], 0);
		$searchstart = new Date($caldav_start);
		$searchend = new Date($caldav_end);

		if( $this->calNames == null )
		{
			$this->calNames = $this->getCalNames($this->_caldav_server, $this->caldav_URL);
		}
			
		$alarms = array();
		$munchedEvents = array();
	
		foreach( $this->calNames as $calName )
		{

			// fetch all events for range
			$events = $this->_caldav_server->GetAlarms($caldav_start,$caldav_end, $calName['relative_href']);

			// 'munch' the events into a nice array
			$munchedEvents = $this->munchEvents($events);
			foreach($munchedEvents as $event)
			{
				$alarm = $this->caldav_extract_alarm($event, $calName['relative_href']);
				if(count($alarm) != 0)
					$alarms[] = $alarm;
			}
		}
		
		return $alarms;
	}

	function caldav_extract_alarm($event, $href)
	{
		$alarm = array();

		if(isset($event['VALARM']))
		{
			$valarm = $event['VALARM'];
			$alarm['id'] = $event['VCALENDAR']['VEVENT']['UID'];
			$alarm['href'] = $href;
			
			// ensure action/trigger properties
			if($valarm['ACTION'] && $valarm['TRIGGER'])
			{				
				switch($valarm['ACTION'])
				{
					case 'DISPLAY' :
					{
						$alarm['action'] = 'DISPLAY';
						$alarm['description'] = $valarm['DESCRIPTION'];
					} break;
					case 'EMAIL' :
					{
						$alarm['action'] = 'EMAIL';
						$alarm['description'] = $valarm['DESCRIPTION'];
						$alarm['attendee'] = str_replace('mailto:', '' , $valarm['ATTENDEE']);
					} break;
					
					case 'PROCEDURE':
					case 'AUDIO' :
					default:
					{
						// not currently supported, ignore.	
						$alarm['action'] = 'UNSUPPORTED';
					} break;
				}
				
				$alarm['eventtime'] = calendar::caldav_extract_dtstamps($event);
				if ( $valarm['TRIGGER'][strlen($valarm['TRIGGER'])-1] == 'Z')
				{
					// date	
					// utc
					$alarm['triggertype'] = "Date";
					
					$alarm['trigger'] = new Date($valarm['TRIGGER']);
					$alarm['alarmtime'] = $alarm['trigger'];
				}
				else
				{
					$alarm['triggertype'] = "Time";
					
					$alarm['trigger'] = ical_duration_to_seconds($valarm['TRIGGER']);
					$alarm['alarmtime'] = new Date($alarm['eventtime'][0]);
					$alarm['alarmtime']->addSpan(new Date_Span($alarm['trigger']));
				}
			}
		}

		return $alarm;
	}
	
	function dismissAlarm($id, $href)
	{
		$events = $this->_caldav_server->GetEntryByUid( $id, urldecode($href));
		$munchedEvents = $this->munchEvents($events);
		// should only be one event here !
		$event = $munchedEvents[0];
		if(isset($event['VALARM']))
		{
			unset($event['VALARM']);
			$event_text = ical_create_entry($event);
			$url = $href . $event['VCALENDAR']['VEVENT']['UID'] . '.ics';
			$event['etag'] = $this->_caldav_server->DoPUTRequest($url, $event_text, $event['etag']);
		}
		return findetag($this->_caldav_server, $href);
	}
	
	function caldav_set_alarm_trigger($event, $href, $alertTrigger, $alertType, $alertPosition, $alertDescription)
	{
		$alarm = array();
		$alertDescription = str_replace("\r", "", $alertDescription);
		$alertDescription = str_replace("\n", " ", $alertDescription);
		if($alertType == "Date")
		{
			$newtrigger = new Date($alertTrigger);
			$trigger = ical_datetime(date($newtrigger->getTime())) . 'Z';
		}
		else
		{
			if($alertPosition == "Before")
			{
				$alertTrigger *= -1; 
			}	
			if($alertType == "Minutes")
			{
				$newtrigger = ($alertTrigger * 60);				
			}
			else if ($alertType == "Hours")
			{
				$newtrigger = ($alertTrigger * 60 * 60);
			}
			else if ($alertType == "Days")
			{
				$newtrigger = ($alertTrigger * 60 * 60 * 24);
			}
			else
			{
				$newtrigger = 0;
			}
			$trigger = seconds_to_ical_duration($newtrigger);	
		}
		$event['VALARM'] = array('TRIGGER' => $trigger, 'DESCRIPTION' => "Alarm for : '" . $alertDescription . "'", 'ACTION' => 'DISPLAY');
		
		$valarm = $event['VALARM'];

		return $valarm;
	}
	
	function caldav_modify_alarm_trigger($event, $href, $adv_mins)
	{
		$alarm = array();

		if(isset($event['VALARM']))
		{
			$valarm = $event['VALARM'];
			$eventtime = calendar::caldav_extract_dtstamps($event);
			// ensure trigger properties
			if($valarm['TRIGGER'])
			{
				$newtrigger = new Date();
				$newtrigger->addSpan(new Date_Span($adv_mins * 60));
				
				if ( $valarm['TRIGGER'][strlen($valarm['TRIGGER'])-1] == 'Z')
				{
					// date	
					// utc
					$trigger = ical_datetime(date($newtrigger->getTime())) . 'Z';
				}
				else
				{
					$eventTime = new Date($eventtime[0]);				
					$newtrigger = ($newtrigger->getTime() - $eventTime->getTime());
					$trigger = seconds_to_ical_duration($newtrigger);
				}
			}
		}

		return $trigger;
	}
	
	function snoozeAlarm($id, $href, $mins)
	{
		$events = $this->_caldav_server->GetEntryByUid( $id, urldecode($href));
		$munchedEvents = $this->munchEvents($events);
		$event = $munchedEvents[0];

		if(isset($event['VALARM']))
		{
			$event['VALARM']['TRIGGER'] = $this->caldav_modify_alarm_trigger($event, $href, $mins);

			$event['VCALENDAR']['VEVENT']['VALARM'] = $event['VALARM'];
			unset($event['VALARM']);
			$event_text = ical_create_entry($event);
			$url = $href . $event['VCALENDAR']['VEVENT']['UID'] . '.ics';
			$event['etag'] = $this->_caldav_server->DoPUTRequest($url, $event_text, $event['etag']);
		}
		
		return findetag($this->_caldav_server, $href);
	}
	
	function testServerType()
	{
		if($this->load_failed)
			return "un";
			
		$this->_server_auth_failed = false;
		$this->_server_type = $this->_caldav_server->DoServerCheckType();
		
		if( $this->_server_type == false )
		{
			$this->_server_auth_failed = true;
			$this->_server_type = "un";
		}
		
		return $this->_server_type;
	}


	function convert_from_outlook_date($date)
	{
		$seconds = time(); // Current time in seconds
	
		$datecalc = $date; // This has the date
		$seconds = '';
		if (preg_match('/\.(.*)/', $date, $match))
			$seconds = $match[1];
	
		$datecalc = preg_replace('/\.(.*)/', '', $datecalc);
	
		// Calculate the number of days since 1899; it differs
		// if the time is greater/lesser then GMT
		if (!$this->time1 || !$this->time2)
		{
			// Get our local time in Epoc
			$this->time1 = date('U', time() + intval(date('Z')));
	
			// Get our GMT time
			$this->time2 = date('U', gmmktime());
	
		}
		$time3 = $this->time1 - $this->time2;
	
		$now = gettimeofday();
		$diff = 0;	
	
		if(intval(date('Z')) < 0)
		{
			$diff = 1;
		}
	
		$datecalc = $datecalc - "25569" + $diff;
		$datecalc = round($datecalc * 60 * 60 * 24);
		$newdate = strftime("%Y-%m-%d", $datecalc );
	
		// Int rounds it up - 86400 seconds in 1 day 0.[secsyougiveme]
		$newsecs = round("0.$seconds"  * 86400);
	
		$time = gmstrftime("%T", $newsecs );
	
		if (preg_match('/:59$/', $time))
			$time = strftime("%T", $newsecs + 1);
		elseif (preg_match('/:01$/', $time))
			$time = strftime("%T", $newsecs - 1);
	
		$newdate = "$newdate $time";
	
		return $newdate;
	}
	
	
	function convert_to_outlook_date($date)
	{
		$seconds = time();
	
		$datecalc = $date;
	
		// Regular expression out the time, just get the secs for that specified day
		$datecalc = preg_replace('/\s(\d+:\d+:\d+)/', ' 00:00:00', $datecalc);

		$seconds = strtotime($datecalc);
		$days = round($seconds / 60 / 60 / 24);
	
		// Calculate the number of days since 1899; it differs
		// if the time is greater/lesser then GMT
		// Calculate the number of days since 1899; it differs
		// if the time is greater/lesser then GMT
		if (!$this->time1 || !$this->time2)
		{
			// Get our local time in Epoc
			$this->time1 = date('U', time() + intval(date('Z')));
	
			// Get our GMT time
			$this->time2 = date('U', gmmktime());
	
		}
		
		$numdays = $days + "25569";
	
		$secsnow = strtotime($date);
		$diff = $secsnow - $seconds;
	
		$perc = $diff / 86400;
	
		$perc = sprintf("%6f", $perc);
		$perc = preg_replace('/\d+\./', '', $perc);
	
		return "$numdays.$perc";
	}

	function getServerType()
	{
		return $this->_server_type;	
	}

	function getServerAuthFailed()
	{
		return $this->_server_auth_failed;	
	}

	function ping()
	{
		return $this->testServerType();
	}

	/****************************************************************
	* munchEvents
	* converts a vCalendar string to a nice array
	*
	* array format will be similar to following
	* Array (
	* [0] => Array (
	*	[VCALENDAR] => Array (
	*		[VERSION] => 2.0
	*		[PRODID] => -//Apple Inc.//iCal 3.0//EN
	*		[CALSCALE] => GREGORIAN )
	*	[VTIMEZONE] => Array (
	*		[TZID] => Australia/Sydney
	*		[STANDARD] => Array (
	*			[TZOFFSETFROM] => +1100
	*			[TZOFFSETTO] => +1000
	*			[DTSTART] => 20080406T030000
	*			[RRULE] => FREQ=YEARLY;BYMONTH=4;BYDAY=1SU
	*			[TZNAME] => EST )
	*		[DAYLIGHT] => Array	(
	*			[TZOFFSETFROM] => +1000
	*			[TZOFFSETTO] => +1100
	*			[DTSTART] => 20081005T020000
	*			[RRULE] => FREQ=YEARLY;BYMONTH=10;BYDAY=1SU
	*			[TZNAME] => EST ) )
	*	[VEVENT] => Array (
	*		[SEQUENCE] => 2
	*		[TRANSP] => OPAQUE
	*		[UID] => 7DDD0A22-0F82-42C9-BF3C-645E9138C690
	*		[DTSTART;TZID=Australia/Sydney] => 20090205T160000
	*		[DTSTAMP] => 20090205T014141Z
	*		[SUMMARY] => ical event!
	*		[CREATED] => 20090205T014134Z
	*		[DTEND;TZID=Australia/Sydney] => 20090205T170000 ) ) )
	*
	* Also supports VTODO
	******************************************************************/
	public function munchEvents($events_in)
	{	
		$events = array();
		if ( is_array($events_in) )
		{
			foreach ( $events_in AS $k => $event )
			{	
				array_push($events, ical_load_entry($event));
			}
		}
		return $events;
	}

	public function generateHtmlPreview($event, $acceptUrl)
	{
		/*
		
		    [VCALENDAR] => Array
		        (
		            [PRODID] => -//Microsoft Corporation//Outlook 12.0 MIMEDIR//EN
		            [VERSION] => 2.0
		            [METHOD] => REQUEST
		            [X-MS-OLK-FORCEINSPECTOROPEN] => TRUE
		            [VEVENT] => Array
		                (
		                    [ATTENDEE] => mailto:test@centos.virgin
		                    [ATTENDEE2] => mailto:testagain@centos.virgi
		                    [CLASS] => PUBLIC
		                    [CREATED] => 20100708T051132Z
		                    [DESCRIPTION] => When: Thursday\, 8 July 2010 3:30 PM-4:00 PM (GMT+10:00) Canber
		                    [DTEND] => 20100708T060000Z
		                    [DTSTAMP] => 20100708T051132Z
		                    [DTSTART] => 20100708T053000Z
		                    [LAST-MODIFIED] => 20100708T051132Z
		                    [ORGANIZER] => mailto:test@centos.virgin
		                    [PRIORITY] => 5
		                    [SEQUENCE] => 0
		                    [SUMMARY] => fesfsef
		                    [TRANSP] => OPAQUE
		                    [UID] => 040000008200E00074C5B7101A82E00800000000600233D9AF1ECB01000000000000000
		                    [X-ALT-DESC] => <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2//E
		                    [ri">When] =>  Thursday\, 8 July 2010 3:30 PM-4:00 PM (GMT+10:00) Canberra\, Me
		                    [X-MICROSOFT-CDO-BUSYSTATUS] => TENTATIVE
		                    [X-MICROSOFT-CDO-IMPORTANCE] => 1
		                    [X-MICROSOFT-CDO-INTENDEDSTATUS] => BUSY
		                    [X-MICROSOFT-DISALLOW-COUNTER] => FALSE
		                    [X-MS-OLK-ALLOWEXTERNCHECK] => TRUE
		                    [X-MS-OLK-AUTOSTARTCHECK] => FALSE
		                    [X-MS-OLK-CONFTYPE] => 0
		                    [X-MS-OLK-SENDER] => mailto:test@centos.virgin
		                )

		        )

		    [VALARM] => Array
		        (
		            [TRIGGER] => -PT15M
		            [ACTION] => DISPLAY
		            [DESCRIPTION] => Reminder
		        )

		    [etag] => 
		)

		*/
		if(!isset($event['VCALENDAR']) || !isset($event['VCALENDAR']['VEVENT']))
		{
			return "Invalid ICS file.";
		}
		$vcal = $event['VCALENDAR'];
		$vevent = $vcal['VEVENT'];
		
		if(isset($vevent['ORGANIZER']))
		{
			// ORGANIZER is set
			$output .= htmlentities(str_replace("mailto:", "", $vevent['ORGANIZER'])) . " has invited you to attend the appointment below : <br><br>";
		}
		else
		{
			$output .= "You have been invited to attend the appointment below : <br>";					
		}

		$entry = array();
		$entry['id'] = $vevent['UID'];
		list($dtstart, $dtend) = calendar::caldav_extract_dtstamps($event);

		$entry['DateStartCal'] = calendar::caldav_strip_date($dtstart);
		$entry['DateStartTime'] = calendar::caldav_strip_time($dtstart);
		$entry['DateEndCal'] = calendar::caldav_strip_date($dtend);
		$entry['DateEndTime'] = calendar::caldav_strip_time($dtend);
		
		$entry['Title'] = ical_decode($event['VCALENDAR']['VEVENT']['SUMMARY']);

		// websync compat patch	
		if(!isset($event['VCALENDAR']['VEVENT']['DESCRIPTION']))
		{
			$event['VCALENDAR']['VEVENT']['DESCRIPTION'] = 'None';
		}

		$entry['CalMessage'] = ical_decode($event['VCALENDAR']['VEVENT']['DESCRIPTION']);
		
		if (isset($event['VCALENDAR']['VEVENT']['LOCATION']))
		{
			$entry['Location'] = ical_decode($event['VCALENDAR']['VEVENT']['LOCATION']);
		}
		else
		{
			$entry['Location'] = 'None';	
		}
				
		$stamp = calendar::caldav_extract_dtstamp('DTSTAMP', $event);
		$entry['DateModified'] = calendar::caldav_strip_date($stamp) . ' ' . calendar::caldav_strip_time($stamp);
		$siteurl = Zend_Registry::get('siteBaseUrl');
		$version = Zend_registry::get('config')->global['version'];
		$output .= <<< EOF
		<link rel="stylesheet" href="{$siteurl}css/reset.css?{$version}" type="text/css" media="screen, print" />
		<link rel="stylesheet" href="{$siteurl}css/common.css?{$version}" type="text/css" media="screen, print" />
		<link rel="stylesheet" href="{$siteurl}css/calendar.css?{$version}" type="text/css" media="screen, print" />
		<link rel="stylesheet" href="{$siteurl}css/ui.css?{$version}" type="text/css" media="screen, print" />
		<link rel="stylesheet" href="{$siteurl}css/webmail.css?{$version}" type="text/css" media="screen, print" />
		<script type="text/javascript" src="{$siteurl}js/jQuery/jquery-1.3.2.min.js"></script>
		<script type="text/javascript" src="{$siteurl}js/jQuery/ui/jquery-ui-1.7.2.custom.min.js"></script>
		<script type="text/javascript" src="{$siteurl}js/jQuery/plugins/jquery.json-1.3.min.js"></script>
		<script type="text/javascript" src="{$siteurl}js/jQuery/plugins/jquery.jcacher-1.0.0.js"></script>
		<script type="text/javascript" src="{$siteurl}js/jQuery/plugins/jquery.php.js"></script>
<div style="position: relative; width: 100%; height: 110px;">
<div id={$entry['id']} style="position: absolute; left: 0px; right: 0px; height: 95px; padding: 0px; background-color: rgb(190, 207, 241); border: 1px solid rgb(73, 109, 192); color: rgb(73, 109, 192);" class="private"><div id="appointment_header" style="position: absolute; overflow: hidden; left: 0px; right: 0px; height: 20px; top: 0px; padding: 0px; opacity: 0.5; background-color: rgb(58, 87, 153);" class="private_header"></div><div style="left: 0px; right: 0px; overflow: hidden; height: 172px; padding: 2px; color: rgb(73, 109, 192);"><div id="title_text" style="overflow: hidden; width: 95%; height: 15px; font-size: smaller;" class="private_text_header">{$entry['DateStartCal']} {$entry['DateStartTime']} to {$entry['DateEndCal']} {$entry['DateEndTime']}</div>
<!--
<div id="remove" title="Remove" style="overflow: hidden; width: 16px; height: 16px; position: absolute; right: 6px; cursor: pointer; top: 2px; opacity: 0.5;">
<img width="16" height="16" border="0" id="remove_img" src="/mail/images/icons/btn-close.png">
</div>
<div id="advanced" title="Edit Event" style="overflow: hidden; position: absolute; top: 2px; right: 26px; width: 16px; height: 16px; opacity: 0.5;">
<img width="16" height="16" border="0" id="advanced" src="/mail/images/icons/options.png">
</div>
<div id="loading" title="" style="display: none; overflow: hidden; position: absolute; top: 1px; right: 46px; width: 16px; height: 16px; opacity: 0.5;"><img width="16" height="16" border="0" id="loading`" src="/mail/images/icons/calendar-wait.gif">
</div>
-->
<div id="textarea" class="private_text" style="height: 60px; position: absolute; left: 1%; right: 1%; width: 97.8%; top: 25px; bottom: 10px; overflow: hidden; word-wrap: break-word; border: 0pt none; background-color: transparent; color: rgb(73, 109, 192); font: 12px/1.3 'Helvetica Neue",Helvetica,Arial,sans-serif'>Title : {$entry['Title']}<br>Description : {$entry['CalMessage']}<br>Location : {$entry['Location']}</div></div></div>
</div>
<div id="action_buttons" style="position:relative">
<div onclick="$.php('{$acceptUrl}');" class="savecontact saveButton" id="back_button"><a href="#"><span>Accept<strong> Event</strong></span></a></div>
</div>
EOF;
		return $output;
	}

	// caldav_strip_date
	// returns yyyy-mm-dd from yyyymmddTHHMMSSZ
	public function caldav_strip_date($caldav_datetime)
	{
		if($caldav_datetime == '')
			return '';
			
		$temp = str_split($caldav_datetime,4);
		$year = $temp[0];
		$temp = str_split($caldav_datetime,2);
		$month = $temp[2];
		$day = $temp[3];
		return sprintf("%s-%s-%s", $year, $month, $day);
	}

	// caldav_strip_time
	// returns HH-MM from yyyymmddTHHMMSSZ
	public function caldav_strip_time($caldav_datetime)
	{
		if($caldav_datetime == '')
			return '';
		list($junk, $temp) = explode("T", $caldav_datetime);
		$temp = str_split($temp,2);
		$hour = $temp[0];
		$min = $temp[1];
		$sec = $temp[2];
		if($hour == '')
			$hour = '00';
		if($min == '')
			$min = '00';
		if($sec == '')
			$sec = '00';

		return sprintf("%s:%s:%s", $hour, $min, $sec);
	}

	public static function caldav_extract_dtstamp($dtstamp, $event)
	{
		if( isset($event['VCALENDAR']['VEVENT']) )
		{
			$type = "VEVENT";
		}
		else if( isset($event['VCALENDAR']['VTODO']) )
		{
			$type = "VTODO";
		}
		if( isset($event['VCALENDAR']['VTIMEZONE']) )
		{
			// we have timezone information
			if( isset($event['VCALENDAR'][$type][$dtstamp . ';TZID='.$event['VCALENDAR']['VTIMEZONE']['TZID']]) )
			{
				return $event['VCALENDAR'][$type][$dtstamp . ';TZID='.$event['VCALENDAR']['VTIMEZONE']['TZID']];
			}
			if( isset($event['VCALENDAR'][$type][$dtstamp . ';VALUE=DATE']) )
			{
				return $event['VCALENDAR'][$type][$dtstamp . ';VALUE=DATE'] . "T235959Z";
			}
		}

		if( isset($event['VCALENDAR'][$type][$dtstamp]) )
		{
			return $event['VCALENDAR'][$type][$dtstamp];
		}
		else if ( isset($event['VCALENDAR'][$type][$dtstamp . ';VALUE=DATE']) )
		{
			return $event['VCALENDAR'][$type][$dtstamp . ';VALUE=DATE'] . 'T000000';
		}
	
		return null;
	}

	public function getGroupMembership($cal, $username)
	{
		return getPrincipalMembers($cal, $username);
	}
	
	// ****************************************************************
	// getPushCalHref
	// Grabs the private calendar store for push (i.e. must be low server load - this is called a lot)
	public function getPushCalHref()
	{
		$cal = $this->_caldav_server;
		$url = $this->caldav_URL;

		$calNames = array();
		if($this->_local && $this->_server_type == "at")
		{
			$folders[] = array('relative_href' => $this->username . '/calendar/', 'displayname' => 'Private');
			$this->calNamesCache = $folders;
		}
		else
		{
			$folders = $this->getCalNames();
		}
		return $folders;
	}
	
	
	// ****************************************************************
	// getCalNames
	// Grabs all the calendar stores from any principal stores connected
	// to the current login !
	public function getCalNames($cal = null, $url = null)
	{
		if( !$cal )
		{
			$cal = $this->_caldav_server;
		}
		
		if( !$url )
		{
			$url = $this->caldav_URL;
		}

		$calNames = array();
		$temp_username = $this->username;
		
		$principals = getfolders($cal, $url, 'calendar', $temp_username . '/');
				
		if( count($principals) == 0 )
		{
			// ok, no principal stores...
			// so lets try and see if there are collections..
			$principals = getfolders($cal, $url, 'collection', $temp_username . '/');
		}
		$groups = $this->getGroupMembership($cal, $this->username);

		if(gettype($principals) != "array")
			$principals = array();
		if(gettype($groups) != "array")
			$groups = array();
		
		$principals = array_merge($principals, $groups);

		$folders = array();

		if( $principals != null )
		{
			foreach( $principals as $principal )
			{

				if( $this->_server_type != 'be' )
				{
					$oldbase = $cal->base_url;
					$cal->base_url = $principal['url_info'][1];
					$newfolders = getfolders($cal, $url, "calendar", $principal['relative_href']);
					$cal->base_url = $oldbase;
	
					for( $i=0;$i<count($newfolders);$i++ )
					{
						if( !in_array( $newfolders[$i], $folders) )
						{
							$folders = array_merge($folders, Array($newfolders[$i]));
						}
					}
				}
				else
				{
					// bedework
					if( $principal['resourcetype'][1] == 'calendar' )
					{
						$folders = array($principal);
					}	
				}
			}
		}
		
		// lets see what folders are ours
		for( $i=0;$i<count($folders);$i++ )
		{
			$folders[$i]['shared'] = '1';
			list($username, $rubbish) = explode("@", $cal->user);
			list($relative_username, $rubbish) = explode("/", urldecode($folders[$i]['relative_href']));
			list($relative_username, $domain) = explode("@", $relative_username);
			if(strstr($relative_username, '-') != NULL && strcmp($relative_username, $username) != 0)
				$relative_username = substr($relative_username, 0, strrpos($relative_username, '-'));

			if( strcmp($relative_username, $username) == 0 )
			{
				$folders[$i]['shared'] = '0';
				$folders[$i]['calendar_owner'] = $cal->user;
			}
			else
			{
				$username = $relative_username;

				if( $username != '' && $domain != '' )
				{
					$folders[$i]['calendar_owner'] = $username . "@" . $domain;
				}
				else
				{
					$folders[$i]['calendar_owner'] = $cal->user;
				}
			}
			$folders[$i]['color'] = substr($folders[$i]['color'], 0, -2);
		}
		$this->calNamesCache = $folders;
		return $folders;
	}
	
	public function getPrivateEtag()
	{
		$etag = findetag($this->_caldav_server, $this->username . '/calendar/');
		if(strpos($etag, '<getetag>') != false)
		{
			list($junk, $etag) = explode('<getetag>', findetag($this->_caldav_server, $this->username . '/calendar/'), 2);
			list($etag, $junk) = explode('</getetag>', $etag, 2);
		}
		
		if($etag)
		{
			$etag = trim($etag, 'W/');
			$etag = trim($etag, '"');
		}
		return $etag;
	}

	public function getEtags()
	{
		return $calNamesCache;
	}
	
	public function PushArray2RecurrenceArray($recurrence)
	{
		if( gettype($recurrence) != "object" )
			return false;
		$recurrenceRules = array();
		
		/*[recurrence] => SyncRecurrence Object
		        (
		            [type] => 0
		            [until] => 
		            [occurrences] => 
		            [interval] => 1
		            [dayofweek] => 
		            [dayofmonth] => 
		            [weekofmonth] => 
		            [monthofyear] => 
		            [content] => 
		            [attributes] => 
		            [flags] => 
		*/
		$recurrenceRules['skipInterval'] = $recurrence->interval;
		switch($recurrence->type)
		{
			case 0: //daily
			case 1: //weekly
			case 2: //monthly
			{
				$recurrenceRules['RecurrenceType'] = $recurrence->type + 10;
			}
			break;
			case 5: // yearly
			{
				$recurrenceRules['RecurrenceType'] = 13;
			}
		}
		
		$recurrenceRules['IsSimple'] = 0;
		$recurrenceRules['recurrenceEndType'] = 0;

		if(isset($recurrence->until))
		{
			$recurrenceRules['recurrenceEndType'] = 2;
		}
		$recurrenceRules['recurrenceEndAfterXOccurances'] = $recurrenceRules['Occurences'] = $recurrence->occurrences;
		$recurrenceRules['recurrenceEndByDate'] = $recurrenceRules['Until'] = $recurrence->until;
		$recurrenceRules['DayOfWeek'] = $recurrence->dayofweek;
		$recurrenceRules['DayOfMonth'] = $recurrence->dayofmonth;
		$recurrenceRules['MonthOfYear'] = $recurrence->monthofyear;
		
		return $recurrenceRules;
	}
	
	public function RecurrenceArray2PushArray($event)
	{
		if(!isset($event['recurrenceArray']))
		{
			return;
		}
		$recurrenceRules = $event['recurrenceArray'];

		$recurrence = new SyncRecurrence;		
		/*RecurrenceType] => 10
		            [IsSimple] => 1
		            [DayOfWeekMask] => 127
		            [skipInterval] => 1
		            [DayOfWeek] => 
		            [DayOfMonth] => 
		            [MonthOfYear] => 
		            [NoEndDate] => 1
		            [Occurences] => 0
		            [PatternStartDate] => 20100816T170000
		            [PatternEndDate] => 20100816T180000
		            [Until] => 0
		            [Instance] => 
		
		*/
		$recurrence->interval = $recurrenceRules['skipInterval'];
		switch($recurrenceRules['RecurrenceType'])
		{
			case 10: //daily
			case 11: //weekly
			case 12: //monthly
			{
				$recurrence->type = $recurrenceRules['RecurrenceType'] - 10;
			}
			break;
			case 13: // yearly
			{
				$recurrence->type = 5;
			}
		}
		
		if(isset($recurrenceRules['recurrenceEndType']) && $recurrenceRules['recurrenceEndType'] != '')
		{
			if( $recurrenceRules['recurrenceEndType'] == 2)
			{
				$recurrence->until = $recurrenceRules['Until'];
				$recurrence->occurrences = $recurrenceRules['Occurences'];
			}
		}
		$recurrence->dayofweek = $recurrenceRules['DayOfWeek'];
		$recurrence->dayofmonth = $recurrenceRules['DayOfMonth'];
		$recurrence->monthofyear = $recurrenceRules['MonthOfYear'];

		return $recurrence;
	}
	
	public function RecurrenceArray2ical($recurrenceRules)
	{
		$recurrenceRule = "";
		
		if(!isset($recurrenceRules['RecurrenceType'])) $recurrenceRules['RecurrenceType'] = 0;
		if(!isset($recurrenceRules['RecurrenceEndType'])) $recurrenceRules['RecurrenceEndType'] = 0;
		if(!isset($recurrenceRules['IsSimple'])) $recurrenceRules['IsSimple'] = 0;
		if(!isset($recurrenceRules['DayOfWeekMask'])) $recurrenceRules['DayOfWeekMask'] = 0;
		if(!isset($recurrenceRules['skipInterval'])) $recurrenceRules['skipInterval'] = 0;
		if(!isset($recurrenceRules['DayOfWeek'])) $recurrenceRules['DayOfWeek'] = 0;
		if(!isset($recurrenceRules['DayOfMonth'])) $recurrenceRules['DayOfMonth'] = 0;
		if(!isset($recurrenceRules['MonthOfYear'])) $recurrenceRules['MonthOfYear'] = 0;
		if(!isset($recurrenceRules['NoEndDate'])) $recurrenceRules['NoEndDate'] = 0;
		if(!isset($recurrenceRules['Occurences'])) $recurrenceRules['Occurences'] = 0;
		if(!isset($recurrenceRules['PatternStartDate'])) $recurrenceRules['PatternStartDate'] = 0;
		if(!isset($recurrenceRules['PatternEndDate'])) $recurrenceRules['PatternEndDate'] = 0;
		if(!isset($recurrenceRules['Until'])) $recurrenceRules['Until'] = 0;
					
		$RecurrenceType = $recurrenceRules['RecurrenceType'];
		$recurrenceEndType = $recurrenceRules['RecurrenceEndType'];
		$simpleRecurrence = $recurrenceRules['IsSimple'];
		$DayOfWeekMask = $recurrenceRules['DayOfWeekMask'];
		$skipInterval = $recurrenceRules['skipInterval'];
		$DayOfWeek = $recurrenceRules['DayOfWeek'];
		$DayOfMonth = $recurrenceRules['DayOfMonth'];
		$MonthOfYear = $recurrenceRules['MonthOfYear'];
		$NoEndDate = $recurrenceRules['NoEndDate'];
		$Count = $recurrenceRules['Occurences'];
		$PatternStartDate = $recurrenceRules['PatternStartDate'];
		$PatternEndDate = $recurrenceRules['PatternEndDate'];
		$Until = $recurrenceRules['Until'];
		
		
		if( $skipInterval == '' )
			$skipInterval = 0;
			
		if( 	$RecurrenceType != 10
			&& 	$RecurrenceType != 11
			&&	$RecurrenceType != 12
			&&	$RecurrenceType != 13
			)
		{
			$recurrenceEndType = -1;
		}
		
		switch ($RecurrenceType)
		{
			case 10 : // daily
			{
				$freq = "DAILY";
			} break;
			case 11 : // Weekly
			{
				$freq = "WEEKLY";		
			} break;
			case 12 : // Monthly
			{
				$freq = "MONTHLY";
			} break;
			case 13 : // Yearly
			{
				$freq = "YEARLY";
			} break;
		}
		
		if($recurrenceEndType == 0)
		{
			// no end date
			$recurrenceRule['RRULE'] = 'FREQ=' . $freq . ';INTERVAL=' . $skipInterval;
			$recurrenceRule['RRULE2'] = 'FREQ=' . $freq . ';COUNT=400';
		}
		else if ($recurrenceEndType == 1)
		{
			// end after occurances
			$recurrenceRule['RRULE'] = 'FREQ=' . $freq . ";INTERVAL=" . $skipInterval .";COUNT=" . $Count;
		}
		else if ($recurrenceEndType == 2)
		{
			// end after occurances
			if(is_int($Until))
			{
				$Until = ical_datetime(date($Until));
			}
			else
			{
				$Until = ical_datetime(date(strtotime($Until)));
			}
			$recurrenceRule['RRULE'] = 'FREQ=' . $freq . ";INTERVAL=" . $skipInterval . ";UNTIL=" . $Until;
		}		
		
		return $recurrenceRule;
	}
	
	// convert ical ics entry to a recurrencearray	
	public function ical2RecurrenceArray($munchedEvent)
	{
		$recurrencePattern = array();
		
		if(!isset($munchedEvent['VCALENDAR']['VEVENT']['RRULE']))
		{
			return;
		}
		
		list($PatternStartDate, $PatternEndDate) = calendar::caldav_extract_dtstamps($munchedEvent);
			
		$recurrenceRule = $munchedEvent['VCALENDAR']['VEVENT']['RRULE'];

		
		//[RRULE] => FREQ=DAILY;INTERVAL=2;COUNT=2

		$recurrenceRawRules = explode(";", $recurrenceRule);
		foreach($recurrenceRawRules as $recurrenceRule)
		{
			$recurrenceRule = explode("=", $recurrenceRule);
			$recurrenceRules[$recurrenceRule[0]] = $recurrenceRule[1];
		}

/*		list($RecurrenceType, $Interval) = explode(";", $recurrenceRule, 2);
		$RecurrenceType = str_replace('FREQ=', '', $RecurrenceType);
		list($Interval, $Count) = explode(";", $Interval);
		$Interval = str_replace("INTERVAL=", '', $Interval);
		$Count = str_replace("COUNT=", '', $Count);*/
		//$Until = UNTIL

		if(isset($recurrenceRules['FREQ']))
			$RecurrenceType = $recurrenceRules['FREQ'];
		if(isset($recurrenceRules['INTERVAL']))
			$Interval = $recurrenceRules['INTERVAL'];
		if(isset($recurrenceRules['COUNT']))
			$Count = $recurrenceRules['COUNT'];
		
		if(!isset($Count) || $Count == 400)
			$Count = 0;
			
		//RRULE:FREQ=WEEKLY;INTERVAL=1
		//RRULE:FREQ=WEEKLY;COUNT=400
		
		// GLUE for ical > old recurrence patterns
		$simpleRecurrence = 0;
		$DayOfWeekMask = '';
		$DayOfMonth = '';
		$MonthOfYear = '';
		$DayOfWeek = '';
		$Until = 0;
			
		if(isset($recurrenceRules['UNTIL']))
		{
			$Until = 1;
			$PatternEndDate = new Date(strtotime($recurrenceRules['UNTIL']) + 60 * 60 * 24);
			$simpleRecurrence = 0;
			$NoEndDate = 0;
		}
		else
		{
			$NoEndDate = 1;
		}
		
		if(isset($munchedEvent['VCALENDAR']['VEVENT']['RRULE2']))
		{
			$recurrenceRule2 = $munchedEvent['VCALENDAR']['VEVENT']['RRULE2'];
			$recurrenceRawRules2 = explode(";", $recurrenceRule2);
			foreach($recurrenceRawRules as $recurrenceRule)
			{
				$recurrenceRule = explode("=", $recurrenceRule);
				$recurrenceRules2[$recurrenceRule[0]] = $recurrenceRule[1];
			}
			
/*			list($RecurrenceType2, $Count) = explode(";", $recurrenceRule2);
			$RecurrenceType2 = str_replace('FREQ=', '', $RecurrenceType2);
			$Count = str_replace("COUNT=", '', $Count);*/
			if(isset($recurrenceRules2['FREQ']))
				$RecurrenceType2 = $recurrenceRules2['FREQ'];
			if(isset($recurrenceRules2['COUNT']))
				$Count = $recurrenceRules2['COUNT'];
			
		}

		// each day
		$skipInterval = $Interval;
		
		switch ($RecurrenceType)
		{
			case "DAILY" : // daily
			{

				$RecurrenceType = 10;
				if($Interval == 1 && $Count == 0)
				{
					$simpleRecurrence = 1;
				}
				$RecurrenceInterval = $Interval;

				// every day is valid
				if($simpleRecurrence)
				{
					$DayOfWeekMask = 0x7f;
				}
			} break;
			case "WEEKLY" : // Weekly
			{
				$RecurrenceType = 11;
				$date = new Date(strtotime($PatternStartDate));
				
				$DayOfWeek = $date->getDayOfWeek();
				
				if($Interval == 1 && $Count == 0 && !$Until)
				{
					$simpleRecurrence = 1;
				}
				
				switch($DayOfWeek)
				{
					case 0 : $DayOfWeekMask = $DayOfWeekMask | 1; break;		// sunday
					case 1 : $DayOfWeekMask = $DayOfWeekMask | 2; break;		// monday
					case 2 : $DayOfWeekMask = $DayOfWeekMask | 4; break;		// tuesday
					case 3 : $DayOfWeekMask = $DayOfWeekMask | 8; break;		// wednesday
					case 4 : $DayOfWeekMask = $DayOfWeekMask | 16; break;		// thursday
					case 5 : $DayOfWeekMask = $DayOfWeekMask | 32; break;		// friday
					case 6 : $DayOfWeekMask = $DayOfWeekMask | 64; break;		// saturday
				}
			} break;
			case "MONTHLY" : // Monthly
			{
				$RecurrenceType = 12;
				if($Interval == 1 && $Count == 0 && !$Until)
				{
					$simpleRecurrence = 1;
				}
				$date = new Date(strtotime($PatternStartDate));
				$DayOfMonth = $date->getDay();
			} break;
			case "YEARLY" : // Yearly
			{
				$RecurrenceType = 13;
				if($Interval == 1 && $Count == 0 && !$Until)
				{
					$simpleRecurrence = 1;
				}
				$date = new Date(strtotime($PatternStartDate));
				$DayOfMonth = $date->getDay();
				$MonthOfYear = $date->getMonth();
			} break;
		}
		
		$recurrencePattern['RecurrenceType'] = $RecurrenceType;
		$recurrencePattern['IsSimple'] = $simpleRecurrence;
		$recurrencePattern['DayOfWeekMask'] = $DayOfWeekMask;
		$recurrencePattern['skipInterval'] = $skipInterval;
		$recurrencePattern['DayOfWeek'] = $DayOfWeek;
		$recurrencePattern['DayOfMonth'] = $DayOfMonth;
		$recurrencePattern['MonthOfYear'] = $MonthOfYear;
		$recurrencePattern['NoEndDate'] = $NoEndDate;
		$recurrencePattern['Occurences'] = $Count;
		$recurrencePattern['PatternStartDate'] = $PatternStartDate;
		$recurrencePattern['PatternEndDate'] = $PatternEndDate;
		$recurrencePattern['Until'] = $Until;
		$recurrencePattern['Instance'] = '';
	//	$recurrencePattern['RecurrenceEndType'] = $recurrenceEndType;
		
 		return $recurrencePattern;
	}
	
	// Generate a recurrence pattern for UI given ID
	public function RecurrenceArray2RecurrencePattern($recurrenceArray)
	{
		$sync = false;
		/*if($shared==1)
		{
			$recurrencePattern = $sql->sqlhash("select * from recurrencePatterns where linkid = $linkid");
		}
		else
		{
			$recurrencePattern = $sql->sqlhash("select * from recurrencePatterns where linkid = $linkid and account = \"$account\"");
		}*/
	
		// we got a pattern ?
		/*if(!isset($munchedEvent['VCALENDAR']['VEVENT']['RRULE']))
			return "0";	*/

		// [RRULE] => FREQ=DAILY;INTERVAL=1
        // [RRULE2] => FREQ=DAILY;COUNT=400


		$recurrencePattern = $recurrenceArray; //$this->ical2RecurrenceArray($munchedEvent, $PatternStartDate, $PatternEndDate);
		
		$RecurrenceType = $recurrencePattern['RecurrenceType'];
		$simpleRecurrence = $recurrencePattern['IsSimple'];
		
		$pattern = "";
		
		switch ($RecurrenceType)
		{
			case 10 : // Daily
			{
				$pattern .= "1";
			} break;
			case 11 : // Weekly
			{
				$pattern .= "2";
			} break;
			case 12 : // Monthly
			{
				$pattern .= "3";
			} break;
			case 13 : // Yearly
			{
				$pattern .= "4";
			} break;
		}
		
		if($simpleRecurrence == 1 && !$sync)
		{
			return $pattern;
		}
	
		// ok, lets build the recurrence pattern for the ui...
		// we are some kind of advanced pattern...
		// ARGH.
		switch ($RecurrenceType)
		{
			case 10 : // Daily
			{
				// if every day is valid and we have a skip interval
				if($recurrencePattern['DayOfWeekMask']==0x7f && $recurrencePattern['skipInterval'] != 0)
				{
					// we must be every x days
					$pattern .= ",0," . $recurrencePattern['skipInterval'];
				}
				else if($sync)
				{
					// we must be every weekday VIA sync ( Fake as a weekly, however @mail internal works as normal )
					$pattern = "2,1,1,1,1,1,1,0,0";
	
				}
				else
				{
					// we must be every weekday
					$pattern .= ",1";
				}
			} break;
			case 11 : // Weekly
			{
				// freq - Different format for Websync again
				if($sync && $recurrencePattern['skipInterval'] == 0)
				$pattern .= ",1";
				// Normal pattern for Webmail
				else
				$pattern .= "," . $recurrencePattern['skipInterval'];
		
				if( ($recurrencePattern['DayOfWeekMask'] & 2)!=0)	// monday
					$pattern .= ",1";
				else
					$pattern .= ",0";
				if( ($recurrencePattern['DayOfWeekMask'] & 4)!=0)	// tuesday
					$pattern .= ",1";
				else
					$pattern .= ",0";
				if( ($recurrencePattern['DayOfWeekMask'] & 8)!=0)	// wednesday
					$pattern .= ",1";
				else
					$pattern .= ",0";
				if( ($recurrencePattern['DayOfWeekMask'] & 16)!=0)	// thursday
					$pattern .= ",1";
				else
					$pattern .= ",0";
				if( ($recurrencePattern['DayOfWeekMask'] & 32)!=0)	// friday
					$pattern .= ",1";
				else
					$pattern .= ",0";
				if( ($recurrencePattern['DayOfWeekMask'] & 64)!=0)	// saturday
					$pattern .= ",1";
				else
					$pattern .= ",0";
				if( ($recurrencePattern['DayOfWeekMask'] & 1)!=0)	// sunday
					$pattern .= ",1";
				else
					$pattern .= ",0";
	
			} break;
			case 12 : // Monthly
			{
				// see if we have a instance value
				if($recurrencePattern['Instance'] != 0)
				{
					// we must be 'the x y of every z months
					$pattern .= ",1";
	
					// this is a INSTANCE PATTERN - not just instance.
					if($recurrencePattern['Instance'] == 32)
					{
						// special value here, 32 = last day of month.
						$pattern .= ",4";
					}
					else
					{
						$pattern .= "," . ($recurrencePattern['Instance'] - 1);
					}
					$DayOfWeekMask = $recurrencePattern['DayOfWeekMask'];
	
					if($DayOfWeekMask==0x7F)		$pattern .= ",0";	// day
					else if($DayOfWeekMask==0x3E)	$pattern .= ",1";	// weekday
					else if($DayOfWeekMask==0x41)	$pattern .= ",2";	// weekend day
					else if($DayOfWeekMask==0x2)	$pattern .= ",3";	// monday
					else if($DayOfWeekMask==0x4)	$pattern .= ",4";	// tuesday
					else if($DayOfWeekMask==0x8)	$pattern .= ",5";	// wednesday
					else if($DayOfWeekMask==0x10)	$pattern .= ",6";	// thursday
					else if($DayOfWeekMask==0x20)	$pattern .= ",7";	// friday
					else if($DayOfWeekMask==0x40)	$pattern .= ",8";	// saturday
					else if($DayOfWeekMask==0x1)	$pattern .= ",9";	// sunday
	
					$pattern .= "," . $recurrencePattern['skipInterval'];
				}
				else
				{
					// we must be Day X of every y months
					$pattern .= ",0";
					$pattern .= "," . $recurrencePattern['DayOfMonth'];
					if($sync && $recurrencePattern['skipInterval'] == 0)
						$pattern .= ",1";
	
					else
					$pattern .= "," . $recurrencePattern['skipInterval'];
				}
	
				if(!$sync)
				$pattern .= "," . $recurrencePattern['DayOfMonth'];
			} break;
			case 13 : // Yearly
			{
				// see if we have a interval value
				if($recurrencePattern['DayOfWeekMask'] != 0)
				{
					// we must the x instance y of z month
					$pattern .= ",1";
	
					// instance
					if($recurrencePattern['Instance'] == 32)
					{
						// special value here, 32 = last day of month.
						$pattern .= ",4";
					}
					else
					{
						$pattern .= "," . ($recurrencePattern['Instance']-1);
					}
	
					// day mask
					$DayOfWeekMask = $recurrencePattern['DayOfWeekMask'];
					if($DayOfWeekMask==0x7F)		$pattern .= ",0";	// day
					else if($DayOfWeekMask==0x3E)	$pattern .= ",1";	// weekday
					else if($DayOfWeekMask==0x41)	$pattern .= ",2";	// weekend day
					else if($DayOfWeekMask==0x2)	$pattern .= ",3";	// monday
					else if($DayOfWeekMask==0x4)	$pattern .= ",4";	// tuesday
					else if($DayOfWeekMask==0x8)	$pattern .= ",5";	// wednesday
					else if($DayOfWeekMask==0x10)	$pattern .= ",6";	// thursday
					else if($DayOfWeekMask==0x20)	$pattern .= ",7";	// friday
					else if($DayOfWeekMask==0x40)	$pattern .= ",8";	// saturday
					else if($DayOfWeekMask==0x1)	$pattern .= ",9";	// sunday
	
					// month of year
					$pattern .= "," . ($recurrencePattern['MonthOfYear'] - 1);
	
					// day of month
					if(!$sync)
					$pattern .= "," . $recurrencePattern['DayOfMonth'];
				}
				else
				{
					// we must be every x month y day
	
					$pattern .= ",0";
					$pattern .= "," . ($recurrencePattern['MonthOfYear'] - 1);
					$pattern .= "," . $recurrencePattern['DayOfMonth'];
					$pattern .= "," . $recurrencePattern['skipInterval'];
	
				}
			} break;
		}
	
	
	
		return $pattern;
	}

	// Generate a time pattern for UI given ID
	public function generateTimePattern($linkid, $shared=0)
	{
		/*$sql = new SQL();
	
		$account = 	addslashes($this->username) . '@' . addslashes($this->pop3host);
	
		if($shared==1)
		{
			$recurrencePattern = $sql->sqlhash("select * from recurrencePatterns where linkid = $linkid");
		}
		else
		{
			$recurrencePattern = $sql->sqlhash("select * from recurrencePatterns where linkid = $linkid and account = \"$account\"");
		}
	
		// we got a pattern ?
		if (count($recurrencePattern) == 0)*/
			return "0";
	
		$pattern = "";
	
		$NoEndDate = $recurrencePattern['NoEndDate'];
		$totalOccurances = $recurrencePattern['Occurences'];
		$EndDay = new Date($recurrencePattern['PatternEndDate']);
		$EndDay->setTZByID("UTC");
		
		if($NoEndDate == 1 && $totalOccurances == 0)
		{
			$pattern .= "0";
			return $pattern;
		}
	
		$pattern .= "1";
	
		if($totalOccurances != 0)
		{
			$pattern .= ",";
			$pattern .= $totalOccurances;
			return $pattern;
		}
	
		$pattern = "2,";
		$pattern .= $EndDay->getDay();
		$pattern .= ",";
		$pattern .= $EndDay->getMonth();
		$pattern .= ",";
		$pattern .= $EndDay->getYear();
	
		return $pattern;
	}
	
	/******************************************************/
	public function getrecurrences($start, $end, $entry)
	//
	//	This function will generate all dates for any recurring
	//	entries within a date range and populate an array with
	//	these values.
	//
	//	Variables :
	//		startDateText/endDateText = (hopefully) ISO compat Date/Time
	//									(%Y-%m-%d %H:%M)
	//			-	They define the range of the results from
	//				the recurrence search.
	//
	//	Returns :
	//		array('ID' => $id, 'DateStart' => $recurrenceDateStart, 'DateEnd' => $recurrenceDateEnd)
	/*****************************************************/
	{				
		// some variable inits
		$res = array();
		$patternFinished = 0;
		
		// loop through and process each one.
		if(1) //count($calenderEntrys)>0)
		{
	
			// ok, we are passed in malformed dates .
			// NOT ISO.
			// so, lets make a HACK.
			// argh.

			// START DATE
			$startDate = new Date($start);
			$startDate->setTZByID("UTC");
		//	$startDate->setYear($start['year']);
	//		$startDate->setMonth($start['month']);
	///		$startDate->setDay($start['day']);
			$startDate->setHour(0);
			$startDate->setMinute(0);
			$startDate->setSecond(0);
	
			// END DATE
			$endDate = new Date($end);
			$endDate->setTZByID("UTC");
		//	$endDate->setYear($end['year']);
	//		$endDate->setMonth($end['month']);
//			$endDate->setDay($end['day']);
			$endDate->setHour(0);
			$endDate->setMinute(0);
			$endDate->setSecond(0);

            /* 
            [id] => 90A0E7EF-B719-0484-4D48-DF2FDBDC1320
            [DateStartCal] => 2010-03-29
            [DateStartTime] => 11:00:00
            [DateEndCal] => 2010-03-29
            [DateEndTime] => 13:15:00
            [Title] => MY NEW EVENT
            [ctag] => 2010-03-20 11:07:30.295741
            [etag] => 383DCB-1000-4BA411C2
            [calendar_owner] => test@centos.virgin
            [calendar] => calendar
            [relative_href] => test%40centos.virgin/calendar/
            [Importance] => 1
            [DateAlertPeriod] => 0
            [Availability] => Free
            [Type] => 2
            [AllDayEvent] => 0
            [IsRecurring] => 1
            [recurrencePattern] => 1
            [recurrenceTime] => 0
            [CalMessage] => 
            [Location] => 
            [DateModified] => 2010-03-29 05:29:42
			*/
						
			$calenderEntrys = array($entry);
			
			foreach($calenderEntrys as $calenderEntry)
			{
				$calDateStart = new Date($calenderEntry['DateStartCal'] . ' ' . $calenderEntry['DateStartTime']);
				$calDateEnd = new Date($calenderEntry['DateEndCal'] . ' ' . $calenderEntry['DateEndTime']);
								
				$calDateStart->setTZByID("UTC");
				$calDateEnd->setTZByID("UTC");
	
				$IsRecurring = $calenderEntry['IsRecurring'];
				//$IsException = $calenderEntry['IsException'];
				
				if($IsRecurring != 1)
				{
					// this is NOT a recurring entry.
					continue;
				}
	
				/*if($shared)
					$recurrencePattern = $sql->sqlhash("select * from recurrencePatterns where linkid = $id");
				else
					$recurrencePattern = $sql->sqlhash("select * from ecurrencePatterns where linkid = $id and account = \"$account\"");*/
				
//				$recurrenceArray = $this->ical2RecurrenceArray($calenderEntry['Data'], $calendarEntry['dtstart'], $calendarEntry['dtend']);
				$recurrenceArray = $calenderEntry['reccurenceArray']; //$this->RecurrenceArray2RecurrencePattern($recurrenceArray);

				if( $this->calDebug == 1)
				{
					file_put_contents("php://stderr", "start date = " . $calDateStart->getDate() . " end date = " . $calDateEnd->getDate() . "\n");
					file_put_contents("php://stderr", print_r($recurrenceArray, true) . "\n");	
				}

				if(1) // count($recurrencePattern)!=0)
				{
					$recurrenceType = $recurrenceArray['RecurrenceType'];
					$DayOfWeekMask = $recurrenceArray['DayOfWeekMask'];
					$DayOfMonth	= $recurrenceArray['DayOfMonth'];
					$Occurances = $recurrenceArray['Occurences'];
					$Duration = strtotime($calDateEnd->getDate()) - strtotime($calDateStart->getDate());
					$IsSimple = $recurrenceArray['IsSimple'];

					$Instance = $recurrenceArray['Instance'];
					if($Instance==32)
					{
						// special value - target the end of the month
						$targetEndOfMonth = 1;
					}
					else
					{
						$targetEndOfMonth = 0;
					}
					$skipInterval = $recurrenceArray['skipInterval'];
					$MonthOfYear = $recurrenceArray['MonthOfYear'];
	
					$patternStartDate = new Date($recurrenceArray['PatternStartDate']);
					$patternStartDate->setTZByID("UTC");
					
					// Brett : we need to start half a year in the past i guess ( well, actually 160 days seems good )
					// really need to generate all the recurrences and then select the date range we want to display..
					// argh, ugly and expensive.
					// See below for caching these results - ITS NEEDED !
					// 60 * 60 * 24 * 160 = 13824000
					// actually, the pattern start date really only needs to start from the events first recurrence
					// so lets start the recurrence pattern just the day before
					$nextDate = new Date($patternStartDate);
					$nextDate->setTZByID("UTC");
	//				$nextDate->subtractSpan	(new Date_span(13824000));
	//				$nextDate->subtractSpan	(new Date_span(86400));
	
					// Brett : Do we want to follow the pattern start dates time?!
					// I think not. Lets use the time of the calendar entry.
					$nextDate->setHour		($calDateStart->getHour());
					$nextDate->setMinute	($calDateStart->getMinute());
					$nextDate->setSecond	($calDateStart->getSecond());
	
					if($this->calDebug==1)
					{
						file_put_contents("php://stderr", date("D", $nextDate->getTime()) . " " . $nextDate->getDate() . "\n");
					}
					//echo $nextDate->getDate();
					//exit;
					
					$id = $recurrenceId = $calenderEntry['etag'];
	
					// grab any recurrence exceptions..
					$calenderExceptions = array(); //$sql->sqlmultihash("select * from $calTable where UserTo = \"$account\" and IsException = 1");
					$hasExceptions = 0; //count($calenderExceptions);
	
					$NoEndDate = $recurrenceArray['NoEndDate'];
	
					// do some setup and sanity
					if ($NoEndDate==0)
					{
						// the pattern has an end date !
						$patternEndDate = new Date($recurrenceArray['PatternEndDate']);
						$patternEndDate->setTZByID("UTC");
						if($this->calDebug==1)
							file_put_contents("php://stderr", "Pattern has end date " . $patternEndDate->getDate() . "\n");
					}
	
					if ($Occurances!=0)
					{
						if($this->calDebug==1)
							file_put_contents("php://stderr", "Pattern has end occurances " . $Occurances . "\n");
						$Occurance_ON=1;
					}
	
					switch($recurrenceType)
					{
	
						case 0x0a : //Daily
						{
	
							// ****
							//	DayOfWeekMask
							//	
							//	Bit pattern as follows:
							//
							//	1 - Sun
							//	2 - Mon
							//	4 - Tues
							//	8 - Wends
							//	16 - Thurs
							//	32 - Fri
							//	64 - Sat
							//
							//	0x3E - All week days
							//	0x7F - All days
							// ****
	
							// do some type specific setup
							if($skipInterval != 0)
							{
								// all days included in search
								$DayOfWeekMask = 0x7F;
							}
							else
							{
								// no skip interval information... must be weekdays only
								$DayOfWeekMask = 0x3E;
								$skipInterval = 1;
							}
						} break;
						case 0x0b : //weekly
						{
							if ($IsSimple)
							{
								$DayOfWeekMask = 1 << $nextDate->getDayOfWeek();
							}
						} break;
						case 0x0c : //monthly
						case 0x0d : //yearly
						{
							// we want to wind forward till we hit the day of month
							if($DayOfMonth != 0)
							{
								// day of month enabled
	
								while($nextDate->getDay() != $DayOfMonth)
									$nextDate = $nextDate->getNextDay();
	
								if($MonthOfYear != 0)
								{
									// we have a month of the year to look at...
									// so lets short circuit the loop
									// and jump straight forward to the first blip
									$nextDate->setMonth($MonthOfYear);
								}
	
								// we want all days included
								$DayOfWeekMask = 0x7F;
							}
							else
							{
								// we are nth month Nth instance of week mask
								// so, lets reset the month
	
								// short circuit the loop
								if($MonthOfYear != 0)
								{
									// we have a month of the year to look at...
									// so lets short circuit the loop
									// and jump straight forward to the first blip
									$nextDate->setMonth($MonthOfYear);
								}
	
								$nextDate->setDay(1);
							}
	
							// we found it ! ( or we span to death... )
						} break;
					}
	
					// debug out
					if($this->calDebug==1)
					{
						file_put_contents("php://stderr", "Generating recurring dates for id# $id from " . $startDate->getDate() . " to " . $endDate->getDate() . "\n" . "Calcd Pattern start date " . $nextDate->getDate() . "\n" . "DayOfWeekMask is " . $DayOfWeekMask . "\n" . "Calcd Pattern End date " . $endDate->getDate() . "\n");
					}
	
					$totalInstances = 0;
					$totalLimit = 0;
	
					// loop through all the days within this range
					// oh, and protect the loop from spinning to death.
					while(Date::compare($nextDate, $endDate) != 1 && $totalLimit != 999)
					{
						$totalLimit++;
	
						if($targetEndOfMonth==1)
						{
							// we are targetting the end of the month
							// so lets set the instance counter to the total days in this month
							$Instance = $nextDate->getDaysInMonth();
						}
	
						$dayBits    = 1<<$nextDate->getDayOfWeek();
						$daytext = date("D", $nextDate->getTime());
						$dayEnabled = $DayOfWeekMask & $dayBits;
	
						if($this->calDebug==1)
							file_put_contents("php://stderr", "Testing " . $nextDate->getDate() . " DOW = " . $nextDate->getDayOfWeek() . " Enabled(" . $nextDate->getDayOfWeek() . " " . $dayBits . " " . $DayOfWeekMask . " " . $daytext . " " . $dayEnabled . ")\n");
	
						if($NoEndDate == 0 && Date::compare($nextDate, $patternEndDate) >= 0)
						{
							// ok, we have hit a pattern end date...
							if($this->calDebug==1)
								file_put_contents("php://stderr", "Pattern end date hit.\n");
	
							$patternFinished = 1;
							break;
						}
	
						/*
	
						// Brett : Erm, for the time being exceptions to recurrences ARE NOT IMPLEMENTED !
	
						if($hasExceptions)
						{
							foreach($calenderExceptions as $calenderException)
							{
								$DateStart	= new Date($calenderException['DateStart']);
								$DateEnd	= new Date($calenderException['DateEnd']);
	
								if( Date::compare($nextDate, $DateStart) == 1 && Date::compare($nextDate, $DateEnd) == -1 )
								{
									$exceptId = $calenderException['id'];
									$recurrenceExceptions = $sql->sqlmultihash("select * from recurrenceExceptions where exceptId = $exceptId and account = \"$account\"");
	
	
								}
							}
	
							// lets check for any exceptions that might disable this day
							foreach ($recurrenceExceptions as $recurrenceException)
							{
								if(Date::compare($nextDate,
							}
						}*/
	
						if ($dayEnabled)
						{						
							// check we are doing a modulas of zero !!!!!
							if($Instance == 0)
								$Instance = 1;
	
							$totalInstances ++;
							if($this->calDebug==1)
								file_put_contents("php://stderr", "totalInstances = " . $totalInstances . " " . $Instance . " " . ($totalInstances % $Instance) ."\n");
	
							if(Date::compare($nextDate, $patternStartDate) == 1 && ($dayEnabled != 0))
							{
								if(($totalInstances % $Instance)==0)
								{
									// add the result!
									$newEndDate = new Date($nextDate);
									$newEndDate->setTZByID("UTC");
									//if($NoEndDate == 1)
									//	$Duration --;
									$newEndDate->addSpan(new Date_Span(intval($Duration)));
									
									// test if this recurrence is actually the real date time of the original cal
									if(Date::compare($nextDate, $calDateStart) != 0 && Date::compare($newEndDate, $calDateEnd) != 0)
									{
										if($this->calDebug == 1)
											file_put_contents("php://stderr", $nextDate->getDate() . "\n");
	
										// AAAnnnnd, make sure we are within the date range specified !
										if(Date::compare($nextDate, $startDate) >= 0 && Date::compare($newEndDate, $endDate) <= 0)
										{
											// store for cache here, under generated md5 string.
											$DateStart = new Date($nextDate);
											$DateStart->setTZByID("UTC");
											
											array_push($res, array('id' => $id, 'DateEnd' => $newEndDate, 'DateStart' => $DateStart));
											if( $this->calDebug == 1)
											{
												file_put_contents("php://stderr", $id . " ADDED " . $DateStart->getDate() . " to " . $newEndDate->getDate() . "\n");
											}
										}
	
										if ($patternFinished==1)
										{
											if($this->calDebug == 1)
											{
												file_put_contents("php://stderr",  "Pattern finished.\n");
											}
											return $res;
										}
																			
										if($Occurances)
										{
											if($this->calDebug==1)
												file_put_contents("php://stderr",  "Occurrance_ON " . $Occurances . "\n");
											// test the total occurances...
											$Occurances --;
	
											if($Occurances <= 1)
											{
												// we have finished !
												if($this->calDebug==1)
													file_put_contents("php://stderr", "Hit occurrance end.\n");
												//return $res;
												break;
											}
										}
									}
								}
							}
						}
	
						switch($recurrenceType)
						{
							case 0x0a : // Daily
								$nextDate->addspan(new Date_Span($skipInterval * 60 * 60 * 24));
							break;
							case 0x0b : // weekly
							{
								// jump forward a day..
								$nextDate->addspan(new Date_Span(1 * 60 * 60 * 24));
	
								// only start jump once we have got to the start of the interval pattern
								if($nextDate->getDayOfWeek() == 0 && Date::compare($nextDate, $calDateStart) != -1 && $skipInterval != 1)
								{
									// we are at the start of a new week !
									// lets add the interval now...
									$nextDate->addspan( new Date_Span(($skipInterval -1)* 60 * 60 * 24 * 7));
									//exit;
								}
							}
							break;
							case 0x0c : // Monthly
							case 0x0d : // Yearly
							{
								if($DayOfMonth!=0)
								{
									if($MonthOfYear == 0)
									{
										$currentMonth = $nextDate->getMonth();
										$addInterval = 1;
										$testDate = new Date($calDateStart);
										$testDate->setTZByID("UTC");
										$testDate->setDay($nextDate->getDay());
										if(Date::compare($nextDate, $testDate) != -1)
										{
											$addInterval = $skipInterval;
											if($addInterval == 0)
											{
												$addInterval = 1;
											}
										}
	
										if($currentMonth+$addInterval >= 13)
										{
											// erm, we walked off the end of the calender
											$currentYear = $nextDate->getYear();
											$nextDate->setYear($currentYear + 1);
											$currentMonth = 0;
										}
	
										$nextDate->setMonth($currentMonth+$addInterval);
									}
									else
									{
										// erm, yeah.
										// we are NOT targeting a specific month.... i.e. we are yearly !
										// lets just add to the year
										$nextDate->setYear($nextDate->getYear() + 1);
									}
								}
								else
								{
									// we need to test days... we have a dayofweekmask !
									if($totalInstances != 0 && ($totalInstances % $Instance)==0)
									{
	
										if($MonthOfYear == 0)
										{
											/*$currentMonth = $nextDate->getMonth();
											if($currentMonth+1 == 13)
											{
												// erm, we walked off the end of the calender
												$currentYear = $nextDate->getYear();
												$nextDate->setYear($currentYear + 1);
												$currentMonth = 0;
											}
	
											$nextDate->setMonth($currentMonth+1);*/
										}
										else
										{
											// erm, yeah.
											// we are targeting a specific month.... i.e. we are yearly !
											// lets just add to the year
											$nextDate->setYear($nextDate->getYear() + 1);
										}
	
	
	
										// we have found the instance we want... move to the next month
										$currentMonth = $nextDate->getMonth();
										$addInterval = 1;
										$testDate = new Date($calDateStart);
										$testDate->setTZByID("UTC");
										$testDate->setDay($nextDate->getDay());
										if(Date::compare($nextDate, $testDate) != -1)
										{
											$addInterval = $skipInterval;
											if($addInterval == 0)
											{
												$addInterval = 1;
											}
										}
	
										if($currentMonth+$addInterval >= 13)
										{
											// erm, we walked off the end of the calender
											$currentYear = $nextDate->getYear();
											$nextDate->setYear($currentYear + 1);
											$currentMonth = 0;
										}
	
										$nextDate->setMonth($currentMonth+$addInterval);
	
										$nextDate->setDay(1);			// erm, start from the start of the month thanks.
										$totalInstances = 0;			// reset the instances!
									}
									else
									{
										$nextDate->addspan(new Date_Span(1 * 60 * 60 * 24));
									}
								}
							}
							break;
						}
					} // while(Date::compare($nextDate, $endDate) != 1)
	
					// hmm, did we loop to death ?
					if($totalLimit == 999)
					{
						if ($this->calDebug == 1)
							file_put_contents("php://stderr", "Hit loop limit!\n");
					}
				} // count($recurrencePattern) != 0
				else
				{
					// hmm, it would seem the database has lost its mind a tad...
					// lets set the current entry to be not recurring...
	
					if($this->calDebug == 1)
					{
						file_put_contents("php://stderr", "Can't find recurrence pattern for $id!!!!\n");
					}
	
					$temp = $sql->sqlhash("update $calTable set IsRecurring=0 where UserTo = \"$account\" and id = $id");
				}
			} // foreach($calenderEntrys as $calenderEntry)
		} //if(count($calenderEntrys)>0)
		else
		{
			if($this->calDebug==1)
				file_put_contents("php://stderr", "No calendar entries!\n");
		}
		
		return $res;
	}
	
	public function recurrencePatternArray($arg)
	{
	
		// grab the recurrence pattern
		$recurrencePattern = $arg['recurrencePattern'];
	
		// Some variable setup.
	
		// RecurrenceType:
		// 10 = Daily
		// 11 = Weekly
		// 12 = Monthly
		// 13 = Yearly
		$RecurrenceType = 0;
	
		$DayOfMonth = 0;
		$Instance = 0;
		$Duration = 0;
		$MonthOfYear = 0;
		$linkid = 0;
		$account = "";
	
		$RecurrenceSimplePattern = 0;
	
		// Pattern recurrence end type
		// 0 = no end date
		// 1 = end after x occurances
		// 2 = end by date
		$PatternEndType = 0; //$arg['recurrenceEndType'];
	
		// PatternStartDate:
		// Well, this can happen anytime, but for the time being we will start the pattern on the same date as the entry starts...\
		// That kinda makes sense..
	
		$PatternStartDate = new Date($arg['DateStart']);
		$PatternStartDate->setTZByID("UTC");
		// PatternEndDate:
		// Again, this can happen anytime !
	
		$PatternEndDate = new Date($arg['recurrenceEndByDate']);
		$PatternEndDate->setTZByID("UTC");
		
		// NoEndDate:
		// Obviously this flags the current entry as having no end date.. Kinda redundant tho - we could just check for NULL data...
		// 1 = NoEndDate
		// 0 = PatternEndDate followed.
	
		$NoEndDate = ($PatternEndType == 2 ? 0 : 1);
	
		// totalOccurances:
		// Total number of repeats for the entry.
		// 0 = Unlimited
		// >0 = Total Limit
	
		if ($PatternEndType == 1)
			$totalOccurances = $arg['recurrenceEndAfterXOccurances'];
		else
			$totalOccurances = 0;
	
		// RecurrenceInterval:
		// Specifies the amount of units to skip in each mode.
		// A value of 0 is a special case for Daily:
		// >0 = every x days
		// 0 = every weekday
		// I.e. A value of 2 in Weekly will make the pattern occur every second week.
	
		$RecurrenceInterval = 0;
	
		// Instance:
		// This value will specify the total amount of hits before an actual event is produced.
		// So, if we are targeting the second Friday of sept, we would define this value to be 2.
		// 0 = all instances.
		// >0 = skip x instances between events.
	
		$Instance = 0;
	
		// DayOfWeekMask:
		// This can be applied to all modes.
		// Construct by OR'ing.
		// 1	= Sunday
		// 2	= Monday
		// 4	= Tuesday
		// 8	= Wednesday
		// 16	= Thurday
		// 32	= Friday
		// 64	= Saturday
		// Some common values :
		// 0x3E - All week days
		// 0x7F - All days
		// So, if we are a daily, with a skipInterval of 0, we would define DayOfWeekMask to be 0x3E.
	
		$DayOfWeekMask = 0;
	
		// DayOfMonth:
		// The day of the month to target when in monthly or yearly modes.
		// 0 = undefined.
	
		$DayOfMonth = 0;
	
		// Duration:
		// Amount of time for the recurrence pattern in seconds.
		// i.e. 3600 = 1 hour.
	
		$durationCalc = new Date_span();
		
		$DateEnd = new Date($arg['DateEnd']);
		$DateEnd->setTZByID("UTC");
		$durationCalc->setFromDateDiff( $PatternStartDate, $DateEnd );
	
		$Duration = $durationCalc->toSeconds();
	
		// MonthOfYear:
		// The month number to target when in monthly or yearly modes.
		// 0 = undefined.
	
		$MonthOfYear = 0;
	
		// linkid:
		// Id of the original event.
	
		$linkid = $arg['id'];
	
		// account:
		// The user account details i.e. joe@blogs.com
	
		$account = $arg['UserTo'];
	
		// Pattern definition
		// ------------------
		//
		// Daily pattern definition :
		// Pattern Pos	| Name				|	Value Behaviour
		// 0			| Repeat Type		|	1 = Daily
		// 1			| Daily Type (BOOL) |	0 = Every x days
		//				|					|	1 = Every weekday
		// 2			| Frequency (INT)	|
		//
		// Weekly pattern definition :
		// Pattern Pos	| Name				|	Value Behaviour
		// 0			| Repeat Type		|	2 = Weekly
		// 1			| Frequency (INT)	|
		// 2			| Monday (BOOL)		|	1 = enabled
		// 3			| Tuesday (BOOL)	|	1 = enabled
		// 4			| Wednesday (BOOL)	|	1 = enabled
		// 5			| Thursday (BOOL)	|	1 = enabled
		// 6			| Friday (BOOL)		|	1 = enabled
		// 7			| Saturday (BOOL)	|	1 = enabled
		// 8			| Sunday (BOOL)		|	1 = enabled
		//
		// Monthly MAIN pattern definition :
		// Pattern Pos	| Name				|	Value Behaviour
		// 0			| Repeat Type		|	3 = Monthly
		// 1			| Monthly Type(BOOL)|	0 = Day x of every y months
		//				|					|	1 = The x y of evert z months
		//
		// Monthly (Day x of every y months) SUB pattern definition:
		// Pattern Pos	| Name				|	Value Behaviour
		// 2			| Day of Month (INT)|
		// 3			| Freq Months(INT)	|
		//
		// Monthly (The x y of evert z months) SUB pattern definition:
		// Pattern Pos	| Name				|	Value Behaviour
		// 2			| Instance (INT)	|	See Instance pattern
		// 3			| Day mask (INT)	|	See Day Mask pattern
		// 4			| Frequency	(INT)	|
		//
		// Yearly MAIN pattern definition :
		// Pattern Pos	| Name				| Value Behaviour
		// 0			| Repeat Type		| 4 = Yearly
		// 1			| Yearly Type (BOOL)| 0 = every x month y day
		//				|					| 1 = the x instance y of z month
		//
		// Yearly (every x month y day) SUB pattern definition :
		// Pattern Pos	| Name				| Value Behaviour
		// 2			| Month of year(INT)| Index of Month (starting 1 = January)
		// 3			| Frequency			|
		// 4			| Day Of Month		|
		//
		// Yearly (the x instance y of z month) SUB pattern definition :
		// Pattern Pos	| Name				| Value Behaviour
		// 2			| Instance (INT)	|	See Instance pattern
		// 3			| Day mask (INT)	|	See Day Mask pattern
		// 4			| Month of year(INT)| Index of Month (starting 1 = January)
		// 5			| DayOfMonth		|
		//
		// Instance pattern
		// Instance (INT)	|	0 = first
		//					|	1 = second
		//					|	2 = third
		//					|	3 = fourth
		//					|	4 = last
		//
		// Day Mask pattern
		// Day mask (INT)	|	0 = day
		//					|	1 = weekday
		//					|	2 = weekend day
		//					|	3 = Monday
		//					|	4 = Tuesday
		//					|	5 = Wednesday
		//					|	6 = Thursday
		//					|	7 = Friday
		//					|	8 = Saturday
		//					|	9 = Sunday
		//
		// Some EXAMPLE patterns:
		//
		// Daily - repeat every 3 days (1,0,3)
		// Weekly - Mon Tues Sat every 2 weeks (2,2,1,1,0,0,0,1,0)
		// Monthly - 13th of every second month (3,0,13,2)
		// Yearly - the second Monday of Jan (4,1,1,3,1)
	
		// delete old recurrence (if it existed)
	/*	$query = "delete from recurrencePatterns where account = ? and linkid = ?";
	
		$data = array(
		  $arg['UserTo'], $arg['id']
		);
	
		$res = $this->db->sqldo($query, $data);*/
	
		// we got a pattern ?
		if (!empty($recurrencePattern))
		{
	
			$patternArray = explode(',', $recurrencePattern);
	
			switch ($patternArray[0])
			{
				case "1" : // Daily
				{
					$RecurrenceType = 10;
				} break;
				case "2" : // Weekly
				{
					$RecurrenceType = 11;
				} break;
				case "3" : // Monthly
				{
					$RecurrenceType = 12;
				} break;
				case "4" : // Yearly
				{
					$RecurrenceType = 13;
				} break;
			}
	
			// if the length is just one - this is a simple pattern
			if (strlen($recurrencePattern) == 1)
			{
				// simple pattern
				$RecurrenceSimplePattern = 1;
				$RecurrenceInterval = 0;
	
				switch ($patternArray[0])
				{
					case "1" : // daily
					{
						// every day is valid
						$RecurrenceInterval = 1;
						$DayOfWeekMask = 0x7f;
					} break;
					case "2" : // Weekly
					{
						$RecurrenceType = 11;
						$DayOfWeek = $PatternStartDate->getDayOfWeek();
	
						switch($DayOfWeek)
						{
							case 0 : $DayOfWeekMask = $DayOfWeekMask | 1; break;		// sunday
							case 1 : $DayOfWeekMask = $DayOfWeekMask | 2; break;		// monday
							case 2 : $DayOfWeekMask = $DayOfWeekMask | 4; break;		// tuesday
							case 3 : $DayOfWeekMask = $DayOfWeekMask | 8; break;		// wednesday
							case 4 : $DayOfWeekMask = $DayOfWeekMask | 16; break;		// thursday
							case 5 : $DayOfWeekMask = $DayOfWeekMask | 32; break;		// friday
							case 6 : $DayOfWeekMask = $DayOfWeekMask | 64; break;		// saturday
						}
					} break;
					case "3" : // Monthly
					{
						$RecurrenceType = 12;
						$DayOfMonth = $PatternStartDate->getDay();
					} break;
					case "4" : // Yearly
					{
						$RecurrenceType = 13;
						$DayOfMonth = $PatternStartDate->getDay();
						$MonthOfYear = $PatternStartDate->getMonth();
					} break;
				}
			}
			else
			{
				// argh, we are some kind of advanced pattern.
				$RecurrenceSimplePattern = 0;
	
				switch ($patternArray[0])
				{
					case "1" : // Daily
					{
						switch($patternArray[1])	// Daily type
						{
							case "0" :
							{
								// Every x days
								$RecurrenceInterval = $patternArray[2];
	
								// every day is valid
								$DayOfWeekMask = 0x7f;
							} break;
							case "1" :
							{
								// Every weekday
	
								// Special 0 = weekdays only
								$RecurrenceInterval = 0;
	
								// Weekdays only
								$DayOfWeekMask = 0x3e;
							} break;
						}
					} break;
					case "2" : // Weekly
					{
						$RecurrenceInterval		= $patternArray[1];
						if($patternArray[8]==1)		// sunday
							$DayOfWeekMask = $DayOfWeekMask | 1;
						if( $patternArray[2]==1)	// monday
							$DayOfWeekMask = $DayOfWeekMask | 2;
						if($patternArray[3]==1)		// tuesday
							$DayOfWeekMask = $DayOfWeekMask | 4;
						if($patternArray[4]==1)		// wednesday
							$DayOfWeekMask = $DayOfWeekMask | 8;
						if($patternArray[5]==1)		// thursday
							$DayOfWeekMask = $DayOfWeekMask | 16;
						if($patternArray[6]==1)		// friday
							$DayOfWeekMask = $DayOfWeekMask | 32;
						if($patternArray[7]==1)		// saturday
							$DayOfWeekMask = $DayOfWeekMask | 64;
					} break;
					case "3" : // Monthly
					{
						switch($patternArray[1])	// monthly type
						{
							case "0" : // Day x of every y months
							{
								$DayOfMonth			= $patternArray[2];
								$RecurrenceInterval	= $patternArray[3];
							} break;
							case "1" : // The x y of every z months
							{
								$Instance = $patternArray[2] + 1;
	
								if($Instance == 5)
								{
									// special - this is the LAST of something.
									// lets store a special value
									// 32.
	
									$Instance = 32;
								}
	
								if($patternArray[3]==0)			$DayOfWeekMask=0x7F;	// day
								else if($patternArray[3]==1)	$DayOfWeekMask=0x3E;	// weekday
								else if($patternArray[3]==2)	$DayOfWeekMask=0x41;	// weekend day
								else if($patternArray[3]==3)	$DayOfWeekMask=0x2;		// monday
								else if($patternArray[3]==4)	$DayOfWeekMask=0x4;		// tuesday
								else if($patternArray[3]==5)	$DayOfWeekMask=0x8;		// wednesday
								else if($patternArray[3]==6)	$DayOfWeekMask=0x10;	// thursday
								else if($patternArray[3]==7)	$DayOfWeekMask=0x20;	// friday
								else if($patternArray[3]==8)	$DayOfWeekMask=0x40;	// saturday
								else if($patternArray[3]==9)	$DayOfWeekMask=0x1;		// sunday
	
								$RecurrenceInterval = $patternArray[4];
							} break;
						}
					} break;
					case "4" : // Yearly
					{
						switch($patternArray[1])
						{
	
							case "0" : {
								// every x month y day
								$MonthOfYear		= ($patternArray[2] + 1);
								$RecurrenceInterval = $patternArray[4];
								$DayOfMonth			= $patternArray[3];
							} break;
							case "1" : {
								//$RecurrenceInterval = 1;
	
								// the x instance y of z month
								$Instance			= ($patternArray[2] + 1);
	
								if($Instance == 5)
								{
									// special - this is the LAST of something.
									// lets store a special value
									// 32.
	
									$Instance = 32;
								}
	
								if($patternArray[3]==0)			$DayOfWeekMask=0x7F;	// day
								else if($patternArray[3]==1)	$DayOfWeekMask=0x3E;	// weekday
								else if($patternArray[3]==2)	$DayOfWeekMask=0x41;	// weekend day
								else if($patternArray[3]==3)	$DayOfWeekMask=0x2;		// monday
								else if($patternArray[3]==4)	$DayOfWeekMask=0x4;		// tuesday
								else if($patternArray[3]==5)	$DayOfWeekMask=0x8;		// wednesday
								else if($patternArray[3]==6)	$DayOfWeekMask=0x10;	// thursday
								else if($patternArray[3]==7)	$DayOfWeekMask=0x20;	// friday
								else if($patternArray[3]==8)	$DayOfWeekMask=0x40;	// saturday
								else if($patternArray[3]==9)	$DayOfWeekMask=0x1;		// sunday
	
								$MonthOfYear = ($patternArray[4] + 1);
							} break;
						}
					//	$var['RepeatType']="Yearly";
					} break;
				}
			}
	
			// create a new recurrence entry
			$query = "insert into recurrencePatterns (RecurrenceType, PatternStartDate, PatternEndDate, NoEndDate, Occurences, skipInterval, DayOfWeekMask, DayOfMonth, Instance, Duration, MonthOfYear, linkid, account, IsSimple) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	
			// Example - Weekly start from 9th of 9th 2007 @ 12:35pm weekly on every weekday. (11, "2007-09-09 12:35:00", "", 1, 0, 1, 62, 0, 0, 3600, 0, 22, \"brett@benbookpro.com\")
			$data = array(
							$RecurrenceType,
							$PatternStartDate->getDate(),
							$PatternEndDate->getDate(),
							$NoEndDate,
							$totalOccurances,
							$RecurrenceInterval,
							$DayOfWeekMask,
							$DayOfMonth,
							$Instance,
							$Duration,
							$MonthOfYear,
							$linkid,
							$account,
							$RecurrenceSimplePattern
						);
	
			$res = $this->db->sqldo($query, $data);
			if (DB::isError($res))
				Log::logError($res->getMessage(), __FILE__, __LINE__ - 2, QUERY_ERROR);
		} // we got a pattern ?
	
	
	}

	public static function caldav_extract_dtstamps($munchedEvent)
	{
		$dtstart = calendar::caldav_extract_dtstamp('DTSTART', $munchedEvent);
		$dtend = calendar::caldav_extract_dtstamp('DTEND', $munchedEvent);
		if( $dtend == null )
		{
			// we have no end date, or - we have a duration instead.
			$dtend = calendar::caldav_extract_dtstamp('DURATION', $munchedEvent);
			if( $dtstart )
			{
				$converted_duration = ical_duration_to_seconds($dtend);
				$dtend = new Date($dtstart);
				$dtend->addSpan(new Date_Span($converted_duration));
				$dtendobj = $dtend;
				$dtend = $dtend->format("%Y%m%dT%H%M%S");
			}
		}
		return array($dtstart, $dtend);
	}
	
	public function getCount($start_in, $end_in, $calendarhref = '')
	{
		$skip_ranges = false;
		// caldav requires different date formatting
		// yyyymmddThhmmssZ
		// so lets massage
		if($start_in == '' && $end_in == '')
		{
			$start_in = new Date();
			$start_in = $start_in->format('%G-%m-%d %R');
			$end_in = new Date();
			$end_in->addYears(1);
			$end_in = $end_in->format('%G-%m-%d %R');
			$skip_ranges = true;
		}

		list($startdate_text, $starttime_text) 			= explode(" ", $start_in);
		list($enddate_text, $endtime_text)			= explode(" ", $end_in);
		list($start['year'], $start['month'], $start['day']) 	= explode("-", $startdate_text);
		list($end['year'], $end['month'], $end['day']) 		= explode("-", $enddate_text);
		list($start['hour'], $start['min']) 			= explode(":", $starttime_text);
		list($end['hour'], $end['min']) 			= explode(":", $endtime_text);

		$caldav_start = sprintf("%04d%02d%02dT%02d%02d%02dZ",$start['year'],$start['month'],$start['day'], $start['hour'], $start['min'], 0);
		$caldav_end = sprintf("%04d%02d%02dT%02d%02d%02dZ",$end['year'],$end['month'],$end['day'], $end['hour'], $end['min'], 0);

			if( $this->calNames == null )
			{
				$this->calNames = $this->getCalNames($this->_caldav_server, $this->caldav_URL);
			}
			
			foreach( $this->calNames as $calName )
			{
				if($calendarhref != '' && $calendarhref != urldecode($calName['relative_href']))
					continue;
					
				$events = $this->_caldav_server->GetEvents($caldav_start,$caldav_end, $calName['relative_href']);
				$total += count($events);
			}
			
			return $total;
	}
	
	// ****************************************************************
	public function getPushRange($start_in, $end_in, $date_alert='', $calendarhref='', $displayrecurrences=true)
	{
		$cal = $this->_caldav_server;
		$url = $this->caldav_URL;

		if($start_in == '')
		{
			$start_in = new Date();
			$start_in->addMonths(-1);
			$start_in = $start_in->getTime();
		}
		
		if($end_in == '')
		{
			$end_in = new Date();
			$end_in = $end_in->getTime();	
		}

		$calNames = array();
		if($this->_local && $this->_server_type == "at")
		{
			$events = array();
			$dir = $this->_caldav_server->getDataDirectory();
			if($dir != false && is_dir($dir))
			{
				$files = scandir($dir);
				foreach($files as $file)
				{
					if(strpos($file, ".ics") != false)
					{
						$id = explode('/', $file);
						$id = $id[count($id) - 1];
						$id = str_replace(".ics", "", $id);			
						$modified = filemtime($dir . $file);

						if($modified > $start_in && $modified < $end_in)
						{
							// .ics file
							$events[] = array('id' => $id, 'DateModified' => $modified); 
						}
					}	
				}				
				
			}
			return $events;
		}
		else
		{
			$start_in = new Date($start_in);
			$start_in = $start_in->format('%G-%m-%d %R');
			$end_in = new Date($end_in);
			$end_in = $end_in->format('%G-%m-%d %R');
			return $this->getRange($start_in, $end_in, $date_alert, $calendarhref, $displayrecurrences);
		}
	}

	// ****************************************************************
	// getRange
	// Grabs all the events for the given range of the current account
	// $start/$end format is yyyy-mm-dd hh:mm
	// if $date_alert == 1 only fetch records that require an alert
	public function getRange($start_in, $end_in, $date_alert='', $calendarhref='', $displayrecurrences=true)
	{
		$entries = array();

		if( $date_alert == 1 )
		{
			// alert fetch goes here
		}
		$skip_ranges = false;
		// caldav requires different date formatting
		// yyyymmddThhmmssZ
		// so lets massage
		if($start_in == '' && $end_in == '')
		{
			$start_in = new Date();
			$start_in->addYears(-4);
			$start_in = $start_in->format('%G-%m-%d %R');
			$end_in = new Date();
			$end_in->addYears(4);
			$end_in = $end_in->format('%G-%m-%d %R');
			$skip_ranges = true;
		}

		list($startdate_text, $starttime_text) 			= explode(" ", $start_in);
		list($enddate_text, $endtime_text)			= explode(" ", $end_in);
		list($start['year'], $start['month'], $start['day']) 	= explode("-", $startdate_text);
		list($end['year'], $end['month'], $end['day']) 		= explode("-", $enddate_text);
		list($start['hour'], $start['min']) 			= explode(":", $starttime_text);
		list($end['hour'], $end['min']) 			= explode(":", $endtime_text);

		$caldav_start = sprintf("%04d%02d%02dT%02d%02d%02dZ",$start['year'],$start['month'],$start['day'], $start['hour'], $start['min'], 0);
		$caldav_end = sprintf("%04d%02d%02dT%02d%02d%02dZ",$end['year'],$end['month'],$end['day'], $end['hour'], $end['min'], 0);
		$searchstart = new Date($caldav_start);
		$searchend = new Date($caldav_end);


		if( $this->calNames == null )
		{
			$this->calNames = $this->getCalNames($this->_caldav_server, $this->caldav_URL);
		}
		
		foreach( $this->calNames as $calName )
		{
			if($calendarhref != '' && $calendarhref != urldecode($calName['relative_href']))
				continue;

			$localread = false;
			$events = array();

			// fetch all events for range
			if($this->_local && $this->_server_type == "at" && urldecode($calName['relative_href']) == $this->_account . '/calendar/')
			{
				// fast disk based modification check
				$dir = $this->_caldav_server->getDataDirectory();
				
				if($dir != false && is_dir($dir))
				{
					$files = scandir($dir);
					foreach($files as $file)
					{
						if(strpos($file, ".ics") != false)
						{
							$file_id = explode('/', $file);
							$file_id = $file_id[count($file_id) - 1];
							$event_contents = file_get_contents($dir.$file);
							$events[] = array('href' => $file_id, 'data' => $event_contents, 'etag' => '');
						}	
					}
					$localread = true;
				}	
			}
			if(!$localread)
			{
				$events = $this->_caldav_server->GetEvents(null, null, /*$caldav_start,$caldav_end,*/ $calName['relative_href']);
			}

			// 'munch' the events into a nice array
			$munchedEvents = $this->munchEvents($events);

			// now we must format that array into the expected xml
			//<App ID="p1" Task="0" User="brett@kurra.calacode.com" Start="2009-02-02 16:00" Finish="2009-02-02 17:00" Shared="0" CalNameID="" Availability="Busy">
			//<Subject>Testing the caldav functions</Subject>
			//</App>
			foreach( $munchedEvents as $munchedEvent )
			{
				// See munchEvents() for description of the array format
				// my fake entry
				$entry = array();
				$entry['id'] = $munchedEvent['VCALENDAR']['VEVENT']['UID'];
				list($dtstart, $dtend) = calendar::caldav_extract_dtstamps($munchedEvent);

				$entry['DateStartCal'] = $this->caldav_strip_date($dtstart);
				$entry['DateStartTime'] = $this->caldav_strip_time($dtstart);
				$entry['DateEndCal'] = $this->caldav_strip_date($dtend);
				$entry['DateEndTime'] = $this->caldav_strip_time($dtend);
				
				$entry['Title'] = ical_decode($munchedEvent['VCALENDAR']['VEVENT']['SUMMARY']);
				$entry['ctag'] = trim($calName['ctag'], '"');
				$entry['etag'] = trim($calName['etag'], '"');
				$entry['calendar_owner'] = $calName['calendar_owner'];
				$entry['calendar'] = $calName['displayname'];
				$entry['calendar_color'] = $calName['color'];
				$entry['relative_href'] = $calName['relative_href'];
				$entry['alarmSet'] = isset($munchedEvent['VALARM']);
				// websync compat patch
				$entry['Importance'] = '1';
				$entry['DateAlertPeriod'] = '0';
				$entry['Availability'] = 'Free';
				$entry['Type'] = '2';
				$entry['AllDayEvent'] = '0';
				if(isset($munchedEvent['VCALENDAR']['VEVENT']['RRULE']))
				{
					$entry['IsRecurring'] = 1;
				}
				else
				{
					$entry['IsRecurring'] = 0;
				}
				$entry['reccurenceArray'] = $this->ical2RecurrenceArray($munchedEvent);
				$entry['recurrencePattern']	= $this->RecurrenceArray2RecurrencePattern($entry['reccurenceArray']);
				$entry['recurrenceTime']	= '0'; //$this->generateTimePattern($var['id'], $var['shared']);
				
				if(!isset($munchedEvent['VCALENDAR']['VEVENT']['DESCRIPTION']))
				{
					$munchedEvent['VCALENDAR']['VEVENT']['DESCRIPTION'] = '';
				}

				$entry['CalMessage'] = ical_decode($munchedEvent['VCALENDAR']['VEVENT']['DESCRIPTION']);
				
				if (isset($munchedEvent['VCALENDAR']['VEVENT']['LOCATION']))
				{
					$entry['Location'] = ical_decode($munchedEvent['VCALENDAR']['VEVENT']['LOCATION']);
				}
				else
				{
					$entry['Location'] = '';	
				}
							
				
				
				
				$stamp = calendar::caldav_extract_dtstamp('DTSTAMP', $munchedEvent);
				$entry['DateModified'] = $this->caldav_strip_date($stamp) . ' ' . $this->caldav_strip_time($stamp);

				$entry['Data'] = $munchedEvent;
				$recurring = $entry['IsRecurring'];

				$entry['IsRecurring'] = 0;
				$datestart = new Date($entry['DateStartCal'] . ' ' . $entry['DateStartTime']);
				$dateend = new Date($entry['DateEndCal'] . ' ' . $entry['DateEndTime']);


				$searchstart->setHour(0);
				$searchstart->setMinute(0);
				$searchstart->setSecond(0);
				$searchend->setHour(0);
				$searchend->setMinute(0);
				$searchend->setSecond(0);
				$datestart->setHour(0);
				$datestart->setMinute(0);
				$datestart->setSecond(0);
				$dateend->setHour(0);
				$dateend->setMinute(0);
				$dateend->setSecond(0);

				if( $skip_ranges || strtotime($datestart->getDate()) >= strtotime($searchstart->getDate()) && strtotime($dateend->getDate()) <= strtotime($searchend->getDate()))
				{
					array_push($entries, $entry);
				}
				
				$entry['IsRecurring'] = $recurring;

				// generate and list recurrences
				$recurrences = $this->getrecurrences($caldav_start, $caldav_end, $entry);
				$instances = 0;
				$guid = $entry['id'];
				if ($displayrecurrences && count($recurrences) > 0)
				{
					foreach ($recurrences as $recurrence)
					{
						$instances++;
						$dtstart = $recurrence['DateStart']->format("%Y%m%dT%H%M%S");
						$dtend = $recurrence['DateEnd']->format("%Y%m%dT%H%M%S");

						$entry['DateStartCal'] = $this->caldav_strip_date($dtstart);
						$entry['DateStartTime'] = $this->caldav_strip_time($dtstart);		
						$entry['DateEndCal'] = $this->caldav_strip_date($dtend);
						$entry['DateEndTime'] = $this->caldav_strip_time($dtend);
						$entry['IsRecurring'] = 1;
						$entry['id'] = $guid . '_' . $instances;
						$datestart = new Date($entry['DateStartCal'] . ' ' . $entry['DateStartTime']);
						$dateend = new Date($entry['DateEndCal'] . ' ' . $entry['DateEndTime']);

						if( $skip_ranges || strtotime($datestart->getDate()) >= strtotime($searchstart->getDate()) && strtotime($dateend->getDate()) <= strtotime($searchend->getDate()) )
						{
							array_push($entries, $entry);
						}
					}
				}
			}

			// fetch all todos for range
			unset($events);
			$events = $this->_caldav_server->GetTodos($caldav_start,$caldav_end, null, null, $calName['relative_href']);
			
			// 'munch' the events into a nice array
			$munchedEvents = $this->munchEvents($events);
			
			// now we must format that array into the expected xml
			//<App ID="p1" Task="0" User="brett@kurra.calacode.com" Start="2009-02-02 16:00" Finish="2009-02-02 17:00" Shared="0" CalNameID="" Availability="Busy">
			//<Subject>Testing the caldav functions</Subject>
			//</App>
			foreach( $munchedEvents as $munchedEvent )
			{
				// See munchEvents() for description of the array format
				// ok, for some reason the caldav server will return vevents within the data..
				// we dont want that.
				// so, lets remove!
				if( isset($munchedEvent['VCALENDAR']['VTODO']) )
				{
					$entry = array();
					$entry['id'] = $munchedEvent['VCALENDAR']['VTODO']['UID'];
					$entry['Task'] = "1";
					$entry['DateModified'] = $this->caldav_strip_date(calendar::caldav_extract_dtstamp('DTSTAMP', $munchedEvent)) . " " . $this->caldav_strip_time(calendar::caldav_extract_dtstamp('DTSTAMP', $munchedEvent));
					$entry['DateStartCal'] = $this->caldav_strip_date(calendar::caldav_extract_dtstamp('DTSTART', $munchedEvent));
					$entry['DateStartTime'] = $this->caldav_strip_time(calendar::caldav_extract_dtstamp('DTSTART', $munchedEvent));
					$entry['DateEndCal'] = $this->caldav_strip_date(calendar::caldav_extract_dtstamp('DUE', $munchedEvent));
					if( $entry['DateEndCal'] == null )
					{
						$entry['DateEndCal'] = $this->caldav_strip_date(calendar::caldav_extract_dtstamp('DTEND', $munchedEvent));
					}
					
					$entry['DateEndTime'] = "23:59";

					if( $entry['DateStartCal'] == "--" )
					{
						unset($entry['DateStartCal']);
						unset($entry['DateStartTime']);
					}
					if( $entry['DateEndCal'] == "--" )
					{
						unset($entry['DateEndCal']);
						unset($entry['DateEndTime']);
					}

					$entry['Title'] = ical_decode($munchedEvent['VCALENDAR']['VTODO']['SUMMARY']);
					$entry['ctag'] = trim($calName['ctag'], '"');
					$entry['etag'] = trim($calName['etag'], '"');
					$entry['calendar_owner'] = $calName['calendar_owner'];
					$entry['calendar'] = $calName['displayname'];
					array_push($entries, $entry);
				}
			}
		}
	
		return $entries;
	}

	function add_proxy($user, $proxy_user, $perms)
	{
		if(strpos($user, '/') != false)
		{
			list($user, $temp) = explode('/', $user);
		}
		
		if(strpos($proxy_user, '/') != false)
		{
			list($proxy_user, $temp) = explode('/', $proxy_user);
		}
		
		addproxy($this->_caldav_server, $user, $this->_caldav_server->pass, $proxy_user, $perms);
	}

	function del_proxy($user, $proxy_user, $perms)
	{
		list($user, $temp) = explode('/', $user);
		list($proxy_user, $temp) = explode('/', $proxy_user);

		removeproxy($this->_caldav_server, $user, $this->_caldav_server->pass, $proxy_user, $perms);
	}

	function delete_record($id, $shared, $relative_href)
	{
		if( $id[0] == 'p' || $id[0] == 's' )
		{
			$id = substr($id, 1, strlen($id));
		}

		$this->_caldav_server->DoDELETERequest($relative_href . $id . ".ics", null);
		$this->delete_extended_data('id');
		
		list($tempuser, $tempdir) = explode("/", $relative_href, 2);
		$relative_href = urlencode($tempuser) . '/' . $tempdir;
		
		// record changed, container etags change.
		// lets find and update
		
		return findetag($this->_caldav_server, $relative_href);
	}

	function add_raw_record($ics, $Permission, $relative_href)
	{
		// add a new raw ics event
		$current_date = getdate();
		$event_text = $ics;
		
		// preg-replace all X-LOTUS-ATTR ( we do not parse them )
		$event_text = preg_replace('/^X-LOTUS-.*:.*$/m', '', $event_text);

		if(($uid_pos = strpos($event_text, "UID:")) != FALSE)
		{
			list($ics_top, $ics_bottom) = explode('UID:', $event_text);
			list($uid, $ics_bottom) = explode("\n", $ics_bottom);
			if(strlen($uid) > 36)
			{
				$uid = create_guid();
				list($ics_top, $ics_bottom) = explode('UID:', $event_text);
				list($junk, $ics_bottom) = explode("\n", $ics_bottom,2);
				$event_text = $ics_top . "UID:" . $uid . "\n" . $ics_bottom;
			}
		}
		else
		{
			$uid = create_guid();
		}

		$url = $relative_href . $uid . '.ics';

		$etag = $this->_caldav_server->DoPUTRequest($url, $event_text);

		if( $etag == "" || $etag == 'no-uid-conflict' )
		{
			// FAILED!
			// lets try again, this time with a new uid
			if($uid_pos != FALSE)
			{
				$uid = create_guid();
				list($ics_top, $ics_bottom) = explode('UID:', $event_text);
				list($junk, $ics_bottom) = explode("\n", $ics_bottom,2);
				$event_text = $ics_top . "UID:" . $uid . "\n" . $ics_bottom;
				$url = $relative_href . $uid . '.ics';
				$etag = $this->_caldav_server->DoPUTRequest($url, $event_text);
				
				if( $etag == "" || $etag == 'no-uid-conflict' )
				{
					// FAILED!
				}
			}
		}
			
		return array($uid, $etag);

	}
	
	function get_record_modified($id, $relative_href)
	{
		if($this->_local && $this->_server_type == "at" && $relative_href == $this->_account . '/calendar/')
		{
			// fast disk based modification check
			$dir = $this->_caldav_server->getDataDirectory();
			
			if($dir != false && is_dir($dir))
			{
				$files = scandir($dir);
				foreach($files as $file)
				{
					if(strpos($file, ".ics") != false)
					{
						$file_id = explode('/', $file);
						$file_id = $file_id[count($file_id) - 1];
						$file_id = str_replace(".ics", "", $file_id);
						if($file_id == $id)
						{
							$modified = filemtime($dir . $file);
							// .ics file
							$event = array('id' => $id, 'DateModified' => $modified);
							return $event;
						} 
					}	
				}
			}		
		}
		else
		{
			return $this->get_record($id, $relative_href);	
		}
	}
	
	function get_record($id, $relative_href)
	{
		$localread = false;
		if($this->_local && $this->_server_type == "at" && $relative_href == $this->_account . '/calendar/')
		{
			// fast disk based modification check
			$dir = $this->_caldav_server->getDataDirectory();

			if($dir != false && is_dir($dir))
			{	
				$file = $dir . '/' . $id . '.ics';
				if( is_file($file) )
				{
					// ok, dir and file exist, lets just grab the data
					$event = file_get_contents($file);
					if($event != false)
					{
						// success!
						$localread = true;
					}	
				}
			}		
		}
		
		if(!$localread)
		{
			$event = $this->_caldav_server->DoGETRequest($relative_href . $id . '.ics');
		}
		list($junk, $event) = explode('BEGIN:VCALENDAR', $event);
		$event = 'BEGIN:VCALENDAR' . $event;
		$event_array = array();
		$event_array['data'] = $event;
		$event_array['href'] = $id . '.ics';
		$event_array['etag'] = '';
		$events[] = $event_array;
		
		$munchedEvents = $this->munchEvents($events);
		$munchedEvent = $munchedEvents[0];
		
		$entry = array();
		
		$stamp = calendar::caldav_extract_dtstamp('DTSTAMP', $munchedEvent);		
		$entry['DateModified'] = $this->caldav_strip_date($stamp) . ' ' . $this->caldav_strip_time($stamp);
		$entry['id'] = $munchedEvent['VCALENDAR']['VEVENT']['UID'];
		list($dtstart, $dtend) = calendar::caldav_extract_dtstamps($munchedEvent);

		$entry['DateStartCal'] = $this->caldav_strip_date($dtstart);
		$entry['DateStartTime'] = $this->caldav_strip_time($dtstart);
		$entry['DateEndCal'] = $this->caldav_strip_date($dtend);
		$entry['DateEndTime'] = $this->caldav_strip_time($dtend);
		
		$entry['Title'] = ical_decode($munchedEvent['VCALENDAR']['VEVENT']['SUMMARY']);
		if (isset($munchedEvent['VCALENDAR']['VEVENT']['LOCATION']))
		{
			$entry['Location'] = ical_decode($munchedEvent['VCALENDAR']['VEVENT']['LOCATION']);
		}
		else
		{
			$entry['Location'] = '';	
		}
		if(!isset($munchedEvent['VCALENDAR']['VEVENT']['DESCRIPTION']))
		{
			$munchedEvent['VCALENDAR']['VEVENT']['DESCRIPTION'] = '';
		}

		$entry['CalMessage'] = ical_decode($munchedEvent['VCALENDAR']['VEVENT']['DESCRIPTION']);
		
		$entry['recurrenceArray'] = $this->ical2RecurrenceArray($munchedEvent);
//		$entry['alertArray'] = $this->ical2RecurrenceArray($munchedEvent);
		
		
		return $entry;
	}
	
	function updateIcs($uri)
	{
		return $this->_caldav_server->updateIcs($uri);	
	}
	
	function add_record($Task, $UserTo, $UserFrom, $Title, $CalMessage, $Importance, $Type, $Alert, $DateStart, $DateEnd, $Parent, $ReadSelectedUsers, $WriteSelectedUsers, $WriteSelectedGroups, $ReadSelectedGroups, $Location, $AllDayEvent, $Permission, $relative_href, $raw = 0)
	{
		$status = 0;
	
		// add a new event
		$vcalendar['VERSION'] 		= $this->ICAL_VERSION;
		$vcalendar['PRODID'] 		= $this->ICAL_PRODID;
		$vcalendar['CALSCALE']		= $this->ICAL_CALSCALE;
		$icalobject['VCALENDAR'] 	= $vcalendar;
		
		//	not going to include any timezone information for the time being
		$current_date = getdate();

		// dont set an alarm by default
		// as we now have alarm control from within the advanced edit pane
		/*$valarm['TRIGGER'] = "-PT30M";
		$valarm['ACTION'] = "DISPLAY";
		$valarm['DESCRIPTION'] = "Alarm for : '" . $Title . "'"; */

		// SEQUENCE - This property defines the revision sequence number of the calendar component within a sequence of revisions.
		// HOWEVER, for our implementation - lets just increament it with every modification
		$vevent['SEQUENCE'] = 2;
		$vevent['TRANS'] = $this->ICAL_TRANS;//This property defines whether an event is transparent or not to busy time searches.

		// UID is interesting field
		// according to the specification it MUST be GLOBALLY UNIQUE.
		// use a GUID and thats all..
		// should be ok to use.

		$vevent['UID'] = create_guid();
		if( $Task == false )
		{
			if( $AllDayEvent == true )
			{
				$vevent['DTSTART;VALUE=DATE'] = substr(ical_datetime($DateStart), 0, 8);
			}
			else
			{
				$vevent['DTSTART'] = ical_datetime($DateStart);
				$res = $vevent['DTSTART'];
			}
		}
		// should be the last thing done really..
		$vevent['DTSTAMP'] = ical_datetime($current_date[0]) . "Z";
		$vevent['SUMMARY'] = $Title;
		$vevent['DESCRIPTION'] = $CalMessage;
		$vevent['LOCATION'] = $Location;
		$vevent['CREATED'] = ical_datetime($current_date[0]) . "Z";

		if( $Task == false )
		{
			if( $AllDayEvent == true )
			{
				$vevent['DTEND;VALUE=DATE'] = substr(ical_datetime($DateStart), 0, 8) + 1;
			}
			else
			{
				$vevent['DTEND'] = ical_datetime($DateEnd);
			}
		}
		else
		{
			if( $DateEnd != null )
			{
				$vevent['DUE;VALUE=DATE'] = ical_datetime($DateEnd);
			}
		}

		if( $Task == false )
		{
			$type = "VEVENT";
		}
		else
		{
			$type = "VTODO";
		}
		
		//$vevent['VALARM'] = $   ;
		$icalobject['VCALENDAR'][$type] = $vevent;
		$event_text = ical_create_entry($icalobject);

		if($raw)
		{
		
			// we are going to write direct to disk
			$components = str_split(str_replace("@", "_", $UserTo), 2);
			list($user, $domain) = explode("@", $UserTo, 2);
			$base_url = "/usr/local/atmail/calendarserver/server/twistedcaldav/atmail/data/calendars/__uids__/" . $components[0] . "/" . $components[1] . "/" . $user . "_" . $domain;
			$calendar_url = $base_url . "/calendar/";
			$inbox_url = $base_url . "/inbox/";
			$test = is_file($calendar_url . ".db.sqlite");
			if($test == false)
			{
				mkdir($calendar_url, 0755, true);
				mkdir($inbox_url, 0755, true);
				if(!$this->_migration)
				{
					chown("/usr/local/atmail/calendarserver/server/twistedcaldav/atmail/data/calendars/__uids__/", 'atmail');
					chgrp("/usr/local/atmail/calendarserver/server/twistedcaldav/atmail/data/calendars/__uids__/", 'atmail');
					chown("/usr/local/atmail/calendarserver/server/twistedcaldav/atmail/data/calendars/__uids__/" . $components[0], 'atmail');
					chgrp("/usr/local/atmail/calendarserver/server/twistedcaldav/atmail/data/calendars/__uids__/" . $components[0], 'atmail');
					chown("/usr/local/atmail/calendarserver/server/twistedcaldav/atmail/data/calendars/__uids__/" . $components[0] . "/" . $components[1], 'atmail');
					chgrp("/usr/local/atmail/calendarserver/server/twistedcaldav/atmail/data/calendars/__uids__/" . $components[0] . "/" . $components[1], 'atmail');
					chown($base_url, 'atmail');
					chgrp($base_url, 'atmail');
					chown($calendar_url, 'atmail');
					chgrp($calendar_url, 'atmail');
					chown($inbox_url, 'atmail');
					chgrp($inbox_url, 'atmail');
					chown($calendar_url . ".db.sqlite", 'atmail');
					chgrp($calendar_url . ".db.sqlite", 'atmail');
					chown($inbox_url . ".db.sqlite", 'atmail');
					chgrp($inbox_url . ".db.sqlite", 'atmail');
				}

				$results = array();
				$results[0] = "SQL error: database is locked";
				
				// setup resourcetype/ctag/trans of new directories
				$this->_caldav_server->setupNewUri($base_url, str_replace("@", "_", $UserTo));
				
				$calendar_db = Zend_Db::factory('PDO_SQLITE', array ('dbname' => $calendar_url . ".db.sqlite"));
				$cursor = $calendar_db->getConnection();
				$retries = 0;
				$ok = false;
				while(!$ok && $retries < 10)
				{				
					try
					{
						$results = array();
						$cursor->exec("BEGIN TRANSACTION; CREATE TABLE CALDAV ('KEY' varchar(255) primary key, 'VALUE' text, 'EXTRA' text );"
							. "INSERT INTO 'CALDAV' VALUES('SCHEMA_VERSION', '7', NULL); INSERT INTO 'CALDAV' VALUES('TYPE', 'Regular Calendar Collection', NULL);"
							. "CREATE TABLE RESOURCE (NAME text unique, UID text unique, TYPE text, RECURRANCE_MAX date, ORGANIZER text);"
							. "CREATE TABLE TIMESPAN (NAME   text, FLOAT  text(1), START  date, END date, FBTYPE text(1) );"
							. "CREATE TABLE RESERVED (UID  text unique, TIME date);"
							. "COMMIT;");
							$ok = true;
					}
					catch(Exception $e)
					{
						fwrite(STDOUT, "Having issues connecting to sqlite db : " . $calendar_url . ".db.sqlite\n");
						fwrite(STDOUT, print_r($e->getMessage(), true) . "\n");
						$retries ++;
					}
				}

				if($retries == 10)
				{
					die("Failed to connect to sqlite db");
				}
			
				if(!$this->_migration)
				{
					$inbox_db = Zend_Db::factory('PDO_SQLITE', array ('dbname' => $inbox_url . ".db.sqlite"));
					$retries = 0;
					$ok = false;
					while(!$ok && $retries < 10)
					{				
						try
						{
							$inbox_db->getConnection()->exec("BEGIN TRANSACTION; CREATE TABLE CALDAV ('KEY' varchar(255) primary key, 'VALUE' text, 'EXTRA' text );"
								. "INSERT INTO 'CALDAV' VALUES('SCHEMA_VERSION', '7', NULL); INSERT INTO 'CALDAV' VALUES('TYPE', 'iTIP Calendar Collection', NULL);"
								. "CREATE TABLE RESOURCE (NAME text unique, UID text unique, TYPE text, RECURRANCE_MAX date, ORGANIZER text);"
								. "CREATE TABLE TIMESPAN (NAME   text, FLOAT  text(1), START  date, END date, FBTYPE text(1) );"
								. "CREATE TABLE RESERVED (UID  text unique, TIME date);"
								. "COMMIT;");
							$ok = true;
						}
						catch(Exception $e)
						{
							fwrite(STDOUT, "Having issues connecting to sqlite db : " . $inbox_url . ".db.sqlite\n");
							fwrite(STDOUT, print_r($e->getMessage(), true) . "\n");
							$retries++;
						}
					}
					if($retries == 10)
					{
						die("Failed to connect to sqlite db");
					}
					$inbox_db->closeConnection();
				}
			}
			file_put_contents($calendar_url . $icalobject['VCALENDAR'][$type]['UID'] . '.ics', $event_text);

			if(!$this->_migration)
			{
				chown($calendar_url . $icalobject['VCALENDAR'][$type]['UID'] . '.ics', 'atmail');
				chgrp($calendar_url . $icalobject['VCALENDAR'][$type]['UID'] . '.ics', 'atmail');
			}
				
			if(!$calendar_db)
			{
				//$calendar_db = new Zend_Db_Adapter_Pdo_Sqlite(array('dbname'     => $calendar_url . ".db.sqlite"));

				$calendar_db = Zend_Db::factory('PDO_SQLITE', array ('dbname' => $calendar_url . ".db.sqlite"));
				$cursor = $calendar_db->getConnection();
			}
				
			$ok = false;
			while(!$ok)
			{
				try
				{
					$cursor->exec("BEGIN TRANSACTION; INSERT INTO 'RESOURCE' VALUES('" . $icalobject['VCALENDAR'][$type]['UID'] . '.ics' . "', '" . $icalobject['VCALENDAR'][$type]['UID'] . "', 'VEVENT', NULL, ''); INSERT INTO 'TIMESPAN' VALUES('" . $icalobject['VCALENDAR'][$type]['UID'] . '.ics' . "', 'Y', '" . $DateStart . "+00:00', '" . $DateEnd . "+00:00', 'B'); COMMIT;");
					$ok = true;
				}
				catch(Exception $e)
				{
					fwrite(STDOUT, "Having issues connecting to sqlite db : " . $url . ".db.sqlite\n");
					fwrite(STDOUT, print_r($e->getMessage(), true));
				}
			}
				
			$calendar_db->closeConnection();
			unset($calendar_db);
			// update the user quota
			if(!$this->_migration)
			{
				$this->_caldav_server->updateIcs($calendar_url . $icalobject['VCALENDAR'][$type]['UID'] . '.ics');
				$this->_caldav_server->updateUserQuota($base_url);
			}
			
			return $icalobject['VCALENDAR'][$type]['UID'];
		}
		
		$url = $relative_href . $icalobject['VCALENDAR'][$type]['UID'] . '.ics';
		$icalevent['etag'] = $this->_caldav_server->DoPUTRequest($url, $event_text);

		if( $icalevent['etag'] == "" )
		{
			// FAILED!
			$status = -1;
			if($this->_migration)
			{
				// log the failure
				fwrite(STDOUT, "***** FAILURE ****** " . $UserTo . " has been logged\n");
				file_put_contents("calendar.raw.failures", $UserTo . " " . $url . " " . $event_text . " " . print_r($icalobject, true) . "\n", FILE_APPEND);
				return array('','');
			}
		}
		else
		{
			$status = 1;
		}
		
		list($tempuser, $tempdir) = explode("/", $relative_href, 2);
		$relative_href = urlencode($tempuser) . '/' . $tempdir;		

		$newcal['etag'] = findetag($this->_caldav_server, $relative_href);
		
		return array($icalobject['VCALENDAR'][$type]['UID'], $newcal['etag']);
	}

	function updateUserQuota($base_url)
	{
		if(strstr($base_url, "data/calendars/__uids__") == NULL)
		{
			$components = str_split(str_replace("@", "_", $base_url), 2);
			list($user, $domain) = explode("@", $base_url, 2);
			$base_url = "/usr/local/atmail/calendarserver/server/twistedcaldav/atmail/data/calendars/__uids__/" . $components[0] . "/" . $components[1] . "/" . $user . "_" . $domain;
		}
		$this->_caldav_server->updateUserQuota($base_url);
	}

	function put_extended_data($id, $name, $value)
	{
		//lets see if the id exists already
		$existingId = $this->dbAdapter->
				select()->from('calendarExtendedData')->
				where('Account = ' . $this->dbAdapter->quote($this->username) . ' and ObjectId = ' . $this->dbAdapter->quote($id))->query()->fetchAll();

		if( count($existingId) > 0 )
		{
			// it exists, lets do an update of the data instead
			$this->dbAdapter->update('calendarExtendedData', array('Account' => $this->username, 'ObjectId' => $id, $name => $value), 'Account = ' . $this->dbAdapter->quote($this->username) . ' and ObjectId = ' . $this->dbAdapter->quote($id));	
			return true;
		}
		
		// id doesn't exist
		$this->dbAdapter->insert('calendarExtendedData', array('Account' => $this->username, 'ObjectId' => $id, $name => $value));
		
		return true;
	}

	function get_extended_data($id)
	{
		//lets see if the id exists already
		$xData = $this->dbAdapter->
			select()->from('calendarExtendedData')->
			where('Account = ' . $this->dbAdapter->quote($this->username) . ' and ObjectId = ' . $this->dbAdapter->quote($id))->query()->fetchAll();
			
		if(count($xData) == 0)
		{
			return array();
		}
		
		return $xData[0];		
	}
	
	function delete_extended_data($id)
	{
		return $this->dbAdapter->delete('calendarExtendedData', 'Account = ' .  $this->dbAdapter->quote($this->username) . ' AND ObjectId = ' . $this->dbAdapter->quote($id));
	}

	function actual_time($offset,$timestamp)
	{
		$offset = $offset*60*60;
		$timestamp = $timestamp + $offset;
		return gmdate($timestamp);
	}

	function update_record(
		$userto, 
		$userfrom, 
		$Title, 
		$DateStart, 
		$DateEnd, 
		$id, 	
		$shared, 
		$CalMessage, 
		$location, 
		$category, 
		$task, 
		$dateStamp = 0, 
		$timezone = 0,
		$RecurrenceType = 0,
		$recurrenceEndType = 0,
		$recurrenceEndByDate = 0,
		$recurrenceEndAfterXOccurances = 0,
		$relative_href = '',
		$alertType = '',
		$alertTrigger = '',
		$alertPosition = '',
		$recurrenceInterval = 1)
	{
		$status = 0;

		if( !isset($task) )
		{
			$task=0;
		}

		if( is_numeric($DateStart) )
		{
			$DateStart = Date("Y-m-d H:i:s", $DateStart);
		}
		if( is_numeric($DateEnd) )
		{
			$DateEnd = Date("Y-m-d H:i:s", $DateEnd);
		}
		
		$Title=trim($Title, '\"');
		$CalMessage=trim($CalMessage, '\"');
		$location=trim($location,'\"');
		$category=trim($category,'\"');

		$foundcal = null;

		if( $id[0] == 'p' || $id[0] == 's' )
		{
			$id = substr($id, 1, strlen($id));
		}
		
		if( strpos($id, '_') != false )
		{
			$id = substr($id, 0, strpos($id, '_'));
		}
        
		if( $relative_href == '' || $relative_href == 'undefined' || $relative_href == null )
		{
			
			if($this->calNames == null)
			{
				$this->calNames = $this->getCalNames($this->_caldav_server, $this->caldav_URL);
			}
			
			foreach( $this->calNames as $calname )
			{
				if( $task==0 )
				{
					$events = $this->_caldav_server->GetEntryByUid( $id, $calname['relative_href']);
				}
				else
				{
					$events = $this->_caldav_server->GetEntryByUidEx( $id, 'VTODO', $calname['relative_href']);
				}
				if( count($events) > 0 )
				{
					$foundcal = $calname;
					break;
				}
			}
		}
		else
		{
			if( strpos($relative_href, '@') != false)
			{
				list($user, $domain) = explode('@', $relative_href);
				$relative_href = $user . "%40" . $domain;
			}
			$foundcal['relative_href'] = $relative_href;
			
			if( $task==0 )
			{
				$events = $this->_caldav_server->GetEntryByUid( $id, $foundcal['relative_href']);
			}
			else
			{
				$events = $this->_caldav_server->GetEntryByUidEx( $id, 'VTODO', $foundcal['relative_href']);
			}
			
		}
		
		// 'munch' the events into a nice array
		$munchedEvents = $this->munchEvents($events);

		// now we must format that array into the expected xml
		//<App ID="p1" Task="0" User="brett@kurra.calacode.com" Start="2009-02-02 16:00" Finish="2009-02-02 17:00" Shared="0" CalNameID="" Availability="Busy">
		//<Subject>Testing the caldav functions</Subject>
		//</App>
		// should only be one event here !
		$event = $munchedEvents[0];
					
		// update the seq counter
		if( isset($event['VCALENDAR']['VEVENT']) )
		{
			$type = 'VEVENT';
		}
		else if( isset($event['VCALENDAR']['VTODO']) )
		{
			$type = 'VTODO';
		}

		$event['VCALENDAR'][$type]['SEQUENCE'] += 1;
		$current_date = getdate();
		

		if($alertType != '' && $alertType != 'None')
		{	
			if(isset($event['VALARM']))
				unset($event['VALARM']);
			if(isset($event['VCALENDAR'][$type]['VALARM']))
				unset($event['VCALENDAR'][$type]['VALARM']);

			$event['VCALENDAR'][$type]['VALARM'] = $this->caldav_set_alarm_trigger($event, $foundcal['relative_href'], $alertTrigger, $alertType, $alertPosition, $Title);
		}
		else
		{
			if(isset($event['VALARM']))
			{
				//$event['VCALENDAR'][$type]['VALARM'] = $event['VALARM'];
				unset($event['VALARM']);
			}
		}
		
		$AllDayEvent = false;
		$dttype = '';

		if( $type == 'VEVENT' && isset($DateStart) && $DateStart != null && $DateStart != ''
		&& isset($DateEnd) && $DateEnd != null && $DateEnd != ''
		&& strpos(ical_datetime(date(strtotime($DateStart))), 'T000000') != false
		&& strpos(ical_datetime(date(strtotime($DateEnd))), 'T000000') != false
		)
		{
			$dttype = ';VALUE=DATE';	
			$AllDayEvent = true;
		}

		if( $type == 'VEVENT' && isset($DateStart) && $DateStart != null && $DateStart != '' )
		{
			if( isset($event['VCALENDAR'][$type]['DTSTART']) || isset($event['VCALENDAR'][$type]['DTSTART' . $dttype]))
			{
				unset($event['VCALENDAR'][$type]['DTSTART']);
				$event['VCALENDAR'][$type]['DTSTART' . $dttype] = ($AllDayEvent ? str_replace('T000000', '', ical_datetime(date(strtotime($DateStart)))) : ical_datetime(date(strtotime($DateStart))));
			}
			else if ( isset($event['VCALENDAR']['VTIMEZONE']['TZID']) && isset($event['VCALENDAR'][$type]['DTSTART;TZID=' . $event['VCALENDAR']['VTIMEZONE']['TZID']]) )
			{
				$event['VCALENDAR'][$type]['DTSTART;TZID=' . $event['VCALENDAR']['VTIMEZONE']['TZID']] = ical_datetime(date(strtotime($DateStart)));
			}
		}

		if( isset($DateEnd) && $DateEnd != null && $DateEnd != '' )
		{
			if( $type == 'VEVENT' && isset($event['VCALENDAR'][$type]['DUE']) )
			{
				$event['VCALENDAR'][$type]['DUE'] = ical_datetime(date(strtotime($DateEnd)));
			}
			else if( $type == 'VTODO' && isset($DateEnd) && $DateEnd != null && $DateEnd != '' && isset($event['VCALENDAR'][$type]['DUE;VALUE=DATE']) )
			{
				$event['VCALENDAR'][$type]['DUE;VALUE=DATE'] = ical_datetime(date(strtotime($DateEnd)));
			}
			else if( isset($event['VCALENDAR'][$type]['DURATION']) )
			{
				$event['VCALENDAR'][$type]['DURATION'] = seconds_to_ical_duration(strtotime($DateEnd) - strtotime($DateStart));
			}

			if( $type == 'VEVENT' && (isset($event['VCALENDAR'][$type]['DTEND']) || isset($event['VCALENDAR'][$type]['DTEND' . $dttype])))
			{
				unset($event['VCALENDAR'][$type]['DTEND']);
				$event['VCALENDAR'][$type]['DTEND' . $dttype] = ($AllDayEvent ? str_replace('T000000', '', ical_datetime(date(strtotime($DateEnd)))) : ical_datetime(date(strtotime($DateEnd))));
			}
			else if( isset($event['VCALENDAR']['VTIMEZONE']['TZID']) && isset($event['VCALENDAR'][$type]['DTEND;TZID=' . $event['VCALENDAR']['VTIMEZONE']['TZID']]) )
			{
				$event['VCALENDAR'][$type]['DTEND;TZID=' . $event['VCALENDAR']['VTIMEZONE']['TZID']] = ical_datetime(date(strtotime($DateEnd)));
			}
		}

		if( isset($Title) && $Title != null && $Title != '' )
		{
			$event['VCALENDAR'][$type]['SUMMARY'] = $Title;
		}

		if( isset($CalMessage) && $CalMessage != null && $CalMessage != '' )
		{
			$event['VCALENDAR'][$type]['DESCRIPTION'] = $CalMessage;
		}

		$event['VCALENDAR'][$type]['DTSTAMP'] = $event['VCALENDAR'][$type]['LAST-MODIFIED'] = ical_datetime($current_date[0]) . "Z";

		if(isset($dateStamp) && $dateStamp != 0)
		{
			$event['VCALENDAR'][$type]['DTSTAMP'] = ical_datetime($this->actual_time($timezone, strtotime($dateStamp))) . "Z";
		}
		else
		{
			$dateStamp = $this->actual_time($timezone, strtotime(gmdate("Y-m-d H:i:s")));
			$event['VCALENDAR'][$type]['DTSTAMP'] = ical_datetime($dateStamp) . "Z";	
		}

		if( isset($location) && $location != null )
		{
			$event['VCALENDAR'][$type]['LOCATION'] = $location;
		}

		if( isset($category) && $category != null )
		{
			$event['VCALENDAR'][$type]['CATEGORY'] = $category;
		}

		// unset anything thats not needed
		if( isset($event['VCALENDAR'][$type]['DESCRIPTION']) && $event['VCALENDAR'][$type]['DESCRIPTION'] == '' )
		{
			unset($event['VCALENDAR'][$type]['DESCRIPTION']);
		}
		if( isset($event['VCALENDAR'][$type]['CATEGORY']) && $event['VCALENDAR'][$type]['CATEGORY'] == '' )
		{
			unset($event['VCALENDAR'][$type]['CATEGORY']);
		}
		if( isset($event['VCALENDAR'][$type]['LOCATION']) && $event['VCALENDAR'][$type]['LOCATION'] == '' )
		{
			unset($event['VCALENDAR'][$type]['LOCATION']);
		}
				
		if($RecurrenceType != null)
		{
		
			if( isset($event['VCALENDAR'][$type]['RRULE']))
			{
				unset($event['VCALENDAR'][$type]['RRULE']);
			}
			if( isset($event['VCALENDAR'][$type]['RRULE2']))
			{
				unset($event['VCALENDAR'][$type]['RRULE2']);
			}
			$recurrenceArray = array();
	
			$recurrenceArray['RecurrenceType'] = $RecurrenceType;
			$recurrenceArray['RecurrenceEndType'] = $recurrenceEndType;
			$recurrenceArray['Until'] = $recurrenceEndByDate;
			$recurrenceArray['Occurences'] = $recurrenceEndAfterXOccurances;
			$recurrenceArray['skipInterval'] = $recurrenceInterval;
			
			$recurrence = $this->RecurrenceArray2ical($recurrenceArray);
			
			if(is_array($recurrence) && count($recurrence) > 0)
			{
				$event['VCALENDAR'][$type] = array_merge($event['VCALENDAR'][$type], $recurrence);
			}

		}
		
		// finally make the event
		$event_text = ical_create_entry($event);
		$url = $foundcal['relative_href'] . $event['VCALENDAR'][$type]['UID'] . '.ics';
        
		$event['etag'] = $this->_caldav_server->DoPUTRequest($url, $event_text, $event['etag']);

		if( $event['etag'] == "" )
		{
			// FAILED!
			$status = -1;
		}
			
		return findetag($this->_caldav_server, $foundcal['relative_href']);
	}

	// Return a array containing the event
	function read_record($id, $shared=false, $relative_href)
	{
		if ($shared)
		{
			// If a shared entry, we fail as its not current supported
			die("SHARED RECORDS ARE NOT SUPPORTED");
		}
		else
		{
			if( $id[0] == 'p' || $id[0] == 's' )
			{
				$id = substr($id, 1, strlen($id));
			}
			
			$localread = false;
			if($this->_local && $this->_server_type == "at" && urldecode($relative_href) == $this->_account . '/calendar/')
			{
				// fast disk based modification check
				$dir = $this->_caldav_server->getDataDirectory();
	
				if($dir != false && is_dir($dir))
				{	
					$file = $dir . '/' . $id . '.ics';
					if( is_file($file) )
					{
						// ok, dir and file exist, lets just grab the data
						$event['href'] = $id . '.ics';
						$event['data'] = file_get_contents($file);
						$event['etag'] = '';
						if($event['data'] != false)
						{
							// success!
							$localread = true;
							$events[] = $event;
						}	
					}
				}		
			}
			
			if(!$localread)
			{
				$events = $this->_caldav_server->GetEntryByUid( $id, $relative_href );
			}
			
			if(count($events) == 0)
				return false;
				
			// 'munch' the events into a nice array
			$munchedEvents = $this->munchEvents($events);
			// should only be one event here !
			$event = $munchedEvents[0];
			$event['Permissions'] = 1;
		}

		return $event;
	}

	function search_record($account)
	{		
		$existingUser = $this->dbAdapter
			->select()
			->from('UserSession')
			->where('Account = ' . $this->dbAdapter->quote($account))
			->query()
			->fetchAll();

		if( count($existingUser) > 0 )
		{
			return true;
		}

		return false;
	}

	function make_principal_calendar($new_user, $caldav_server)
	{

$xml = <<<EOXML
<?xml version="1.0" encoding="UTF-8" ?>
<x0:mkcalendar xmlns:x0="urn:ietf:params:xml:ns:caldav" xmlns:x1="DAV:" xmlns:x2="http://apple.com/ns/ical/">
<x1:set>
<x1:prop>
<x1:displayname>Untitled</x1:displayname>
</x1:prop>
</x1:set>
</x0:mkcalendar>
EOXML;
		$caldav_server->DoXMLRequest( "MKCALENDAR", $xml, $caldav_server->user . '/' . $new_user . '/');
		return $caldav_server->user . '/' . $new_user . '/';
	}

	function add_group_user($username, $password)
	{
		$status = true;

		//lets see the group exists already
		$existingUser = $this->dbAdapter->fetchOne("select Account from UserSession where Account = ?", array($username));
		if( empty($existingUser))
		{
			// it exists, but lets make sure the password is up to date.
			$this->dbAdapter->insert('UserSession', array('Account' => $username, 'Password' => $password, 'CalUser' => '1'));
			users::changePassword($username, $password);
		}
		else
		{
			// user doesn't exist
			$status=false;
		}
		
		users::changePassword($username, $password);
		
		return $status;
	}

	function delete_group_user($username, $password)
	{
		// TODO: NEED TO USE THE USER API
		// ALSO TODO: CHECK USER EXISTS.
		// user remove
		$this->dbAdapter->delete('UserSession', 'Account = ' .  $this->dbAdapter->quote($username) . ' AND Password = ' . $this->dbAdapter->quote($password) . ' AND CalUser = 1');

		return true;
	}

	function get_proxy($user)
	{
		return getproxy($this->_caldav_server, $user, $relative_href);
	}

	function get_calendar_name($name)
	{
		list($username, $domain) = explode('@', $this->_caldav_server->user);
		$name = str_replace(" ", "", $name);

		if( $name != "Untitled" )
		{
			if( $name == '' )
			{
				$new_user = $username . '@' . $domain;
			}
			else
			{
				$new_user = $username . '-' . urlencode($name) . '@' . $domain;
			}
		}
		else
		{
			$new_user = $username . '-' . str_replace("-" , "", create_guid()) . '@' . $domain;
		}

		if($domain == '')
		{
			$new_user = rtrim($new_user, "@");
		}

		return $new_user;
	}
	
	function get_server_type()
	{
		return $this->_server_type;
	}

	function make_calendar($account, $ctag, $etag, $name, $json = 0)
	{
		$status = true;
		list($username, $domain) = explode('@', $this->_caldav_server->user);

		$new_user = $this->get_calendar_name($name);
		if($this->_server_type != 'at')
		{
			list($new_user, $junk) = explode('@', $new_user, 2);
			$new_href = $this->make_principal_calendar($new_user, $this->_caldav_server);

			if($new_href != "")
			{
				list($junk, $etag) = explode('<getetag>', findprops($this->_caldav_server, $new_href), 2);
				list($etag, $junk) = explode('</getetag>', $etag, 2);
			}
			else
			{
				$status = false;
			}
		}
		else
		{
			if( !$this->add_group_user($new_user, $this->_caldav_server->pass) )
			{
				// we are going to ignore the fact that the calendar user already EXISTS
				// lets go through the motions just in case the calendar requires a proxy set as sometimes
				// these can go walkabouts (say, reinstalled calendar server but didn't clear UserSession)				
				// $status = false;
			}

			$group_caldav_server = new CalDAVClient( $this->caldav_URL, $new_user,  $this->_caldav_server->pass, 'calendar' );
			$group_caldav_server->SetUserAgent("Atmail 6.0");

			$this->update_calendar( '/' . $new_user . '/calendar/',  'displayname', $name, $group_caldav_server, $json);	
			addproxy($group_caldav_server, $new_user, $group_caldav_server->pass, $this->_caldav_server->user, "RW", true);

			$new_href = $new_user . '/calendar/';
		}
		
		$etag = findetag($this->_caldav_server, $new_href);

		if( $status )
		{
			return array($new_href, $etag);
		}
		else
		{
			return false;
		}
	}

	function delete_calendar($relative_href, $ctag, $etag)
	{
		$result = 1;
		list($user, $rubbish) = explode('/', $relative_href);
		list($username, $domain) = explode('@', $user);

		$group_caldav_server = new CalDAVClient( $this->caldav_URL, $user,  $this->_caldav_server->pass, 'calendar' );
		$group_caldav_server->SetUserAgent("Atmail 6.0");

		removeproxy($group_caldav_server, $user, $group_caldav_server->pass, $this->_caldav_server->user, "RW");

		$result = $group_caldav_server->DoDELETERequest($relative_href, null);

		$this->delete_group_user($user, $this->_caldav_server->pass);

		return $result;
	}

	function update_calendar($relative_href, $prop, $patch, $server=null, $json=0)
	{
$xml = <<<EOXML
<?xml version="1.0" encoding="UTF-8" ?>
<x0:propertyupdate xmlns:x0="DAV:"><x0:set><x0:prop><x0:$prop>$patch</x0:$prop></x0:prop></x0:set></x0:propertyupdate>
EOXML;
		if( $server == null )
		{
			$server = $this->_caldav_server;
		}
if(!$json)
{
		return $server->DoXMLRequest( "PROPPATCH", $xml, $relative_href);
}
else
{
	return json_encode($server->DoXMLRequest( "PROPPATCH", $xml, $relative_href));
}
	}

	function update_calendar_ex($relative_href, $namespace_in, $prop, $patch, $server=null)
	{
$xml = <<<EOXML
<?xml version="1.0" encoding="UTF-8" ?>
<x0:propertyupdate xmlns:x0="DAV:" xmlns:x1="http://apple.com/ns/ical/"><x0:set><x0:prop><x1:$prop>$patch</x1:$prop></x0:prop></x0:set></x0:propertyupdate>
EOXML;
		if( $server == null )
		{
			$server = $this->_caldav_server;
		}

		$output = $server->DoXMLRequest( "PROPPATCH", $xml, $relative_href);

		return $output;
	}

	function print_mkcal($ctag, $etag, $relative_href, $status, $name, $description,$color,$order, $calendar_owner, $account, $json)
	{
if(!$json)
{
		print "<calName relative_href='{$relative_href}' ctag='{$ctag}' etag='{$etag}' name='{$name}' description='{$description}' color='{$color}' order='{$order}' calendar_owner='{$calendar_owner}' account='{$account}'><Error Status='{$status}'></Error></calName>\n";
}
else
{
	print json_encode(array('ctag' => $ctag, 'etag' => $etag, 'relative_href' => $relative_href, 'status' => $status, 'name' => $name, 'description' => $description, 'color' => $color, 'order' => $order, 'calendar_owner' => $calendar_owner, 'account' => $account));
}
	}

	function print_calnames($calNames, $json)
	{
if(!$json)
{
print <<<EOF
<CalNames>
EOF;
		$totalstr = '';
		foreach( $calNames as $calname )
		{
			$str = "<CalName ctag='{$calname['ctag']}' shared='{$calname['shared']}' etag='{$calname['etag']}' name='{$calname['displayname']}' description='{$calname['description']}' color='{$calname['color']}' order='{$calname['order']}' relative_href='{$calname['relative_href']}' calendar_owner='{$calname['calendar_owner']}'/>\n";
			$totalstr .= $str;
		}
		$md5checksum = md5($totalstr);
		print $totalstr;
		print "<SystemInfo MD5='$md5checksum'/>\n";
print <<<EOF
</CalNames>
EOF;
}
else
{
		foreach( $calNames as &$calname )
{
//	$calname['color'] = trim($calname['color'], '#');
//	$calname['color'] = substr($calname['color'], 0, -2);
}
		echo json_encode($calNames);
}

	}

	function print_total( $total )
	{
		$output['total'] = $total;
		echo json_encode($output);
	}

	function print_return_code($id, $status, $json)
	{
if(!$json)
{
		if( $status == '' )
		{
			$status = 0;
		}
		print "<Cal ID='{$id}'><Error Status='{$status}'></Error></Cal>\n";
}
else
{
	print json_encode(array('id'=> $id, 'status' => $status));
}
	}

	function print_cal($func, $md5client, $account, $event_entries, $date_alert, $json)
	{
	
		$recipients = array();

		// If using the Ajax calendar, we are only viewing our records and shared details
		if( $func == 'ajaxcal' || $func == 'freebusy' )
		{
			$recipients[0] = $account;			// this should probably come from somewhere else
		}
		else
		{
			$recipients = $param['recipients'];
		}
if(!$json)
{
print <<<EOF
<Appointments>
EOF;
}
		$myarray = array();
		$totalstr = '';
		foreach( $recipients as $user )
		{
			list($username, $pop3host) = explode('@', $user);

			foreach ($event_entries as $db)
			{
				// map to json packet
				$temp = array();
				$temp['id'] = $db['id'];
				$temp['title'] = $db['Title'];
				$temp['start'] = strtotime($db['DateStartCal'] . " " . $db['DateStartTime']);
				$temp['end'] =  strtotime($db['DateEndCal'] . " " . $db['DateEndTime']);
				$temp['user'] = $user;
				$temp['color'] = $db['calendar_color'];
				$temp['relative_href'] = $db['relative_href'];
				$myarray[] = $temp;
				$str = '';
				if( $func == 'ajaxcal' )
				{
					if( isset($db['Task']) && $db['Task'] != null )
					{
						$str = "<App ID='p{$db['id']}' Task='1' User='$username@$pop3host' ";
						if( $db['DateStartCal'] != null )
						{
							$str .= "Start='{$db['DateStartCal']} {$db['DateStartTime']}' ";
						}
						if( $db['DateEndCal'] != null )
						{
							$str .= "Finish='{$db['DateEndCal']} {$db['DateEndTime']}' ";
						}
						$str .= "Shared='0' ctag='{$db['ctag']}' etag='{$db['etag']}' owner='{$db['calendar_owner']}' relative_href='{$db['relative_href']}' alarmSet='0'><Subject><![CDATA[{$db['Title']}]]></Subject></App>\n";
					}
					else
					{
						$str = "<App ID='p{$db['id']}' Task='0' User='$username@$pop3host' Start='{$db['DateStartCal']} {$db['DateStartTime']}' Finish='{$db['DateEndCal']} {$db['DateEndTime']}' Shared='0' ctag='{$db['ctag']}' owner='{$db['calendar_owner']}' etag='{$db['etag']}' IsRecurring='{$db['IsRecurring']}' recurrencePattern='{$db['recurrencePattern']}' recurrenceTime='{$db['recurrenceTime']}' relative_href='{$db['relative_href']}' alarmSet='{$db['alarmSet']}'><Subject><![CDATA[{$db['Title']}]]></Subject></App>\n";
					}
					
					$totalstr .= $str;
				}
				else
				{
					$str = "<App User='$user' Date='{$db['DateStartCal']}' Start='{$db['DateStartTime']}' Finish='{$db['DateEndTime']}' Title='{$db['Title']}' Type='Busy' owner='{$db['calendar_owner']}' ctag='{$db['ctag']}' etag='{$db['etag']}' relative_href='{$db['relative_href']}' alarmSet='{$db['alarmSet']}'/>\n";
					$totalstr .= $str;
				}
			}
		}

		$md5checksum = md5($totalstr);

		// Validate if we have anything that is due now
		if( $date_alert != '1' )
		{
			// TODO: Get the date from the users client in JS
			$due = 0;
			$count = count($due);
		}

if(!$json)
{
		if( $md5checksum == $md5client )
		{
			print "<SystemInfo MD5='$md5checksum' Changes='0' Due='$count'/>\n";
		}
		else
		{
			print $totalstr;
			print "<SystemInfo MD5='$md5checksum' Changes='1' Due='$count'/>\n";
		}
print <<<EOF
</Appointments>
EOF;
}
else
{
	echo json_encode($myarray);
}
	}

	function print_users($users, $json)
	{
if(!$json)
{
print <<<EOF
<Users>
EOF;

		$totalstr = '';
		if( count($users) )
		{
			foreach( $users as $user )
			{
				$str = "<User username='{$user[0]}' permissions='{$user[1]}'/>\n";
				$totalstr .= $str;
			}
		}
		$md5checksum = md5($totalstr);
		print $totalstr;
		print "<SystemInfo MD5='$md5checksum'/>\n";

print <<<EOF
</Users>
EOF;
}
else
{
	print json_encode($users);
}
	}
}
