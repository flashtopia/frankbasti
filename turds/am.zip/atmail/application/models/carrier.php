<?php
 /**
 * @category   Atmail
 * @package    contacts model
 * @author     Allan Wrethman allan@staff.atmail.com
 * @license    Copyrighted by Atmail 2008
 */
 
require_once('library/Atmail/Abook/Abook/Abook.php');
require_once('application/models/sync.php'); 

class contacts
{
	//current contacts and contacts group implimentation is based on A5 database structure to ease the upgrade to A6 from older versions
	//once A6 is stable in the market place, then next step is to optomise/normalise all tables into 3rd normal form to implove performance, integrity and maintainance cost
	//currently group can only really be used for mail groups, but should be expanded to encompass complete groups
	
	private $_session;
	private $_account;
	private $_tableNames;
	private $_namespaceName = 'carrier';
	private $_admin = false; //this will allow an admin to modify contacts without needing a valid Account (owner)
	private $_abook;
		
	public function __construct(Array $args)
	{

		if( !isset($args['Account']) )
		{
			throw new Atmail_Exception('Carrier constructor requires Account field in arguments array');
		}
		else
		{
			$this->_account = $args['Account'];               
		}
			
		$email = explode('@', $this->_account);
		
		if(!empty($email['1']))
		{
			$this->_username = $email['0'];
			$this->_domain = $email['1'];		
		}
		else
		{	
			$this->_username = '';		
			$this->_domain = '';	
		}

		$this->view->global = Zend_Registry::get('config')->global;
        	if( isset($args['namespaceName']) )
			$this->_namespaceName = $args['namespaceName'];
		$this->_session = new Zend_Session_Namespace($this->_namespaceName); // session used as seperate persistent store for if caching disabled
		
		$this->dbAdapter = Zend_Registry::get('dbAdapter');
		//$this->dbAdapter->getProfiler()->setEnabled(true); //link to enable debug for performance 
		
		$this->log = Zend_Registry::get('log');
	}
	
}
