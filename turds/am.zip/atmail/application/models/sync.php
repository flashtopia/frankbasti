<?php
 /**
 * @category   Atmail
 * @package    Sync model 
 * @author    Brett Embery brett@staff.atmail.com
 * @license    Copyrighted by Atmail 2010
 */

require_once 'application/models/calendar.php';
require_once 'application/models/contacts.php';
require_once 'application/models/users.php';
		

class sync
{
	private $_session;
	private $_account;
	private $_tableNames;
	private $xml;
	private $username;
	private $password;
	private $enabled;
	private $shared_enabled;
	private $global_enabled;
	
	private $contacts;
	private $calendar;
	private $data;
	private $CalDavType;
	
	/*		if($xml)
			header("Content-type: text/xml;");
			*/

	public function __construct($xml)
	{	
		$this->dbAdapter = Zend_Registry::get('dbAdapter');
		$this->log = Zend_Registry::get('log');
	}
	
	public function init($user, $domain, $password)
	{
		// -1 == NOUSER
		// -2 == DISABLED
		
		// First, check the user account exists
		$matches = $this->dbAdapter->select("Account")->from("UserSession")->where("Account=" . $this->dbAdapter->quote("$user@$domain"))->query()->fetchAll();
		if( count($matches) != 1 )
		{
			return -1;
		}
		
		// Next, authorize the account
		// TODO add md5 enabled/disabled switch
		$matches = $this->dbAdapter->select("Account, password")->from("UserSession")->where("Account=" . $this->dbAdapter->quote("$user@$domain") . " and password=" . $this->dbAdapter->quote("$password"))->query()->fetchAll();
		if( count($matches) != 1 )
		{
			// try again with md5
			$matches = $this->dbAdapter->fetchAll("select Account, password from UserSession where Account=? and Password=MD5(?)", array("$user@$domain", $password));

			if( count($matches) != 1 )
			{
				return -1;
			}
		}
		$this->username = $matches[0]['Account'];
		$this->password = $matches[0]['Password'];
		
		
		//create the admin object to access group/user data
		try
		{
			require_once('application/models/api.php');
			$api = new api(array('Username' => $this->username, 'Password' => $this->password, 'directApi' => 1));
		
			$current_user = $api->userView($this->username, '');
			$current_user_group = $current_user['Ugroup'];
			$current_user_status = $current_user['UserStatus'];
		
			// TODO: follow user status
			$current_group = $api->groupGet($current_user_group);
			$current_group = $current_group['response']['results'];
			
			$this->enabled = $current_group['Sync'];
			$this->shared_enabled = $current_group['WebSyncShared'];
			$this->global_enabled = $current_group['WebSyncGlobal'];
			
			// clear the variables
			unset($current_group);
			unset($current_user);
			unset($api);
		}
		catch (Exception $e)
		{
			file_put_contents("php://stderr", "SYNC : Error fetch user/group data for " . $this->username . " (" . $e->getMessage() . ")\n");
			$this->enabled = 0;
		}
		
		// Disallow operation if disabled on server
		if (!$this->enabled)
		{
			return -2;
		}
		
		//Load the account preferences
		$userDataRows = $this->dbAdapter->select()->from("Users")->join("UserSettings", "Users.Account = UserSettings.Account")->where("Users.Account = " . $this->dbAdapter->quote($this->username))->query()->fetchAll();
		Zend_Registry::set('UserSettings', $userDataRows[0]);
		
		$userSettings = Zend_Registry::get('UserSettings');
		
		// ********************** CONNECT TO SERVICES ************************* //
		$this->contacts = new contacts( array('Account' => $this->username, 'largeInstall' => '1') );
		$config = Zend_Registry::get('config');
		
		// If no defined CalDavUser/CalDavPass in the UserSettings table, revert to the current logged in session details
		if(empty($config->global['CalDavUser']))
		{
			$CalDavUser = $userSettings['Account'];
		}
		else
		{
			$CalDavUser = $config->global['CalDavUser'];
		}
		
		if(empty($config->global['CalDavPass']))
		{
			if(isset($userSettings['Password']))
			{
				$CalDavPass = $userSettings['Password'];
			}
			else
			{
				$CalDavPass = $this->password;
			}
		}
		else
		{
			$CalDavPass = $config->global['CalDavPass'];
		}
		
		if(empty($CalDavPass))
		{
			$CalDavPass = $this->password;
		}
		
		$this->username = $CalDavUser;
		$this->password = $CalDavPass;
		
		
		// load cal object
		$this->CalDavType = $userSettings['CalDavType'];
		$this->CalDavBaseUrl = 
		$this->calendar = new calendar(array('Type' => $userSettings['CalDavType'], 'URL' => $userSettings['CalDavUrl'], 'Account' => $CalDavUser, 'Password' => $CalDavPass, 'Calendar' => "calendar", 'home', 'largeInstall' => '1') );
	}
	
	function setData($data_in)
	{
		$this->data = $data_in;
	}

	function myurlencode ($v)
	{
		$v = urlencode($v);
		$v = str_replace("+", "%20", $v);
		return $v;
	}
	
	function httpheaders()
	{
		echo '<html><head><xml version="1.0" encoding="ISO-8859-1"></head>';
	}
	
	function httpend()
	{
		echo '</html>';
	}
	
	function convert_from_outlook_date($date)
	{
		return $this->calendar->convert_from_outlook_date($date);
	}
	
	//
	// Start function definitions
	//
	
	// Add a new record to the addressbook
	function sync_add()
	{
		if (isset($this->data['global']) && $this->data['global'] == 1)
		{
			print "<Status failed=1 name='AddAbook' value='$id' return='{$this->data['UserEmail']}'></Status>\n";
			return;
		}
		if (isset($this->data['Shared']) && $this->data['Shared'] && !$this->shared_enabled)
		{
			$this->data['Shared'] = 0;
		}
		if (isset($this->data['Shared']) && $this->data['Shared'] && $this->shared_enabled && $this->data['Permissions'] == '')
		{
			$this->data['Permissions'] = $this->username;
		}
		
		if(isset($this->data['DateModified']) && isset($this->data['TimeZone']))
		{
			$this->data['DateModified'] = $this->data['DateModified'] - ($this->data['TimeZone'] / 1440);
		}		
		$id = $this->contacts->addContact($this->data);
	
		if (isset($this->data['Shared']) && $this->data['Shared'] && $this->shared_enabled)
		{
			// add to shared group
			$status = $this->contacts->addContactToGroup(array('GroupID' => '-2', 'id' => $id));
			$status = $this->add_entryidmap($this->data['EntryID'], $id, "abook");
		}
		
		if($this->xml)
		{
			print "<Status name='AddAbook' value='$id' return='{$this->data['UserEmail']}'></Status>\n";
		}
		else
		{
			$this->httpheaders();
			print "Added record {$this->data['UserEmail']}";
		}
	}
	
	
	// LEGACY VERSION STRING
	// This is for old WebSync plug-ins that had a version bug.
	// Basically, if we don't the plugin will suddenly report
	// that the server has lost it's mind,
	// but it's really just a version string change.....
	function sync_version()
	{
		global $SERVER_VERSION;
	
		print $SERVER_VERSION . "\nSERVER CHECK\n";
		print("Shared = " . $this->shared_enabled . "\n");
		print("Global = " . $this->global_enabled . "\n");
	
		// Log the user was successful
	}
	
	function call($func)
	{
		$this->$func();
	}
	
	// version string for new websync that has some version logic...
	function sync_version_check()
	{
		return $this->sync_version();
	}
	
	function sync_updateurl()
	{
		$protocol = "http";
		if ( isset($_SERVER['HTTPS']) || strtolower($_SERVER['HTTPS']) == 'on' ) {
			$protocol = "https";
		}
		print $protocol . '://' . $_SERVER["SERVER_NAME"] . substr($_SERVER["SCRIPT_NAME"],0,strpos($_SERVER["SCRIPT_NAME"],'sync.php')) . "downloads/websync.zip\n";
	}
	
	function sync_update()
	{	
		$EntryID = '';
		if(isset($this->data['EntryID']))
		{
			$EntryID = $this->data['EntryID'];
		}
	
		$UpdateAll = '';
		if(isset($this->data['updateall']))
		{
			$UpdateAll = $this->data['updateall'];
		}
		
		$Shared = '';
		if(isset($this->data['Shared']))
		{
			$Shared = $this->data['Shared'];
		}
		
		$var = $this->data;
	
		if ($this->data['updateall'])
		{
			$var['DateModified'] = $var['DateModified'] + ($var['TimeZone'] / 1440.0);
			
			// We are updating the entry addressbook
			$status = $this->contacts->updateContact(array(
				'UserEmail'		=> $var['UserEmail'],
				'UserEmail2'		=> $var['UserEmail2'],
				'UserEmail3'		=> $var['UserEmail3'],
				'UserFirstName'		=> $var['UserFirstName'],
				'UserMiddleName'	=> $var['UserMiddleName'],
				'UserLastName'		=> $var['UserLastName'],
				'UserTitle'		=> $var['UserTitle'],
				'UserHomeAddress'	=> $var['UserHomeAddress'],
				'UserHomeCity'		=> $var['UserHomeCity'],
				'UserHomeState'		=> $var['UserHomeState'],
				'UserHomeZip'		=> $var['UserHomeZip'],
				'UserHomeCountry'	=> $var['UserHomeCountry'],
				'UserHomePhone'		=> $var['UserHomePhone'],
				'UserHomeMobile'	=> $var['UserHomeMobile'],
				'UserHomeFax'		=> $var['UserHomeFax'],
				'UserURL'		=> $var['UserURL'],
				'UserWorkCompany'	=> $var['UserWorkCompany'],
				'UserWorkTitle'		=> $var['UserWorkTitle'],
				'UserWorkAddress'	=> $var['UserWorkAddress'],
				'UserWorkCity'		=> $var['UserWorkCity'],
				'UserWorkState'		=> $var['UserWorkState'],
				'UserWorkZip'		=> $var['UserWorkZip'],
				'UserWorkCountry'	=> $var['UserWorkCountry'],
				'UserWorkPhone'		=> $var['UserWorkPhone'],
				'UserWorkMobile'	=> $var['UserWorkMobile'],
				'UserWorkFax'		=> $var['UserWorkFax'],
				'EntryID' 		=> $var['EntryID'],
				'DateModified' 		=> $var['DateModified'],
				'Shared' 		=> $var['Shared'],
				'id' 			=> $var['id']
			));
		}	
		// Update the EntryID, in the lookup tables or the direct abook entry
		elseif ($this->data['EntryID'] && $this->data['Shared'] && $this->shared_enabled)
		{
			$this->add_entryidmap($var['EntryID'], $var['id'], "abook");
		}
		elseif ($this->data['EntryID'] && $this->data['global'] && $this->global_enabled)
		{
			$this->add_entryidmap($var['EntryID'], $var['id'], "global");
		}
		elseif ($this->data['EntryID'])
		{
			$this->contacts->updateContact(array('EntryID' => $var['EntryID'], 'id' => $var['id']));
		}
	
		// Update the Datemodified, in the lookup tables or the direct abook entry
		//elseif ($this->data['DateModified'] && $this->data['Shared'] && $this->shared_enabled)
	//	{
	//		$this->add_entryidmap("", $var['id'], "abook", $var['DateModified'] + ($var['TimeZone'] / 1440.0));
	//	}
		elseif ($this->data['DateModified'] && $this->data['global'] == 1 && $this->global_enabled)
		{
			$this->add_entryidmap("", $var['id'], "global", $var['DateModified']);
		}
		elseif ($this->data['DateModified'])
		{
			$var['DateModified'] = $var['DateModified'] + ($var['TimeZone'] / 1440.0);
			$this->contacts->updateContact(array('DateModified' => $var['DateModified'], 'id' => $var['id']));
		}
		
		if(!isset($status))
		{
			$status = 0;
		}
	
		if($this->xml)
		{
			if(!$status)
			{
				print "<Status name='UpdateAbook' value='1' return='OK'></Status>\n";
			}
			else
			{
				print "<Status name='UpdateAbook' value='0' return='FAIL'></Status>\n";
			}
		}
		else
		{
			// Display the status
			if (!$status)
			{
				print "<OK>\n";
			}
			else
			{
				print "<FAIL>\n";
			}
		}
	}
	
	
	function sync_delete()
	{
		// Delete a shared or personal addressbook
		$var = $this->data;
		
		if ($this->data['Shared'] && $this->shared_enabled)
		{
			// TODO : Add shared delete support
			//$status = $abook->deleteshared($var['email'], $var['id']);
		}
		else
		{
			try
			{
				$status = $this->contacts->deleteContact($var);
			}
			catch(Exception $e)
			{
				//silent
			}
		}
	
		if($this->xml)
		{
			if(!$status)
			{
				print "<Status name='DeleteAbook' value='1' return='OK'></Status>\n";
			}
			else
			{
				print "<Status name='DeleteAbook' value='0' return='FAIL'></Status>\n"; 
			}
		}
		else
		{
			// Display the status
			if (!$status)
			{
				print "<OK>\n";
			}
			else
			{
				print "<FAIL>\n";
			}
		}
	}
	
	function sync_view()
	{
		$h = $this->contacts->getContacts( array() );
	
		// Get a hash containing all our Groups
		$group = $this->contacts->getGroups( $this->data['sort'] );
	
		$this->_view($h, $group);
	}
	
	function sync_viewshared()
	{
		// -1 = global
		// -2 = shared
		if(isset($this->data['global']) && $this->data['global'] && $this->global_enabled )
		{
			$h = $this->contacts->getContacts( array('GroupID' => -1) );
		}
		else if(!$this->shared_enabled)
		{
			return;
		}
		else
		{
			$this->data['Shared'] = 1;
			$h = $this->contacts->getContacts( array('GroupID' => -2) );
			$group = $this->contacts->getGroups( $this->data['sort'] );
		}
		$this->_view($h, array(), true);
	}
	
	
	// Print in XML style, of Websync utility Style
	function printstyle($record, $value)	{
		if($this->xml)
		{
			print "\t<$record>" . urldecode($value) . "</$record>\n";
		}
		else
		{
			print "$record = $value\n";
		}
	
		return;
	
	}
	
	function printstart()
	{
		if($this->xml)
		{
			print "<AbookData>\n"; // XML, just one last line
		}
	
		return;
	
	}
	
	function printeof()
	{
		if($this->xml)
		{
			print "</AbookData>\n\n\n"; // XML, just one last line
		}
		else
		{
			print "\n<br>\n"; // Record break for WebSync code
		}
	
		return;
	
	}
	
	function xmlbegin()
	{
		if($this->xml)
		{
			print "<Abook>\n";
		}
		return;
	}
	
	function xmlend()
	{
		if($this->xml)
		{
			print "</Abook>\n";
		}
		return;
	}
	
	function printblank()
	{
		if($this->xml)
		{
			print "<Blank>1</Blank>\n"; // XML, just one last line
		}
		else
		{
			print "<BLANK>\n";
		}
		return;
	}

	function add_entryidmap($EntryID, $id, $type, $datemodified=null, $account=null)
	{
		if($account != null)
		{
			$this->username = $account;
		}
		if ($datemodified && $EntryID )
		{
			// Check if the record already exists
			$v = $this->dbAdapter->fetchOne('select LookupID from SharedLookup where Account=' . $this->dbAdapter->quote($this->username) . ' and LookupID=' . $this->dbAdapter->quote($id) . ' and Type=' . $this->dbAdapter->quote($type));
	
			if (!$v)
			{
				$this->dbAdapter->insert('SharedLookup', array('Type' => $type, 'DateModified' => $datemodified, 'LookupID' => $id, 'EntryID' => $EntryID, 'Account' => $this->username));
			}
			else
			{
				$this->dbAdapter->update('SharedLookup', array('DateModified' => $datemodified, 'EntryID' => $EntryID), 'LookupID = ' . $this->dbAdapter->quote($id, 'INTEGER') .' and Account = ' . $this->dbAdapter->quote($this->username));
			}
		}
		elseif ($datemodified)
		{
			// Check if the record already exists
			$v = $this->dbAdapter->fetchOne('select LookupID from SharedLookup where Account=' . $this->dbAdapter->quote($this->username) . ' and LookupID=' . $this->dbAdapter->quote($id) . ' and Type=' . $this->dbAdapter->quote($type));
			if (!$v)
			{
				$this->dbAdapter->insert('SharedLookup', array('Type' => $type, 'DateModified' => $datemodified, 'LookupID' => $id, 'Account' => $this->username));
			}
			else
			{
				$this->dbAdapter->update('SharedLookup', array('DateModified' => $datemodified), 'LookupID = ' . $this->dbAdapter->quote($id, 'INTEGER') .' and Account = ' . $this->dbAdapter->quote($this->username));
			}
		}
		else
		{
			// Check if the record already exists
			$v = $this->dbAdapter->fetchOne('select LookupID from SharedLookup where Account=' . $this->dbAdapter->quote($this->username) . ' and LookupID=' . $this->dbAdapter->quote($id) . ' and Type=' . $this->dbAdapter->quote($type) . 'and LookupID is not null');

			if (!$v)
			{
				$this->dbAdapter->insert('SharedLookup', array('Type' => $type, 'EntryID' => $EntryID, 'LookupID' => $id, 'Account' => $this->username));
			}
			else
			{
				$this->dbAdapter->update('SharedLookup', array('EntryID' => $EntryID), 'LookupID = ' . $this->dbAdapter->quote($id, 'INTEGER') .' and Account = ' . $this->dbAdapter->quote($this->username));
			}
		}
	
		return 1;
	}
	
	function view_entryidmap($id, $type, $datemodified=null)
	{
		try
		{
			if ($datemodified)
			{
				$result = $this->dbAdapter->fetchOne('select DateModified from SharedLookup where LookupID=' . $this->dbAdapter->quote($id) . ' and Type=' . $this->dbAdapter->quote($type) . ' and DateModified is not null');
				return $result;
			}
			//print('select EntryID from SharedLookup where Account=' . $this->dbAdapter->quote($this->username) . ' and LookupID=' . $this->dbAdapter->quote($id) . ' and Type=' . $this->dbAdapter->quote($type));
			return $this->dbAdapter->fetchOne('select EntryID from SharedLookup where Account=' . $this->dbAdapter->quote($this->username) . ' and LookupID=' . $this->dbAdapter->quote($id) . ' and Type=' . $this->dbAdapter->quote($type));
		}
		catch(Exception $e)
		{
			// unable to retrieve
			return '';
		}
	}
	
	function _view($h, $group, $viewshared=null)
	{
		$count = 0;
	
		foreach($h as $id => $v)
		{
			$totalstr = '';
	
			// We are a group address entry, skip, do not display
			if(isset($v['UserEmail']) && isset($group[$v['UserEmail']]) && $group[$v['UserEmail']])
			{
				continue;
			}
			
			// if we are a global contact, and global isn't defined, dont display
			if((!isset($this->data['global']) || (isset($this->data['global']) && !$this->data['global'])) && $v['Global'] == '1')
			{
				continue;
			}
			
			// if we are a shared contact, and global isn't defined, dont display
			if((!isset($this->data['Shared']) || (isset($this->data['Shared']) && !$this->data['Shared'])) && $v['Shared'] == '1')
			{
				continue;
			}
			
			
			ksort($v);
	
			$this->printstart();
	
			foreach ($v as $record => $value)
			{
				// Convert to ISO-8859-1
				$h[$id][$record] = $value; //iconv('UTF-8', 'iso-8859-1', $value);
				
				// Convert the EntryID to our account 'mask'
				if ($record == 'EntryID' && $viewshared && !$this->data['global'])
				{
					$value = $this->view_entryidmap($v['id'], 'abook');
				}
				else if ($record == 'EntryID' && $viewshared && $this->data['global'])
				{
					$value = $this->view_entryidmap($v['id'], 'global');
				}
				/*elseif ($record == 'DateModified' && $viewshared && !$this->data['global'])
				{
					$value = $this->view_entryidmap($v['id'], 'abook', 1);
				}*/
				elseif ($record == 'DateModified' && $this->data['global'])
				{
					$value = "99999.99";
				}             
				
				if ($record == 'DateModified')
				{
					$value = $value - ($this->data['TimeZone'] / 1440.0);
				} 
				
				$h[$id][$record] = $this->myurlencode($value);
	
				if (strcmp($record, 'UserEmail') == 0)
				{
					$h[$id][$record] = trim( $h[$id][$record], "%0D" );
					$this->printstyle($record, $h[$id][$record]);
				}
				else if ($record != 'UserPhoto')
				{
					if ($record == 'EntryID')
					{
						$h[$id][$record] = strtoupper($value);
					}
					else
					{
						$h[$id][$record] = strtolower($value);
					}
					$this->printstyle($record, $h[$id][$record]);
				}
	
				if (strpos($record, 'User') === 0 && !preg_match('/UserDOB|UserPhoto|UserEmail4|UserEmail5|UserGender|UserInfo|UserPgpKey|UserWorkDept|UserWorkOffice|UserType|EntryID/', $record) || $record == 'DateModified')
				{
					$str = ($h[$id][$record])? strtolower($h[$id][$record]) : $this->myurlencode('(null)');
					$totalstr .= "$str";
				}
			}
			$count++;

			$this->printstyle('MD5', strtolower(md5($totalstr)) );
			$this->printstyle('MD5STR', $totalstr);
			$this->printeof();
		}
	
		if (!$count)
		{
			$this->printblank();
		}
	}
	
	function sync_viewcalnames()
	{
		$calendars = $this->calendar->getCalNames();
		$private_etag = 0;
		if(isset($_REQUEST['shared']) && $_REQUEST['shared'])
		{
			$private_etag = $this->calendar->getPrivateEtag();
		}
		
		$total_shown = 0;
		foreach ($calendars as $cal)
		{
			if(isset($_REQUEST['shared']) && $_REQUEST['shared'] && $cal['etag'] == $private_etag)
			{
				$printme = 0;
			}
			else
			{
				$printme = 1;
			}
			if($printme)
			{
				$this->printstart();
				$this->printstyle('calendar_owner', $cal['calendar_owner']);
				$this->printstyle('href', $cal['href']);
				$this->printstyle('relative_href', $cal['relative_href']);
				$this->printstyle('ctag', $cal['ctag']);
				$this->printstyle('displayname', $cal['displayname']);
				$this->printstyle('etag', $cal['etag']);
				$this->printstyle('description', $cal['description']);
				$this->printstyle('shared', $cal['shared']);
				$this->printeof();
				$total_shown ++;
			}
		}
	
		if(!$total_shown)
		{
			print "<BLANK>";
			return;
		}

		
	}
	
	//
	// Calendar Sync Functions
	//

	function sync_viewcalshared()
	{
		return $this->sync_viewcal(true);
	}

	
	function sync_viewcal($shared = false)
	{
		$var = $this->data;
		$calendar = $this->calendar;
		$h = $calendar->getRange('2004-01-01 00:00:00', '2014-01-01 00:00:00');
		$count = 0;

		$etag = $calendar->getPrivateEtag();
		
		foreach (array_keys($h) as $id)
		{
			$totalstr = '';
			
			if($this->data['Task'] != '1' && isset($h[$id]['Task']))
				continue;
				
			if(!isset($h[$id]['DateStart']))
			{
				$h[$id]['DateStart'] = '';
			}
			if(!isset($h[$id]['DateEnd']))
			{
				$h[$id]['DateEnd'] = '';
			}
			if(!isset($h[$id]['Shared']))
			{
				$h[$id]['Shared'] = '';
			}
	
			if (!$h[$id]['DateStart'] && $h[$id]['DateStartCal'] )
			{
				$h[$id]['DateStart'] = $h[$id]['DateStartCal'] . ' ' . $h[$id]['DateStartTime'];
			}
			if (!$h[$id]['DateEnd'] && $h[$id]['DateEndCal'] )
			{
				$h[$id]['DateEnd'] = $h[$id]['DateEndCal'] . ' ' . $h[$id]['DateEndTime'];
			}
	
			if (!$h[$id]['DateStart'] && $h[$id]['Task'] == '1')
			{
				$h[$id]['DateStart'] = '';
			}
			if (!$h[$id]['DateEnd'] && $h[$id]['Task'] == '1')
			{
				$h[$id]['DateEnd'] = '';
			}
	
			if (!$h[$id]['DateStart'] && !$h[$id]['Task'] == '1')
			{
				continue;
			}
			
		/*	if (($h[$id]['Shared'] && !$shared) || (!$h[$id]['Shared'] && $shared))
			{
				continue;
			}
			
			if(!$shared && $h[$id]['calendar_owner'] != $this->username)
			{
				continue;
			}
			else if ($shared )*/
			
			if($shared && $etag == $h[$id]['etag'])
				continue;
			if(!$shared && $etag != $h[$id]['etag'])
				continue;
				

			if(!isset($h[$id]['Task']))
			{
				$h[$id]['Task'] = '0';
			}
			if($this->data['Task'] != '1')
			{
				if($h[$id]['Task'] == '1')
				{
					continue;	
				}
			}
			if($this->data['Task'] == '1')
			{
				if($h[$id]['Task'] == '0')
				{
					continue;	
				}
			}
			
			$count++;
	
			ksort($h[$id]);
			// entry id support for caldav server
			$xData = $this->calendar->get_extended_data($h[$id]['id']);
			if(isset($xData['EntryID']))
			{
				$h[$id]['EntryID'] = $xData['EntryID'];
			}
			else
			{
				$h[$id]['EntryID'] = '';
			}
						
			if(!isset($h[$id]['EntryID']))
			{
				$h[$id]['EntryID'] = '';
			}
	
			if(isset($h[$id]['Task']) && $h[$id]['Task'] == '1')
			{
				$h[$id]['CalMessage'] = '';
			}
						
			foreach (array_keys($h[$id]) as $record)
			{
				// Covnert to ISO-8859-1
				$h[$id][$record] = $h[$id][$record]; //iconv('UTF-8', 'iso-8859-1', $h[$id][$record]);
	
				// Convert the EntryID to our account 'mask'
				if ($record == 'EntryID' && $shared)
				{
					$h[$id]['EntryID'] = $this->view_entryidmap($h[$id]['id'], 'cal');
					if($h[$id]['EntryID'] == '')
					{
						$temp = $this->calendar->get_extended_data($h[$id]['id']);
						$h[$id]['EntryID'] = $temp['EntryID'];
					}
				}
				/*elseif ($record == 'DateModified' && $shared)
				{
					$h[$id]['DateModified'] = $this->view_entryidmap($h[$id]['id'], 'cal', 1);
				}*/
				
				if ($record == 'DateStart' || $record == 'DateEnd' || $record == 'DateModified')
				{
					$h[$id][$record] = $this->calendar->convert_to_outlook_date($h[$id][$record]);
				}
				if (($record == 'DateStart' || $record == 'DateEnd') && $this->data['Task'])
				{
					$h[$id][$record] = preg_replace('/\..*/', '.000000', $h[$id][$record]);
				}
							
	//			$h[$id][$record] = myurlencode($h[$id][$record]);
				if ($record == "relative_href" || ( ($record == 'ctag' || $record == "etag") && $shared ) || $record == "calendar_owner" || $record == "Availability" || $record == 'Title' || $record == 'CalMessage' || $record == 'DateStart' || $record == 'DateEnd' || $record == 'Type' || $record == 'Task' || $record == 'EntryID' || $record == 'id' || $record == 'DateModified' || $record == 'Permissions' || $record == 'Location' || $record == 'AllDayEvent' || $record == "IsRecurring" || $record == 'DateAlertPeriod')
				{
				
					// If Type, set in the Outlook version, Complete = 2 , otherwise = 0
					if ($record == 'Type' && $this->data['Task'])
					{
						if ($h[$id][$record] == 'Complete')
						{
								$h[$id][$record] = 2;
						}
						else
						{
							$h[$id][$record] = 0;
						}
						$str = $h[$id][$record];	// Correctly append the string to the end of the MD5 and checksum
					}
					elseif( $record == 'Type' && !$this->data['Task'])
					{
						$str = '';
					}
					elseif ($record == 'AllDayEvent')
					{
						$str = ($h[$id][$record])? strtolower($h[$id][$record]) : 0;
					}
					else
					{
						$str = ($h[$id][$record])? strtolower($h[$id][$record]) : $this->myurlencode('(null)');
					}
	
					if($record == "DateModified")
					{
						// apply timezone offset
						$h[$id][$record] = $h[$id][$record] - ($this->data['TimeZone'] / 1440.0);
					}				
	
					if ($str == '25570.000000')
					{
						$h[$id][$record] = '949998.000000';
						$str = $h[$id][$record];
					}

					if (preg_match('/Availability|CalMessage|DateStart|DateEnd|Title|EntryID|DateModified|Type|Location|AllDayEvent|IsRecurring|DateAlertPeriod/', $record))
					{
						if ($record == 'Type' && !$this->data['Task'])
						{
							continue;
						}
					
						$totalstr .= $str;
					}
					print "$record = " . $h[$id][$record] . "\n";
				}
	
			}
			
			// If the event is recurring, we need more fields listed
			if($h[$id]['IsRecurring'])
			{
				$var['recurrencePattern']	= $h[$id]['recurrencePattern'];
				$var['recurrenceTime']		= $h[$id]['recurrenceTime'];
				
				// Add the MD5 if the recurrence changes $totalstr .= 
				strtolower(myurlencode($var['recurrencePattern'])); 
				$totalstr .= 
				strtolower(myurlencode($var['recurrenceTime']));
				
				echo "recurrencePattern = " . $var['recurrencePattern'] . "\n";
				echo "recurrenceTime = " . $var['recurrenceTime'] . "\n";
			}
			print 'MD5 = ' . strtolower(md5($totalstr)) . "\n";
			print "MD5STR = $totalstr\n";
			print "\n<br>\n";
		}
	
		if (!$count)
		{
			print "<BLANK>\n";
		}
	}
		
	// Add a new record to the addressbook
	function sync_addcal()
	{
		$var = $this->data;
		$href = $this->username . "/calendar/";
		if( isset($_REQUEST['Shared']) && $_REQUEST['Shared'] && $this->shared_enabled )
		{
			// The owner has default read/write access
			$names = $this->calendar->getCalNames();
			foreach($names as $name)
			{
				if($name['relative_href'] == str_replace('@', "%40", $_REQUEST['href']))
				{
					$href = $name['relative_href'];
				}
			}

		}
		$new_record = $this->calendar->add_record(	
					$var['Task'], 
					$this->username,
					$this->username, 
					$var['Title'], 
					$var['CalMessage'], 
					$var['Importance'], 
					$var['Type'], 
					$var['Alert'], 
					$var['DateStart'], 
					$var['DateEnd'], 
					(isset($var['Parent'])?$var['Parent']:''), 
					$var['ReadSelectedUsers'], 
					$var['WriteSelectedUsers'], 
					$var['WriteSelectedGroups'], 
					$var['ReadSelectedGroups'], 
					$var['Location'], 
					$var['AllDayEvent'], 
					(isset($var['Permission'])?$var['Permission']:''),
					$href
			);
			
		$this->calendar->put_extended_data($new_record[0], 'EntryID', $var['EntryID']);

		print("<OK>\n");
	}
	
	function sync_deletecal()
	{	
		$var = $this->data;
		$href = $this->username . "/calendar/";
		if (isset($_REQUEST['shared']) && $_REQUEST['Shared'] && $this->shared_enabled )
		{
			// The owner has default read/write access
			$names = $this->calendar->getCalNames();
			foreach($names as $name)
			{
				if($name['relative_href'] == str_replace('@', "%40", $_REQUEST['href']))
				{
					$href = $name['relative_href'];
				}
			}

		}
	
		// Sanity check, do not delete if shared disabled
		if (!$this->shared_enabled && $var['Shared'] )
			httpend();
		
		$this->calendar->delete_record($var['id'], $var['Shared'], $href);
		$this->calendar->delete_extended_data($var['id']);
		
		print ("<OK>\n");
	}
	
	function sync_updatecal()
	{
		$var = $this->data;
		if (isset($_REQUEST['updateall']) && $_REQUEST['updateall'])
		{
			//echo "RECUR = ". $var['recurrencePattern'];
			// We are updating the entry calendar entry
			$this->calendar->update_record(	$this->username, 
							$this->username, 
							$var['Title'], 
							$var['DateStart'], 
							$var['DateEnd'],
							$var['id'], 
							$var['Shared'], 
							$var['CalMessage'], 
							$var['Location'], 
							$var['Type']? $var['Type'] : 'General', 
							$var['Task'], 
							$this->calendar->convert_from_outlook_date($var['DateModified']),
							$this->data['TimeZone'] / 60.0
							,0,0,0,0);
							
			// Update recurrence pattern if required
			/*if($var['IsRecurring'] == '1')	{
				$cal->addrecurrence($user);			
			}*/
		}
		elseif (isset($_REQUEST['EntryID']) && $_REQUEST['EntryID'] && isset($_REQUEST['Shared']) && $_REQUEST['Shared'] && $this->shared_enabled )
		{
			$this->calendar->put_extended_data($var['id'], 'EntryID', $var['EntryID']);
			$this->add_entryidmap($var['EntryID'], $var['id'], 'cal');
		}
		elseif (isset($_REQUEST['EntryID']) && $_REQUEST['EntryID'])
		{
			$this->calendar->put_extended_data($var['id'], 'EntryID', $var['EntryID']);
		}
		//elseif ($this->data['DateModified'] && $this->data['Shared'] && $this->shared_enabled )
//		{
//			$this->add_entryidmap('', $var['id'], 'cal', $var['DateModified']);
//		}
		elseif(isset($_REQUEST['DateModified']) && $_REQUEST['DateModified'])
		{
			// bump the modification date
			$this->calendar->update_record(
			null, 
			null,
			null, 
			null, 
			null, 
			$var['id'], 
			$var['Shared'], 
			null, 
			null, 
			null, 
			0, 
			$this->convert_from_outlook_date($_REQUEST['DateModified']), 
			$_REQUEST['TimeZone'] / 60.0
			,0,0,0,0);
		}
		
		print "<OK>\n";
	}
	
	// Function to return an ID, from the EntryID ( Calendar )
	function sync_entryidtowebid()
	{
		// TODO : add entryid support for calendar
	}
}

