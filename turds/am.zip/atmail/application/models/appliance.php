<?php
 /**
 * @category   Atmail
 * @package    appliance model
 * @author     Ben Duncan
 * @license    Copyrighted by Atmail 2009-2010
 */

class appliance
{
	/*
	Load the system IP, hostname and network configuration directly. Don't trust the vales in the Config
	array/DB, just in case an admin has changed the settings via the terminal/SSH
	*/
	public static function loadNetworkSettings($array)
	{
	
	// Find current IP's
	$eth0 = `/sbin/ifconfig eth0`;
	if (preg_match('/inet addr:(.*?) /', $eth0, $m))
        $array['ipeth0'] = $m[1];

	if (preg_match('/Mask:(.*)/', $eth0, $m))
        $array['networketh0'] = $m[1];

	$eth1 = `/sbin/ifconfig eth1`;
	if (preg_match('/inet addr:(.*?) /', $eth1, $m))
        $array['ipeth1'] = $m[1];

	if (preg_match('/Mask:(.*)/', $eth1, $m))
        $array['networketh1'] = $m[1];

	// Find the default route
	$droute = `/bin/netstat -nr`;

	if (preg_match('/^0\.0\.0\.0\s+(.*?)\s.*?eth0/m', $droute, $m))	{
        $array['defaultgatewayeth0'] = $m[1];
	}

	if (preg_match('/^0\.0\.0\.0\s+(.*?)\s.*?eth1/m', $droute, $m)) {
        $array['defaultgatewayeth1'] = $m[1];
	}

	// Find the default nameserver
	if ($fh = fopen('/etc/resolv.conf', 'r')) {

		$nameservers = array();

    	while(false !== $line = fgets($fh))	{
            $line = trim($line);
    		if (preg_match('/nameserver (.*)/', $line, $m)) {		
				array_push($nameservers, $m[1]);
    		}
    	}

		$array['nameserver1'] = $nameservers[0];
		
		if(isset($nameservers[1]))
		$array['nameserver2'] = $nameservers[1];

		if(isset($nameservers[2]))
		$array['nameserver3'] = $nameservers[2];

    	fclose($fh);
	} else {
	    print "Cannot open /etc/resolv.conf\n";
	}

	$array['ipconfeth0'] = '';
	$array['ipconfeth1'] = '';
	
	// Check if a device is DHCP
	if ($fh = fopen('/etc/sysconfig/network-scripts/ifcfg-eth0', 'r')) {
    	while (false !== $line = fgets($fh))	{
    	   if (strpos(strtoupper($line), 'BOOTPROTO=DHCP') !== false) {
    	       $array['ipconfeth0'] = 'DHCP';
    	       break;
    	   }
    	}

    	fclose($fh);
	}

	if ($fh = fopen('/etc/sysconfig/network-scripts/ifcfg-eth1', 'r')) {
    	while (false !== $line = fgets($fh)) {
            if (strpos(strtoupper($line), 'BOOTPROTO=DHCP') !== false) {
                $array['ipconfeth1'] = 'DHCP';
                break;
            }
    	}

    	fclose($fh);
	}

	// Find the servers hostname
	$array['hostname'] = trim(`/bin/hostname`);	
	return $array;
}

	/* Restart the network services using the setuid root script */
	public static function restartNetworkSettings()
	{
	
		system('/usr/local/atmail/mailserver/bin/atmail-restart-network > /dev/null 2>&1');
    	
		return;
		
	}
	
	public static function saveNetworkSettings($array)
	{
		$config = '';
		
		// Save the settings
		if ($array['save'])	{

			system('/bin/hostname ' . escapeshellarg($array['hostname']));
			//$pref['hostname'] = $var['hostname'];
			//writeconf();

			// Write the /etc/init.d/network with the new hostname
			if (!$read = @fopen("/etc/sysconfig/network", 'r'))
	            catcherror("Cannot read /etc/init.d/network");

	        while(!feof($read))
	        {
	            $line = fgets($read);
				$line = preg_replace('/HOSTNAME=.*/', "HOSTNAME={$array['hostname']}", $line);
				$config .= $line;
			}

	        fclose($read);

	        if (!$write = @fopen("/etc/sysconfig/network", 'w'))
	            catcherror("Cannot write /etc/sysconfig/network");

	        fwrite($write, $config);
	        fclose($write);

	    	foreach(array('eth0', 'eth1') as $int) {

	    		// If we are DHCP
	    		if ( $array["ipconf$int"] == 'DHCP' )	{
	                if ($fh = fopen("/etc/sysconfig/network-scripts/ifcfg-$int", 'w')) {
	                    fwrite($fh, "BOOTPROTO=dhcp\nTYPE=Ethernet\nDEVICE=$int\nONBOOT=yes\n");
	                    fclose($fh);
	                } else {
	                    print "Cannot write: /etc/sysconfig/network-scripts/ifcfg-$int\n";
	                }

	    		} else	{
	        		// Manually configure interface
	                if ($fh = fopen("/etc/sysconfig/network-scripts/ifcfg-$int", 'w')) {
	                    fwrite($fh, "BOOTPROTO=none\nTYPE=Ethernet\nDEVICE=$int\nNETMASK=" . $array["network$int"] . "\nIPADDR=" . $array["ip$int"] . "\nGATEWAY=" . $array["defaultgateway$int"] . "\nONBOOT=yes\n");
	                    fclose($fh);
	                } else {
	                    print "Cannot write: /etc/sysconfig/network-scripts/ifcfg-$int\n";
	                }
	    		}
	    	}

	        // Change the nameservers
	        if ($fh = fopen("/etc/resolv.conf", 'w')) {
	            if ($array['nameserver1'])
	                fwrite($fh, "nameserver {$array['nameserver1']}\n");
	            if ($array['nameserver2'])
	                fwrite($fh, "nameserver {$array['nameserver2']}\n");
	            if ($array['nameserver3'])
	                fwrite($fh, "nameserver {$array['nameserver3']}\n");

	            fclose($fh);
	        } else {
	            print "Cannot write /etc/resolv.conf\n";
	        }

			// Sleep after config write, ifconfig/hostname seem to have a lag
	        sleep(2);
	    }

	}                                               

}