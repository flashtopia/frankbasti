<?php
//CONSIDER: revise message view to enable viewing messge id linked to folder, compound key to guarantee found
class Mail_MailController extends Atmail_Controller_Action
{
	public function init()
	{
		parent::init();
		$contextSwitch = $this->_helper->getHelper('contextSwitch');
		$contextSwitch->addActionContext('index', 'xml')->addActionContext('read', 'xml')->initContext();
	}

	public function preDispatch()
	{
		//make debugging available in this context - can be safely left on because debugging is disabled if no debug flag set in Config
		$this->log = Zend_Registry::get('log');
		
		// Setup filters
		$this->filter = Atmail_Filter_Input_Controller::filterInput($this->_request);

		// Had to move this here to enable unit testing to work
		require_once 'library/jQuery/jQuery.php';
		$this->view->jsonIdsToRender = array();

		// simple Access Control, user has to be logged in to access any of these actions
		if( !Atmail_FormAuth::authenticated() )
		{
			$this->_forward('index', 'auth'); 
			return;		
		}
		else
		{
			$this->view->requestParams = $this->_request->getParams();

			$this->view->setEncoding('UTF-8');
			$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
			$this->view->appBaseUrl = $this->_request->getBaseUrl() . (strpos($this->_request->getBaseUrl(),'index.php')?'':'/index.php');
			$this->view->moduleBaseUrl = $this->view->appBaseUrl . ($this->view->requestParams['module']=='default'?'':DIRECTORY_SEPARATOR . $this->view->requestParams['module']);
			$this->view->thisActionURL = $this->view->moduleBaseUrl . '/' . $this->view->requestParams['controller'] . '/' . $this->view->requestParams['action'];
			$this->view->notices = array();
			$this->view->errors = array();
			$this->session = new Zend_Session_Namespace('defaultNamespace');
			$this->userData = Zend_Auth::getInstance()->getStorage()->read();
			
			$this->view->account = $this->userData['Account']; // Used in the HTML template for the logged in user
			$this->_globalConfig = Zend_Registry::get('config')->global;
			$this->view->UserSettings = Zend_Registry::get('UserSettings');
            $this->view->company_url = $this->_globalConfig['company_url'];
            $this->view->brandname = $this->_globalConfig['brandname'];
            if($this->view->company_url == NULL || empty($this->view->company_url))
            {
            	$this->view->company_url = $this->siteBaseUrl;
            }
            
			//handle folder change requests here (allowing change from all actions/events) so that correct cache can be loaded (correct folder)
			$this->_currentConfig = array();

			if( isset($this->view->requestParams['refresh']) )
			{
				$this->_currentConfig['cacheRefresh'] = $this->view->requestParams['refresh'];
			}

			if( isset($this->view->requestParams['selectFolder']) && $this->view->requestParams['selectFolder'] != 'undefined' )
			{
				$selectFolder = urldecode($this->view->requestParams['selectFolder']);
				$this->_currentConfig['folder'] = $selectFolder;
				if( isset($this->session->pageNumber) )
				{
					$this->session->pageNumber = 1;
				}
			}

			//set up mail store config to connect directly to correct folder if about to exec a move action
			if( isset($this->view->requestParams['fromFolder']) )
			{
				$fromFolder = urldecode($this->view->requestParams['fromFolder']);
				$this->_currentConfig['folder'] = $fromFolder;
				if( isset($this->session->pageNumber) )
				{
					$this->session->pageNumber = 1;
				}
			}

			$this->_mailStoreConfig = array_merge($this->_globalConfig, $this->userData, $this->_currentConfig, $this->view->UserSettings);
			if( isset($this->view->UserSettings['ThreadLimit']) )
			{
				
				$this->_mailStoreConfig['threadsLimitMonths'] = $this->view->UserSettings['ThreadLimit'];
				
			}
			
			//check if SSL enabled in UserSettings
			$this->_mailStoreConfig['ssl'] = ($this->_mailStoreConfig['UseSSL']=='1'?'SSL':'');
			  
			$this->AtmailMailStorage = Atmail_Mail_Storage::getInstance($this->_mailStoreConfig);
			$this->AtmailMailStorageMain = &$this->AtmailMailStorage->getMailStore($this->_mailStoreConfig['namespaceName']);

			if( isset($this->_globalConfig['cacheEnabled']) && $this->_globalConfig['cacheEnabled'] )
			{
				//Cache enabled. This hits data source is $this->AtmailMailStorageMain->dataSource
				if( $this->AtmailMailStorageMain->dataSource == 'cached' )
				{
					// test cache time passed
					if( (time() - $this->AtmailMailStorageMain->updateCacheStamp) > 60 )
					{
						// too old, update
						$this->AtmailMailStorageMain->updateCache();
					}
				} 
				elseif( isset($this->_mailStoreConfig['cacheRefresh']) && $this->_mailStoreConfig['cacheRefresh'] == true )
				{
					// refresh required
					$this->AtmailMailStorageMain->updateCache();
				}
			} 
			elseif( !isset($this->_globalConfig['cacheEnabled']) || $this->_globalConfig['cacheEnabled'] == false )
			{
				// Cache disabled so instance was created new from scratch
			}
			
			$this->AtmailMailStorageMain->setThreadsEnabled( $this->view->UserSettings['ViewThreads'] ); //will still be forced to false if !supported
			
		}
	}

	public function postDispatch()
	{
		if(isset($this->_mailStoreConfig['cacheEnabled']) && $this->_mailStoreConfig['cacheEnabled'] )
		{
			$this->AtmailMailStorageMain->saveCache();
		}
	}

	public function indexAction()
	{
		
		$requestParams = $this->getRequest()->getParams();
		
		if( isset($requestParams['testing']) )
			$this->view->testing = true;
		
		$this->view->currentFolder = $this->AtmailMailStorageMain->getCurrentFolder();
		$this->view->foldersObject = $this->AtmailMailStorageMain->getFolders();
		$this->view->folders = new RecursiveIteratorIterator($this->view->foldersObject, RecursiveIteratorIterator::SELF_FIRST);
		
		// convert recursiveIteratorIterator to array
		// as natcasesort expects them
		if($this->view->folders)
		{
			$flat = array();
			foreach($this->view->folders as $key=>$value)
			{
				if(!is_array($value))
				{
					$flat[$key] = (string)$value;
	            }
    	    }
    	}
       
        $this->view->folders = $flat;
		natcasesort($this->view->folders);

		$this->view->mainFolders = array();
		$this->view->mainFolders['Inbox'] = $this->AtmailMailStorageMain->getMainFolderName();
		$this->view->mainFolders['Drafts'] = $this->AtmailMailStorageMain->getMainFolderName('Drafts');
		$this->view->mainFolders['Sent'] = $this->AtmailMailStorageMain->getMainFolderName('Sent');
		$this->view->mainFolders['Spam'] = $this->AtmailMailStorageMain->getMainFolderName('Spam');
        $this->view->mainFolders['Trash'] = $this->AtmailMailStorageMain->getMainFolderName('Trash');
		
		switch($this->view->UserSettings['DefaultView'])
		{
			case "2p" :
				$this->session->listViewType = 'twoPane'; // other available view is compact
			break;
			case "3p" :
				$this->session->listViewType = 'compact'; // other available view is compact
			break;
			default:
				$this->session->listViewType = 'compact'; // other available view is twoPane
		}
		
		//TODO: if not in session dather default to user custom config

		$this->view->listViewType = $this->session->listViewType;
		$this->view->AtmailMailStorageMain = $this->AtmailMailStorageMain;
		// Return our base folders
		//change back to current folder
		$this->AtmailMailStorageMain->selectFolder($this->view->currentFolder);

		$user = users::get($this->userData['Account']);

		try
		{
			$this->view->group = groups::get( $user['Ugroup'] );
			if($this->view->group == false)
			{
				$this->view->group = groups::get( 'default' );
			}
		}
		catch( exception $e )
		{
			$this->view->group = groups::get( 'default' );			
		}
	}

	/**
	*   expects to get an ajax request for data on folder info
	*   @return JSON
	*/
	public function updatefoldertotalsAction()
	{
		
		//calculate folder message totals
		$folderTotals = array();
		$folders = new RecursiveIteratorIterator($this->AtmailMailStorageMain->getFolders(), RecursiveIteratorIterator::SELF_FIRST);
		
		//special ids for reserved folders
		$reservedFoldernamesGlobal = array();
		$reservedFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName('Inbox');
		$reservedFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName('Sent');
		$reservedFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName('Trash');
		$reservedFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName('Drafts');
		$reservedFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName('Spam');
                
		foreach( $folders as $localName => $folder )
		{
			
			//if folder not countable (corrupted etc. then flag as such but continue)
			try
			{
				// TODO: Count *UNREAD* messages
				//'name' => $folder->getGlobalName(), //not needed, causes confusion and corruption of ajax response
				
				
				if( in_array($folder->getGlobalName(), $reservedFoldernamesGlobal) )
				{
					
					$id = 'folder_' . strtolower($localName); //for CSS icons
					
				}
				else
				{
					
					$id = 'folder_' . safeId($folder->getGlobalName());
					
				}
				
				$folderTotals[] = array(
						//'name' => $folder->getGlobalName(), //not needed, causes confusion and corruption of ajax response
						'info' => array('unseen' => $this->AtmailMailStorageMain->countUnseenMessages($folder->getGlobalName())),
						'id' => $id 
				);
			}
			catch ( Exception $e )
			{
				// silent fail
			}
			
		}
		
		// we output directly here!
		echo Zend_Json::encode($folderTotals);
		$this->_helper->viewRenderer->setNoRender();
		
		return;

	}

	public function listfoldermessagesAction() 
	{

		$requestParams = $this->_request->getParams();

		$threadsEnabled = $this->AtmailMailStorageMain->getThreadsEnabled();
		
		//fork here to prep for searching folder instead of just listing
		$this->view->searching = false;
		$resultContext = 'messageList';
		if( isset($requestParams['searching']) && $requestParams['searching'] == 'true' )
		{
			
			$this->view->searching = true;
			$resultContext = $requestParams['resultContext'];
			$this->view->searchQueryUTF8 = urldecode( urldecode( $this->view->requestParams['searchQuery'] ) );
			
		}

		$this->view->resultContext = $resultContext;
			
		if( isset($requestParams['listViewType']) )
		{
			$this->session->listViewType = $requestParams['listViewType'];
		}
		
		// Reset sort order, third click
		if( isset($requestParams['nosort']) )
		{
			$this->session->order = '';
			$this->session->sort = '';
		}

		//handle page changes
		$this->session->pageVolume = $this->view->UserSettings['MsgNum'];

		if( !isset($this->session->pageNumber) )
		{
			$this->session->pageNumber = 1;
		}

		if( !isset($this->session->sort) )
		{
			$this->session->sort = 'UID';
		}
		
		if( !isset($this->session->order) )
		{
			$this->session->order = 'REVERSE';
		}
		
		if( isset($requestParams['page']) )
		{
			$this->session->pageNumber = $requestParams['page'];
		}
		
		if( isset($requestParams['quantity']) )
		{
			$this->session->pageVolume = $requestParams['quantity'];
		}
		
		if( isset($requestParams['sort']) )
		{
			$this->session->sort = $requestParams['sort'];
			$this->session->pageNumber = 1;
		}

		if( isset($requestParams['order']) )
		{
			$this->session->order = $requestParams['order'];
		}
		
		//flip sorting on from to sorting on to if browsing a sent folder
		if( $this->session->sort == 'from' && strtolower($this->AtmailMailStorageMain->getCurrentFolder()) == strtolower($this->AtmailMailStorageMain->getMainFolderName('Sent')) )
			$this->session->sort = 'to';
		
		$this->AtmailMailStorageMain->setSortAndOrder($this->session->sort,$this->session->order);
		$this->view->AtmailMailStorageMain = $this->AtmailMailStorageMain;
		
		$this->view->pageVolume = $this->session->pageVolume;
		$this->view->pageNumber = $this->session->pageNumber;
		$this->view->sort = $this->session->sort;
		$this->view->order = $this->session->order;
		$this->view->listViewType = $this->session->listViewType;
		$this->view->currentFolder = $this->AtmailMailStorageMain->getCurrentFolder();
		
		//calling getFolderInfo() will set threadsEnabled
		$currentFolderInfo = $this->AtmailMailStorageMain->getFolderInfo(); 
		
		//disable threads for drafts and sent folders
		if( 
			$this->view->currentFolder == $this->AtmailMailStorageMain->getMainFolderName('Sent') || 
			$this->view->currentFolder == $this->AtmailMailStorageMain->getMainFolderName('Drafts') 
		)
			$this->AtmailMailStorageMain->setThreadsEnabled(false);
		
		$currentFolderObject = $this->AtmailMailStorageMain->getCurrentFolderObject(); 
		
		$this->view->currentFolderLocalNameUTF8 = $this->AtmailMailStorageMain->decodeUTF7( $currentFolderObject->getLocalName() );
        
		if( isset($requestParams['sort']) && !in_array('SORT', $this->AtmailMailStorageMain->getCapability() ) )
			jQuery::addMessage('Remote mail server does not support sorting, ordered by id');
		elseif( isset($requestParams['sort']) && $this->AtmailMailStorageMain->countTotalThreadMessages() > $this->AtmailMailStorageMain->getSortMaxLimit() )
			jQuery::addMessage('Sorting disabled, too many messages, ordered by id');
		elseif( !$threadsEnabled &&  isset($requestParams['sort']) && $this->AtmailMailStorageMain->countTotalMessages() > $this->AtmailMailStorageMain->getSortMaxLimit() )
			jQuery::addMessage('Sorting disabled, too many messages, ordered by id');
		
		$this->view->threadsEnabled = $this->AtmailMailStorageMain->getThreadsEnabled();
		        
		$this->view->currentFolderURLEncoded = urlencode($this->view->currentFolder);
		$this->view->currentFolderDoubleURLEncoded = urlencode($this->view->currentFolderURLEncoded);
		
		
		//special ids for reserved folders
		$reservedFoldernamesGlobal = array();
		$reservedFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName();
		$reservedFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName('Sent');
		$reservedFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName('Trash');
		$reservedFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName('Drafts');
		$reservedFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName('Spam');
                
		if( in_array($this->view->currentFolder, $reservedFoldernamesGlobal) )
		{
				
			$folderObj = $this->AtmailMailStorageMain->getCurrentFolderObject($this->view->currentFolder);
			$localName = $folderObj->getLocalName();
			$id = 'folder_' . strtolower( $localName );
			
		}
		else
		{
				
			$id = 'folder_' . safeId($this->view->currentFolder);
		
		}
		
		$current_backend_quota = $this->AtmailMailStorageMain->getquota();
		jQuery::evalScript("quota = [" . $current_backend_quota[0] . ', ' . $current_backend_quota[1] . "];");
				
		//update current folder item in folder list with latest total
		jQuery('#Email div#' . $id . ' .unread:first strong:first')->updateTotal( $this->AtmailMailStorageMain->countUnseenMessages() );
		

		//this message prep section should move out of view layer and into controller layer
		if( $this->view->searching )
		{
			
			//try split the query by tokens else search to, from, subject.
			$tokensPos = array(
				'from:'    => array('start' => -1, 'end' => -1, 'value' => null),
				'to:'      => array('start' => -1, 'end' => -1, 'value' => null),
				'subject:' => array('start' => -1, 'end' => -1, 'value' => null),
				'body:'    => array('start' => -1, 'end' => -1, 'value' => null),
				'text:'    => array('start' => -1, 'end' => -1, 'value' => null)
			);

			$this->view->searchQueryUTF8 = strtolower($this->view->searchQueryUTF8);			
			foreach( $tokensPos as $token => $pos )
			{
				if( ($pos = mb_strpos($this->view->searchQueryUTF8, $token, 0, 'UTF-8')) !== false )
				{
					$tokensPos[$token]['start'] = $pos;	
				}	
			}
			
			//if the lowest pos > -1 is not 0 then we have non token search as well
			$strlenSearch = mb_strlen($this->view->searchQueryUTF8);
			
			//now go through each one and build up the boundaries, trim and apply as a search term
			$lowestTokenStart = $strlenSearch;
			foreach( $tokensPos as $token => $vector )
			{
				
				$vector['end'] = $strlenSearch;
				//got start now find end
				foreach( $tokensPos as $testToken => $testVector)
				{
					
					//if tested token is after current token and is shorter than current length then switch 
					//(making sleection shorter and shorter intil we have just the one token)
					if( $testVector['start'] > $vector['start'] && $testVector['start'] < $vector['end'] )
					{
						
						$vector['end'] = $testVector['start'];
						
					}
					
				}
				
				//push start forward the length of the token and save $pos back into array
				if( $vector['start'] >= 0 && $vector['end'] >= 0 )
				{
					$vector['value'] = trim(mb_substr($this->view->searchQueryUTF8, $vector['start']+mb_strlen($token), $vector['end']-($vector['start']+mb_strlen($token))));
				}
				$tokensPos[$token] = $vector;
				
				//update lowestPos to try find if untokenised string present.
				if( $vector['start'] >= 0 && $vector['start'] < $lowestTokenStart )
				{
					
					$lowestTokenStart = $vector['start'];
					//Zend_Registry::get('log')->debug( "\n" . print_r($lowestTokenStart, true) . "\n" . __METHOD__ . ' #' . __LINE__ . ": \$lowestTokenStart \n");
					
				}
				
			}
			
			                                 
			//Zend_Registry::get('log')->debug( "\n" . print_r($tokensPos, true) . "\n" . __METHOD__ . ' #' . __LINE__ . ": \$tokensPos \n");
			$preparedSearchQuery = array();
			$tokensFoundInSearchString = false;
			foreach( $tokensPos as $token => $vector )
			{
				
				if( $vector['value'] != null )
				{
					$tokensFoundInSearchString = true;
					$searchKey = mb_substr($token,0,-1);
					$words = mb_split("[ ]+", $vector['value'] );

					foreach($words as $word)
						$preparedSearchQuery[] = array('field' => $searchKey, 'value' => $word);
					
				}
				
			}
			if( $tokensFoundInSearchString == false )
			{
				
				$words = mb_split("[ ]+", $this->view->searchQueryUTF8 );
                foreach($words as $word)
					$preparedSearchQuery[] = array('raw' => 'OR FROM "' . $word . '" OR TO "' . $word . '" SUBJECT "' . $word . '"');
				
			}
			else
			{
				
				//if tokens found and lowestTokenPos != 0 then add a raw string as well
				//if lowestPos > 0, then raw string between 0 and lowestToken
				if( $lowestTokenStart != 0 )
				{
					
					$words = mb_split("[ ]+", trim(mb_substr($this->view->searchQueryUTF8, 0, $lowestTokenStart)) );
					
					foreach($words as $word)
						$preparedSearchQuery[] = array('raw' => 'OR FROM "' . $word . '" OR TO "' . $word . '" SUBJECT "' . $word . '"');
					
				}
				
			}
			$searchResults = $this->view->AtmailMailStorageMain->search($preparedSearchQuery);
			$this->view->messages = $this->view->AtmailMailStorageMain->getBasicHeadersPage($this->view->pageNumber, $this->view->pageVolume);
			$this->view->totalMessages = count($searchResults);
			$this->view->AtmailMailStorageMain->setThreadsEnabled( false );
			$this->view->threadsEnabled = $this->view->AtmailMailStorageMain->getThreadsEnabled();
			
		}
		elseif( $this->view->threadsEnabled ) 
		{
		
			$this->view->messages = $this->view->AtmailMailStorageMain->getThreadsBasicHeadersPage($this->view->pageNumber, $this->view->pageVolume);
			$this->view->totalMessages = $this->view->AtmailMailStorageMain->countTotalThreadMessages();
			
		}
		else
		{
		
			$this->view->messages = $this->view->AtmailMailStorageMain->getBasicHeadersPage($this->view->pageNumber, $this->view->pageVolume);
			$this->view->totalMessages = $this->view->AtmailMailStorageMain->countTotalMessages();
		
		}
		
		if($this->session->listViewType == 'compact')
			$this->view->jsonIdsToRender[$resultContext] = 'mail/indexlistmessagescompact.phtml';
		else
			$this->view->jsonIdsToRender[$resultContext] = 'mail/indexlistmessages.phtml';

		jQuery::evalScript("$('#action_get_mail a').enableActionSimpler()");

		//$timeDelta = microtime(true);
		$this->render('global/jsonresponse', null, true);
		/*
		//$timeDelta = microtime(true);
		Zend_Registry::get('log')->debug("called renderlist: " . round((microtime(true)-$timeDelta)*1000,1) . " milliseconds. highest=" . $this->higestDelta);
		if( (microtime(true)-$timeDelta)*1000 > $this->higestDelta )
		{
		
			$this->higestDelta = round((microtime(true)-$timeDelta)*1000,1);
			
		}
		*/
		
	}
	
	public function foldercreateAction()
	{
		
		$requestParams = $this->_request->getParams();
		if( !isset($requestParams['folderNameNew']) )
		{

			throw new Atmail_Mail_Exception('Compulsory argument folderNameNew not present');

		}
		
		//if main folder force to root folder (physically in INBOX. (main namespace root), but logically (according to UI) appears as a root folder)
		//special ids for reserved folders
		$mainFoldernamesGlobal = array();
		$mainFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName();
		$mainFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName('Sent');
		$mainFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName('Trash');
		$mainFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName('Drafts');
		$mainFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName('Spam');
        
		$currentFolder = $this->AtmailMailStorageMain->getCurrentFolder();
		
		if( in_array($currentFolder, $mainFoldernamesGlobal) || (isset($requestParams['makeRootFolder']) && $requestParams['makeRootFolder'] == true) )
		{
				
			$currentFolder = $this->AtmailMailStorageMain->getFolderNamespaceDefault();
			
		}
		
		$folderNameNewAsOrigionallySuppliedFromJsEncoding = $requestParams['folderNameNew'];
		$folderNameNew = urldecode( $requestParams['folderNameNew'] );
		$folderNameNewUrlencodedDouble = urlencode( urlencode( $folderNameNew ) );
		$folderNameNewUTF7 = $this->AtmailMailStorageMain->encodeUTF7( $folderNameNew );
        $folderNameGlobalOrigional = urlencode($folderNameNewAsOrigionallySuppliedFromJsEncoding);
			
		try
		{
			
			$folderNameGlobalUTF7 = $this->AtmailMailStorageMain->createFolder( $folderNameNewUTF7, $currentFolder );
			
			$folderNameGlobalUTF7UrlencodedDouble = urlencode( urlencode( $folderNameGlobalUTF7 ) );
            if( strrpos( $folderNameGlobalUTF7, $this->AtmailMailStorageMain->getFolderDelimiterDefault() ) !== false )
			{
				
				$folderNameLocalUTF7 = substr($folderNameGlobalUTF7, (strrpos( $folderNameGlobalUTF7, $this->AtmailMailStorageMain->getFolderDelimiterDefault() )+1) );
            }
			else
			{
				
				$folderNameLocalUTF7 = $folderNameGlobalUTF7;
				
			}
			
			$folderNameLocalUTF8 = $this->AtmailMailStorageMain->decodeUTF7( $folderNameLocalUTF7 );
			$folderNameLocalUTF8HtmlEntities = htmlentities($folderNameLocalUTF8, ENT_QUOTES, 'UTF-8' );
				
			jQuery('div[folderNameGlobal=' . $folderNameGlobalOrigional . '] a span.label')->html( $folderNameLocalUTF8HtmlEntities );
			jQuery('div[folderNameGlobal=' . $folderNameGlobalOrigional . '] a')->attr('href', $this->view->moduleBaseUrl . '/mail/listfoldermessages/selectFolder/' . $folderNameGlobalUTF7UrlencodedDouble);
			jQuery('div[folderNameGlobal=' . $folderNameGlobalOrigional . ']')->attr('id', 'folder_' . safeId($folderNameGlobalUTF7) ); //for css icons
			jQuery('div[folderNameGlobal=' . $folderNameGlobalOrigional . ']')->attr('folderNameGlobal', $folderNameGlobalUTF7UrlencodedDouble);
			
			jQuery::evalScript('setMessageDroppableFolder(\'div[folderNameGlobal=' . $folderNameGlobalUTF7UrlencodedDouble . '] a\')');
			
		}
		catch( Exception $e ) 
		{                                            
			//fail gracefully
			//jQuery('#Email #nav_secondary div[folderNameGlobal=' . $folderNameGlobalOrigional . ']:last')->fadeOut('slow');
			//jQuery('#Email #nav_secondary li[folderNameGlobal=' . $folderNameNewUrlencodedDouble . ']:last')->remove();
			jQuery('#Email #nav_secondary li:last')->remove();
			jQuery::addError( $this->view->translate('Unable to create folder.') );// . $e->getMessage() );
			
		}
		
		$this->render('global/jsonresponse', null, true);
	}

	public function folderrenameAction()
	{
		$this->AtmailMailStorageMain->connect();
		$log = Zend_Registry::get('log');
		$requestParams = $this->_request->getParams();
		$folderNameGlobalOldUTF7 = urldecode( $requestParams['folderNameGlobalOld'] );
		$folderNameGlobalOldUTF7UrlencodedDouble = urlencode(urlencode($folderNameGlobalOldUTF7));
		$folderNameLocalNewUTF8 = urldecode($requestParams['folderNameNew']);
        $folderNameLocalNewUTF7 = $this->AtmailMailStorageMain->encodeUTF7( $folderNameLocalNewUTF8 );
        
		//calculate folderNameGlobalNew from folderNameGlobalOld and folderNameNew
		$lastDelimiter = strrpos($folderNameGlobalOldUTF7, $this->AtmailMailStorageMain->getFolderDelimiterDefault());
		
		if( $lastDelimiter === false )
		{
		
			//not a subfolder
			$folderNameGlobalNewUTF7 = $folderNameLocalNewUTF7;
		
		}
		else
		{
		
			$folderNameGlobalNewUTF7 = substr($folderNameGlobalOldUTF7, 0, $lastDelimiter ) . $this->AtmailMailStorageMain->getFolderDelimiterDefault() . $folderNameLocalNewUTF7;
		
		}

		try
		{
		    
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": renaming: " . $folderNameGlobalOldUTF7 . ' to ' . $folderNameGlobalNewUTF7);
			
			$folderNameGlobalNewUTF7 = $this->AtmailMailStorageMain->renameFolder($folderNameGlobalOldUTF7, $folderNameGlobalNewUTF7);
		    $folderNameGlobalNewUTF7UrlencodedDouble = urlencode( urlencode( $folderNameGlobalNewUTF7 ) );
            
			if( strrpos( $folderNameGlobalNewUTF7, $this->AtmailMailStorageMain->getFolderDelimiterDefault() ) !== false )
			{
				
				$folderNameLocalNewUTF7 = substr($folderNameGlobalNewUTF7, (strrpos( $folderNameGlobalNewUTF7, $this->AtmailMailStorageMain->getFolderDelimiterDefault() )+1) );
            }
			else
			{
				
				$folderNameLocalNewUTF7 = $folderNameGlobalNewUTF7;
				
			}
						
			$folderNameLocalNewUTF8 = $this->AtmailMailStorageMain->decodeUTF7( $folderNameLocalNewUTF7 );
			$folderNameLocalNewUTF8HtmlEntities = htmlentities($folderNameLocalNewUTF8, ENT_QUOTES, 'UTF-8' );
			
			//update 3pane title if current folder
			if( $this->AtmailMailStorageMain->getCurrentFolder() == $folderNameGlobalNewUTF7 )
			{

				jQuery('#viewFolder')->html( $folderNameLocalNewUTF8HtmlEntities );
			
			}
			
			//update link
			jQuery('#Email #nav_secondary div[foldernameglobal=' . $folderNameGlobalOldUTF7UrlencodedDouble . ']')->updateChildrenGlobalFolder( $folderNameGlobalOldUTF7UrlencodedDouble,$folderNameGlobalNewUTF7UrlencodedDouble );
			jQuery('#Email #nav_secondary div[foldernameglobal=' . $folderNameGlobalOldUTF7UrlencodedDouble . '] a span.label')->html( $folderNameLocalNewUTF8HtmlEntities );
			jQuery('#Email #nav_secondary div[foldernameglobal=' . $folderNameGlobalOldUTF7UrlencodedDouble . '] a')->attr('href', $this->view->moduleBaseUrl . '/mail/listfoldermessages/selectFolder/' . $folderNameGlobalNewUTF7UrlencodedDouble);
			jQuery('#Email #nav_secondary div[folderNameglobal=' . $folderNameGlobalOldUTF7UrlencodedDouble . ']')->attr('id', 'folder_' . safeId($folderNameGlobalNewUTF7) ); //for css icons
			jQuery('#Email #nav_secondary div[foldernameglobal=' . $folderNameGlobalOldUTF7UrlencodedDouble . ']')->attr('folderNameGlobal', $folderNameGlobalNewUTF7UrlencodedDouble);
			//jQuery::addMessage('Folder successfully renamed'); //redundant
		
		}
		catch( Exception $e )
		{
			
			$folderNameLocalNewUTF8HtmlEntities = htmlentities($folderNameLocalNewUTF8, ENT_QUOTES, 'UTF-8' );
			//jQuery('#Email #nav_secondary li[folderNameGlobal=' . $folderNameGlobalOldUTF7UrlencodedDouble . '] a span.label')->html( htmlspecialchars( $this->AtmailMailStorageMain->decodeUTF7($folderNameGlobalOldUTF7) ) );
			jQuery::addError('Unable to rename folder to ' . $folderNameLocalNewUTF8HtmlEntities );
			
		}
		$this->render('global/jsonresponse', null, true);
	}

	public function folderremoveAction()
	{
		
		$requestParams = $this->_request->getParams();

		$preserveList = array();
		$preserveList[] = $this->AtmailMailStorageMain->getMainFolderName('Inbox');
		$preserveList[] = $this->AtmailMailStorageMain->getMainFolderName('Sent');
		$preserveList[] = $this->AtmailMailStorageMain->getMainFolderName('Trash');
		$preserveList[] = $this->AtmailMailStorageMain->getMainFolderName('Drafts');
		$preserveList[] = $this->AtmailMailStorageMain->getMainFolderName('Spam');

		$folderNameGlobalUTF7 = urldecode( $requestParams['folderNameGlobal'] );
		if( in_array($folderNameGlobalUTF7, $preserveList) )
		{
		
			throw new Atmail_Mail_Exception( $this->view->translate('Cannot remove a main folder') );
		
		}
		
		//TODO: only switch to root folder if not selected or sub folder.
		$rootFolderGlobalUTF7 = $this->AtmailMailStorageMain->getMainFolderName();
		
		$rootFolderGlobalUTF7UrlencodedDouble = urlencode( urlencode( $rootFolderGlobalUTF7 ) );
		$this->AtmailMailStorageMain->selectFolder( $rootFolderGlobalUTF7 ); //change to inbox first
		jQuery('#Email #nav_secondary div[folderNameGlobal=' . $rootFolderGlobalUTF7UrlencodedDouble . '] a')->click();
				
        try 
		{
		    
			$listOfDeletedFolders = array();
			$folderObject = $this->AtmailMailStorageMain->getFolderObject( $folderNameGlobalUTF7 );
			
			if( $folderObject == null )
			{
				
				throw new Exception( $this->view->translate('Unable to remove folder. Folder not found') );
				
			}
			$foldersRemoved = 0;
			foreach( new RecursiveIteratorIterator( $folderObject, RecursiveIteratorIterator::SELF_FIRST) as $object )
			{

				$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Deleting: " . $object->getGlobalName());
				
				$this->AtmailMailStorageMain->removeFolder( $object->getGlobalName() );
				$listOfDeletedFolders[] = $object->getGlobalName();
				$foldersRemoved++;
				
			}
			
			//remove parent (for some reason ::SELF_FIRST is not including self)
			if( !in_array($folderNameGlobalUTF7, $listOfDeletedFolders) )
			{
			
				$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Deleting head: " . $folderNameGlobalUTF7 );
				$this->AtmailMailStorageMain->removeFolder( $folderNameGlobalUTF7 );
				$foldersRemoved++;
				
			}
			
			/*
			// redundant, as folders being removed from tree is sufficient indication of success
			if( $foldersRemoved > 1 )
			{
				
				$message = $this->view->translate('Folder successfully removed');
				
			}
			else
			{
				
				$message = $this->view->translate('Folders successfully removed');				
				
			}
			jQuery::addMessage( $message );			
		    */
		   	//call a cleanup on the head node that was deleted
			$folderNameGlobalUTF7UrlencodedDouble = urlencode( urlencode( $folderNameGlobalUTF7 ) );
			jQuery('#Email #nav_secondary div[folderNameGlobal=' . $folderNameGlobalUTF7UrlencodedDouble  . ']:last')->removeTreeNode();
		
		}
		catch( Exception $e) 
		{
		
		   jQuery::addError('Error:' . $e->getMessage() );
			
		}

		//jQuery::addMessage('Folder successfully removed');
		//jQuery('#Email #nav_secondary li[folderNameGlobal=' . $requestParams['folderNameGlobal'] . ']')->remove();
		//jQuery('#Email #nav_secondary div[folderNameGlobal=' . urlencode( urlencode($folderNameGlobal) ) . ']:last')->remove();
		$this->render('global/jsonresponse', null, true);
	}

	/**
	* Handle events to set flags
	* ZF flag action accepts an array of all flags and values so can set multiple flags.
	* Implimented to only change one flag at a time while preserving the other flags
	* Recent flag will probably fall away on setFlags
	*/
	public function flagmessageAction()
	{
		
		$params = $this->getRequest()->getParams();
		
		$appendFlag = $params['appendFlag'];
		$setFlag = $params['flag'];
		$selectFolder = $params['selectFolder'];
		
		$UIDs = $params['mailId'];
		if( !is_array($UIDs) )
			$UIDs = array($UIDs);
		$mode = "";
		
		//sanitize UIDs
		foreach( $UIDs as &$UID )
			$UID = (int)$UID;
		
		if( isset($appendFlag) && $appendFlag == 'true' )
			$mode = "+";
		
		$wantedFlags = array();
        if($setFlag == 'seen')
			$wantedFlags[] = Zend_Mail_Storage::FLAG_SEEN;
		else if( $setFlag == 'unseen' )
			$mode = "";
		
		$this->AtmailMailStorageMain->connect();
		//Zend_Registry::get('log')->debug( "\n" . print_r($UIDs, true) . "\n" . __METHOD__ . ' #' . __LINE__ . ": \$UIDs \n");
		//Zend_Registry::get('log')->debug( "\n" . print_r($wantedFlags, true) . "\n" . __METHOD__ . ' #' . __LINE__ . ": \$wantedFlags \n");
		//Zend_Registry::get('log')->debug( "\n" . print_r($mode, true) . "\n" . __METHOD__ . ' #' . __LINE__ . ": \$mode \n");
		
		$this->AtmailMailStorageMain->setFlagsAdvanced($UIDs, $wantedFlags, $mode);

		//now update total
		//special ids for reserved folders
		$reservedFoldernamesGlobal = array();
		$reservedFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName();
		$reservedFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName('Sent');
		$reservedFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName('Trash');
		$reservedFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName('Drafts');
		$reservedFoldernamesGlobal[] = $this->AtmailMailStorageMain->getMainFolderName('Spam');
        if( $selectFolder == 'undefined' )
        	$selectFolder = $this->AtmailMailStorageMain->getCurrentFolderObject()->getGlobalName();
        
		if( in_array($selectFolder, $reservedFoldernamesGlobal) )
		{
				
			$folderObj = $this->AtmailMailStorageMain->getCurrentFolderObject($selectFolder);
			$localName = $folderObj->getLocalName();
			$id = 'folder_' . strtolower( $localName );
			
		}
		else
			$id = 'folder_' . safeId($selectFolder);
		
		//update current folder item in folder list with latest total
		jQuery('#Email div#' . $id . ' .unread:first strong:first')->updateTotal( $this->AtmailMailStorageMain->countUnseenMessages() );
		
		//jQuery::addMessage('Messages successfully flagged as: ' . $setFlag);
		$this->render('global/jsonresponse', null, true);
		return;
		
	}

	public function movetofolderAction()
	{
		
		$requestParams = $this->_request->getParams();
		
		//fromFolder already handled by mailstore setup in Predispatch to eliminate redundant folder changes on the IMAP server
		$this->AtmailMailStorageMain->connect();
		$moveSuccess = true;
        
		//if this move request is comming from search results then disable threadding so that threaded messages not moved with moved search results
        if( isset( $requestParams['searching']) && $requestParams['searching'] == 'true' )
		{
	
			$this->AtmailMailStorageMain->setThreadsEnabled( false );
	
		}
		$threadsEnabled = $this->AtmailMailStorageMain->getThreadsEnabled();

		if( !isset($requestParams['unseen']))
		{
			$requestParams['unseen'] = array();
		}

		if( isset($requestParams['mailId']) && is_array($requestParams['mailId']) && count($requestParams['mailId']) > 0 )
		{
			
			$UIDArray = $requestParams['mailId'];
			$plural = 's';
			$unseenArray = $requestParams['unseen'];
			$unseenCount = 0;
			foreach( $UIDArray as $UID )
			{
				
				if( isset($unseenArray[$UID]) )
				{
					
					//total unread count for thread
					$unseenCount += $unseenArray[$UID];
					
				}
				
			}
			
		}
		else
		{
			
			$UIDArray = array($requestParams['UID']);
			$plural = '';
			//total unread count for thread
			$unseenCount = (isset($requestParams['unseen'])?$requestParams['unseen']:0 );
			
		}
		
		try
		{
			
			//now get all thread uids related to these uids
			$allThreadUIDs = array();
			$otherThreadUIDs = array();

			foreach( $UIDArray as $v )
			{
			
				if( $threadsEnabled )
				{
				
					$otherThreadUIDs = $this->AtmailMailStorageMain->recursivelyGetAllThreadUIDs( $this->AtmailMailStorageMain->getThread($v) );
				
				}
				
				// add to notice is thread messages were also found and moved
				if( count($otherThreadUIDs) > 1)
				{
					$plural = ' and threads ';
				}

				if( is_array($otherThreadUIDs) )
				{
					$allThreadUIDs = array_merge($allThreadUIDs, $otherThreadUIDs);
				}
				else
				{
					$allThreadUIDs[] = $v;
				}
			}

			//catch servers which dont support threads and just add the origional requested uids.
			if( count($allThreadUIDs) == 0 )
			{
				$allThreadUIDs = $UIDArray;
			}
			
			$fromFolder = urldecode($requestParams['fromFolder']);
			$toFolder = urldecode($requestParams['toFolder']);
			if(!isset($requestParams['actuallyDelete']))
			{
				$requestParams['actuallyDelete'] = false;
			}
			
			$actuallyDelete = $requestParams['actuallyDelete'];
			
			if( $fromFolder == $this->AtmailMailStorageMain->getMainFolderName('Trash') && $toFolder == $this->AtmailMailStorageMain->getMainFolderName('Trash') )
			{
				
				$actuallyDelete = true;
				
			}

			if( $actuallyDelete ) 
	 		{
	 			
					$this->AtmailMailStorageMain->removeMessage($allThreadUIDs);
					$current_backend_quota = $this->AtmailMailStorageMain->getquota();
					jQuery::evalScript("quota = [" . $current_backend_quota[0] . ', ' . $current_backend_quota[1] . "];");
	 			
			}
	 		else
	 		{
			
				$this->AtmailMailStorageMain->moveMessage($allThreadUIDs , $toFolder);

			}

		}
		catch ( Exception $e )
		{

			$moveSuccess = false;
			$message = $e->getMessage();

		}

		if( $moveSuccess )
		{
			// Remove the selected entries
			foreach($UIDArray as $v)
			{
				
				jQuery::evalScript("$('#primary_content_inner .messagesListForm #$v', getVisiblePanelContext()).addClass('removing');");
				jQuery::evalScript("$('#primary_content_inner .messagesListForm #$v', getVisiblePanelContext()).hideMailRow();");
                
                //if this request comes from search results then we need to also cull the moved messages out of the current folder (showing in #messageList context)
				if( !isset($requestParams['searching']) || $requestParams['searching'] === 'true' )
				{
					jQuery::evalScript("$('#primary_content_inner .messagesListForm #$v', '#messageList').addClass('removing');");				
					jQuery::evalScript("$('#primary_content_inner .messagesListForm #$v', '#messageList').hideMailRow();");					
				}
				// TODO: If you move a message and you still have that panel open, need to change the ID returned from copy, so click forward still works
			}
			jQuery::evalScript('enableMailActions()');
			
			$lastUID = $UIDArray[count($UIDArray) - 1];
			
			if( isset($requestParams['searching']) && $requestParams['searching'] === 'true' )
			{
				
				$resultContext = '#' . $requestParams['resultContext'];

			}
			else
			{
				
				$resultContext = '#messageList';
			
			}
			
			 if($resultContext == '#')
			{
				
				$resultContext .= "messageList";	
				
			}

			jQuery::evalScript("$('.messagesListForm #$lastUID', '" . $resultContext . "').getMailRow('" . $resultContext . "');");

			// Update the folder count for the "new" folder
			if( $requestParams['fromFolder'] != $this->AtmailMailStorageMain->getMainFolderName('Trash') || $toFolder != $this->AtmailMailStorageMain->getMainFolderName('Trash') )
			{
				
				jQuery('#Email div[foldernameglobal=' . urlencode(urlencode($toFolder)) . '] .unread strong')->updateCount( $unseenCount );

			}

			// Increment down our original folder
			jQuery('#Email div[foldernameglobal=' . urlencode(urlencode($this->AtmailMailStorageMain->getCurrentFolder())) . '] .unread strong')->updateCount( '-' . $unseenCount );
		} 
		else
		{
			jQuery::addError('Error moving message' . $plural . '. ' . $message);
		}

		$this->render('global/jsonresponse', null, true);
	}
	
}
