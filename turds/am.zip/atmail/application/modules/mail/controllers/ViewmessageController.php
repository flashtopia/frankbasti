<?php
class Mail_ViewmessageController extends Atmail_Controller_Action
{
	public function init()
	{
		parent::init();

		//$contextSwitch = $this->_helper->getHelper('contextSwitch');
		//$contextSwitch->addActionContext('index', 'xml')->addActionContext('read', 'xml')->initContext();

		require_once('application/models/messageHandling.php');
	}

	public function preDispatch()
	{

		// setup filters
		//$this->filter = Atmail_Filter_Input_Controller::filterInput( $this->_request );
		
		// Added "$this->getRequest()->isAjax" option to ease unit testing
		if( $this->getRequest()->isXmlHttpRequest() || $this->getRequest()->isAjax )
		{
			require_once 'library/jQuery/jQuery.php';
			$this->view->jsonIdsToRender = array();
			//Zend_Registry::get('log')->info(__METHOD__ . ' is an AJAX request');//show a hidden dialog box and include desired content
			$this->isAjax = true;
			$this->view->jsonIdsToRender = array();
			$this->view->notices = array();
			$this->view->errors = array();
		}
		else
		{
			//Zend_Registry::get('log')->info(__METHOD__ . ' normal HTML request');//show a hidden dialog box and include desired content
			$this->isAjax = false;
		}

		// check if we have been authenticated... and redirect if not
		if(!Atmail_FormAuth::authenticated())
		{
			// we have most probably timed out, so lets kick them to the timeout bootstrap page
			// this will poison json responses, which will fire the php.error ( or ajax.error ) which can detect the special page
			$this->_forward('timeout', 'index', 'default');
			return;
		}
		else
		{
			//exposing the incoming vars to template becomes confusing with encoding, rather explicitly unpack and required vars into base form (e.g. UTF7 for folder names)
			$requestParams = $this->getRequest()->getParams();
			
			$this->view->setEncoding('UTF-8');
			$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
			$this->view->appBaseUrl = $this->getRequest()->getBaseUrl() . (strpos($this->getRequest()->getBaseUrl(),'index.php')?'':'/index.php');
			$this->view->moduleBaseUrl = $this->view->appBaseUrl . DIRECTORY_SEPARATOR . ($this->view->requestParams['module']=='default'?'':$this->view->requestParams['module']) . DIRECTORY_SEPARATOR;
			$this->view->thisActionURL = $this->view->moduleBaseUrl . $this->view->requestParams['controller'] . DIRECTORY_SEPARATOR . $this->view->requestParams['action'] . DIRECTORY_SEPARATOR;
			
			$this->userData = Zend_Auth::getInstance()->getStorage()->read();
			
			$this->_globalConfig = Zend_Registry::get('config')->global;
			$this->view->UserSettings = Zend_Registry::get('UserSettings');
			
			$this->view->autocompleteFetchThreshold = (isset($this->_globalConfig['autocompleteFetchThreshold']) ? $this->_globalConfig['autocompleteFetchThreshold'] : 50);
			$this->view->autocompleteCacheSize = (isset($this->_globalConfig['autocompleteCacheSize']) ? $this->_globalConfig['autocompleteCacheSize'] : 100);
			$this->view->autocompleteFetchSize = (isset($this->_globalConfig['autocompleteFetchSize']) ? $this->_globalConfig['autocompleteFetchSize'] : 25);
			$this->view->autocompleteMinFetchLength = (isset($this->_globalConfig['autocompleteMinFetchLength']) ? $this->_globalConfig['autocompleteMinFetchLength'] : 2);

			//if this hit refers to a folder, connect to the store configured with this folder
			//TODO: this must be refactored in then refactoring cache
			$this->_currentConfig = array();
			if( isset($requestParams['folder']) )
				$this->_currentConfig['folder'] = urldecode($requestParams['folder']);
			
			$this->_mailStoreConfig = array_merge($this->_globalConfig, $this->userData, $this->_currentConfig);
			if( isset($this->view->UserSettings['ThreadLimit']) )
				$this->_mailStoreConfig['threadsLimitMonths'] = $this->view->UserSettings['ThreadLimit'];
			
			//add UsetSettings['UseSSL'] to IMAP config
			$this->_mailStoreConfig['UseSSL'] = $this->view->UserSettings['UseSSL'];
			$this->AtmailMailStorage = Atmail_Mail_Storage::getInstance($this->_mailStoreConfig);
			$this->AtmailMailStorageMain = &$this->AtmailMailStorage->getMailStore($this->_mailStoreConfig['namespaceName']);
			$this->view->tmpFolderBaseName = $this->_mailStoreConfig['tmpFolderBaseName'];
			if(!isset($requestParams['folder']))
				$requestParams['folder'] = '';
    		
			$this->view->folderUTF7 = urldecode( $requestParams['folder'] );

			if( strpos( strtolower($this->AtmailMailStorageMain->getCurrentFolder()),'drafts') !== false )
				$this->_forward('edit', 'composemessage', null, $requestParams);	
			
			try
			{
				date_default_timezone_set($this->view->UserSettings['TimeZone']);
			} 
			catch ( Exception $e )
			{
				//dont bother trying to set user timezone if UserSettings not jet available
			}
			
			$this->AtmailMailStorageMain->setThreadsEnabled( $this->view->UserSettings['ViewThreads'] ); //will still be forced to false if !supported
						
		}
	}

	public function replyAction()
	{
		$this->view->requestParams = $this->getRequest()->getParams();
		$this->render('reply');
	}

	public function indexAction()
	{
		$requestParams = $this->getRequest()->getParams();
		
		//switch off threads if we know this message has no threads to speed up preparing message data
		if( isset($requestParams['threadChildrenUIDs']) && $requestParams['threadChildrenUIDs'] == 'false' )
		{
			
			$this->AtmailMailStorageMain->setThreadsEnabled(false);
			Zend_Registry::get('log')->debug( __METHOD__ . ' #' . __LINE__ . ": disabling threads for this hit");
			
		}
		
		//disable threadding of view messages for searching and viewing search result messages
		if( isset( $requestParams['searching']) && $requestParams['searching'] == 'true' )
		{
			
			$this->AtmailMailStorageMain->setThreadsEnabled( false );
			
		}
        
		$this->view->uniqueId = $requestParams['uniqueId'];
		//$this->view->viewmessageTabNumber = 0;
		if( isset($requestParams['viewmessageTabNumber']) )
		{
			
			$this->view->viewmessageTabNumber = $requestParams['viewmessageTabNumber'];
			
		}
		$this->view->AtmailMailStorageMain = $this->AtmailMailStorageMain;
		$folderUTF7 = urldecode( $requestParams['folder'] );
		$this->view->folderUTF7 = $folderUTF7;
		$this->AtmailMailStorageMain->connect();
		
		//updateFolderInfo will also set threadsEnabled
		$this->AtmailMailStorageMain->getFolderInfo();
		
		
		//check if loading message in other than default resultContext (viewable DOM panel)
		$resultContext = 'messageList';
		if( isset($requestParams['resultContext']) )
		{
			
			$resultContext = $requestParams['resultContext'];
			
		}
		$this->view->resultContext = $resultContext;      
		if(
			
			$this->AtmailMailStorageMain->getThreadsEnabled() 
			&& 
			( empty($requestParams['inline']) || $requestParams['inline'] == false ) 

		)
		{
			$this->view->thread = $this->AtmailMailStorageMain->getThread( $requestParams['uniqueId'] );
			$this->AtmailMailStorageMain->getThreadWithAllBasicHeaders($this->view->thread);
			$latestThreadChild = &$this->AtmailMailStorageMain->findLatestThreadChild($this->view->thread);
			//$this->AtmailMailStorageMain->setThreadsEnabled( false);	
			$flags = $this->AtmailMailStorageMain->getFlags($latestThreadChild['UID']);
			$latestThreadChildMessage = &$this->AtmailMailStorageMain->getMessage($latestThreadChild['UID']);
			$this->view->seen = isset($flags['\Seen']);
			$headers = $latestThreadChildMessage->getHeaders();
            $latestThreadChild['mainHeaders'] = $latestThreadChildMessage->processHeaders( array('uniqueid' => $latestThreadChild['UID']) );
			$latestThreadChild['messageObject'] = &$latestThreadChildMessage;
			$latestThreadChild['messageArray'] = messageHandling::returnPreparedMessageArray($latestThreadChildMessage, array('tmpFolderBaseName' => users::getTmpFolder(), 'folder' => $folderUTF7, 'uniqueId' => $requestParams['uniqueId']));
			//$this->view->message = $latestThreadChild;
		}
		else
		{
			//might have been forced here cos box > 2000 for make sure threadsEnabled = false
			$this->AtmailMailStorageMain->setThreadsEnabled( false );
			$this->view->message = array();
			$flags = $this->AtmailMailStorageMain->getFlags($requestParams['uniqueId']);
			$this->view->message['messageObject'] = &$this->AtmailMailStorageMain->getMessage($requestParams['uniqueId']);
			$this->view->seen = isset($flags['\Seen']);
			$this->view->message['messageObject']->getHeaders();
            $this->_helper->pluginCall("postGetMessage");
			$this->view->message['messageArray'] = messageHandling::returnPreparedMessageArray($this->view->message['messageObject'], array('tmpFolderBaseName' => users::getTmpFolder(), 'folder' => $folderUTF7, 'uniqueId' => $requestParams['uniqueId']));
            //Zend_Registry::get('log')->debug( "\n" . print_r($this->view->message['messageArray'], true) . "\n" . __METHOD__ . ' #' . __LINE__ . ": \$this->view->message['messageArray'] \n");
            
		}

		$this->view->threadsEnabled = $this->AtmailMailStorageMain->getThreadsEnabled();
        
		if( isset($requestParams['drilldown']) && $requestParams['drilldown'] == true )
		{

			$this->view->drilldown = true;
			$this->render('threadedmessage');
		
		}
		elseif( isset($requestParams['compact']) )
		{

			$this->view->compact = 1;                      
			jQuery('#' . $resultContext . ' div#primary_content div#mail_info:first')->html( iconv("UTF-8", "UTF-8//TRANSLIT", $this->view->partial('viewmessage/threadedmessage.phtml', $this->view)) );
			if( isset($requestParams['searching']) && $requestParams['searching'] == 'true' )
			{

				$searchQuery = urldecode( urldecode( $requestParams['searchQuery'] ) );
				if($searchQuery != '')
				{
					jQuery('#' . $resultContext . ' div#primary_content div#mail_info:first')->highlight( $searchQuery );
				}
			}
			$this->render('global/jsonresponse', null, true);

		}
		elseif( isset($requestParams['viewmessageTabNumber']) )
		{
			if( $this->isAjax )
			{
                
				//get rendered content to put in your JSON packet this way if you need to control the order in which the JSON and this the Javascript gets executed
				//e.g. you cant highlight the search terms in the body until you have loaded the body content
				jQuery('#viewmessageTab' . $requestParams['viewmessageTabNumber'])->html( iconv("UTF-8", "UTF-8//TRANSLIT", $this->view->partial('viewmessage/threadedmessage.phtml', $this->view)) );
				if( isset($requestParams['searching']) && $requestParams['searching'] == 'true' )
				{

					$searchQuery = urldecode( urldecode( $requestParams['searchQuery'] ) );
					if($searchQuery != '')
					{
						jQuery('#viewmessageTab' . $requestParams['viewmessageTabNumber'] )->highlight( $searchQuery );
					}				
				}
				$this->render('global/jsonresponse', null, true);

			}
			else
			{

				$this->render('threadedmessage');

			}
			

		}
		else
		{	
            
			// is inline
			$this->view->inline = true;
			$this->view->messageArray = $this->view->message['messageArray'];
			$this->render('recursivelyrenderinlinemessage');

		}
		
	}   

	/**
	 * filename must be FS and URL safe
	 * filename is an Id composed of URL safe filename and uniqueId and folder	
  	 */

	public function getattachmentAction()
	{
		$this->_helper->viewRenderer->setNoRender();
		$requestParams = $this->getRequest()->getParams();
		$requiredArgs = array('folder', 'uniqueId', 'filenameOriginal');
		
		foreach( $requiredArgs as $requiredArg ) {
		
			if( !array_key_exists( $requiredArg, $requestParams) )
				throw new Atmail_Mail_Exception('invalid call to getattachment Action: required request argument missing: ' . $requiredArg);
		
		}
        
		$tmpFolderBaseName = users::getTmpFolder();
		$filenameOriginal = urldecode( $requestParams['filenameOriginal'] ); //UTF-8
		$folderUTF7 = urldecode($requestParams['folder']);
		if( array_key_exists('mimeType', $requestParams) )
			$mimeType = base64_decode( $requestParams['mimeType'] );
		// IE requires filenames to be rawurlencoded if multibyte chars are to be
		// displayed properly
		if( strpos($filenameOriginal, 'unknownfilename') !== false )
		{
			
			$filename = makeFSSafe( $filenameOriginal );
			
		}
		else
		{
			
			$filename = makeFSSafe( $folderUTF7 . $requestParams['uniqueId'] . $filenameOriginal ); 
			
		}
		$filename = APP_ROOT . $tmpFolderBaseName . $filename;
		
		if( isset($_SERVER['HTTP_USER_AGENT']) && strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') )
		{

		    $filenameOriginalHeader = rawurlencode( $filenameOriginal );

		}
		else
		{
			
			$filenameOriginalHeader = str_replace( '"','\"', $filenameOriginal );//properly escape double quotes as the header is wrapped in double quotes
			
		}
		
		// Check if attachment already on disk
		if( file_exists($filename) )
		{
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Attachment found on disk");
			
			if( array_key_exists('mimeType', $requestParams) )
			{
				
				header("Content-Type: " . $mimeType );
				$contentType = $mimeType;
				
			}
			else 
			{
				$extension = strtolower(substr($filenameOriginal, (strrpos($filenameOriginal,'.')+1) ));
				switch( $extension ) {
					case 'doc':
						$contentType = 'application/msword';
						break;
					case 'gif':
						$contentType = 'image/gif';
						break;
					case 'ics':
						$contentType = 'text/calendar';
						break;
					case 'jpg':
					case 'jpeg':
						$contentType = 'image/jpeg';
						break;
					case 'pdf':
						$contentType = 'application/pdf';
						break;
					case 'png':
						$contentType = 'image/png';
						break;
					case 'txt':
						$contentType = 'text/plain';
						break;
					case 'xls':
						$contentType = 'application/x-msexcel';
						break;
					case 'xml':
						$contentType = 'text/xml';
						break;
					case 'zip':
						$contentType = 'application/x-compressed'; //or /x-zip-compressed or /zip or /x-zip
						break;
					case 'wmv':
						$contentType = 'video/x-wmv';
						break;
					case 'xlsx':
						$contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
						break;
					case 'docx':
						$contentType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
						break;
					default:
						$contentType = 'text/plain';
				}
				if( isset($_SERVER['HTTP_USER_AGENT']) ) //needed for CLI UT (cant handle propper HTTP testing)
					header("Content-Type: " . $contentType); //to assist with browser trying to render inside itself without poping download dialogue (e.g. images etc.)
				
			}
            
			if( isset($_SERVER['HTTP_USER_AGENT']) ) //needed for CLI UT (cant handle propper HTTP testing)
			{
				
				header("Pragma: ");
				header("Cache-Control: ");
				
				//force some types to be attachment and not attempt to play inline (e.g. Media Player cant play HTTPS streams)
				$forcedAttachments = array('video/x-wmv');
				if( in_array($contentType, $forcedAttachments) )
					header("Content-Disposition: attachment; filename=\"" . $filenameOriginalHeader . "\"");
				else
					header("Content-Disposition: inline; filename=\"" . $filenameOriginalHeader . "\"");
				header("Content-Length: " . filesize($filename) );
			}
			readfile($filename);
			return;
		}
		else
		{
			// Connect to the mailserver, get the message, and parse the attachment
			$this->AtmailMailStorageMain->connect();
			$message = $this->AtmailMailStorageMain->getMessage($requestParams['uniqueId']);
			$found = messageHandling::recursivelySearchMessageForAttachment($message, array('folder' => $folderUTF7, 'uniqueId' => $requestParams['uniqueId'], 'filename' => $filenameOriginal), $file);
             
			if( $found ) 
			{
			
				$bytesWritten = file_put_contents ($filename, $file['content'] );
				
				if( isset($_SERVER['HTTP_USER_AGENT']) ) //needed for CLI UT (cant handle propper HTTP testing)
				{

					//header("Cache-control: private"); //use this to open files directly
					header("Pragma: ");
					header("Cache-Control: ");
					//force some types to be attachment and not attempt to play inline (e.g. Media Player cant play HTTPS streams)
					if( in_array($file['mimeType'], array('video/x-wmv')) )
						header("Content-Disposition: attachment; filename=\"" . $filenameOriginalHeader . "\"");
                    else
						header("Content-Disposition: inline; filename=\"" . $filenameOriginalHeader . "\"");
                    header("Content-Type: " . $file['mimeType']);
					header("Content-Length: " . $bytesWritten );
					
				}
				readfile($filename);
				return;

			}  

		}
		throw new Atmail_Mail_Exception('Attachment was not found: ' . $filenameOriginal);
		
	}
	
	/**
	 * filename must be FS and URL safe
	 * this should only get called from code generated by FilePreview plugin, if enabled/installed	
  	 */
	public function getthumbnailAction() {
	
		$this->_helper->viewRenderer->setNoRender();
		$requestParams = $this->getRequest()->getParams();
		
		$requiredArgs = array('folder', 'uniqueId', 'filenameOriginal');
		foreach( $requiredArgs as $requiredArg ) {
		
			if( !array_key_exists( $requiredArg, $requestParams) )
				throw new Atmail_Mail_Exception('invalid call to getthumbnail Action: required request argument missing: ' . $requiredArg);
		
		}
		
		$filenameOriginal = urldecode( $requestParams['filenameOriginal'] ); //UTF-8
		$folderUTF7 = urldecode( $requestParams['folder'] );
		
		if( !array_key_exists('fileType', $requestParams) ) {
		
			//create fileType from mimeType
			$requestParams['fileType'] = substr( $filenameOriginal, (strrpos($filenameOriginal,'.')+1) );
			
		}
			
		// First, check the Atmail Cache for the thumbnail
		
		$backendOptions = array( 'cache_dir' =>  users::getTmpFolder('attachmentThumbs'), 'file_name_prefix' => simplifyString($this->userData['user']) );
		$frontendOptions = array( 'lifetime' => 14400, 'automatic_serialization' => true );
        $cache = Zend_Cache::factory('Core', 'File', $frontendOptions, $backendOptions);
		$cacheItemId = md5( $folderUTF7 . $requestParams['uniqueId'] . $filenameOriginal );
		
		// Check the cache (currently only thumbnails are stored in the cache)
		if( $requestParams['fileType'] != 'ics' && $thumb = $cache->load($cacheItemId) )
		{
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": thumbnail found in cache" );
			
			// send the attachment from cache
			header("Pragma: ");
			header("Cache-Control: ");
			header("Content-Disposition: inline; filename=\"" . $thumb['filename'] . "\"");
			header("Content-Type: " . $thumb['mimeType']);
			header("Content-Length: " . strlen($thumb['content']) );
			echo $thumb['content']; 
		
		}
		else
		{
		   	$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": thumbnail NOT found on disk" );
			// Connect to the mailserver (folder set in preDispatch _config), get the message, and find the attachment for making a thumbnail
			$this->AtmailMailStorageMain->connect();
			$message = $this->AtmailMailStorageMain->getMessage($requestParams['uniqueId']);
			$found = messageHandling::recursivelySearchMessageForAttachment($message, array('folder' => $requestParams['folder'], 'uniqueId' => $requestParams['uniqueId'], 'filename' => $filenameOriginal), $file );

			if( !$found )
				throw new Atmail_Mail_Exception('Attachment was not found in message.');
			
			$args = array(
				'cache'     => $cache,
				'cacheItemId' => $cacheItemId,
				'filename'	=> $filenameOriginal,
				'fileType'  => $requestParams['fileType'], 
				'content'	=> $file['content'],
				'extendeddata' => array('requestParams' => $requestParams, 'moduleBaseUrl' => $this->view->moduleBaseUrl, 'folder' => $requestParams['folder'], 'uniqueId' => $requestParams['uniqueId'], 'tmpFolderBaseName' => users::getTmpFolder())
			);

			if(isset($requestParams['accept']) && $requestParams['accept'] == '1')
			{
				$found = messageHandling::recursivelySearchMessageForAttachment($message, array('folder' => $requestParams['folder'], 'uniqueId' => $requestParams['uniqueId'], 'filename' => $filenameOriginal), $file );

				if( !$found )
					throw new Atmail_Mail_Exception('Attachment was not found in message.');
				
				//N.B. createFilePreview actually sends the content response
				$this->_helper->pluginCall('acceptFilePreview', $args);	
				$this->render('global/jsonresponse', null, true);
				return;	
			}
			else
			{
				//N.B. createFilePreview actually sends the content response
				$this->_helper->pluginCall('createFilePreview', $args);
			}
		}
		
	}
	
	public function downloadmessageAction() 
	{
			$this->_helper->viewRenderer->setNoRender();
			$requestParams = $this->getRequest()->getParams();
			
			$requiredArgs = array('folder', 'uniqueId');
			foreach( $requiredArgs as $requiredArg ) {

				if( !array_key_exists( $requiredArg, $requestParams) )
					throw new Atmail_Mail_Exception('invalid call to downloadmessage Action: required request argument missing: ' . $requiredArg);

			}
	        $folderUTF7 = urldecode( $requestParams['folder'] );
			
			// Connect to the mailserver, get the message, and parse the attachment
			$this->AtmailMailStorageMain->connect();
			$message = $this->AtmailMailStorageMain->getMessage($requestParams['uniqueId']);
			
			
			if( $message ) {

				//produce i18n fs safe filename from subject
				$mailHeader = $this->AtmailMailStorageMain->getRawHeader($requestParams['uniqueId']);
				$mailContent = $this->AtmailMailStorageMain->getRawContent($requestParams['uniqueId']);
			
				$message->getHeaders();
				$headers = $message->processHeaders( array('uniqueid' => $requestParams['uniqueId']) ); 
			
				$rawSubject = $headers['subject'];                  
				$filename = $this->getSafeFileNameFromSubject($rawSubject) . '.eml';
			
				//compose manual filename if subject was not suitable
				if( $filename == '.eml' )
					$filename = 'email' . time() . '.eml';
			
				header("Pragma: ");
				header("Cache-Control: ");
				header("Content-Disposition: attachment; filename=\"" . $filename . "\"");
				header("Content-Type: message/rfc822");
			    header("Content-Length: " . strlen($mailHeader . $mailContent) );
				echo $mailHeader . $mailContent;
				return;
				
			}  
		   
			throw new Atmail_Mail_Exception('Attachment was not found: ' . $filenameOriginal);
		
	}
	
	public function sendreadreceiptAction()
	{
		
		$requestParams = $this->getRequest()->getParams();
		
		$message = &$this->AtmailMailStorageMain->getMessage($requestParams['uniqueId']);
		$headers = $message->getHeaders();
		
		// Decide if to enable SMTP auth or regular connection
		if( !empty($this->_globalConfig['smtpauth_username']) && !empty($this->_globalConfig['smtpauth_password']) && !empty($this->_globalConfig['smtp_auth']) )
		{

			$config = array(
							'auth' => 'login',
							'username' => $this->_globalConfig['smtpauth_username'],
							'password' => $this->_globalConfig['smtpauth_password']
	   		);

		}
		else
			$config = array( );
		
		if(PHP_OS == "Darwin")
			$config['name'] = php_uname('n');
		
        $transportClass = $this->_helper->pluginCall("smtpTransportClass");
        if (empty($transportClass))
            $transportClass = "Atmail_Mail_Transport_Smtp";

        $transport = new $transportClass($this->_globalConfig['smtphost'], $config);
		$this->charset = 'UTF-8';
        $newMessage = new Atmail_Mail( $this->charset );
        $newMessage->setMessageId(true);
        
		//format propper replyto address if short Account
		if( strpos($this->view->UserSettings['Account'], '@') !== false )
			$requestParams['fromAddress'] = $this->view->UserSettings['Account'];
		else
		{
			
			$configDovecot = Zend_Registry::get('config')->dovecot;
			if( !isset($configDovecot['default_domain']) || $configDovecot['default_domain'] == '' )
				throw new Exception( $this->view->translate('Unable to send, Administrator needs to set Default Domain in Admin > Services > POP3/IMAP') );
        	$requestParams['fromAddress'] = $this->view->UserSettings['Account'] . '@' . $configDovecot['default_domain'];
			
		}

		if( isset($this->view->UserSettings['RealName']) && strlen($this->view->UserSettings['RealName']) > 0 )
			$requestParams['fromRealname'] = $this->view->UserSettings['RealName'];
        else
			$requestParams['fromRealname'] = '';
        
		
		if( strlen($requestParams['fromRealname']) > 0 )
		{

			// Optionally encode the users name in the header
			if( containsUTF8($requestParams['fromRealname']) )
				$requestParams['fromRealname'] = Atmail_MIMEWords::encode_mimeword($requestParams['fromRealname'], "B", $this->charset);
        	//TODO: check if ZF wraps in ""
			$newMessage->setFrom( $requestParams['fromAddress'], $requestParams['fromRealname'] );


		}
		else
			$newMessage->setFrom( $requestParams['fromAddress']);

		$addressObjectsArray = getProcessedRecipientObjects( $headers['x-confirm-reading-to'] );
        foreach ($addressObjectsArray as $addressObject)
		{

			$personal = '';
			if (is_string($addressObject))
			{

				preg_match('/(.*?)<(.*?)>/', $addressObject, $m);
				$personal = trim($m[1]);
				$mail = $m[2];

			}
			else
			{

				$personal = $addressObject->personal;
				$mail = $addressObject->mailbox . '@' . $addressObject->host;

			}
			$personal = trim($personal, '"');
			$newMessage->addTo($mail, (strlen($personal)>0?$personal:null) );

		}

		$newMessage->addHeader('X-Mailer', "Atmail " . $this->_globalConfig['version'] );
		$newMessage->addHeader('in-reply-to', $headers['message-id'] );
        $newMessage->setSubject( $this->view->translate('Read:') . ' ' . $headers['subject'] );
        $newMessage->setBodyText( "Message read.\n" . strip_tags($this->_globalConfig['footer_msg']));

		// Send the message
		try
		{
            
			$newMessage->send($transport);
            jQuery::addMessage($this->view->translate('Read receipt sent.'));
		}
		catch (Exception $e)
		{
        
    		$error = $e->getMessage();
			if( $error == 'Blocked' )
				$error = $this->view->translate('The server has rejected the email address. If you feel this address is legitimate please contact your administrator.');				
			elseif( $error == 'No recipient forward path has been supplied' )
				$error = $this->view->translate('Specify a recipient address');
			jQuery::addError( $error );
		
		}
		$this->render('global/jsonresponse', null, true);
		
	}
	
	//TODO: move this and duplicates to General.php
	private function getSafeFileNameFromSubject( $subject ) {
		return str_replace('.','_', str_replace('/','', str_replace('\\', '', strip_tags($subject))));
	}

}
                             
