<?php

class Atmail_FilePreview_Plugin extends Atmail_Controller_Plugin
{
    
    // Only supports PDF previews atm
    private   $_supportedFileTypes = array('pdf', 'ics', 'txt', 'html');
	public $_attachSeen = array();
	
    protected $_pluginFullName   = 'File Preview';
    protected $_pluginAuthor = 'Brad Kowalczyk <brad@staff.atmail.com>';
    protected $_pluginDescription = 'Creates a preview thumbnail image for PDF file attachments';
    protected $_pluginCopyright = 'Copyright (c) NetBased Software Pty Ltd';
    protected $_pluginUrl = '';
	protected $_pluginCompat = '6.1.6 6.1.7';
	protected $_pluginNotes = 'Requires the ImageMagick package of image manipulation tools to function';
    protected $_pluginVersion = '1.0.0';
    protected $_pluginModule = 'mail';
    
    public function __construct()
    {
        // Set PHP extension deps
        //$this->_setDependencies(array('gd'));

		$this->log = Zend_Registry::get('log');
		
		
		parent::__construct();
    }
    
    public function createFilePreview($args)
    {   	
        if (!$this->_supportedFileType($args['fileType']))
            return;
        
        switch (strtolower($args['fileType'])) {
            
            case 'pdf': $this->_createPdfPreview($args);
                        break;
            case 'ics': $this->_createIcsPreview($args);
                        break;
                        
            default: break;
        }
    }
    
	public function acceptFilePreview($args)
	{
		// accepts a preview into the system
		if (!$this->_supportedFileType($args['fileType']))
	            return;

	        switch (strtolower($args['fileType'])) {
	            case 'ics': $this->_acceptIcs($args);
	                        break;

	            default: break;
	        }
	}
    
    public function filePreviewHtml($args)
    {	
		
		
		//Zend_Registry::get('log')->debug( "\n" . print_r($args['content'], true) . "\n" . __METHOD__ . ' #' . __LINE__ . ": \$args['content'] \n");
		//Zend_Registry::get('log')->debug( "\n" . print_r($args['fileType'], true) . "\n" . __METHOD__ . ' #' . __LINE__ . ": \$args \n");
		//if( is_array($args['content']) )
		//	throw new Exception(__METHOD__ . ' #' . __LINE__);
		
		//Zend_Registry::get('log')->debug( "\n" . print_r($args, true) . "\n" . __METHOD__ . ' #' . __LINE__ . ": \$args \n");
		if( !$this->_supportedFileType($args['fileType']) )
			return false;
		$requiredArgs = array('moduleBaseUrl', 'attachId', 'currentFolder', 'uniqueId', 'filenameFS', 'filenameOriginal', 'fileType', 'size');
		foreach( $requiredArgs as $v )
			if( !array_key_exists($v, $args) )
				throw new exception('Missing argument for '. __METHOD__ );
		
		//assume currentFolder is UTF7
		$currentFolderUTF7UrlencodedDouble = urlencode( urlencode( $args['currentFolder'] ) );
		$filenameOriginalUrlencodedDouble = urlencode( urlencode( $args['filenameOriginal'] ) );
		$filenameOriginalHtmlentities = htmlentities( $args['filenameOriginal'], ENT_QUOTES, 'UTF-8' );
		
		//TODO: this html should really go into the template layer for more freedom.
		switch($args['fileType'])
		{
			case 'pdf':
			
				$output = <<<EOF
			<li class="pdf" id="attachment{$args['attachId']}">
				<a class="ajaxDownload" href="{$args['moduleBaseUrl']}viewmessage/getattachment/folder/{$currentFolderUTF7UrlencodedDouble}/uniqueId/{$args['uniqueId']}/filenameOriginal/{$filenameOriginalUrlencodedDouble}" target="_blank">
					<img id="pdfThumbnail" src="{$args['moduleBaseUrl']}viewmessage/getthumbnail/folder/{$currentFolderUTF7UrlencodedDouble}/thumbnail/1/uniqueId/{$args['uniqueId']}/filenameOriginal/{$filenameOriginalUrlencodedDouble}/fileType/{$args['fileType']}" border="0">
				</a>
				<br />
				<a class="filename" href="{$args['moduleBaseUrl']}viewmessage/getattachment/folder/{$currentFolderUTF7UrlencodedDouble}/uniqueId/{$args['uniqueId']}/filenameOriginal/{$filenameOriginalUrlencodedDouble}" target="_blank">{$filenameOriginalHtmlentities}</a> <span class="filesize">PDF Document - {$args['size']}</span>
			</li>
EOF;
				break;
			case 'ics':
			
				$output = <<<EOF
			<li class="calendar" id="attachment{$args['attachId']}">
				<a class="ajaxDownload" href="{$args['moduleBaseUrl']}viewmessage/getattachment/folder/{$currentFolderUTF7UrlencodedDouble}/uniqueId/{$args['uniqueId']}/filenameOriginal/{$filenameOriginalUrlencodedDouble}" target="_blank">
					<iframe id="icsThumbnail" style="width: 100%; height:180px; overflow: hidden;" src="{$args['moduleBaseUrl']}viewmessage/getthumbnail/folder/{$currentFolderUTF7UrlencodedDouble}/thumbnail/1/uniqueId/{$args['uniqueId']}/filenameOriginal/{$filenameOriginalUrlencodedDouble}/fileType/{$args['fileType']}" />
				</a>
				<br />
				<a class="filename" href="{$args['moduleBaseUrl']}viewmessage/getattachment/folder/{$currentFolderUTF7UrlencodedDouble}/uniqueId/{$args['uniqueId']}/filenameOriginal/{$filenameOriginalUrlencodedDouble}" target="_blank">{$filenameOriginalHtmlentities}</a> <span class="filesize">Calendar Appointment - {$args['size']}</span>
			</li>
EOF;
				break;
			case 'txt':

				//make safe from malitious html embedded in txt part
				return convertPlainTextLinksToUrls(strip_unsafe_tags($args['content']));
				break;
			
			case 'html':
                
				return convertPlainTextLinksToUrls(strip_unsafe_tags($args['content']));
				break;
				
			default :
				return false;
		}
        
        return $output;
    }
    
    
    public function settings()
    {
        $settings = $this->_getPluginSettings();
    }
    
    private function _supportedFileType($type)
    {
        return in_array(strtolower($type), $this->_supportedFileTypes);
    }      
    
    
    private function _createPdfPreview($args)
    {
		$config = Zend_Registry::get('config')->global;
    	
		if (!is_executable($config['convertPath'])) {
    	    return;
		}
    	
		$tempABSFilename = tempnam($config['tmpFolderBaseName'], 'pdfthumb');
		
		file_put_contents($tempABSFilename, $args['content']);
		
		$tempABSThumbFilename = $tempABSFilename . '-thumb.gif';
    	$tempThumbFilename = substr($tempABSThumbFilename, strlen($config['tmpFolderBaseName']));   				
    	
		$command = $config['convertPath'] . " -thumbnail x300 '" . escapeshellcmd($tempABSFilename) . "'[0] '" . escapeshellcmd($tempABSThumbFilename) . "'";
		$output = array();
		exec($command, $output);
		if( strpos(implode("\n", $output), 'error') !== false )
			return false;
    	
    	$file = array();
    	$file['filename'] = $tempThumbFilename;
		$file['mimeType'] = "image/gif";
		$file['content'] = file_get_contents($tempABSThumbFilename);
    	header("Content-Disposition: attachment; filename=\"" . $file['filename'] . "\""); 
		header("Content-Type: " . $file['mimeType']);
    	header("Content-Length: " . strlen($file['content']));
    	echo $file['content'];
    	
		// Save the thumbnail to Zend::Cache
		$args['cache']->save($file, $args['cacheItemId']);
    	
    	// Cleanup tmp files on disk
    	unlink($tempABSFilename);
    	unlink($tempABSThumbFilename);
    }

  private function _createIcsPreview($args)
  {
		$config = Zend_Registry::get('config')->global;
	
		if(!isset($args['extendeddata']))
			return;
	
		$md5Filename = md5($args['content']) . '.ics';
		
		// its the main content type of the message which we have forced as an attachment
		//$folderUTF7 = $args['extendeddata']['folder'];
		$tmpFolderBaseName = $args['extendeddata']['tmpFolderBaseName'];
		//$partFilename = 'calendar' . $args['parentEmbeddedAttachmentPrefix'] . ($embeddedAttachmentPrefix) . '.ics';
		//$partFilenameOriginal = $partFilename;
		//$partFilenameFS = makeFSSafe( $folderUTF7 . $args['extendeddata']['uniqueId'] . $partFilename );
		
		$currentFolderUTF7UrlencodedDouble = urlencode( urlencode( $args['extendeddata']['requestParams']['folder'] ) );
		$filenameOriginalUrlencodedDouble = urlencode( urlencode( $args['extendeddata']['requestParams']['filenameOriginal'] ) );
		
		$tempABSFilename = APP_ROOT . $tmpFolderBaseName . $md5Filename . '.ics';

		file_put_contents($tempABSFilename, $args['content']);

    	$file = array();
    	$file['filename'] = $tempIcsFilename;
		$file['mimeType'] = "text/html";
		$file['content'] = file_get_contents($tempABSFilename);
		header("Content-Type: " . $file['mimeType']);
    	$output = calendar::generateHtmlPreview(ical_load_entry(array('data' => $file['content'])), "{$args['extendeddata']['moduleBaseUrl']}viewmessage/getthumbnail/folder/{$currentFolderUTF7UrlencodedDouble}/thumbnail/1/uniqueId/{$args['extendeddata']['requestParams']['uniqueId']}/filenameOriginal/{$filenameOriginalUrlencodedDouble}/fileType/{$args['extendeddata']['requestParams']['fileType']}/accept/1");
		echo $output;

		// Save the thumbnail to Zend::Cache
		//$args['cache']->save($file, $args['cacheItemId']);
    }
  private function _acceptIcs($args)
  {
		$config = Zend_Registry::get('config')->global;

		if(!isset($args['extendeddata']))
			return;

		require_once 'library/jQuery/jQuery.php';

		// its the main content type of the message which we have forced as an attachment
		$folderUTF7 = $args['extendeddata']['folder'];
		$tmpFolderBaseName = $args['extendeddata']['tmpFolderBaseName'];
		$partFilename = 'calendar' . $args['parentEmbeddedAttachmentPrefix'] . ($embeddedAttachmentPrefix) . '.ics';
		$partFilenameOriginal = $partFilename;
		$partFilenameFS = makeFSSafe( $folderUTF7 . $args['extendeddata']['uniqueId'] . $partFilename );

		$currentFolderUTF7UrlencodedDouble = urlencode( urlencode( $args['extendeddata']['requestParams']['folder'] ) );
		$filenameOriginalUrlencodedDouble = urlencode( urlencode( $args['extendeddata']['requestParams']['filenameOriginal'] ) );

		//$tempABSFilename = APP_ROOT . $tmpFolderBaseName . $folderUTF7 . $args['extendeddata']['uniqueId'] . $args['filename'];
		$md5Filename = md5($args['content']) . '.ics';
		$tempABSFilename = APP_ROOT . $tmpFolderBaseName . $md5Filename . '.ics';

    	$file = array();
    	$file['filename'] = $tempIcsFilename;
		$file['mimeType'] = "text/html";
		$file['content'] = file_get_contents($tempABSFilename);
		$userSettings = Zend_Registry::get('UserSettings');
		$userData = Zend_Auth::getInstance()->getStorage()->read();
		if(empty($userSettings['CalDavUser']))
			$CalDavUser = $userData['Account'];
		else
			$CalDavUser = $userSettings['CalDavUser'];
			
		if(empty($userSettings['CalDavPass']))
			$CalDavPass = $userData['password'];
		else
			$CalDavPass = $userSettings['CalDavPass'];
			
		$_calendar = new calendar(array('Type' => $userSettings['CalDavType'], 'URL' => $userSettings['CalDavUrl'], 'Account' => $CalDavUser, 'Password' => $CalDavPass, 'Calendar' => "calendar", 'home', 'largeInstall' => '0') );
		
		$_calendar->add_raw_record(ical_create_entry(ical_load_entry(array('data' => $file['content']))), "RW", $_calendar->username . '/calendar/');
		
		// TODO: Add language translation
		jQuery::evalScript("$('#action_buttons #back_button SPAN').html('Event <strong>Added</strong>');");
		jQuery::evalScript("$('#action_buttons #back_button').attr('onclick', '');");
		jQuery::evalScript("$('#action_buttons #back_button').bind('click', function() { alert('Event already added to calendar') });");
		
		
	}
}
