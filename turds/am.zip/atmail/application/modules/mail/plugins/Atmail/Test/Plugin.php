<?php

class Atmail_Test_Plugin extends Atmail_Controller_Plugin
{
    
    protected $_pluginFullName   = 'Test';
    protected $_pluginAuthor = 'Brad Kowalczyk <brad@staff.atmail.com>';
    protected $_pluginDescription = 'Simple plugin used by unit tests to verify plugin system is working';
    protected $_pluginCopyright = 'Copyright Brad Kowalczyk';
    protected $_pluginUrl = '';
    protected $_pluginNotes = '';
	protected $_pluginVersion = '1.0.0';
    protected $_pluginCompat = '6.1.5';
	protected $_pluginModule = 'mail';
    
	private $_loginPage = false;

    public function dispatchLoopStartup(Zend_Controller_Request_Abstract $request)
    {
        $request = $this->getRequest();
        if (($request->getControllerName() == 'index' && $request->getActionName() == 'index') ||
            ($request->getControllerName() == 'auth' && $request->getActionName() == 'logout')) {
            $this->_loginPage = true;
        }
    }

    public function postDispatch(Zend_Controller_Request_Abstract $request)
    {
        if ($this->_loginPage) {
            $page = $this->getResponse()->getBody();
            $page = str_replace("</body>", "<!-- plugins working -->\n</body>", $page);
            $this->getResponse()->setBody($page);
        }
    }
    
    
    public function setup()
    {
        $db = zend_Registry::get("dbAdapter");
        $db->query("drop table if exists `TestPluginSettings`");
        $db->query("create table `TestPluginSettings` (`id` int auto_increment primary key, `keyName` varchar(12), `keyValue` text, index `keyName` (`keyName`))");
    }
    
    public function setViewRenderScript()
    {
        //return "/path/to/nothing.phtml";
    }
    
    
    public function setViewRenderAction()
    {
    }
}

