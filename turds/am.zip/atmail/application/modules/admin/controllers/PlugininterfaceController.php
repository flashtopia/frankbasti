<?php

class Mail_PlugininterfaceController extends Zend_Controller_Action 
{

    public function init()
    {
        $this->_helper->viewRenderer->setNoRender(true);  
    }

    public function indexAction()
    {
        if(!Atmail_FormAuth::authenticated()) {
			return;
		}

        $req = $this->getRequest()->getParams();
        $plugin = $req["plugin"];
        $event = $req["event"];
	    unset($req["plugin"]);
	    unset($req["event"]);
        $plugin = Zend_Controller_Front::getInstance()->getPlugin($plugin);
        if ($plugin instanceof Atmail_Controller_Plugin && method_exists($plugin, $event)) {
            $result = $plugin->$event($req);
            if (is_string($result)) {
                echo $result;
            }
        }
    }

}
