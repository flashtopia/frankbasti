<?php
class Admin_UpdateController extends Zend_Controller_Action
{

	public function init()
	{
        $this->view->addHelperPath('library/Atmail/View/Helper/', 'Atmail_View_Helper');
		$this->log = Zend_Registry::get('log');

		$this->_helper->pluginCall('initAdminController', $this);
		 
		$this->request  = $this->getRequest();

		$this->view->baseUrl = $this->request->getBaseUrl();

		$this->view->appBaseUrl = $this->request->getBaseUrl() . (strpos($this->request->getBaseUrl(),'index.php')?'':'/index.php');

		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		$this->view->moduleBaseUrl = $this->view->appBaseUrl . ($this->request->module == 'default'?'':DIRECTORY_SEPARATOR . $this->request->module);
		$this->config = Zend_Registry::get('config');
		$this->dbAdapter = Zend_Registry::get('dbAdapter');
		$this->dbTables = new dbTables();

		require_once 'application/models/admin.php';
		$this->admin = new admin();

		if ($this->request->action == 'index' )
		{
			return;
		}

		$this->_helper->viewRenderer->setNoRender();

		if( !isset($this->view->errors) )
		{
			$this->view->errors = array();
		}

		if( !isset($this->view->notices) )
		{
			$this->view->notices = array();
		}

		if( !isset($this->view->jsonIdsToRender) )
		{
			$this->view->jsonIdsToRender = array();
		}

		require_once 'library/jQuery/jQuery.php';
		// TODO: Get the Username, Password and server API, pass to admin API
	}

	public function preDispatch()
	{

		// Check the session is active, otherwise redirect to the login page
		$this->view->userData = $this->admin->getCurrentAdminData();

		if( empty($this->view->userData) ) 
		{

			$this->_forward( 'timeout', 'index', 'default' );
			return;

		}

		$this->downloadFilename = ''; //'atmail6.mailserver.tgz';
		$this->downloadMD5Filename = ''; //'atmail6.mailserver.tgz.md5';
		$this->tmpDownloadLocation = '/tmp/';
		$this->updateHostBaseUrl = ''; //'http://atmail.com/download/';


	}

	/**
	* Display version and available update info
	*/
	public function indexAction()
	{
		$expiry = Zend_Registry::get('config')->reg['expiry'];
		if(time() > strtotime($expiry) && !empty($expiry))
			$this->view->licenseExpired = 1;

		//first check if new update code has already been unpacked over old code
		$this->view->versionCurrentDBSchema = $this->_getVersionCurrentDBSchema();
		$this->view->availableVersion = $this->_getAvailableVersion();
		$this->view->reg = $this->config->reg;
	}


	/**
	* SVN update for appliance edition
	*/
	public function svnupdateAction()
	{
		/*
		// do "svn update" for Appliances only
		if (file_exists("/usr/local/atmail/mailserver/bin/atmail-update-version")) 
		{
		
			$uname = escapeshellarg($this->config->reg['downloadId']);
			$pass = escapeshellarg($this->config->reg['serialKey']);
			$output = $return = null;
			exec("svn update --non-interactive --username=$uname --password=$pass /usr/local/atmail", $output, $return);
			if ($return != 0) 
			{
			
				// return error to browser
				jQuery('#dialog')->dialog('close');
				jQuery::addError( $this->view->translate("Error fetching latest version, please check your support expiry date. You may need to renew your support to be eligible for upgrades") );
				$this->render('global/jsonresponse', null, true);
				return;
			
			}
			
			$this->view->conflicts = array();
			foreach ($output as $line) 
			{
			
				// Look for any conflicts, rename new file to
				// replace the modified file
				if (preg_match("/^C\s+(.+)$/", $line, $m)) 
				{
				
					$this->view->conflicts[]= "{$m[1]}.mine";
					
					// Find files related to the conflict
					$files = glob("{$m[1]}.r*");
					
					// Get the name of the latest revision
					// and rename to original filename
					$latest = end(natsort($files));
					rename($latest, $m[1]);
					unset($files[$latest]);
					
					// Delete any other revisions (excluding the .mine backup)
					foreach($files as $f)
						unlink($f);

				}

			}
			
			if (file_exists("/usr/local/atmail/mailserver/bin/atmail-update-version") && !empty($this->view->conflicts))
				$this->view->jsonIdsToRender['updateProcessInstructions'] = 'update/conflicts.phtml'; 

			jQuery('#dialog')->dialog('close');                      

			jQuery::evalScript("$.php('" . $this->view->moduleBaseUrl . "/update/doversionupdate');"); 

			jQuery::evalScript("$('#dialog').html('<strong>Installing new version</strong><br />The server is automatically upgrading to the latest release. The process involves upgrading the database schema then installing any additional software. The process can take between <strong>2-10</strong> minutes depending on the size of the update.<br/><br /><div id=\'countdown\'></div>');"); 
			jQuery::evalScript("$('#countdown').countdown({until: +600, layout: 'Approximate time left %M%n %l%M, %S%n %l%S.'});"); 
			jQuery::evalScript("$('#dialog').dialog('open');"); 

			$this->render('global/jsonresponse', null, true); 
         
		}
		*/
    }

	/** 
	* Update the system to the latest version 
	*/ 
	public function doversionupdateAction() 
	{ 

		if( isset($this->config->global['demo']) &&  $this->config->global['demo'] == 1) 
		{ 

			throw new Exception('Disabled in demo'); 
		    
		}
		
		//first check if new update code has already been unpacked over old code
		$this->view->versionCurrentDBSchema = $this->_getVersionCurrentDBSchema();
		$this->view->versionCurrentLocalCodebase = $this->_getVersionCurrentLocalCodebase();
		$this->view->versionOrig = $this->view->versionCurrentDBSchema;

		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );
		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentLocalCodebase \n" . print_r($this->view->versionCurrentLocalCodebase, true) );

		//local code is unpacked as latest version so ready to proceed with db schema update prior to serving server-update script (if server install)

		/* db schema changes start here */
		//CONSIDER only upgrading one chunk at a time, and ending hit so ui get updated with each chunk complete.
		// this will allow easier diagnosis of chunk update failers and will stop gracefully at a specific version
		// NB do schema changes inside a transaction to allow gracefull failure without half updated schema for a specific version chunk

		// ********************************* 6.0.5 UPDATE ***************************************** //

		$versionChunk = '6.0.5';
		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') ) 
		{

			//<6.0.5 - 6.0.5
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Beginning schema update to " . $versionChunk );

			$this->dbAdapter->beginTransaction();

			try
			{
				$this->exceptionQuery('ALTER TABLE `Config` DROP INDEX `section`');
			}
			catch (Exception $e) {}	//ignore if didnt exist

			try
			{
				$this->exceptionQuery('RENAME TABLE `GROUPS` TO `CalGroups`');
			} 
			catch (Exception $e) {}	//ignore if didnt exist

			try
			{
				$this->exceptionQuery('RENAME TABLE `CALDAV` TO `CalDav`');
			}
			catch (Exception $e) {} //ignore if didnt exist

			try
			{
				$this->exceptionQuery('RENAME TABLE `SERVICE` TO `CalDavService`');
			}
			catch (Exception $e) {} //ignore if didnt exist

			try
			{
				$this->exceptionQuery('RENAME TABLE `ADDRESSES` TO `CalAddresses`');
			}
			catch (Exception $e) {} //ignore if didnt exist

			try
			{
				$this->exceptionQuery('ALTER TABLE CalDavService CHANGE COLUMN REALM Realm text');
			}
			catch (Exception $e) {} //ignore if didnt exist

			try
			{
				$this->exceptionQuery('ALTER TABLE CalGroups CHANGE COLUMN SHORT_NAME ShortName varchar(255)');
			}
			catch (Exception $e) {} //ignore if didnt exist

			try
			{
				$this->exceptionQuery('ALTER TABLE CalGroups CHANGE COLUMN MEMBER_RECORD_TYPE MemberRecordType text');
			}
			catch (Exception $e) {} //ignore if didnt exist

			try
			{
				$this->exceptionQuery('ALTER TABLE CalGroups CHANGE COLUMN MEMBER_SHORT_NAME MemberShortName text');
			}
			catch (Exception $e) {} //ignore if didnt exist

			try
			{
				$this->exceptionQuery('ALTER TABLE CalAddresses CHANGE COLUMN ADDRESS Address varchar(255)');
			}
			catch (Exception $e) {} //ignore if didnt exist

			try
			{
				$this->exceptionQuery('ALTER TABLE CalAddresses CHANGE COLUMN SHORT_NAME ShortName varchar(255)');
			}
			catch (Exception $e) {} //ignore if didnt exist

			//complile list of missing Abook entries and add them (needed for Admin external account list)
			try
			{
				$AccountUserSessions = $this->dbAdapter->select()->from('UserSession', array('Account'))->query()->fetchAll();
				$AccountAbooks = $this->dbAdapter->select()->from('Abook', array('Account'))->where('Global = 1')->query()->fetchAll();
				$missingAbooks = array();
				foreach( $AccountUserSessions as $AccountUserSession )
				{
					$missing = true;
					foreach( $AccountAbooks as $AccountAbook )
					{
						if( $AccountAbook['Account'] == $AccountUserSession['Account'] )
						{
							$missing = false;
							break;
						}
					}
					if( $missing )
					{
						$result = $this->dbAdapter->insert('Abook', array('Account' => $AccountUserSession['Account'],
						'UserEmail' => $AccountUserSession['Account'],
						'DateAdded' => new Zend_Db_Expr('NOW()'),
						'Global' => 1) );
					}
				}

				//$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$AccountUserSessions \n" . print_r($AccountUserSessions, true) );
				//$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$AccountAbooks \n" . print_r($AccountAbooks, true) );

			}
			catch (Exception $e) {} //ignore if didnt exist

			// Fix global "duplicate" Exim/DKIM settings
			try
			{
				$this->exceptionQuery('delete from Config where keyName="dkim_enable" and section="global"');
				$this->exceptionQuery('delete from Config where keyName="dkim_enable_outbound" and section="global"');
				$this->exceptionQuery('delete from Config where keyName="tlssmtp" and section="global"');
				$this->exceptionQuery('delete from Config where keyName="tlssmtp_remote" and section="global"');

			}
			catch (Exception $e) {} //ignore if didnt exist

			$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="groupwareenable"');
			if($row == "")
			{
				$result = $this->dbAdapter->insert('Config', array('keyName' => 'groupwareenable',
				'keyValue' => 'system',
				'section' => 'global',
				'keyType' => 'String'));
			}

			$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="sharedAbook"');
			if($row == "")
			{
				$result = $this->dbAdapter->insert('Config', array('keyName' => 'sharedAbook',
				'keyValue' => '1',
				'section' => 'global',
				'keyType' => 'String'));
			}

			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update to " . $versionChunk );

			// At this point db schema is upgraded to this version so save Version in db 
			// incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
			// do this just before commit so that a fail will roll back to a known schema version
			$this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");
			$this->view->versionCurrentDBSchema = $versionChunk;

			$this->dbAdapter->commit();
			$this->view->cliRequired = 1;
		}

		// ********************************* 6.0.6 UPDATE ***************************************** //

		$versionChunk = '6.0.6';
		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
		{
			// No schema changes for 6.0.6
			// No cli required
			// At this point db schema is upgraded to this version so save Version in db 
			// incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
			$this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");
			$this->view->versionCurrentDBSchema = $versionChunk;

		}

		// ********************************* 6.0.7 UPDATE ***************************************** //

		$versionChunk = '6.0.7';
		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
		{

			$this->view->cliRequired = 1;

			// insert default mail view value for webadmin
			try
			{
				$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="DefaultView"');
				if( $row == "" )
				{
					$this->exceptionQuery('insert into Config (section, keyName, keyValue, keyType) values ("defaultUserSettings", "DefaultView", "3p", "String")');
				}
			}
			catch (Exception $e) {}

			// add user default view
			try
			{
				try
				{
					$row = $this->dbAdapter->fetchOne('select DefaultView from UserSettings');
				}
				catch (Exception $e)
				{
					$row = "";
				}
				if( $row == "" )
				{
					$this->exceptionQuery('ALTER TABLE UserSettings add DefaultView varchar(2)');
				}

				$this->exceptionQuery('update UserSettings set DefaultView = "3p" where DefaultView is NULL or DefaultView = ""');
			}
			catch (Exception $e) {}

			// At this point db schema is upgraded to this version so save Version in db 
			// incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
			// do this just before commit so that a fail will roll back to a known schema version
			$this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");
			$this->view->versionCurrentDBSchema = $versionChunk;

		}

		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );


		// ********************************* 6.0.8 UPDATE ***************************************** //

		$versionChunk = '6.0.8';
		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
		{
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Beginning schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );

			$this->dbAdapter->beginTransaction();
			$this->view->cliRequired = 1;
			// insert default caldav type
			try
			{
				$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="CalDavType"');
				if( $row == "" )
				{
					$this->exceptionQuery('insert into Config (section, keyName, keyValue, keyType) values ("defaultUserSettings", "CalDavType", "at", "String")');
				}
			}
			catch (Exception $e) 
			{
				//throw exception here if failure of this point not allowed
			}

			try
			{
				$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="session_timeout"');
				if( $row == "" )
				{
					$this->exceptionQuery('insert into Config (section, keyName, keyValue, keyType) values ("global", "session_timeout", "120", "String")');
				}
			}
			catch (Exception $e) 
			{
				//throw exception here if failure of this point not allowed
			}

			// insert user
			try
			{
				try
				{
					$row = $this->dbAdapter->fetchOne('select CalDavType from UserSettings');
				}
				catch (Exception $e)
				{
					$row = "";
				}
				if( $row == "" )
				{
					$this->exceptionQuery('ALTER TABLE UserSettings add CalDavType varchar(2)');
				}
			}
			catch (Exception $e) {}

			try
			{
				$this->exceptionQuery('update UserSettings set CalDavType = "at" where CalDavType is NULL or CalDavType = ""');
				$this->exceptionQuery('update UserSettings set DefaultView = "3p" where DefaultView is NULL or DefaultView = ""');
				$this->exceptionQuery('update UserSettings set CalDavUrl = "http://localhost:8008/calendars/users/" where CalDavUrl is NULL or CalDavUrl = ""');
			}
			catch(Exception $e) 
			{


			}

			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );

			// At this point db schema is upgraded to this version so save Version in db 
			// incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
			// do this just before commit so that a fail will roll back to a known schema version
			$this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");
			$this->view->versionCurrentDBSchema = $versionChunk;

			$this->dbAdapter->commit();


		}

		// ********************************* 6.0.9 UPDATE ***************************************** //

		$versionChunk = '6.0.9';

		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
		{
			$this->view->cliRequired = 1;
			$this->dbAdapter->beginTransaction();

			try
			{
				$this->exceptionQuery('ALTER TABLE `MailRelay` change IPaddress IPaddress varchar(18)');
			}

			catch (Exception $e) {}	//ignore if didnt exist

			$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="virus_autoupdate"');
			if($row == "")
			{
				$result = $this->dbAdapter->insert('Config', array('keyName' => 'virus_autoupdate',
				'keyValue' => '1',
				'section' => 'exim',
				'keyType' => 'String'));
			}

			$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="spam_autoupdate"');
			if($row == "")
			{
				$result = $this->dbAdapter->insert('Config', array('keyName' => 'spam_autoupdate',
				'keyValue' => '1',
				'section' => 'exim',
				'keyType' => 'String'));
			}

			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );

			// At this point db schema is upgraded to this version so save Version in db 
			// incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
			// do this just before commit so that a fail will roll back to a known schema version
			$this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");
			$this->view->versionCurrentDBSchema = $versionChunk;

			$this->dbAdapter->commit();

		}

		// ********************************* 6.0.10 UPDATE ***************************************** //

		$versionChunk = '6.0.10';
		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
		{

			$this->view->cliRequired = 1;

			// At this point db schema is upgraded to this version so save Version in db 
			// incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
			// do this just before commit so that a fail will roll back to a known schema version
			$this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");
			$this->view->versionCurrentDBSchema = $versionChunk;

		}

		// ********************************* 6.0.11 UPDATE ***************************************** //

		$versionChunk = '6.0.11';
		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
		{

			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Beginning schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );
			$this->dbAdapter->beginTransaction();
			$this->view->cliRequired = 1;
			try
			{
				// purge duplicate admin users/groups
				$this->exceptionQuery('delete bad_rows.* from AdminGroup as good_rows inner join AdminGroup as bad_rows on bad_rows.Domain = good_rows.Domain and bad_rows.Username = good_rows.Username and bad_rows.id > good_rows.id');
				$this->exceptionQuery('delete bad_rows.* from AdminUsers as good_rows inner join AdminUsers as bad_rows on bad_rows.Username = good_rows.Username and bad_rows.Password = good_rows.Password and bad_rows.BrandDomain = good_rows.BrandDomain and bad_rows.id > good_rows.id');
			}

			catch (Exception $e) {}	//ignore if didnt exist

			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );

			// At this point db schema is upgraded to this version so save Version in db 
			// incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
			// do this just before commit so that a fail will roll back to a known schema version
			$this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");
			$this->view->versionCurrentDBSchema = $versionChunk;

			$this->dbAdapter->commit();

		}

		// ********************************* 6.1.0 UPDATE ***************************************** //

		$versionChunk = '6.1.0';

		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
		{

			$this->view->cliRequired = 1;

			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Beginning schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );
			$this->dbAdapter->beginTransaction();
			try
			{

				// add calendar extended data table
				$this->exceptionQuery('create table `calendarExtendedData` ( `Account` varchar(128) character set latin1 default NULL, `EntryID` varchar(64) default NULL, `ObjectId` varchar(64) default NULL, `id` mediumint(12) NOT NULL auto_increment, PRIMARY KEY (`id`))');

				$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="websyncEnabled"');
				if($row == "")
				{

					$result = $this->dbAdapter->insert('Config', array('keyName' => 'websyncEnabled', 'keyValue' => '1', 'section' => 'global', 'keyType' => 'String'));
					$result = $this->dbAdapter->insert('Config', array('keyName' => 'websyncEnabledShared', 'keyValue' => '1', 'section' => 'global', 'keyType' => 'String'));
					$result = $this->dbAdapter->insert('Config', array('keyName' => 'websyncEnabledGlobal', 'keyValue' => '1', 'section' => 'global', 'keyType' => 'String'));

				}

			}
			catch (Exception $e)
			{
				file_put_contents("php://stderr", "DB UPDATE FAILED");
			}

			//TODO: update all references to table names to use dbTables class
			$this->exceptionQuery('ALTER TABLE `AdminUsers` ADD `sessionData` TEXT NULL AFTER `Password`');
			$this->exceptionQuery('ALTER TABLE `AdminUsers` ADD `ipAddress` VARCHAR( 15 ) NULL AFTER `LastLogin`'); // standard Practice
			$this->exceptionQuery('ALTER TABLE `AdminUsers` ADD `modified` INT NULL AFTER `LastLogin`'); //used for gc UNIXTIMESTAMP GMT

			//Update User RealName to UTF-8
			$this->exceptionQuery('ALTER TABLE `UserSettings` CHANGE `RealName` `RealName` VARCHAR( 128 ) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL');  
			$this->exceptionQuery('ALTER TABLE `Abook` CHANGE `UserFirstName` `UserFirstName` VARCHAR( 128 ) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL');
			$this->exceptionQuery('ALTER TABLE `Abook` CHANGE `UserMiddleName` `UserMiddleName` VARCHAR( 128 ) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL');
			$this->exceptionQuery('ALTER TABLE `Abook` CHANGE `UserLastName` `UserLastName` VARCHAR( 128 ) CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL');

			$this->exceptionQuery('alter table UserSession change modified modified INT(11) unsigned not null default 0');
			$this->exceptionQuery('alter table UserSession change lifetime lifetime INT(11) unsigned not null default 0');

			// Next, insert max values for threads/sort
			try
			{

				$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="sortMaxLimit"');
				if($row == "")
				{

					$result = $this->dbAdapter->insert('Config', array('keyName' => 'sortMaxLimit', 'keyValue' => '30000', 'section' => 'global', 'keyType' => 'String'));
				}

				$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="threadingMaxLimit"');
				if($row == "")
				{

					$result = $this->dbAdapter->insert('Config', array('keyName' => 'threadingMaxLimit', 'keyValue' => '30000', 'section' => 'global', 'keyType' => 'String'));
				}


			}
			catch (Exception $e)
			{


			}

			// Next, add the new thread limit code
			try
			{

				$this->exceptionQuery('ALTER TABLE `UserSettings` ADD `ThreadLimit` tinyint(2) default 6 AFTER `CalDavType`'); 

			}
			catch (Exception $e) 
			{

				//throw exception here if failure of this point not allowed
			}

			try
			{
				// Update the filter_max_bodysize from boolean to string
				$this->exceptionQuery('update Config set keyType="string" where keyName="filter_max_bodysize"');

				$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="filter_max_bodysize"');
				if( $row == "1" )
				{
					$this->exceptionQuery('update Config set keyValue="50" where keyName="filter_max_bodysize"');
				}
			}
			catch (Exception $e) 
			{
				//throw exception here if failure of this point not allowed
			}

			//delete log files as may contain sensitive data, disable logging by default
			@unlink( APP_ROOT . 'log/debug.log');
			@unlink( APP_ROOT . 'log/error.log');
			@unlink( APP_ROOT . 'log/imap.log');


			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );

			// At this point db schema is upgraded to this version so save Version in db 
			// incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
			// do this just before commit so that a fail will roll back to a known schema version
			$this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");

			try
			{
				// ensure debug is turned off
				$this->exceptionQuery('delete from Config where keyName = "debug"');
			}
			catch (Exception $e)
			{
			}

			$this->view->versionCurrentDBSchema = $versionChunk;

			$this->dbAdapter->commit();


		}

		// ********************************* 6.1.1 UPDATE ***************************************** //

		$versionChunk = '6.1.1';

		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
		{
			$this->view->cliRequired = 1;
			$this->dbAdapter->beginTransaction();

			$this->exceptionQuery("alter table Domains modify Enable char(1) NOT NULL default '1'");
			$this->exceptionQuery("alter table Users modify UserStatus char(1) NOT NULL default '0'");
			//making this a db rule prevents the use case of configuring server install to allow logins to remote servers
			//$this->exceptionQuery("alter table Users modify MailDir varchar(255) NOT NULL default ''");
			$this->exceptionQuery("update Domains set Enable = 1 where (Enable is NULL or Enable='')");
		  
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );

			// At this point db schema is upgraded to this version so save Version in db 
			// incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
			// do this just before commit so that a fail will roll back to a known schema version
			$this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");
			$this->view->versionCurrentDBSchema = $versionChunk;

			$this->dbAdapter->commit();
		}


		// ********************************* 6.1.2 UPDATE ***************************************** //

		$versionChunk = '6.1.2';
		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
		{
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Beginning schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );
			$this->dbAdapter->beginTransaction();
			$this->view->cliRequired = 1;
			$this->exceptionQuery("ALTER TABLE `Users` CHANGE `MailDir` `MailDir` VARCHAR( 255 ) NULL");
			$this->exceptionQuery("ALTER TABLE `AdminUsers` ADD `UArchiveVault` TINYINT ( 1 ) NULL DEFAULT '0' AFTER `UAlias`");
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );

			// Update all AdminUsers, to reflect the NumQuota in MB vs the old Atmail 5 KB
			$adminusers = $this->dbAdapter->fetchAll('select id from AdminUsers where NumQuota > 0');

			foreach($adminusers as $adminuser) {
				// Select the existing NumQuota
				$quota = $this->dbAdapter->fetchOne('select NumQuota from AdminUsers where id = ' . $this->dbAdapter->quote($adminuser) );

				$quota = round($quota / 1024);

				$this->dbAdapter->update("AdminUsers", array('NumQuota' => $quota), "id=" . $this->dbAdapter->quote($adminuser) );

			}

			// Update the UserSession table for CalendarUserStatus support, used as a performance reference for the Calendar-server.
			$this->exceptionQuery("alter table UserSession add CalendarUserStatus int(1) NOT NULL default '0'");
				$disabled_domain_users = $this->dbAdapter->fetchAll('select Account from Users where UserStatus = "1"');
			foreach($disabled_domain_users as $user)
			{
				$this->dbAdapter->update('UserSession', array('CalendarUserStatus' => '1'), "Account = " . $this->dbAdapter->quote($user['Account']));
				list($username, $domain) = explode('@',$this->dbAdapter->quote($user['Account']), 2);
				$this->dbAdapter->update('UserSession', array('CalendarUserStatus' => '1'), "Account like " . $username . "-%@" . $domain );
			}
				$disabled_users = $this->dbAdapter->fetchAll('select Account from Users where UserStatus = "2"');
			foreach($disabled_users as $user)
			{
				$this->dbAdapter->update('UserSession', array('CalendarUserStatus' => '2'), "Account = " . $this->dbAdapter->quote($user['Account']));
				list($username, $domain) = explode('@',$this->dbAdapter->quote($user['Account']), 2);
				$this->dbAdapter->update('UserSession', array('CalendarUserStatus' => '2'), "Account like " . $username . "-%@" . $domain );
			}
			$this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");
			$this->view->versionCurrentDBSchema = $versionChunk;
			$this->dbAdapter->commit();
		}

		// ********************************* 6.1.3 UPDATE ***************************************** //

		$versionChunk = '6.1.3';
		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
		{
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Beginning schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );
			$this->dbAdapter->beginTransaction();
			$this->view->cliRequired = 1;

			//mail filtering changes
			$this->exceptionQuery("ALTER TABLE `UserSettings` ADD `SieveSupport` SMALLINT NOT NULL DEFAULT '0'");
			$rows = $this->dbAdapter->select()->from('Config')->where("`keyName` = 'enableMailFilters'")->query()->fetchAll();
			Zend_Registry::get('log')->debug( "\n" . print_r($rows, true) . "\n" . __METHOD__ . ' #' . __LINE__ . ": \$rows \n");

			if( $rows == null || $rows == false || count($rows) == 0)
			{

				$result = $this->dbAdapter->insert('Config', array('section' => 'exim', 'keyName' => 'enableMailFilters', 'keyValue' => '1', 'keyType' => 'Boolean') );

			}

			$this->dbAdapter->update('Config', array('keyType' => 'String'), "section = 'exim' AND keyName = 'filter_max_bodysize'");

			//update Config.version to this version stage
			$this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");

			try
			{
				$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="cssStyle"');
				if( $row == "" )
				{
					$this->exceptionQuery('insert into Config (section, keyName, keyValue, keyType) values ("global", "cssStyle", "Original", "String")');
				}
			}
			catch (Exception $e) 
			{
				//throw exception here if failure of this point not allowed
			}

			// Check URI DNS ability
			try
			{
				$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="filter_uridnsbl_servers"');
				if( $row == "" )
				{
					$this->exceptionQuery('insert into Config (section, keyName, keyValue, keyType) values ("exim", "filter_uridnsbl_servers", "multi.surbl.org", "String")');
				}
			}
			catch (Exception $e) 
			{
				//throw exception here if failure of this point not allowed
			}


			$this->view->versionCurrentDBSchema = $versionChunk;
			$this->dbAdapter->commit();
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );
		}


		// ********************************* 6.1.4 UPDATE ***************************************** //

		$versionChunk = '6.1.4';
		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
		{

			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Beginning schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );
			$this->dbAdapter->beginTransaction();
			$this->view->cliRequired = 1;
			
            //Abook UTF8 changes
			$this->dbAdapter->query("ALTER TABLE `" . $this->dbTables->AbookGroup . "` CHANGE `GroupName` `GroupName` VARCHAR( 128 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL");  
			$this->dbAdapter->query("ALTER TABLE `" . $this->dbTables->AbookGroupNames . "` CHANGE `GroupName` `GroupName` VARCHAR( 128 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL");
			//Update Groups table
			//upgrade dependant fields to same size as domain/hostname field
			$this->dbAdapter->query("ALTER TABLE `" . $this->dbTables->Users . "`  CHANGE `Ugroup` `Ugroup` VARCHAR( 255 ) NULL DEFAULT NULL");
			$this->dbAdapter->query("ALTER TABLE `" . $this->dbTables->UserSettings . "` CHANGE `Language` `Language` VARCHAR( 5 ) NULL DEFAULT NULL");
			$this->dbAdapter->query("ALTER TABLE `" . $this->dbTables->Groups . "` CHANGE `GroupName` `GroupName` VARCHAR( 255 ) NOT NULL");
			//provide a little more room for Group description
			$this->dbAdapter->query("ALTER TABLE `" . $this->dbTables->Groups . "` CHANGE `GroupDescription` `GroupDescription` VARCHAR( 255 ) NULL DEFAULT NULL");
			
			//add new AdminUsers fields
			$describeAdminUsers = $this->dbAdapter->query('DESCRIBE `' . $this->dbTables->AdminUsers . '`')->fetchAll();
			$adminUsersFields = array();
			foreach( $describeAdminUsers as $adminUsersField )
			{
                
				$adminUsersFields[] = $adminUsersField['Field'];

			}
			if( !in_array('Language', $adminUsersFields) )
			{
				
				$this->dbAdapter->query("ALTER TABLE `" . $this->dbTables->AdminUsers . "` ADD `Language` VARCHAR( 5 ) NULL ; ");
				
			}
			
			//add new Groups fields
			$describeGroups = $this->dbAdapter->query('DESCRIBE `' . $this->dbTables->Groups . '`')->fetchAll();
			
			$groupsFields = array();
			foreach( $describeGroups as $groupField )
			{
                
				$groupsFields[] = $groupField['Field'];

			}
			if( !in_array('GroupwareZone', $groupsFields) )
			{
				
				$this->dbAdapter->query("ALTER TABLE `" . $this->dbTables->Groups . "` ADD `GroupwareZone` VARCHAR( 6 ) NOT NULL DEFAULT 'Domain'");
				
			}

			if( !in_array('Webmail', $groupsFields) )
			{
				
				$this->dbAdapter->query("ALTER TABLE `" . $this->dbTables->Groups . "` ADD `Webmail` INT( 1 ) NOT NULL DEFAULT '1'");
				
			}

			if( !in_array('Calendar', $groupsFields) )
			{
				
				$this->dbAdapter->query("ALTER TABLE `" . $this->dbTables->Groups . "` ADD `Calendar` INT( 1 ) NOT NULL DEFAULT '1'");
				
			}

			if( !in_array('SharedAbook', $groupsFields) )
			{
				
				$this->dbAdapter->query("ALTER TABLE `" . $this->dbTables->Groups . "` ADD `SharedAbook` INT( 1 ) NOT NULL DEFAULT '1'");
				
			}	   
			if( in_array('GlobalAbook', $groupsFields) )
			{

				$this->dbAdapter->update($this->dbTables->Groups, array('GroupwareZone' => 'Off'), "GlobalAbook = 0");
				$this->dbAdapter->query("ALTER TABLE `" . $this->dbTables->Groups . "` DROP `GlobalAbook`");

			}
			//only add INDEX if not already and INDEX
			foreach( $describeGroups as $groupField )
			{
                
				if( $groupField['Field'] == 'POP3Support' && $groupField['Key'] != 'MUL' )                               
				{
					
					$this->dbAdapter->query("ALTER TABLE `" . $this->dbTables->Groups . "` ADD INDEX ( `POP3Support` )");
					
				}
				elseif( $groupField['Field'] == 'Webmail' && $groupField['Key'] != 'MUL' )                               
				{
					
					$this->dbAdapter->query("ALTER TABLE `" . $this->dbTables->Groups . "` ADD INDEX ( `Webmail` )");
					
				}
				elseif( $groupField['Field'] == 'IMAPSupport' && $groupField['Key'] != 'MUL' )                               
				{
					
					$this->dbAdapter->query("ALTER TABLE `" . $this->dbTables->Groups . "` ADD INDEX ( `IMAPSupport` )");
					
				}
				
			}
			
			//Add default group that domains without 'inherit' set will 'inherit' - by extracting settings from Config
			$configGlobal = $this->config->global;
			//set default settings based on server config.
			$defaultConfig = array(
									'GroupwareZone' => 'System', 
									'Webmail' => '1', 
									'Calendar' => ($configGlobal['calendarenable']=='on'?'1':'0'), 
									'SharedAbook' => ($configGlobal['sharedAbook']=='0'?'0':'1'), 
									'POP3Support' => 1, 
									'IMAPSupport' => 1, 
									'Sync' => ($configGlobal['websyncEnabled']=='1'?'1':'0'), 

									);
			//inset the default group/system group config before removing old config vars out of Config
			$result = $this->dbAdapter->query("INSERT IGNORE INTO " . $this->dbTables->Groups . " (`GroupName`, `GroupwareZone`, `Webmail`, `Calendar`, `SharedAbook`, `POP3Support`, `IMAPSupport`, `Sync`) values ('default', '" . $defaultConfig['GroupwareZone']  . "', '" . $defaultConfig['Webmail']  . "', '" . $defaultConfig['Calendar']  . "', '" . $defaultConfig['SharedAbook']  . "', '" . $defaultConfig['POP3Support']  . "', '" . $defaultConfig['IMAPSupport']  . "', '" . $defaultConfig['Sync']  . "')");
			
			//update all users and set them to belong to default group if not already set
			$result = $this->dbAdapter->query("UPDATE `" . $this->dbTables->Users . "` SET `Ugroup` = 'default' WHERE (`Ugroup` IS NULL or `Ugroup` = '' or `Ugroup` = 'Default')");
			$this->exceptionQuery("UPDATE `" . $this->dbTables->Users . "` SET `UserStatus` = 0 WHERE `UserStatus` IS NULL"); 
			$this->exceptionQuery("ALTER TABLE `" . $this->dbTables->Users . "` CHANGE `UserStatus` `UserStatus` INT( 1 ) NOT NULL DEFAULT '0'"); 
		 
			$this->exceptionQuery('update Config set keyValue="0" where keyName="allow_Signup"');
	
                        try
                        {
                                $smtpuser = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="smtpauth_username"');
                                $smtppass = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="smtpauth_password"');
                                $smtpauth = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="smtp_auth" and section="global"');
                                $smtpauthsection = $this->dbAdapter->fetchOne('select section from Config where keyName="smtp_auth" and section="global"');

								// SMTP auth flag is missing
								if(!empty($smtpuser) && !empty($smtppass) && empty($smtpauthsection)) {
                                    $this->dbAdapter->query('insert ignore into Config (section, keyName, keyValue, keyType) values ("global", "smtp_auth", "1", "String")');								
								} else if(empty($smtpuser) && empty($smtppass) && empty($smtpauthsection)) {
                                    $this->dbAdapter->query('insert ignore into Config (section, keyName, keyValue, keyType) values ("global", "smtp_auth", "0", "String")');								
								}
								
								// SMTP auth is on, update flag
								elseif(!empty($smtpuser) && !empty($smtppass)) {
                                    $this->dbAdapter->query('update Config set keyValue="1" where keyName="smtp_auth" and section="global"');
								} else if(empty($smtpuser) && empty($smtppass)) {
                                    $this->dbAdapter->query('update Config set keyValue="0" where keyName="smtp_auth" and section="global"');
								}
								
								// SMTP auth is off, update flag
								
                        }
                        catch (Exception $e)
                        {
                        }
			
			//TODO: do we drop the old config fields in this release or in next release when we know these changes are stable and no cascading problems with code relying on removed Config rows.
			
			$row = $this->dbAdapter->fetchOne('select keyValue from Config where section="admin" and keyName="password" and keyValue="md5"');
			if( $row == "" )
			{
				
				//switch all plain text passwords to md5
				$this->dbAdapter->update('AdminUsers', array('Password' => new Zend_Db_Expr('md5(Password)')));
				$this->dbAdapter->update('Config', array('keyValue' => 'md5'), "section = 'admin' AND keyName = 'password'");
				
			}
			
            $this->dbAdapter->query("update Config set keyName = concat('mail:', keyName) where section = 'plugins' and keyName not like 'mail:%'");
			
			@unlink("application/modules/mail/plugins/Atmail/MailOS.php");			
			@unlink("application/modules/mail/plugins/Atmail/FilePreview.php");         

            // expand the IPaddress column to 16 chars beacause as is (varchar(15)) it wont fit an address like 123.123.123.0/22
            $this->dbAdapter->query("alter table MailRelay modify IPaddress varchar(16) not null");
			
			// At this point db schema is upgraded to this version so save Version in db
			// incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
			// do this just before commit so that a fail will roll back to a known schema version
			$this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");

			
			$this->view->versionCurrentDBSchema = $versionChunk;
			$this->dbAdapter->commit();
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );

 	 	}


        // ********************************* 6.1.5 UPDATE ***************************************** //

		$versionChunk = '6.1.5';
		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
 	 	{
 	 		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Beginning schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );
			$this->dbAdapter->beginTransaction();
			
			// Set all user groups to default, if state is messed up
			$result = $this->dbAdapter->query("UPDATE `" . $this->dbTables->Users . "` SET `Ugroup` = 'default' WHERE (`Ugroup` IS NULL or `Ugroup` = '' or `Ugroup` = 'Default')");

			// Fix Default == default in schema
			$result = $this->dbAdapter->query("UPDATE Groups SET GroupName='default' where GroupName='Default'");

			// Delete any group names with '' , not allowed
			$result = $this->dbAdapter->query("delete from Groups where GroupName=''");
			
			// Set Ugroup to default in the schema
			$this->exceptionQuery("ALTER TABLE `" . $this->dbTables->Users . "` CHANGE `Ugroup` `Ugroup` varchar(255) NOT NULL DEFAULT 'default'"); 

			$this->dbAdapter->query("ALTER TABLE `" . $this->dbTables->Users . "` ADD INDEX ( `Ugroup` )");
			
            $this->view->versionCurrentDBSchema = $versionChunk;
			$this->dbAdapter->commit();
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );
        }
        
        
        // ********************************* 6.1.6 UPDATE ***************************************** //

		$versionChunk = '6.1.6';
		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
 	 	{
 	 		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Beginning schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );
			$this->dbAdapter->beginTransaction();

			// Delete duplicate smtp_auth setting
			$result = $this->dbAdapter->query("delete from Config where keyName = 'smtp_auth' and section = 'global'");
			
            $this->dbAdapter->query("DROP TABLE IF EXISTS `Plugins`");
			$this->dbAdapter->query("CREATE TABLE `Plugins` (
			  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
			  `module` varchar(8) NOT NULL,
			  `settings` text,
			  `status` tinyint(1) NOT NULL DEFAULT '1',
			  `name` varchar(64) NOT NULL,
			  `company` varchar(64) NOT NULL,
			  PRIMARY KEY (`id`),
			  KEY `module` (`module`),
			  KEY `status` (`status`)
			) ENGINE=MyISAM DEFAULT CHARSET=latin1;");
            
			$row = $this->dbAdapter->fetchOne('select name from Plugins where name="FilePreview"');
			if( empty($row) )
			{
	            $this->dbAdapter->insert('Plugins', array('module' => 'mail', 'status' => 1, 'name' => 'FilePreview', 'company' => 'Atmail'));
			}
			
			$row = $this->dbAdapter->fetchOne('select name from Plugins where name="Test"');
			if( empty($row) )
			{
	            $this->dbAdapter->insert('Plugins', array('module' => 'mail', 'status' => 1, 'name' => 'Test', 'company' => 'Atmail'));
			}
            
			$this->dbAdapter->query("delete from Config where section = 'plugins'");
			
			$this->dbAdapter->query("alter table UserSession modify SessionData MEDIUMTEXT");

			// add calendar extended data table

			$this->dbAdapter->query('drop table if exists `calendarExtendedData`');
			$this->dbAdapter->query('create table `calendarExtendedData` ( `Account` varchar(128) character set latin1 default NULL, `EntryID` varchar(64) default NULL, `ObjectId` varchar(64) default NULL, `id` mediumint(12) NOT NULL auto_increment, PRIMARY KEY (`id`))');
			$this->dbAdapter->query('alter table SharedLookup modify column LookupID varchar(128)');
            
			$describeGroups = $this->dbAdapter->query('DESCRIBE Groups')->fetchAll();
			$groupsFields = array();
			foreach( $describeGroups as $groupsField )
			{
                
				$groupsFields[] = $groupsField['Field'];

			}
			if( !in_array('WebSyncShared', $groupsFields) )
			{
				$this->exceptionQuery("ALTER TABLE Groups ADD `WebSyncShared` int(1) NOT NULL DEFAULT 1"); 
			}
			if( !in_array('WebSyncGlobal', $groupsFields) )
			{
				$this->exceptionQuery("ALTER TABLE Groups ADD `WebSyncGlobal` int(1) NOT NULL DEFAULT 1"); 
			}
			
			$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="websyncEnabledShared"');
			if($row == "")
			{
				$this->dbAdapter->query('delete from Config where keyName="websyncEnabledShared"');
			}

			$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="websyncEnabledGlobal"');
			if($row == "")
			{
				$this->dbAdapter->query('delete from Config where keyName="websyncEnabledGlobal"');
			}

			$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="websyncEnabled"');
			if($row == "")
			{
				$this->dbAdapter->query('delete from Config where keyName="websyncEnabled"');
			}
			
            $this->view->versionCurrentDBSchema = $versionChunk;
			$this->dbAdapter->commit();
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );
        }


		// ********************************* 6.1.7 UPDATE ***************************************** //

		$versionChunk = '6.1.7';
		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
		{

			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Beginning schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );

			$this->dbAdapter->beginTransaction();
			//Optional: Clear UserSession.SessionData to force users to log in again (for cached js changes etc.)
			$this->dbAdapter->update( $this->dbTables->UserSession, array('SessionData' => '') );

			//clean up external user accounts (remove password - only store in session data which gets destroyed when logout clicked.)
			//stitched off for now because 6.1.7 calendar needs password to auth 3rd party cal logins against
			//$this->dbAdapter->query("UPDATE " . $this->dbTables->UserSession . " SET Password = NULL WHERE SUBSTR(Account,INSTR(Account,'@')+1) NOT IN ( SELECT Hostname FROM " . $this->dbTables->Domains . " )");
			
			//$this->view->cliRequired = 1;
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );

			// At this point db schema is upgraded to this version so save Version in db
			// incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
			// do this just before commit so that a fail will roll back to a known schema version
			$this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");
			$this->view->versionCurrentDBSchema = $versionChunk;
			$this->dbAdapter->commit();

		}
		
		// ********************************* 6.1.8 UPDATE ***************************************** //

                $versionChunk = '6.1.8';
                $this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

                if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
                {
                        $this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Beginning schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );
                        $this->dbAdapter->beginTransaction();
                        $this->view->cliRequired = 1;

			//Optional: Clear UserSession.SessionData to force users to log in again (for cached js changes etc.)
			$this->dbAdapter->update( $this->dbTables->UserSession, array('SessionData' => '') );
			

			$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="userPasswordEncryptionType"');
			if($row == "")
			{
				$result = $this->dbAdapter->insert('Config', array('keyName' => 'userPasswordEncryptionType',
																   'keyValue' => 'PLAIN',
																   'section' => 'global',
																   'keyType' => 'String'));
			}
			
			//set up theme fields. 
			//NB: fields are currently ambiguous, cssSyle = Login theme, cssStyleTheme = main webmail theme
			
			// check that cssStyle and cssStyleTheme in Config
			$rows = $this->dbAdapter->select()->from($this->dbTables->Config)->where("section = 'global' AND keyName = 'cssStyle'")->query()->fetchAll();
			if( count($rows) == 0 )
			{

				$result = $this->dbAdapter->insert($this->dbTables->Config, array('section' => 'global',
																				  'keyName' => 'cssStyle',
																				  'keyValue' => 'original',
																				  'keyType' => 'String'));

			}
			$rows = $this->dbAdapter->select()->from($this->dbTables->Config)->where("section = 'defaultUserSettings' AND keyName = 'cssStyleTheme'")->query()->fetchAll();
			if( count($rows) == 0 )
			{

				$result = $this->dbAdapter->insert($this->dbTables->Config, array('section' => 'defaultUserSettings',
																				  'keyName' => 'cssStyleTheme',
																				  'keyValue' => 'Blue-Steel',
																				  'keyType' => 'String'));

			}
			
			//check for or insert with default UserSettings.cssStyle
			$describeUserSettings = $this->dbAdapter->query('DESCRIBE `' . $this->dbTables->UserSettings . '`')->fetchAll();
			$found = false;
			foreach( $describeUserSettings as $field )
			{
				
				if( $field['Field'] == 'cssStyleTheme' )
				{
					
					$found = true;
					break;
					
				}
				
			}
			if( !$found )
			{
				
				$this->exceptionQuery("ALTER TABLE `" . $this->dbTables->UserSettings . "` ADD cssStyleTheme varchar(64) CHARACTER SET utf8 NOT NULL default 'Blue-Steel'");
				$this->dbAdapter->update($this->dbTables->UserSettings, array('cssStyleTheme' => 'Blue-Steel'));
				
			}
			
			try
			{
				$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="themeEnabled"');
				if( $row == "" )
				{
					$this->exceptionQuery('insert into Config (section, keyName, keyValue, keyType) values ("global", "themeEnabled", "1", "Boolean")');
				}
			
			}
			catch (Exception $e) {}
			
			
			// insert default carddav value
			try
			{
				$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="CardDavUrl"');
				if( $row == "" )
				{
					$this->exceptionQuery('insert into Config (section, keyName, keyValue, keyType) values ("defaultUserSettings", "CardDavUrl", "http://localhost:8800", "String")');
					$this->exceptionQuery('insert into Config (section, keyName, keyValue, keyType) values ("defaultUserSettings", "ViewCardDav", "0", "String")');
				}
			}
			catch (Exception $e) {}
			
			//clean up old, redundant sql fields (how can you access these args if you dont have them)
			try{
				$this->exceptionQuery('delete from Config where keyName = "sql_host";');
			} catch (Exception $e) {}
			try{
				$this->exceptionQuery('delete from Config where keyName = "sql_user";');
			} catch (Exception $e) {}
			try{
				$this->exceptionQuery('delete from Config where keyName = "sql_pass";');
			} catch (Exception $e) {}
			try{
				$this->exceptionQuery('delete from Config where keyName = "sql_table";');
			} catch (Exception $e) {}
			system("chmod 0660 " . APP_ROOT . "config/dbconfig.ini");
				
			$this->dbAdapter->query("DROP TABLE IF EXISTS `AbookServers`");
			$this->dbAdapter->query("CREATE TABLE `AbookServers` (
			  `Account` varchar(128) NOT NULL default '',
			  `username` varchar(128) character set utf8 default NULL,
			  `password` varchar(128) character set utf8 default NULL,
			  `server` varchar(256) character set utf8 default NULL,
			  `port` int(6) NOT NULL default '8800',
			  `url` text character set utf8 default NULL,
			  `protocol` varchar(7) NOT NULL default 'carddav',
			  `id` mediumint(8) unsigned NOT NULL auto_increment,
			  PRIMARY KEY  (`id`),
			  KEY `iAccount` (`Account`)
			) ENGINE=MyISAM DEFAULT CHARSET=latin1;");


			try
			{
				try
				{
					$row = $this->dbAdapter->fetchOne('select Carddav from Groups');
				}
				catch (Exception $e)
				{
					$row = "";
				}
				if( $row == "" )
				{
					$this->exceptionQuery('ALTER TABLE Groups add Carddav int(1) default 1');
				}
			}
			catch (Exception $e) 
			{
				
			}

			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );

			// At this point db schema is upgraded to this version so save Version in db
			// incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
			// do this just before commit so that a fail will roll back to a known schema version
			$this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");
			$this->view->versionCurrentDBSchema = $versionChunk;
			$this->dbAdapter->commit();
		}

		// ********************************* 6.1.9 UPDATE ***************************************** //
 
                $versionChunk = '6.1.9';
                $this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

                if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
 	 	{
                        $this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Beginning schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );
                        $this->dbAdapter->beginTransaction();
                        $this->view->cliRequired = 1;
                        $this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );

                        // At this point db schema is upgraded to this version so save Version in db
                        // incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
                        // do this just before commit so that a fail will roll back to a known schema version
                        $this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");
                        $this->view->versionCurrentDBSchema = $versionChunk;
                        $this->dbAdapter->commit();
 	 	}

		// ********************************* 6.20 UPDATE ***************************************** //
 
                $versionChunk = '6.20';
                $this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

                if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
 	 	{
                        $this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Beginning schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );
                        $this->dbAdapter->beginTransaction();
                        $this->view->cliRequired = 1;
                        $this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );

						// Update the new SerialConf
						try
						{
							$this->exceptionQuery('ALTER TABLE `SerialConf` change `Value` `Value` longtext;');
						}
						catch (Exception $e) {}	//ignore if didnt exist
						
						// Convert SerialConf to InnoDB for performance
						try
						{
							$this->exceptionQuery('ALTER TABLE `SerialConf` TYPE=INNODB');
						}
						catch (Exception $e) {}	//ignore if didnt exist

						// Update all Subadmins with logs, unless specifically turned off ( NULL , if 0 turned off by admin previously )
						try
						{
							$this->exceptionQuery('update AdminUsers set ULogs="1" where ULogs is null');
						}
						catch (Exception $e) {}	//ignore if didnt exist
						
						// Delete duplicate entries in Plugins ( can cause issues from running upgrade multiple times )
						try
						{
							$this->exceptionQuery('DELETE t1 FROM Plugins t1, Plugins t2 WHERE t1.name=t2.name AND t1.id < t2.id');
						}
						catch (Exception $e) {}	//ignore if didnt exist
                        $this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );

                        // At this point db schema is upgraded to this version so save Version in db
                        // incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
                        // do this just before commit so that a fail will roll back to a known schema version
                        $this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");
                        $this->view->versionCurrentDBSchema = $versionChunk;
                        $this->dbAdapter->commit();
 	 	}

		// ********************************* 6.20.1 UPDATE ***************************************** //
 
                $versionChunk = '6.20.1';
                $this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

                if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
 	 	{
                        $this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Beginning schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );
                        $this->dbAdapter->beginTransaction();
                        //$this->view->cliRequired = 1;
                        $this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );

                        // At this point db schema is upgraded to this version so save Version in db
                        // incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
                        // do this just before commit so that a fail will roll back to a known schema version
                        $this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");
                        $this->view->versionCurrentDBSchema = $versionChunk;
                        $this->dbAdapter->commit();
 	 	}

		// ********************************* 6.20.2 UPDATE ***************************************** //

		$versionChunk = '6.20.2';
		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
		{
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Beginning schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );
			$this->dbAdapter->beginTransaction();
			
			$this->ignorableQuery("ALTER TABLE `" . $this->dbTables->AdminUsers . "` ADD EmailAddress varchar(128) NULL default NULL AFTER Fullname");
			$this->ignorableQuery('update ignore UserSession set Account = replace(Account, "@", "") where account like "%-%@"');

			$this->ignorableQuery("ALTER TABLE `UserSettings` ADD ThreadLimit tinyint default 6");
			try
			{
				$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="ThreadLimit"');
				if( $row == "" )
				{
					$this->ignorableQuery('insert into Config (section, keyName, keyValue, keyType) values ("defaultUserSettings", "ThreadLimit", 6, "Integer")');
				}
			}
			catch (Exception $e) {}

			// make sure everyone is on the same page :)
			$this->ignorableQuery("alter table AbookGroup modify GroupName varchar(128) character set utf8 default NULL");
			
			$this->ignorableQuery("alter table Abook modify UserFirstName varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserMiddleName varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserLastName varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserTitle varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserHomeAddress varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserHomeCity varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserHomeState varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserHomeZip varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserHomeCountry varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserWorkCompany varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserWorkTitle varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserWorkDept varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserWorkOffice varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserWorkAddress varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserWorkCity varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserWorkState varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserWorkZip varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserWorkCountry varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table Abook modify UserInfo varchar(128) character set utf8 default NULL");
			
			$this->ignorableQuery("alter table AbookGroupNames modify GroupName varchar(128) character set utf8 default NULL");
			
			$this->ignorableQuery("alter table AdminGroup modify Ugroup varchar(64) character set utf8 default NULL");

			$this->ignorableQuery("alter table AdminUsers modify Username varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table AdminUsers modify Password varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table AdminUsers modify Company varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table AdminUsers modify Fullname varchar(128) character set utf8 default NULL");
		
			$this->ignorableQuery("alter table Config modify keyValue varchar(256) character set utf8 default NULL");
			$this->ignorableQuery("alter table Config modify keyType varchar(8) default NULL");

			$this->ignorableQuery("alter table Groups modify GroupName varchar(255) character set utf8 NOT NULL default ''");
			$this->ignorableQuery("alter table Groups modify GroupDescription varchar(255) character set utf8 default NULL");

			$this->ignorableQuery("alter table UserSession modify Password varchar(64) character set utf8 default NULL");
			$this->ignorableQuery("alter table UserSession modify SessionData mediumtext character set utf8");

			$this->ignorableQuery("alter table UserSettings modify RealName varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table UserSettings modify ReplyTo varchar(128) character set utf8 default NULL");
			$this->ignorableQuery("alter table UserSettings modify Signature text character set utf8");
			$this->ignorableQuery("alter table UserSettings modify cssStyleTheme varchar(64) character set utf8 NOT NULL default 'Blue-Steel'");

			$this->ignorableQuery("alter table Users modify PasswordQuestion varchar(256) character set utf8 default NULL");
			$this->ignorableQuery("alter table Users modify Ugroup varchar(255) character set utf8 default 'default'");
			$this->ignorableQuery("alter table Users modify AutoReply text character set utf8");
			$this->ignorableQuery("alter table Users modify Forward varchar(128) character set utf8 default NULL");
			
			$this->ignorableQuery("update Users set Ugroup = 'default' where (select count(*) from Groups where Ugroup = GroupName) = 0");
			$this->ignorableQuery("update Users set Ugroup = 'default' where Ugroup = 'Default'");
			$this->ignorableQuery("update Config set keyValue = 'Blue-Steel' where keyName = 'cssStyleTheme' and keyValue = 'blue-steel'");
			$this->ignorableQuery("update UserSettings set cssStyleTheme = 'Blue-Steel' where cssStyleTheme = 'blue-steel'");

			// Fix the broken spam-score value
			$this->ignorableQuery("update SpamSettings set value='20' where preference='required_score' and value='Disabled'");
			$this->ignorableQuery("update SpamSettings set value='2' where preference='required_score' and value='Minimal'");
			$this->ignorableQuery("update SpamSettings set value='3' where preference='required_score' and value='Low'");
			$this->ignorableQuery("update SpamSettings set value='4' where preference='required_score' and value='Normal'");
			$this->ignorableQuery("update SpamSettings set value='6' where preference='required_score' and value='High'");
			$this->ignorableQuery("update SpamSettings set value='15' where preference='required_score' and value='Max'");
						
			$this->view->cliRequired = 1;
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );

			// At this point db schema is upgraded to this version so save Version in db
			// incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
			// do this just before commit so that a fail will roll back to a known schema version
			$this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");
			$this->view->versionCurrentDBSchema = $versionChunk;
			$this->dbAdapter->commit();
		} 

		// ********************************* 6.20.3 UPDATE ***************************************** //

		$versionChunk = '6.20.3';
		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
		{
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Beginning schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );
			$this->dbAdapter->beginTransaction();
			$this->view->cliRequired = 1;

			$this->ignorableQuery("update SpamSettings set value='20' where preference='required_score' and value='Disabled'");


			try
			{
				$row = $this->dbAdapter->fetchOne('select distinct true from Config where (select true from Config where keyName = "remoteServersOverwrite" and keyValue = 0) and (select true from Config where keyName = "remoteServers" and keyValue = "")');
				if( $row == 1 )
				{
					$this->ignorableQuery('update Config set keyValue = 1 where keyName = "remoteServersOverwrite"');
				}
			}
			catch (Exception $e) {}
			
			$this->ignorableQuery('update Config set keyType = "Array" where keyName = "remoteServers" and keyType = "String"');
		        
		        // expand the IPaddress column to 16 chars beacause as is (varchar(15)) it wont fit an address like 123.123.123.0/22
            		$this->ignorableQuery("alter table MailRelay modify IPaddress varchar(16) not null");

			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );



			// At this point db schema is upgraded to this version so save Version in db
			// incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
			// do this just before commit so that a fail will roll back to a known schema version
			$this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");
			$this->view->versionCurrentDBSchema = $versionChunk;
			$this->dbAdapter->commit();
		} 

		// ********************************* 6.20.4 UPDATE ***************************************** //

		$versionChunk = '6.20.4';
		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		if( version_compare($this->view->versionCurrentDBSchema, $versionChunk, '<') )
		{
			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Beginning schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );
			$this->dbAdapter->beginTransaction();
			$this->view->cliRequired = 1;
			
			$this->insertConfig("global", "autocompleteFetchThreshold", 50, "Integer");
			$this->insertConfig("global", "autocompleteCacheSize", 100, "Integer");
			$this->insertConfig("global", "autocompleteFetchSize", 25, "Integer");
			$this->insertConfig("global", "autocompleteMinFetchLength", 2, "Integer");

			$this->insertConfig("global", "log_purge_days", 180, "Integer");
			$this->insertConfig("exim", "filter_awl_purge_low", 7, "Integer");
			$this->insertConfig("exim", "filter_awl_purge_medium", 14, "Integer");
			$this->insertConfig("exim", "filter_awl_purge_high", 30, "Integer");

			$this->insertConfig("global", "ActiveSyncCacheLifespan", 14, "Integer");
			
			$this->ignorableQuery('alter table Abook modify Global tinyint(1) not null default 0');
			$this->ignorableQuery('alter table Abook modify Shared tinyint(1) not null default 0');

			$this->ignorableQuery('alter table Abook add column Favourite tinyint(1) default NULL');
			$this->ignorableQuery('alter table Abook add column UsageCount int default 0 not null');
			$this->ignorableQuery('alter table AbookGroup modify GroupID mediumint(12) default NULL');
			$this->ignorableQuery('update UserSettings set CalDavUrl = "http://localhost:8008/calendars/users/" where CalDavUrl is NULL or CalDavUrl = ""');

			$this->ignorableQuery('delete from Config where keyName = "calendarenable" and section = "global"');
			$this->ignorableQuery("update UserSession LEFT JOIN Users on Users.Account = (IF ( position('@' in SUBSTRING_INDEX(UserSession.Account, '-', 1)) = 0 , CONCAT( SUBSTRING_INDEX( UserSession.Account, '-', 1), '@', SUBSTRING_INDEX(UserSession.Account, '@', -1) ), UserSession.Account)) LEFT JOIN Groups ON Users.Ugroup = GroupName  LEFT JOIN Domains ON HostName = SUBSTRING_INDEX(Users.Account, '@', -1) set CalendarUserStatus = !((select Calendar from Groups where GroupName = 'default') && IFNULL(Calendar, 0) && IFNULL(Enable,1) && !IFNULL(UserStatus, 0))");

			$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": Finished schema update from " . $this->view->versionCurrentDBSchema . " to " . $versionChunk );

			// At this point db schema is upgraded to this version so save Version in db
			// incase lower/future/next updates fail then at lease we know up which point it succeeded and at what state the dbschema is at
			// do this just before commit so that a fail will roll back to a known schema version
			$this->dbAdapter->update('Config', array('keyValue' => $versionChunk), "section = 'global' AND keyName = 'version'");
			$this->view->versionCurrentDBSchema = $versionChunk;
			$this->dbAdapter->commit();
		}

		

		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );

		/* end db schema changes */
		if( version_compare($this->view->versionCurrentDBSchema, $this->view->versionCurrentLocalCodebase, '==' ) )
		{
			
			jQuery::addMessage( $this->view->translate('Database schema update complete.') );
			jQuery('#versionCurrentDBSchema')->html($this->view->versionCurrentDBSchema);
			jQuery('#versionUpdateButtonArea')->html('<p>' . $this->view->translate('You are up to date with the latest version available.') . '</p>');
			
			//give additional instructions if server install
			
			if( $this->config->global['install_type'] == 'server' && $this->view->cliRequired == 1 )
			{
                // If we're an appliance, just auto run the CLI script
                if (file_exists("/usr/local/atmail/mailserver/bin/atmail-update-version")) {
                	`/usr/local/atmail/mailserver/bin/atmail-update-version {$this->view->versionOrig} server`;

					// Check return code
					jQuery::addMessage( $this->view->translate('New version downloaded, database schema upgraded and new version installed') );
					
               	} else {
					$this->view->jsonIdsToRender['updateProcessInstructions'] = 'update/updateserverinstructions.phtml';
				}
			}
			elseif( $this->view->cliRequired )
			{
				
				// If we're an appliance, just auto run the CLI script
                if (file_exists("/usr/local/atmail/mailserver/bin/atmail-update-version")) {
                	`/usr/local/atmail/mailserver/bin/atmail-update-version {$this->view->versionOrig} client`;
				} else {
					$this->view->jsonIdsToRender['updateProcessInstructions'] = 'update/updateclientinstructions.phtml';
				}
			}

		}
		else
		{

			jQuery::addError( $this->view->translate('Database update did not complete.') . ' Current version: ' . $this->view->versionCurrentDBSchema . ' Available version: ' . $this->view->versionCurrentLocalCodebase );

		}

		// Close the upgrade dialog if using the appliance version
		//if (file_exists("/usr/local/atmail/mailserver/bin/atmail-update-version"))
		
		// Close the dialog-box on the upgrade window
		jQuery('#dialog')->dialog('close');
		
		$this->render('global/jsonresponse', null, true);

	}

	private function _getVersionCurrentLocalCodebase()
	{

		if (false !== $version = file_get_contents( APP_ROOT . '.VERSION') )
		{

			return trim($version);

		}
		else
		{

			return false;

		}

	}

	/**
	* Get current version number
	*
	* @return String|False
	*/
	private function _getVersionCurrentDBSchema()
	{

		return $this->config->global['version'];

	}


	/**
	 * Get current available Atmail version
	 *
	 * @return String
	 */
	 
	private function _getAvailableVersion()
	{
		// If an appliance we want to get latest version available via SVN
		if (file_exists("/usr/local/atmail/mailserver/bin/atmail-update-version")) {
			return $this->_getCurrentVersionSvn();
		} else {
			return $this->_getVersionCurrentLocalCodebase();
		}
	}


	/**
	 * Get latest SVN version (for appliances only)
	 *
	 * @return String
	 */
	private function _getCurrentVersionSvn()
	{
		$resp = file_get_contents("http://atmail.com/latestversion.php");
		list($latestVersion,) = explode("|", $resp);
		return $latestVersion;
	}
	
	
	/**
	* Try a query, wrap in an exception, to avoid an error
	*
	*/
	private function exceptionQuery($sql)
	{

		try {

			$this->dbAdapter->query($sql);

		} catch (Exception $e) 
		{
			file_put_contents("php://stderr", "Query failed: $sql\n");
		}

	}
	
	private function ignorableQuery($q)
	{
		
		try { $this->dbAdapter->query($q); }
		catch( Exception $e ) {}
		
	}
	
	private function insertConfig($section, $keyName, $keyValue, $keyType)
	{
		try
		{
			$row = $this->dbAdapter->fetchOne('select keyValue from Config where keyName="' . $keyName . '"');
			if( $row == "" )
			{
				if($keyType == 'Integer')
				{
					$this->ignorableQuery('insert into Config (section, keyName, keyValue, keyType) values ("' . $section . '", "' . $keyName . '", ' . $keyValue . ', "' . $keyType . '")');
				}
				else
				{
					$this->ignorableQuery('insert into Config (section, keyName, keyValue, keyType) values ("' . $section . '", "' . $keyName . '", "' . $keyValue . '", "' . $keyType . '")');					
				}
			}
			
	}
	catch (Exception $e)
	{
		file_put_contents("php://stderr", 'Failed to insert ("' . $section . '", "' . $keyName . '", "' . $keyValue . '", "' . $keyType . '") into Config table.\n');
	}

}

}