<?php

class Atmail_TestPlugin1_Plugin extends Atmail_Controller_Plugin
{
    
    protected $_pluginFullName   = 'Test Plugin 1';
    protected $_pluginAuthor = 'Brad Kowalczyk <brad@staff.atmail.com>';
    protected $_pluginDescription = 'Simple plugin used by unit tests to verify plugin system is working';
    protected $_pluginCopyright = 'Copyright Brad Kowalczyk';
    protected $_pluginUrl = '';
    protected $_pluginNotes = '';
    protected $_pluginVersion = '1.0.0';
    protected $_pluginCompat = '6.1.6';
    protected $_pluginModule = 'mail';
    
    private $_loginPage = false;
	
    public function dispatchLoopStartup()
    {
        $request = $this->getRequest();
        if (($request->getControllerName() == 'index' && $request->getActionName() == 'index') ||
            ($request->getControllerName() == 'auth' && $request->getActionName() == 'logout')) {
            $this->_loginPage = true;
        }
    }

    public function postDispatch(Zend_Controller_Request_Abstract $request)
    {
        if ($this->_loginPage) {
            $page = $this->getResponse()->getBody();
            $page = str_replace("</body>", "<!-- Atmail TestPlugin1 working -->\n</body>", $page);
            $this->getResponse()->setBody($page);
        }
    }
}
