<?php

class Atmail_RedirectLogout_Plugin extends Atmail_Controller_Plugin
{
    
    // Only supports PDF previews atm
    private   $_supportedFileTypes = array('pdf');

    protected $_pluginFullName   = 'Logout Redirector';
    protected $_pluginAuthor = 'Brad Kowalczyk <brad@staff.atmail.com>';
    protected $_pluginDescription = 'Redirects on logout to a specified URL';
    protected $_pluginCopyright = 'Copyright (c) NetBased Software Pty Ltd';
    protected $_pluginUrl = '';
	protected $_pluginCompat = '6.1.2';
	protected $_pluginNotes = 'You must modify this Plugin.php to change the URL that the browser gets redirected to on logout';
    protected $_pluginVersion = '1.0.0';
    protected $_pluginModule = 'mail';
	protected $logoutURL = 'http://www.atmail.com';
    
    public function __construct()
    {
        // Set PHP extension deps
        //$this->_setDependencies(array('gd'));

		$this->log = Zend_Registry::get('log');
		parent::__construct();
    }
    
    public function dispatchLoopStartup()
    {
        $request = $this->getRequest();
		$this->_logoutRedirect = false;
		if ( $request->getControllerName() == 'auth' && $request->getActionName() == 'logout' ) 
		{
        
    		$this->_logoutRedirect = true;

        }

    }

    public function postDispatch(Zend_Controller_Request_Abstract $request)
    {
        if ($this->_logoutRedirect) {
            $page = $this->getResponse()->getBody();
            $page = str_replace("</body>", "<script>location.href = '" . addslashes($this->logoutURL) . "'</script></body>", $page);
            $this->getResponse()->setBody($page);
        }
    }
 
  
}
