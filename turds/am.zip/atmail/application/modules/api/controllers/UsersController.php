<?php
class Api_UsersController extends Zend_Controller_Action 
{
	
	public function init()
	{

		//TODO: extend authentication to support multiple user levels/roles/groups 
		require_once 'application/models/api.php';
		$this->api = new api();
		
		$this->view->baseUrl = $this->_request->getBaseUrl();
		$this->view->appBaseUrl = $this->_request->getBaseUrl() . (strpos($this->_request->getBaseUrl(),'index.php')?'':'/index.php');
		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		$this->view->moduleBaseUrl = $this->view->appBaseUrl . ($this->_request->module == 'default'?'':DIRECTORY_SEPARATOR . $this->_request->module);
		
		$this->_helper->viewRenderer->setNoRender();
		
		$this->restserver = new Zend_Rest_Server();
		$this->restserver->setClass('api');
		
		if( !Atmail_HttpAuth::authenticated(3, null, 'admin', null) )
			$this->_forward('authenticationfailed');
		
		$this->APIArgs = $this->getRequest()->getParams();
		
		//check and convert rest call args
		if( 
			count($this->APIArgs) == 5 && 
			array_key_exists('rest', $this->APIArgs) && 
			$this->APIArgs['rest'] == 1 && 
			array_key_exists('module', $this->APIArgs) && 
			array_key_exists('controller', $this->APIArgs) && 
			array_key_exists('action', $this->APIArgs)  
		)
			$this->APIArgs = $this->APIArgs[0];
			
		unset($this->APIArgs['action']);
		unset($this->APIArgs['module']);
		unset($this->APIArgs['controller']);
		
		$this->log = Zend_Registry::get('log');
	} 

	public function authenticationfailedAction()
	{

		//just an empty deadend so failed XML responses are uniform
		$this->restserver->handle( array('method' => 'authenticationFailed') ); 

	}
	
	public function authenticateAction()
	{

		$params = $this->getRequest()->getParams();
		$this->restserver->handle( array('method' => 'authenticate', 'username' => $_SERVER["PHP_AUTH_USER"], 'password' => $_SERVER["PHP_AUTH_PW"]) );

	}
	
	public function indexAction()
	{

        $this->restserver->handle( array('method' => 'index') );

	}
	
	public function createAction()
	{
		
		$params['method'] = 'userCreate';
        $params['args'] = $this->APIArgs;
		$this->restserver->handle($params);

	}
	
	public function viewAction()
	{

		$params = $this->getRequest()->getParams();
		$params['method'] = 'userView';		
		$this->restserver->handle($params);

	}
	
	public function listAction()
	{

		$params = $this->getRequest()->getParams();
		$params['method'] = 'userList';
		$this->restserver->handle($params);

	}	

	public function updateAction()
	{

		$params['method'] = 'userUpdate';
		$params['args'] = $this->APIArgs;
		
		$this->restserver->handle($params);

	}

	public function deleteAction()
	{

		$params = $this->getRequest()->getParams();
		$params['method'] = 'userDelete';		
		$this->restserver->handle($params);

	}
	
	public function newmessagescountAction()
	{
		
		$params = $this->getRequest()->getParams();
		$params['method'] = 'userMessagesCount';
		$this->restserver->handle($params);
		
	}	
}
