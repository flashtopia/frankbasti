<?php
class Api_AliasesController extends Zend_Controller_Action 
{
	
	public function init()
	{

		//TODO: extend authentication to support multiple user levels/roles/groups 
		require_once 'application/models/api.php';
		$this->api = new api();
		
		$this->view->baseUrl = $this->_request->getBaseUrl();
		$this->view->appBaseUrl = $this->_request->getBaseUrl() . (strpos($this->_request->getBaseUrl(),'index.php')?'':'/index.php');
		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		$this->view->moduleBaseUrl = $this->view->appBaseUrl . ($this->_request->module == 'default'?'':DIRECTORY_SEPARATOR . $this->_request->module);
		
		$this->_helper->viewRenderer->setNoRender();
		
		$this->restserver = new Zend_Rest_Server();
		$this->restserver->setClass('api');
		
		if( !Atmail_HttpAuth::authenticated(3, null, 'admin', null) )
			$this->_forward('authenticationfailed');
		$this->APIArgs = $this->getRequest()->getParams();
		unset($this->APIArgs['action']);
		unset($this->APIArgs['module']);
		unset($this->APIArgs['controller']);
			
	} 

	public function authenticationfailedAction() {

		//just an empty deadend so failed XML responses are uniform
		$this->restserver->handle( array('method' => 'authenticationFailed') ); 

	}
	
	public function authenticateAction() {

		$params = $this->getRequest()->getParams();
		$this->restserver->handle( array('method' => 'authenticate', 'username' => $_SERVER["PHP_AUTH_USER"], 'password' => $_SERVER["PHP_AUTH_PW"]) );

	}
	
	public function indexAction() {

        $this->restserver->handle( array('method' => 'index') );

	}
	
	public function createAction() {
		
		$params['method'] = 'aliasesCreate';
        $params['args'] = $this->APIArgs;
		$this->restserver->handle($params);

	}
	
	public function viewAction() {

		$params['method'] = 'aliasesView';		
		$params['args'] = $this->APIArgs;
		$this->restserver->handle($params);

	}
	
	public function listAction() {

		$params = $this->getRequest()->getParams();
		$params['method'] = 'aliasesList';
		$params['args'] = $this->APIArgs;
		$this->restserver->handle($params);

	}	

	public function updateAction() {

		$params['method'] = 'aliasesUpdate';
		$params['args'] = $this->APIArgs;
		$this->restserver->handle($params);

	}

	public function deleteAction() {

		$params = $this->getRequest()->getParams();
		$params['method'] = 'aliasesDelete';
		$params['args'] = $this->APIArgs;	
		$this->restserver->handle($params);

	}
	
	
}