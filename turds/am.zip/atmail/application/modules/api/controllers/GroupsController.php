<?php
class Api_GroupsController extends Zend_Controller_Action
{

	public function init()
	{

		require_once 'application/models/api.php';
		$this->api = new api();

		$this->view->baseUrl = $this->_request->getBaseUrl();
		$this->view->appBaseUrl = $this->_request->getBaseUrl() . (strpos($this->_request->getBaseUrl(),'index.php')?'':'/index.php');
		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		$this->view->moduleBaseUrl = $this->view->appBaseUrl . ($this->_request->module == 'default'?'':DIRECTORY_SEPARATOR . $this->_request->module);

		$this->_helper->viewRenderer->setNoRender();

		$this->restserver = new Zend_Rest_Server();
		$this->restserver->setClass('api');

		if( !Atmail_HttpAuth::authenticated(3, null, 'admin', null) )
		{

			$this->_forward('authenticationfailed');

		}

	}

	public function authenticationfailedAction()
	{
	
	   	//just an empty deadend so failed XML responses are uniform
		$this->restserver->handle( array('method' => 'authenticationFailed') );

	}

	public function indexAction()
	{

		$this->restserver->handle( array('method' => 'index') );

	}

	public function createAction()
	{

		$params = $this->getRequest()->getParams();
		$params['args'] = $params;
		$params['method'] = 'groupCreate';
		$this->restserver->handle( $params );

	}

	public function getAction()
	{

		$params = $this->getRequest()->getParams();
		$params['method'] = 'groupGet';
		$this->restserver->handle( $params );

	}

	public function existsAction()
	{

		$params = $this->getRequest()->getParams();
		$params['method'] = 'groupExists';
		$this->restserver->handle( $params );

	}

	public function listAction()
	{

		$this->restserver->handle( array('method' => 'groupsList') );

	}

	public function totalAction()
	{

		$this->restserver->handle( array('method' => 'groupTotal') );

	}

	public function listtotalsAction()
	{

		$this->restserver->handle( array('method' => 'groupsListTotals') );

	}

	public function updateAction()
	{

		$params = $this->getRequest()->getParams();
		$params['method'] = 'groupUpdate';
		$params['args'] = $params;
		$this->restserver->handle( $params );

	}
	
	public function useraddAction()
	{
		
		$params = $this->getRequest()->getParams();
		$params['method'] = 'groupUserAdd';
		$this->restserver->handle( $params );
		
	}

	public function usersaddAction()
	{
		
		$params = $this->getRequest()->getParams();
		$params['method'] = 'groupUsersAdd';
		$this->restserver->handle( $params );
		
	}

	public function userdeleteAction()
	{
		
		$params = $this->getRequest()->getParams();
		$params['method'] = 'groupUserDelete';
		$this->restserver->handle( $params );
		
	}

	public function usersdeleteAction()
	{
		
		$params = $this->getRequest()->getParams();
		$params['method'] = 'groupUsersDelete';
		$this->restserver->handle( $params );
		
	}

	public function deleteAction()
	{

		$params = $this->getRequest()->getParams();
		$params['method'] = 'groupDelete';
		$this->restserver->handle( $params );

	}

}
