<?php
class IndexController extends Zend_Controller_Action 
{

	//point user to correct ui on first hit (application may only have certain startingpoints installed/available)
	//e.g. could also be used to catch mobile devices and redirect to other module 
	
	public function indexAction() 
	{
    	
		$requestParams = $this->getRequest()->getParams();
		if( isset($requestParams['signup']) )
		{

			$this->_request->setParam('module', 'mail');
			$this->_forward('signup', 'signup', 'mail');
			
		}
		else
		{
			
			//forward to correct starting point depending on what modules installed, i.e. archive
			$this->_request->setParam('module', 'mail');
			$this->_forward('index', 'mail', 'mail');
			
		}
	
	}


	public function sessiontimeoutAction() 
	{
	
		$requestParams = $this->getRequest()->getParams();
		
		if( isset($requestParams['admin']) || $requestParams['module'] == 'admin' )
		{

			$this->view->admin = true;

		}
		$this->view->version = file_get_contents(APP_ROOT . ".VERSION");
		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');

	}
	
	/**
	 * timeoutAction sends a mini response that will work as expected for html and json expected responses (additional logic to detect the timeout on response string)
	 */
	public function timeoutAction() 
	{

		$requestParams = $this->_request->getParams();
		if( isset($requestParams['admin']) || $requestParams['module'] == 'admin' )
		{
			
			$this->view->admin = true;
			
		}
		$this->view->version = file_get_contents(APP_ROOT . ".VERSION");
		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');

	}
	
	public function dberrorAction() 
	{
	
		$request = $this->getRequest();
    	$this->view->version = file_get_contents(APP_ROOT . ".VERSION");
		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		$this->view->error = $request->error;	

	}
	
	public function ie6Action() 
	{
	    $this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		//nothing to do but render
	}
	
}
