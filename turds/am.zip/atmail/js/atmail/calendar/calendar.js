/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/
// Custom jQuery functions to modify the calendar

function searchCalendar() {

	lastTabNumber++
	tabLabel = "Calendar Search";

	var searchOffset 	= $("#search_anything").offset();
	var lastTabOffset 	= $('ul#navMessages li:last').offset();
	var lastTabWidth 	= $('ul#navMessages li:last').width();
	
	//TODO: browser style non-fitting tabs dropdown, currently oldest tab is dropped/removed
	if( (searchOffset.left - lastTabOffset.left - lastTabWidth) < 190 )
		$('div#navMessages').tabs('remove', 1);
	
	$('div#navMessages').tabs('add','#searchResultsTab' + lastTabNumber, tabLabel);
	$('#searchResultsTab' + lastTabNumber).index = 4;
	$('#searchResultsTab' + lastTabNumber).addClass('viewmessageTab');
	$('#searchResultsTab' + lastTabNumber).bind('tabSelected', function() 
	{
		enableMailActions();
	});
	
	$('#searchResultsTab' + lastTabNumber).trigger('tabSelected');
	$('#searchResultsTab' + lastTabNumber).html('<div id="primary_header" class="loading"><h1>Searching ...</h1></div>');
	$('#searchResultsTab' + lastTabNumber).load(moduleBaseUrl + '/search/search?searchType=calendar', $('#searchForm').serializeArray(), function() 
	{
		$('#primary_header').each( function() { 
			$(this).removeClass('loading');
		}); 
	});
	
	return false;
}


function dump(arr,level,maxlevel) {
	var dumped_text = "";
	if(!level) level = 0;
	
	//The padding given at the beginning of the line.
	var level_padding = "";
	for(var j=0;j<level;j++) level_padding += "------";
	
	if(level > maxlevel) {
		dumped_text += level_padding + "maximum level<br>"; 
		return dumped_text;
	}

	if(typeof(arr) == 'object') { //Array/Hashes/Objects 
		for(var item in arr) {
			try
			{
				var value = arr[item];
			
				if(typeof(value) == 'object') { //If it is an array,
					dumped_text += level_padding + "'" + item + "' ... <br>";
					dumped_text += dump(value,level+1,maxlevel);
				} else {
					dumped_text += level_padding + "'" + item + "' => \"" + value + "\"<br>";
				}
			}
			catch(err)
			{
				dumped_text += level_padding + " ERROR : " + err + "<br>";
			}
		}
	} else { //Stings/Chars/Numbers etc.
		dumped_text = "===>"+arr+"<===("+typeof(arr)+")";
	}
	return dumped_text;
}

function popup_debug(text)
{
/*	my_window = window.open("","mywindow","status=1,width=350,height=150, scrollbars=1");
	my_window.document.write(text);  
	my_window.document.body.scrollTop = my_window.document.body.scrollHeight;*/
}

var alarmsSet = [];
var qtipdragging = false;

function setAlarm(urlstr, datestr, timestr, daystr, description, timeout, id, href)
{
	// timeout input is in seconds
	// its required to be ms
	timeout = timeout * 1000;
	resetAlarm = false;
	
	popup_debug(urlstr + " " + datestr + " " + timestr + " " + daystr + " " + description + " " + timeout + " " + id + " " + href);
	
	if(typeof(alarmsSet) != 'undefined' && typeof(alarmsSet[id]) != 'undefined')
	{
		popup_debug("alarm already defined");

		// reset the alarm if its not displayed
		if(!alarmsSet[id].displayed)
		{
			popup_debug("but not displayed");

			clearTimeout(alarmsSet[id].timeoutHandle);
			alarmsSet[id].timeoutHandle = 0;
			delete alarmsSet[id];
			resetAlarm = true;
		}
	}
	else
	{
		popup_debug("resetting alarm");
		resetAlarm = true;
	}

	if(!resetAlarm)
	{
		popup_debug("not resetting alarm");
		return;
	}

	alarmsSet[id] = {
		displayed: false, 
		timeoutHandle : setTimeout( 
		function()
		{ 
			popup_debug("timeout reached " + dump(alarmsSet));
			alarmsSet[id].displayed = true;
			$('#alarmholder').qtip(
			{
				content:
				{
					title:
					{
						text: 'Reminder',
						button: ''
					},
					text: 'Loading...',
					url: urlstr,
					data:
					{
						url: urlstr, 
						description : description,
						time: timestr,
						date: datestr,
						day: daystr,
						overdue: timeout,
						id: id,
						href: href
					},
					method: 'post'
				},
				show: { ready: true },
				hide: false,
				position:
				{
					target: $(document.body),
					corner: 'center'
				},
				style:
				{
					width: "100%",
					background: "transparent"
				},
				api:
				{
					beforePositionUpdate: function()
					{
						if(qtipdragging == true)
							return false;
					},
					onRender: function()
					{
						$(this).find('.grey-back').css({height: "215px"});
				         //this.elements.tooltip.<span class="highlight" style="padding-left: 0px; padding-right: 0px;">draggable</span>();
						this.elements.tooltip.draggable({
							start: function(){
								qtipdragging = true;
								}
							}
						);
					},
					onHide : function()
					{
						popup_debug("alarm resolved " + dump(alarmsSet));
						alarmsSet[id].displayed = false;
						this.destroy();
					}
				}
			})
		}, timeout)
	};
	
	popup_debug(dump(alarmsSet));
	
}

function ToggleAdvancedRecurrence()
{
	//RepeatAdvancedView

}
