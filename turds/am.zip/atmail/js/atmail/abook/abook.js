/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

// Custom jQuery functions to modify the abook panel

// Disable the edit button on the toolbar
// TODO: Make this function accept the button-name we are to disable, use globally
$.fn.disable = function() { 
  return this.each(function() {
		$(this).attr("disabled",true); 
		$(this).css('opacity', 0.4);
		$(this).children().children().css('cursor', 'not-allowed');
		$(this).unbind("click");
	}); 
} 

// Enable the edit toolbar on the abook panel
$.fn.enable = function(func) {
  return this.each(function() { 
		if($(this).attr("disabled")) {
		$(this).children().children().css('cursor', 'pointer');		
		$(this).unbind("click");
		$(this).bind("click", func );					
		$(this).attr("disabled",false); 
		$(this).css('opacity',1);			
		}
	
	}); 
} 

// Display the updated number of contacts in the view after deletion
$.fn.updateCount = function(count) {
	
	count = Number(count);
	
	// Load the current count
	var current = $(this).text();
	var groupCount = Number(current) + count;
	
	if(groupCount > 0) {

		$(this).text(groupCount);
		$(this).parent().fadeIn('slow');

	} else {

		// Hide the count, do not show (0)
		$(this).parent().fadeOut('slow');
		$(this).text(groupCount);
		
	}
	
}

// Display the updated number of contacts if total specified
$.fn.updateTotal = function(totalCount) {
	
	totalCount = Number(totalCount);
	
	// Load the current count
	if(totalCount > 0) {
	
		$(this).text(totalCount);
		$(this).parent().fadeIn('slow');
			
	} else {
	
		// Hide the count, do not show (0)
		$(this).parent().fadeOut('slow');
	    $(this).text(totalCount);
	
	}
	
}

checkTotalContacts = function(element)
{
	var totalItems = 0;
	
	if(element.parent() == undefined)
		return 0;
		
	return element.parent().children('.address_row').length;
}

$.fn.getAbookRow = function(context) 
{
	var item;
	var current_item;
	var id = false;

	// try the next item
	// but make sure its not being removed!
	current_item = $(this).next();
	if(!current_item.is('.removing'))
	{
		id = current_item.attr('contactid');
	}
	
	if(!id || id == 0 || id == 'pageNumber')
	{
		var searching = true;
		// next item doesn't exist or is being removed
		// lets find the next item which exists and isn't being removed
		
		while(searching)
		{
			current_item = current_item.next();
			if(!current_item.attr('contactid'))
			{
				searching = false;
			}
			else
			{
				if(!current_item.is('.removing'))
				{
					id = current_item.attr('contactid');
					searching = false;
				}
			}
		}
	
	}
	
	if(!id || id == 0 || id == 'pageNumber')
	{
		// didn't find anything after the current item, so lets go back up the list
		current_item = $(this).prev();
		if(!current_item.is('.removing'))
		{
			id = current_item.attr('contactid');
		}
		if(!id || id == 0 || id == 'pageNumber')
		{
			var searching = true;
			// prev item doesn't exist or is being removed
			// lets find the prev item which exists and isn't being removed
			while(searching)
			{
				current_item = current_item.prev();
				if(!current_item.attr('contactid'))
				{
					searching = false;
				}
				else
				{
					if(!current_item.is('.removing'))
					{
						id = current_item.attr('contactid');
						searching = false;
					}
				}
			}
	
		}
		
	}
	item = $('.address_row[contactid=' + id + ']', getVisiblePanelContext());
	totalContactsLeft = checkTotalContacts(item) - item.parent().children(".removing").length;

	// No messages are left to display
	if( !totalContactsLeft || !id || id == 0 || id == 'pageNumber' )
	{
		return $('#contact_info', context).html('');		
	}
		
	setTimeout(function() { $('.address_row[contactid=' + id + ']', getVisiblePanelContext()).trigger('click'); }, 200);	
}

// Display new contact panel
function newContact(nohtml, skipadd, id, firstname, lastname, email) {
	if (skipadd == undefined)
		skipadd = false;
	if(nohtml == undefined)
		nohtml = false;
	if(id == undefined)
		id = '';
	if(firstname == undefined)
		firstname = 'No Name';
	if(lastname == undefined)
		lastname = '';
	if(email == undefined)
		email = '';
		
	
	if(!nohtml)
	{
		var newContact = $('.address_row:first', '#Address_Book').clone();
		if(newContact.size() == 0)
		{
			//nothing to clone !, reload the contacts
			$('li.current a', '#Address_Book').click();
			return;
		}
		//remove global class if needed
		newContact.children('div.check').children('input.contactRow').removeClass('contactGlobal')
		newContact.children('div.check').children('input.contactRow').attr('value', id);
		newContact.attr('contactid', id);
	
		newContact.insertBefore('.address_row:first');

		// Add the bind
		$('.check .contactRow').unbind('click');
		$('.address_row .contact_click').unbind('click');

		$('.check .contactRow').bind('click', function() { toggleContact(this); });	
		$('.address_row .contact_click').bind('click', function() { viewContact(this); });
		
		if(firstname == 'No Name' && email != '')
		{
			newContact.find('.first_name').html(email);
		}
		else
		{
			newContact.find('.first_name').html(firstname);	
		}
		newContact.find('.last_name').html(lastname);
	}

	// Remove previously selected rows
	$('.contactRow:checked', '#Address_Book').each(function(){ 
		this.checked = false;
		$(this).parent().parent().removeClass('selected');
	});

	if(!nohtml)
	{
		newContact.find('.check').children().each(function() {
			this.checked = true;
			$(this).parent().parent().addClass('selected');
		});
//		$('.contact_icon:first', '#Address_Book').parent().parent().addClass('selected');
		
		newContact.draggable(
		{
			helper: function() { return dragContact(this); },
			stop: function(event, ui) { dragContactStop(); },
			appendTo:'#draggableContactsContainer',
			cursor:'move',
			preventionDistance:"3",
			cursorAt:{top:15, left:48},
			revert: "invalid",
			revertDuration: 300
		});
	}
	
	if(!skipadd)
	{
		// Where are we, in the base folder, or a group
		var GroupID = $('li.current', '#Address_Book').attr('groupid');
		if(GroupID.indexOf("server") != -1 || GroupID > 0)
		{
			$.php(moduleBaseUrl + '/contacts/newcontact/new/1/ui/1/GroupID/' + GroupID )
		}
		else
		{
			$.php(moduleBaseUrl + '/contacts/newcontact/new/1/ui/1' )
		}
		$.jCacher.remove('autocomplete')
	}
}

// Delete a specified contact
function deleteContact(clickedObject) 
{
	if( $('#action_contact_delete a').attr("disabled") == true )
		return;
	
	// Where are we, in the base folder, or a group
	var GroupID = $('li.current', '#Address_Book').attr('GroupID')
	
	if(GroupID > 0)
		$.php(moduleBaseUrl + '/contacts/deletecontactgroup/GroupID/' + GroupID + '/',$("#listcontacts").serializeArray());	 	
	else 
	{
		
	/*	var checkedRows = $('.contactGlobal:checked', '#Address_Book').size();
		if( checkedRows > 0 ) 
		{
		
			//TODO: make translatable
			alert("Cannot delete global contacts.");
			return;
		
		}*/
		nextID = $("input.contactRow:checked:last", '#Address_Book').parent().parent().next('.address_row').attr('contactid');
		$.php(moduleBaseUrl + '/contacts/deletecontact/GroupID/' + GroupID + '/',$("#listcontacts").serializeArray());		
	
	}
	$.jCacher.remove('autocomplete')
	

	// Show the next contact in the view
	// TODO: If 0 contacts, need to show 'null'
	//TODO: unless returning php.complete to previous state - remove all overloading of php.complete and rather use callback function or server push methods
	php.complete = function ()
	{

		php.complete = function() 
		{ 
		
			$('.loading').each( function() { $(this).removeClass('loading') } );
            $('#back_button').each( function() { $(this).fadeTo(100, 1) } );
 		
		}
		
		// If we have additional contacts, show the next user
		
		if(typeof(nextID) != "undefined" && nextID > 0) 
		{
		
			$.php(moduleBaseUrl + '/contacts/viewcontact/id/' + nextID + '/groupid/' + GroupID);
            // Select the next row as the "current view"
			$('.contact_icon:first', '#Address_Book').prev('.check').children().each(function() 
			{
			
				$(this).attr('checked', 'true');
				$(this).parent().parent().addClass('selected');
			
			});
		
		} 
		else 
		{
			
			// Show "empty" contacts otherwise
			setTimeout( "$.php('" + moduleBaseUrl + "/contacts/viewcontacts/GroupID/" + GroupID + "');", 300);
			
		}  
		$('#primary_header').each( function() { $(this).removeClass('loading') } );

	}
	
}

function editContactDblClick(clickedObject) 
{
	var contactID = $('#contact_table', '#Address_Book').attr('contactid');
	var GroupID = $('li.current', '#Address_Book').attr('groupid');
	
	if(contactID)
	{
		
		$.php(moduleBaseUrl + '/contacts/editcontact/id/' + contactID + '/GroupID/' + GroupID );
		
	}
	$.jCacher.remove('autocomplete')

}

function toggleContact(clickedObject) {
	var GroupID = $('li.current', '#Address_Book').attr('GroupID');
		
	// Add the selected row if checkbox clicked, else remove
	if(clickedObject.checked)
	$(clickedObject).parent().parent().addClass('selected');
	else
	$(clickedObject).parent().parent().removeClass('selected');
	
	// If global addressbook, disable edit and delete
	if(GroupID < 0)
		return;
	
	var checkedRows = $('.contactRow:checked', '#Address_Book').size();
	
	if(checkedRows >= 1)	{
		$('#action_contact_delete a').enable(function() { return deleteContact($('#contact_table:first')); });
	} else {
		$('#action_contact_delete a').disable();
	}
	
	// Count how many elements exist, disable the edit button, only for the one selected contact
	if(checkedRows >= 2)	{
		$('#action_contact_edit a').disable();
	} else {
		$('#action_contact_edit a').enable( function() { return editContactDblClick() } );
	}
	
}

function viewContact(clickedObject) {
	var GroupID = $('li.current', '#Address_Book').attr('GroupID')
	$('#contact_table', '#Address_Book').hide();

	url = moduleBaseUrl + '/contacts/viewcontact/id/' + $(clickedObject).parent().attr('contactid') + '/GroupID/' + GroupID;			
	$.php( url );

	// Remove previously selected rows
	$('.contactRow:checked', '#Address_Book').each(function(){ 
		this.checked = false;
		$(this).parent().parent().removeClass('selected');
	});
	
	// Create a checkbox of the selection
	$(clickedObject).prev('.check').children().each(function() {
		this.checked = true;
		this.focus();
		$(this).parent().parent().addClass('selected');
		//$('#action_contact_edit').enable();
	});
	
}

function dragContact(clickedObject) 
{ 

	var size = $('.contactRow:checked', '#Address_Book').size();
	
	$('.contactRow:checked', '#Address_Book').each(function() {
	
		$(this).parent().parent().css('opacity', 0.6);
		
	});
	
	if(!size)
		size = 1;
    return $('<div class="contact_icon_drag"><div class="contact_drag_no"><span class="drag"><strong>' + size + '</strong></span></div></div>');

}

function dragContactStop(clickedObject) 
{ 

	$('.contactRow', '#Address_Book').each(function() {
	
		$(this).parent().parent().css('opacity', 1);
		
	});
	
}

function resetDroppables() 
{

	$("ul#nav_secondary li:not('.current'):not('li[groupid=-1]'):not('li[groupid=-3]')", '#Address_Book').droppable(
	{
		accept: "div.address_row",
		activeClass: 'droppable-active',
		hoverClass: 'droppable-hover',
		drop: function(ev, ui) 
		{
			$.jCacher.remove('autocomplete')
			$.jCacher.remove('autocomplete_global')
			contactId = $(ui.draggable).attr('contactid')
			GroupID = $(this).attr('groupid');

			var dragMatch;			
			// First, check the contacts we are dragging has been selected on the DnD
			$('.contactRow:checked', '#Address_Book').each(function() 
			{
		
				var checkedID = $(this).parent().parent().attr('contactid');
				if(checkedID == contactId)
				dragMatch = 1;
		
			});
					
			// Drag multiple contacts, or a single element
			if($('.contactRow:checked', '#Address_Book').size() > 0 && dragMatch == 1)
			{
		
				$.php(moduleBaseUrl + '/contacts/addcontacttogroup/GroupID/' + GroupID, $("#listcontacts:first").serializeArray())
		
			}
			else
			{
		
				$.php(moduleBaseUrl + '/contacts/addcontacttogroup/GroupID/' + GroupID + '/id/' + contactId)
		
			}
		
		}

	})
	
}

/*
Functions used for listGroups.phtml
*/

function listContactsClick(clickedObject)
{
	if(!currentlyEditingAGroup) {
		$('ul#nav_secondary li', '#Address_Book').removeClass('current')
		$(clickedObject).parent().addClass('current')
					
		if( $(clickedObject).parent().attr('GroupName') == 'All' ) {
			$('#Address_Book #folder_remove a').removeClass('enabled');           
			$('#Address_Book #folder_remove a').addClass('disabled');           
		} else {
			$('#Address_Book #folder_remove a').removeClass('disabled');
			$('#Address_Book #folder_remove a').addClass('enabled');
		}
		
		$('#listcontacts', '#Address_Book').hide();
		$('#contact_table', '#Address_Book').hide();
				
		$.php( moduleBaseUrl + "/contacts/viewcontacts/GroupID/" + $(clickedObject).parent().attr('GroupID'));		
	}

	return false
}  

function editGroupDblClick(clickedObject) 
{

	a = $(clickedObject)
	
	if(a.parent().attr('groupid') <= 0)
	{
		
		return;
		
	}

	currentlyEditingAGroup = true
	
	li = a.parent()
	span = a.children('span')
	oldGroupName = li.attr('groupname')
	
	// Create a form to specify the new name
	$('<form id="updateGroupForm" method="post" target="_blank"><input name="newGroupName" oldGroupName="' + oldGroupName + '" value="' + oldGroupName + '"></form>').insertAfter(a); 

	// Hide the label text
	a.hide();

	form = li.children('form');
	input = form.children('input');
	input.focus();
	input.select();

	input.bind('blur', function() 
	{
	
		$(this).parent().submit()
	
	})
	
	form.submit( function() 
	{ 
	
		form = $(this)
		GroupID = $(this).parent().attr('groupid')
		newGroupName = $(this).children('input').attr('value')
		oldGroupName = $(this).children('input').attr('oldGroupName')
		// Change the text to the new groupname
		$('.groupLink:hidden .label span.labelname', '#Address_Book').text(newGroupName);
		$(this).parent().attr('GroupName', newGroupName);
		
		// Show the original div
		$('.groupLink:hidden', '#Address_Book').show();
		// Remove from the DOM the html form for editing
		form.remove();
		$.jCacher.remove('autocomplete')
		if( newGroupName != oldGroupName )
		{
			
			$.php(moduleBaseUrl + '/contacts/updategroupname/GroupID/' + GroupID + '/newGroupName/' + newGroupName )
			
		}
		currentlyEditingAGroup = false
		return false
	
	})
	  
}

function addGroup(clickedObject) 
{

	if( $('#newGroupForm', '#Address_Book').length == 0 ) 
	{
	
		$('#nav_secondary', '#Address_Book').append('<li>' + 
										   '<form id="newGroupForm" method="post" target="_blank">' + 
										   '<input name="newGroupName" value="New Group">' + 
										   '</form>' + 
										   '</li>')
		$("#secondary", '#Address_Book').attr({ scrollTop: $("#Address_Book #secondary").attr("scrollHeight") });
	
		$('#newGroupForm input', '#Address_Book').select()
	
		$('#newGroupForm input', '#Address_Book').bind('blur', function() 
		{
	
			$(this).parent().submit()
	
		})
	
		$('#newGroupForm', '#Address_Book').submit( function() 
		{
		
			args = $('#newGroupForm').serializeArray(); 
	        li = $(this).parent()
			newGroupName = htmlentities($(this).children('input').attr('value'), 'ENT_QUOTES');
		
			// TODO: Remove language string
			if( newGroupName == 'New Group' ) {
				li.remove()                                          
				return false
			}
		
	        //CONSIDER: use clone instead to transparently cope with html changes to the list
			li.attr('groupname', newGroupName )
			li.attr('groupid', '' )
			li.attr('newgroup', 'true' )
			li.addClass('ui-droppable')
			li.html('<a class="groupLink" href="#"><span class="label"><span class="labelname">' + newGroupName + '</span></span><span class="unread" style="display:none;"><strong>0</strong></a></span></a>');
		
			a = li.children('a')
			a.bind('click', function() { return listContactsClick(this) } )     
			a.bind("dblclick", function() { return editGroupDblClick(this) } )

			$.php(moduleBaseUrl + '/contacts/creategroup/', args);
		    $.jCacher.remove('autocomplete')
			resetDroppables()
			return false
	    })
  
	}

	return false;
	
}

function removeGroup(clickedObject) 
{

	// TODO: Remove any english language strings from the JS array
	if( $(clickedObject).attr('class') != 'enabled' )
	{
		
		return false
		
	}
	else if($('#Address_Book li.current').length > 0 && confirm('Are you sure you want to delete ' + html_entity_decode($('#Address_Book li.current').attr('GroupName') )) ) 
	{
	
		$.jCacher.remove('autocomplete')
		$.php(moduleBaseUrl + '/contacts/deletegroup/GroupID/' + $('#Address_Book li.current').attr('GroupID') )
		//listContactsClick($('#Address_Book ul#nav_secondary li:first a'));
	
	}
	return false;

}

function searchAbook(clickedObject)
{
	query = $(clickedObject).attr('value');
	
	if(query.length > 1)
	{
		$.php(moduleBaseUrl + '/contacts/searchFuzzy/query/' + escape(query) + "/GroupID/" + $('#Address_Book li.current').attr('GroupID') + '/');
	}
	else
	{
		$.php(moduleBaseUrl + '/contacts/viewcontacts/GroupID/' + $("#Address_Book li.current").attr("GroupID") + '/');
	}
	
	return true;
}

function exportContact(clickedObject) {

	url = moduleBaseUrl + '/contacts/exportcontact/GroupID/' + $('li.current', '#Address_Book').attr('groupid') + '/id/';
	urlArgs = '';
	
	// Which elements to export?
	$('.contactRow:checked', '#Address_Book').each(function(){
		var checkedID = $(this).parent().parent().attr('contactid');		
		urlArgs = urlArgs + checkedID + ":";
	});
	
	url = url + urlArgs + '/vcard.vcf';
	
	location.href=url;
}

function emailSelected() {

	// Which elements to export?
	var contacts = Array();
	
	$('.contactRow:checked', '#Address_Book').each(function(){
		var email = $(this).parent().parent().find('SPAN.email').text();
		
		if(email != '' && email != undefined)
			contacts.push(email);
			
	});
	
	openNewComposerTab( {'to': contacts } ); 
	
}

function selectAll(clickedObject) {
	jsddm_close();
	
	$('.contactRow', '#Address_Book').each(function(){ 
		this.checked = true;
		$(this).parent().parent().addClass('selected');
	});
	
}

function deselectAll(clickedObject) {
	jsddm_close();
	
	$('.contactRow', '#Address_Book').each(function(){ 
		this.checked = false;
		$(this).parent().parent().removeClass('selected');
	});
	
}

// Edit addressbook functions
// Functions to handle default states
function changeDefault(fieldObject) 
{
    //TODO: still used? cleanup (remove references to external dependant data), remote Javascript specific code (not jQueryalized)
	if( fieldObject.value == formNames[fieldObject.id] ) 
		fieldObject.select()
	
}

function checkDefault(fieldObject) 
{

	//TODO: still used? cleanup (remove references to external dependant data), remote Javascript specific code (not jQueryalized)
	if( !fieldObject.value || fieldObject.value == formNames[fieldObject.id]) 
	{
		
		fieldObject.value = formNames[fieldObject.id]
		fieldObject.className='default'
	
	}

}

function updateDependantSelects(selectorName, allOptions) {

	usedOptions = Array();
	unusedOptions = Array();
	
	$("[name='" + selectorName + "']", '#Address_Book').children('option:selected').each( function() {
		usedOptions[$(this).attr('value')] = $(this).attr('value');
	})                           

	// Build a list of unused options
	for(var item in allOptions) {
		if(usedOptions[item] == undefined) {
			unusedOptions[item] = allOptions[item];
		}
	}
	
	$("[name='" + selectorName + "']", '#Address_Book').children('option:not(:selected)').remove()
	appendOptions = ''
	for( var item in unusedOptions ) {
		appendOptions += '<option value="' + item + '">' + unusedOptions[item] + '</option>\n'
	}

	$("[name='" + selectorName + "']").each( function() {
		$(this).append(appendOptions)
	})
}

function removeClicked(clickedObject, allOptions) {
	//remove row then unhide last add button
	var rowType = $(clickedObject).parent().parent().children('td:first').children('select').attr('name');
	
	if( $("[name='" + rowType + "']", '#Address_Book').length <= 1) {
		$(clickedObject).parent().children('input').attr('value', '');
		$(clickedObject).parent().children('input').effect('highlight', {}, 500);
		$(clickedObject).parent().children('input').focus();
		return;
	}
	
	$(clickedObject).parent().parent().remove();                   

	$("[name='" + rowType + "']:last", '#Address_Book').each( function() { $(this).parent().parent().find('img').show(); });

	updateDependantSelects( $(clickedObject).parent().parent().children('td:first').children('select').attr('name'), allOptions );
}

function addClicked(clickedObject, allOptions) {

	if( $(clickedObject).parent().children('input').attr('value') == '') {
		$(clickedObject).parent().children('input').effect('highlight', {}, 500);
		$(clickedObject).parent().children('input').focus();
		return false;
	}
	
	newRow = $(clickedObject).parent().parent().clone(true);
	newRow.children('td').children('select').children('option').each(function() { $(this).remove(); }); //.remove();
	newRow.children('td').children('select').children('option:first').attr('selected','selected');

	var total = 0;
	for(var item in allOptions) {
		total ++;
	}

	if( $("[name='" + $(clickedObject).parent().parent().children('td:first').children('select').attr('name') + "']", '#Address_Book').length >= total -1)
	{
		$(newRow).children('td').children('img.contactFieldAdd').css('display','none');
	}
	
	$(clickedObject).parent().parent().after( newRow );
       
	newRow = $(clickedObject).parent().parent().next();
	
	$(newRow).children('td').children('input').attr('value', '');
	$(newRow).children('td').children('input').select();
	$(newRow).children('td').children('input').keypress( function(e) { 
		if($(this).attr('value') == '' && (e.which == 32 || e.which == 8 || e.which == 0 ))
			$(this).parent().children('img.contactFieldAdd').css('display','none');
		else if( $(this).parent().parent().children('td').children('select').children('option').length > 1 )
			$(this).parent().children('img.contactFieldAdd').css('display','');
	})
	$(clickedObject).css('display','none');
	
	updateDependantSelects( $(clickedObject).parent().parent().children('td:first').children('select').attr('name'), allOptions );
}
