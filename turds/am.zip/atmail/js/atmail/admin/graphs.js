/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

var graphData = [];

// Fetch a large graph
function onDataReceived(series, graphId) {
	
	if($("#Dashboard").css('display') == 'none' && $("#Users").css('display') == 'none') {
		return;
	}
	
	var options = {
	    lines: { show: true },
	    points: { show: true },
		grid: { color: "#999" },
		yaxis: {tickDecimals: 1, min: 0, autoscaleMargin: 0.1},
		xaxis: { mode: "time" }
	};

	var data = [];
    data.push(series);
    $.plot(graphId, data, options);
 }

function zoomGraph(largeGraphId, smallGraphId) {
	
	if($("#Dashboard").css('display') == 'none') {
		return;
	}
	
	var options = {
	    lines: { show: true },
	    points: { show: true },
	    //xaxis: { tickSize: 1 },
		grid: { color: "#999" },
		yaxis: {tickDecimals: 1, min: 0, autoscaleMargin: 0.1},
		xaxis: { mode: "time" }
	};

	var data = [];
    data.push( smallGraphId.data('graphData') );
    $.plot(largeGraphId, data, options);
	
	// Update the header in the UI
	var graphText = smallGraphId.parent().find('.statName').text();
	largeGraphId.parent().parent().parent().parent().find('H1').html(graphText);
	
 }

// Fetch a small graph
function onDataReceivedSmall(series, graphId, type) {

	if(!type)
		type = '';
		
	if($("#Dashboard").css('display') == 'none' && $("#Users").css('display') == 'none') {
		return;
	}
	
	if(type == 1)
		var optionsSmall = {
		    lines: { show: true },
			grid: { color: "#999" },
			yaxis: {tickDecimals: 1, min: 0, autoscaleMargin: 0.1, ticks: []},
			xaxis: { mode: "time" },
			label: ""
		};
	else
		var optionsSmall = {
		    lines: { show: true },
			grid: { color: "#999" },
			yaxis: {tickDecimals: 1, min: 0, autoscaleMargin: 0.1},
			xaxis: { mode: "time" },
			label: ""
		};
	
	var total = 0;

	// Not IE compat
	for (var item in series.data) {
		var row = series.data[item];
		total = Number(row[1]) + Number(total);
	}
	
	$("#" + graphId).data('graphData', series);
	var dataRecord = $("#" + graphId).data('graphData');
		
	var graphData = [];
    graphData.push(series);

	$("#" + graphId).parent().find('.statTotal').text(total);

	// Format the number, e,g 24,340
	$("#" + graphId).parent().find('.statTotal').format({format:"#,###", locale:"us"});
	
    // and plot all we got
    $.plot($("#" + graphId), graphData, optionsSmall);
}


function generateLargeGraph(graph, url, view, log) {
	
	// Launch request for large graph
	$.ajax({
	    url: url + view + "/log/" + log + "/type/" + $(graph).attr('logtype'),
	    method: 'GET',
	    dataType: 'json',
		success: function(graphdata, type) {
		onDataReceived(graphdata, graph );
		}
	});

}

function generateSmallGraph(graph) {
	
	// Launch an ajax query for each graph
	$('#sent .statGraphSmall').each(function(n){ 
		var myid = this.id;
		var data = [];
		//$.plot($("#" + myid), data, optionsSmall);

		$.ajax({
	        url: "<?php echo $this->moduleBaseUrl ?>/graph/json/view/day/log/Log_SendMail/type/" + $(this).attr('logtype'),
	        method: 'GET',
	        dataType: 'json',
	        success: function(graphdata, type) {
			onDataReceivedSmall(graphdata, myid );
				}
	    });

	});

}

$.fn.viewLogs = function(url, log, view) {
	
	// Don't enable log-search if Subadmin does not have the rights
	if( $("#dashboard_logs").size() == 0 ) {
		$(this).css('text-decoration', 'none');
		$(this).css('pointer', '');
		return;
		
	}
	
	$(this).attr('title', 'View expanded logs');
	
	$(this).bind('click', function() {
					
		id = $(this).parent().find('.statGraphSmall').attr('LogType');
				
		if(!id)
			id = 0;
			
		var navbar = $('#secondary', '#Dashboard').tabs();
		var tabLen = navbar.tabs( "length" ) - 1;
		
		// Check if we are the Subadmin user
		if( $("#account_profile").size() != 0 ) {
			tabLen = navbar.tabs( "length" ) - 1;
		}
		
		navbar.tabs( "url" , tabLen , url + '/dashboard/log/log/' + log + '/type/' + id + '/view/' + view );
		navbar.tabs('select', tabLen);

	});
	
}
