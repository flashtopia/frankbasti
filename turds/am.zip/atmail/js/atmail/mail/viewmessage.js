/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/
function setTextBoxList( origionalFormObject, newArray, autocompleteList, autocompleteCacheSize, autocompleteFetchThreshold, autocompleteFetchSize, autocompleteMinFetchLength, autocompleteUrl)
{
	if(autocompleteCacheSize == undefined) autocompleteCacheSize = 100;
	if(autocompleteFetchThreshold == undefined) autocompleteFetchThreshold = 50;
	if(autocompleteFetchSize == undefined) autocompleteFetchSize = 25;
	if(autocompleteMinFetchLength == undefined) autocompleteMinFetchLength = 2;
	if(autocompleteUrl == undefined) autocompleteUrl = 'contacts/autocomplete/limit/';
	//return
	origionalFormObject.siblings('.textboxlist').remove()
	$(origionalFormObject).attr('value', '')
	var newTextBoxList = new TextboxList(origionalFormObject, {unique: true, bitsOptions:{editable: {addOnBlur:true}}, plugins: {autocomplete: {placeholder:false, cacheSize: autocompleteCacheSize}}});

	// Don't repopulated with null values
	if(autocompleteList != undefined)
	{
	
		newTextBoxList.plugins['autocomplete'].setValues(autocompleteList);
	
	}
	
	// above static lookup, enable dynamic lookup
	if(autocompleteList.length >= autocompleteFetchThreshold)
	{
		newTextBoxList.plugins['autocomplete'].setOptions( 
			{
				placeholder: false,
				cacheSize: autocompleteCacheSize,
				minRemoteLength: autocompleteMinFetchLength,
				queryRemote: true,
				remote: {url: (autocompleteUrl + 'contacts/autocomplete/limit/' + autocompleteFetchSize)}
			});
	}

	for(var index in newArray) {
		
		//already html entities
		//newArray[index] = $('<div/>').text( newArray[index] ).html()
		//TextboxList.add = function(plain, id, html, afterEl)
		if( newArray[index].length > 0 )
		{
			newArray[index] = $.trim(html_entity_decode(newArray[index]));

			// remove blank descriptions
			if(	newArray[index].indexOf('"" ') == 0 ||
				newArray[index].indexOf("'' ") == 0)
			{
				newArray[index] = newArray[index].substring(3);
			}
	
			// remove <> from just emails
			if(newArray[index][0] == '<' && newArray[index][newArray[index].length - 1] == '>')
			{
				newArray[index] = newArray[index].substring(1, newArray[index].length - 1);
			}

			newTextBoxList.add(newArray[index]); //, newArray[index], newArray[index]);
		}
	}
	
	return newTextBoxList
	
}

function getPreparedReplyBody( bodyObject ) {
	
	bodyObject = bodyObject.clone()

	$('BLOCKQUOTE', bodyObject ).each(function() { $(this).show() })
	$('.showQuotedText', bodyObject ).remove();    

	//CONSIDER: allow inline (CID) attchments to be added, strip out img from body otherwise
	$('img', bodyObject).remove()
	//expand show quoted sections
	return bodyObject.html()

}
