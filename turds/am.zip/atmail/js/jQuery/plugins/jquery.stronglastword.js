
(function($)
{
	
	$.fn.stronglastword = function()
	{

		var existingContent = $(this).html();
		if( existingContent == undefined )
		{
		
			return this;
			
		}
		
		//trim right spaces off before looking for last word (after last space before word)
		var lastSpacePos = existingContent.replace(/\s+$/,"").lastIndexOf(' ');
		//dont append strong if already has
		if( existingContent.search('<strong>') == -1 && existingContent.search('</strong>') == -1 )
		{
			
			$(this).html( existingContent.substring(0,lastSpacePos) + '<strong>' + existingContent.substring(lastSpacePos) + '</strong>');
			
		}

		// Return the jQuery object to allow for chainability
		return this;
		
	}

})(jQuery);
