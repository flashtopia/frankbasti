DD_belatedPNG.fix('#nav li a span');
DD_belatedPNG.fix('#sign_out a span');
DD_belatedPNG.fix('#for_messages li a');
DD_belatedPNG.fix('#for_messages li a span');

DD_belatedPNG.fix('#action_new a span strong');
DD_belatedPNG.fix('#action_reply a span strong');
DD_belatedPNG.fix('#action_reply_all a span strong');
DD_belatedPNG.fix('#action_forward a span strong');
DD_belatedPNG.fix('#action_junk a span strong');
DD_belatedPNG.fix('#action_delete a span strong');

DD_belatedPNG.fix('#back_button a');
DD_belatedPNG.fix('#back_button a span');

DD_belatedPNG.fix('#nav_secondary li a span.label');
DD_belatedPNG.fix('#nav_secondary li a span.unread');
DD_belatedPNG.fix('#nav_secondary li a span.unread strong');