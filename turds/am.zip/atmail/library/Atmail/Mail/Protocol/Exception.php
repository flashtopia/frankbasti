<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

class Atmail_Mail_Protocol_Exception extends Zend_Exception
{
	//do custom email error related handling here
}

