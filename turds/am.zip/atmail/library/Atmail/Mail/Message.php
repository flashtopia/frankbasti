<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

require_once('Mail/RFC822.php');
require_once 'application/models/contacts.php';

class Atmail_Mail_Message extends Zend_Mail_Message
{
	public $_bodystructure;
	public $_attachments;              
	protected $_flags = null;
	private $_headersProcessed = false;

	public function __construct($args)
	{
		if( isset($args['bodystructure']) )
		{
			$this->_bodystructure = $args['bodystructure'];
		}
		parent::__construct($args); 

		//This may not be the best way to cache messages, the message class should be unaware (and not care) about what is happening higher up with the message class (caching etc)
		// should operate as an independant unit with cache happening higher up in the application heirarchy
		// as it stands now, this message class is dependant on cache dependant env vars being set up properly
		//this also breaks late strategy
		if ($this->_mail && array_key_exists('id', $args) )
		{
			
			//need to be server aware for testing else cache gets confused
			$auth = Zend_Auth::getInstance();
			$authedUserData = $auth->getStorage()->read();
			$port = $authedUserData['port'];

			$configGlobal = Zend_Registry::get('config')->global;
			if( array_key_exists('cacheEnabled', $configGlobal) && $configGlobal['cacheEnabled'] == 1 ) 
			{
				// TODO: Implement improved Atmail::Cache class for directory/storage
				$frontendOptions = array(
					'lifetime' => 300,
					'automatic_serialization' => true
					);

				$backendOptions = array('cache_dir' => APP_ROOT . users::getTmpFolder());
				try 
				{
				$cache = Zend_Cache::factory('Output',
					'File',
					$frontendOptions,
					$backendOptions);
				}
				catch( Exception $e )
				{
					
					if( $e->getMessage() == 'cache_dir is not writable' )
					{
						
						$configGlobal = Zend_Registry::get('config')->global;
						throw new exception('Unable to save to cache. Web server user must own ' . APP_ROOT . $configGlobal['tmpFolderBaseName'] . ' and subfolders and have access permissions.');
						
					}
					else
					{
						
						throw $e;
						
					}
					
				}
				$cacheName = md5($this->_mail->getCurrentFolder() . '-' . $port . $args['id']);

				if( !$this->_content = $cache->load($cacheName) )
				{
					$this->_content = $this->_mail->getRawContent($args['id']);
					$cache->save($this->_content, $cacheName);
				}
				else
					Zend_Registry::get('log')->debug('Message found cached content on disk: ' . $this->_mail->getCurrentFolder() . '/' . $args['id']);
			}
			//else
			//	$this->_content = $this->_mail->getRawContent($args['id']);
		}
		
	}

	public function getContent()
	{
		if ($this->_content !== null)
		{
			return $this->_content;
		}
        
		if ($this->_mail)
		{
			//need to be server aware for testing else cache gets confused
			$auth = Zend_Auth::getInstance();
			$authedUserData = $auth->getStorage()->read();
			$port = $authedUserData['port'];

			$configGlobal = Zend_Registry::get('config')->global;
			if( array_key_exists('cacheEnabled', $configGlobal) && $configGlobal['cacheEnabled'] == 1 ) 
			{
				// TODO: Implement improved Atmail::Cache class for directory/storage
				$frontendOptions = array(
					'lifetime' => 300,
					'automatic_serialization' => true
					);

				$backendOptions = array('cache_dir' => APP_ROOT . users::getTmpFolder());

				$cache = Zend_Cache::factory('Output',
					'File',
					$frontendOptions,
					$backendOptions);

				$cacheName = md5($this->_mail->getCurrentFolder() . '-' . $port . $this->_headers['uniqueid']);

				if( !$this->_content = $cache->load($cacheName) )
				{
					$this->_content = $this->_mail->getRawContent($this->_headers['uniqueid']);
					$cache->save($this->_content, $cacheName);
				}
				else
					Zend_Registry::get('log')->debug('Message found cached content on disk! ' . $this->_mail->getCurrentFolder() . '/' . $this->_headers['uniqueid']);
			}
			else 
				$this->_content = $this->_mail->getRawContent($this->_headers['uniqueid']);
				
			return $this->_content;
		} 
		else
		{
			throw new Atmail_Mail_Exception('no content');
		}
	}

	private function recursivelyGetAttachments( &$bodyStructureNode )
	{
		//will fetch inline, CID, and normal attachments (application layer can decide how to categorize/render/forceinline)
		$currList = array();

		if( !is_array($bodyStructureNode) )
		{
			return $currList;
		}
		
		foreach( $bodyStructureNode as $subNode )
		{
			if( isset($subNode[8]) 
			&&  is_array($subNode[8]) 
			&&  $subNode[8][0] == 'attachment' 
			&&  $subNode[8][1][0] == 'filename' )
			{
				//then we have the main kind of attachment so compile attachment record
				$currItem = array();
				$currItem['filename'] = $subNode[8][1][1];
				$currItem['sizeBytes'] = $subNode[6];
				$currItem['mimeType'] = $subNode[0] . '/' . $subNode[1];
				$currItem['encoding'] = $subNode[5];
				$currList[] = $currItem;
			} 
			else 
			{
				$currList = array_merge($this->recursivelyGetAttachments( $subNode ), $currList);
			}
		}
		return $currList;
	}

	public function getAttachmentsList()
	{
		$this->_attachments = $this->recursivelyGetAttachments( $this->_bodystructure);
		return $this->_attachments;
	}

	//TODO: consider implimenting more graceful toplines (if user enabled) + header processing to lighten remote hit
	//	(really only beneficial to remote server case = <1% usercase)
	public function processHeaders($existingDataArray = null)
	{
		//existingDataArray implimented because some data not available to sibling($this, like UniqueId, size (without another call to remote server) )
		// or may already be available to calling class so can use without another call to remote server
		
		if( !isset($this->_headers) )
		{
			Zend_Registry::get('log')->info('Headers not found (probably corrupted) while trying to process headers for message number ' . $this->_messageNum);
			return array(); //gracefully handle corrupted headers
		}
		$this->log = Zend_Registry::get('log');
		
		if( is_array($existingDataArray) )
		{
		
			$this->_headers = array_merge($this->_headers,$existingDataArray);
		
		}

		//NB Zend defines all headers as lower case unless '-' character where it is dropped and next character is Caps. wierd.
		//process headers to arrive at more human friendly headers
		
		if( !isset($this->_headers['sizeraw']) )
			$this->_headers['sizeraw'] = $this->getSize();
		$this->_headers['size'] = bytesToHumanReadable($this->_headers['sizeraw']);
		if( isset($this->_headers['date']) )
		{
			
			$this->_headers['dateraw'] = $this->_headers['date'];
			$this->_headers['date'] = $this->_headers['dateraw'];
			$this->_headers['epoch'] = strtotime($this->_headers['date']); //GMT
		
		}
		if( isset($this->_headers['preview']) )
			$this->_headers['preview'] = $this->_headers['preview'];
		
		//try flag as has attachment
		$this->_headers['hasattachments'] = 'no';
		$foundPart = null;
		if( $this->_headers['sizeraw'] > 2000 ) // to prevent huge messages from chocking processHeaders with downloadloading attachments that may not be wanted
			$this->_headers['hasattachments'] = 'yes';
		
		// USE IMAP BODYSTRUCTURE to get attachment types/list
		//need a better way of counting attachments cos currently to get a simple message list, below method will have to process all parts (slow, thick)

		//try find reply-to address
		if( isset($this->_headers['reply-to']) )
		{

			// do nothing	

		}
		elseif( isset($this->_headers['from']) )
			$this->_headers['reply-to'] = $this->_headers['from'];
		elseif( isset($this->_headers['return-path']) )
			$this->_headers['reply-to'] = $this->_headers['return-path'];
		else
			$this->_headers['reply-to'] = 'unknown';
		//try correct from if missing
		if( isset($this->_headers['from']) )
		{
			
			//do nothing
			
		}
		else if( isset($this->_headers['reply-to']) )
			$this->_headers['from'] = $this->_headers['reply-to'];
		else if( isset($this->_headers['return-path']) )
			$this->_headers['from'] = $this->_headers['return-path'];
		else
			$this->_headers['from'] = 'unknown';
		
		$this->_headers['fromOrigional'] = $this->_headers['from'];
		$fromProcessedObjects = getProcessedRecipientObjects($this->_headers['from']);
		$fromProcessedObject = $fromProcessedObjects[0];
		//try cleanup from (some can be illegal)
		$this->_headers['from'] = '"' . $fromProcessedObject->personalUTF8 . '" <' . $fromProcessedObject->mailbox . '@' . $fromProcessedObject->host . '>';
		$this->_headers['name'] = (strlen($fromProcessedObject->personalUTF8) > 0?$fromProcessedObject->personalUTF8:'Unknown');
		$this->_headers['email'] = $fromProcessedObject->mailbox . '@' . $fromProcessedObject->host;
		if( $this->_headers['email'] == '@' )
			$this->_headers['email'] = '';
		
		// Determine if the user has a photo specified for the message view
		require_once 'application/models/contacts.php';
		
		//$this->userData = Zend_Auth::getInstance()->getStorage()->read();
		$Account = Zend_Registry::get('Account'); //authorised user Account //CONSIDER: pop user photo code out because breaks IO best practice
		$this->_contacts = new contacts( array('Account' => $Account) );
		$photoEmail = trim(str_replace(array('<','>'),'', $this->_headers['email']));
		
		$this->_headers['UserPhoto'] = $this->_contacts->validateUserPhoto($photoEmail);

		//clean up message-id if necessary
		if( isset($this->_headers['message-id']) )
			if( is_array($this->_headers['message-id']) )
				$this->_headers['message-id'] = implode($this->_headers['message-id'], ', ');

		//sometimes no header supplied
		if( !isset($this->_headers['subject']) )
			$this->_headers['subject'] = '';
		if( isset($this->_headers['to']) )
		{
			//do nothing
		}
		elseif( isset($this->_headers['envelope-to']) )
			$this->_headers['to'] = $this->_headers['envelope-to'];
		else
			$this->_headers['to'] = 'unknown';
		
		if( !isset($this->_headers['content-type']) )
			$this->_headers['content-type'] = 'text/plain'; //looks like some senders like apache dont define this in their plain text emails

		//perform any remaining processing that requires searching _headers

		//try flag as important
		$this->_headers['priority'] = 'normal';

		foreach ($this->_headers as $key => &$value)
		{
			if ( strpos($key, 'x-priority') === 0 || strpos($key, 'x-msmail-priority') === 0 || strpos($key, 'importance') === 0)
			{
				$this->_headers['priority'] = $value;
				break; //NB this will break out on first header match
			}
			//if(!is_array($value) && substr($value, 0, 1) == '<' && substr($value, -1) == '>')
			//$this->_headers[$key] = substr($value, 1, -1);
            
			//already iconv_mime_decode on 'to', 'from' 'subject' done at this stage decode relevant to UTF-8
			//checked for missed decoding
			if( messageHandling::isMimeEncoded($value) )
			{
				
				$value = messageHandling::mimeEncodedDecode( $value );
			
			}    
			
		}
		
		
		$this->_headersProcessed = true;
		return $this->_headers;
	}

	public function getProcessedHeaders($existingDataArray = null)
	{
		if ( $this->_headersProcessed )
			return $this->_headers;
		else
			return $this->processHeaders($existingDataArray);
	}

}
