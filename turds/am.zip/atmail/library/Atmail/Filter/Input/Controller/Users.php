<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

/**
 * Defines filters and validators for the Users controller
 */
class Atmail_Filter_Input_Controller_Users extends Atmail_Filter_Input
{
    private $_filters = array(
    );
   
    private $_validators = array(
    );

    
    public function __construct($action, $params)
    {
        $filters    = (isset($this->_filters[$action]))? $this->_filters[$action] : array();
        $validators = (isset($this->_validators[$action]))? $this->_validators[$action] : array();
        parent::__construct($filters, $validators, $params);
        
    }
}
