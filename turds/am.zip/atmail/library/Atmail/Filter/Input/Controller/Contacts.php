<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

/**
 * Defines filters and validators for the Contacts controller
 */
class Atmail_Filter_Input_Controller_Contacts extends Atmail_Filter_Input
{
    private $_filters = array(
    
        // Filters for creategroup action
        'creategroup' => array(
            'newGroupName' => 'StripTags',
        ),
		'updategroupname' => array(
            'newGroupName' => 'StripTags',
        ),
		
        'updatecontact' => array(
            'UserTitle'       => array('StripTags'),
            'UserFirstName'   => array('StripTags'),
            'UserMiddleName'  => array('StripTags'),
            'UserLastName'    => array('StripTags'),
            'UserEmail'    => array('EmailPurifier'),
            'UserEmail2'    => array('EmailPurifier'),
            'UserEmail3'    => array('EmailPurifier'),
            'UserEmail4'    => array('EmailPurifier'),
            'UserEmail5'    => array('EmailPurifier'),
            'UserHomeAddress' => array('StripTags'),
            'UserHomeCity'    => array('StripTags'),
            'UserHomeState'   => array('StripTags'),
            'UserHomeZip'     => array('StripTags'),
            'UserHomeCountry' => array('StripTags'),
            'UserHomePhone'   => array('StripTags'),
            'UserHomeMobile'  => array('StripTags'),
            'UserHomeFax'     => array('StripTags'),
            'UserWorkPhone'   => array('StripTags'),
            'UserWorkMobile'  => array('StripTags'),
            'UserWorkFax'     => array('StripTags'),
            'UserWorkAddress' => array('StripTags'),
            'UserWorkCity'    => array('StripTags'),
            'UserWorkState'   => array('StripTags'),
            'UserWorkZip'     => array('StripTags'),
            'UserWorkCountry' => array('StripTags'),
            'UserWorkCompany' => array('StripTags'),
            'UserWorkTitle'   => array('StripTags'),
            'UserWorkDept'    => array('StripTags'),
            'UserWorkDept'    => array('StripTags'),            
            'UserDOB'         => array('StripTags'),
            'UserURL'         => array('StripTags'),
            'UserInfo'        => array('StripTags'),
        ),
        
        'editcontact' => array(
            'UserTitle'       => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserFirstName'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserMiddleName'  => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserLastName'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserEmail'		  => array('EmailPurifier'),
            'UserEmail2'      => array('EmailPurifier'),
            'UserEmail3'      => array('EmailPurifier'),
            'UserEmail4'      => array('EmailPurifier'),
            'UserEmail5'      => array('EmailPurifier'),
            'UserHomeAddress' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeCity'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeState'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeZip'     => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeCountry' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomePhone'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeMobile'  => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeFax'     => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkPhone'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkMobile'  => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkFax'     => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkAddress' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkCity'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkState'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkZip'     => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkCountry' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkCompany' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkTitle'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkDept'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkDept'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),            
            'UserDOB'         => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserURL'         => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserInfo'        => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
        ),
        
        'viewcontact' => array(
            'UserTitle'       => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserFirstName'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserMiddleName'  => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserLastName'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserEmail'    	  => array('EmailPurifier'),
            'UserEmail2'      => array('EmailPurifier'),
            'UserEmail3'      => array('EmailPurifier'),
            'UserEmail4'      => array('EmailPurifier'),
            'UserEmail5'      => array('EmailPurifier'),
            'UserHomeAddress' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeCity'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeState'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeZip'     => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeCountry' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomePhone'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeMobile'  => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeFax'     => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkPhone'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkMobile'  => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkFax'     => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkAddress' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkCity'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkState'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkZip'     => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkCountry' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkCompany' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkTitle'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkDept'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkDept'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),            
            'UserDOB'         => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserURL'         => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserInfo'        => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
        ),
        
        'index' => array(
            'UserTitle'       => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserFirstName'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserMiddleName'  => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserLastName'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserEmail'    	  => array('EmailPurifier'),
            'UserEmail2'      => array('EmailPurifier'),
            'UserEmail3'      => array('EmailPurifier'),
            'UserEmail4'      => array('EmailPurifier'),
            'UserEmail5'      => array('EmailPurifier'),
            'UserHomeAddress' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeCity'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeState'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeZip'     => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeCountry' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomePhone'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeMobile'  => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeFax'     => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkPhone'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkMobile'  => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkFax'     => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkAddress' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkCity'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkState'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkZip'     => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkCountry' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkCompany' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkTitle'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkDept'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkDept'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),            
            'UserDOB'         => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserURL'         => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserInfo'        => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'GroupName'		  => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
        ),

        
        'viewcontacts' => array(
            'UserTitle'       => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserFirstName'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserMiddleName'  => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserLastName'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserEmail'    	  => array('EmailPurifier', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserEmail2'      => array('EmailPurifier', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserEmail3'      => array('EmailPurifier', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserEmail4'      => array('EmailPurifier', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserEmail5'      => array('EmailPurifier', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeAddress' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeCity'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeState'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeZip'     => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeCountry' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomePhone'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeMobile'  => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserHomeFax'     => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkPhone'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkMobile'  => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkFax'     => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkAddress' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkCity'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkState'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkZip'     => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkCountry' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkCompany' => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkTitle'   => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkDept'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserWorkDept'    => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),            
            'UserDOB'         => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserURL'         => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
            'UserInfo'        => array('StripTags', array('HtmlEntities', array('quotestyle' => ENT_QUOTES, 'encoding' => 'UTF-8'))),
        ),
        
    );
   
    private $_validators = array(
        'creategroup' => array(),
                
        'addcontacttogroup' => array(
            'id'      => 'Int',
            'GroupID' => 'Int'
        ),

    );

    
    public function __construct($action, $params)
    {

        $filters    = (isset($this->_filters[$action]))? $this->_filters[$action] : array();
        $validators = (isset($this->_validators[$action]))? $this->_validators[$action] : array();
        parent::__construct($filters, $validators, $params);
        
    }
}
