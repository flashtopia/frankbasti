<?php

/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

/**
 * Defines filters and validators for the Composemessage controller
 */
class Atmail_Filter_Input_Controller_Composemessage extends Zend_Filter_Input
{
    
    private $_filters = array(
    	
		'send' => array(
            //'emailSubject' => 'HTMLPurifier', //(was causing corruption to legal subects) subject should allow any chars, we should purify/secure when viewing messages
		    'emailBodyHtml' => 'HTMLPurifier'
		)
	);
	
    private $_validators = array(
    ); 
    
    public function __construct($action, $params)
    {
        $filters    = (isset($this->_filters[$action]))? $this->_filters[$action] : array();
        $validators = (isset($this->_validators[$action]))? $this->_validators[$action] : array();
        parent::__construct($filters, $validators, $params);
    }
}
