<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

/**
 * Defines filters and validators for the Mail controller
 */
class Atmail_Filter_Input_Controller_Settings extends Atmail_Filter_Input
{
    
    private $_filters = array(
        'webmailsave' => array(       
			'fields' => 'HTMLPurifier', 
			'RealName' => array('HTMLPurifier', 'HtmlEntities') 
		),
		
		'webmail' => array(       
			'fields' => 'HTMLPurifier', 
			'ReplyTo' => 'EmailPurifier',
			'RealName' => array('HTMLPurifier', 'StripTags', 'HtmlEntities')
		),
		
		'mailsave' => array(       
			'Forward' => 'EmailPurifier', 
			'AutoReply' => array('HTMLPurifier', 'HtmlEntities') 
		),
		
		'mail' => array(       
			'Forward' => 'EmailPurifier', 
			'AutoReply' => array('HTMLPurifier', 'StripTags')
		),		
		
		'calendarsave' => array(
			'calDavUrl' => array('HTMLPurifier', 'StripTags'),
		),
		
		'serversave' => array(
			'username' => array('HTMLPurifier', 'StripTags'),
			'server' => array('HTMLPurifier', 'StripTags'),
			'port' => array('HTMLPurifier', 'StripTags'),
			'url' => array('HTMLPurifier', 'StripTags'),
		),
		
		'spam' => array(
			'rewrite_header' => array('HTMLPurifier', 'StripTags'),
		),
		
		'spamsave' => array(
			'rewrite_header' => array('HTMLPurifier', 'StripTags'),
		)
    );
   
    private $_validators = array(
        'settings' => array(
            'ReplyTo' => 'EmailAddress',
        )	
    ); 
    
    public function __construct($action, $params)
    {
    	//Zend_Registry::get('log')->debug( "\n\n" . print_r($action, true) . "\n" . __METHOD__ . ' #' . __LINE__ . ": \$action \n\n");
		$filters    = (isset($this->_filters[$action]))? $this->_filters[$action] : array();
        $validators = (isset($this->_validators[$action]))? $this->_validators[$action] : array();
        
        parent::__construct($filters, $validators, $params);
	}
}