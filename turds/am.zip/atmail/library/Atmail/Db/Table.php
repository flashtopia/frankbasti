<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

//this class is intended to be used to access simple tables without having to create seperate table classes for access
class Atmail_Db_Table extends Zend_Db_Table_Abstract
{
}