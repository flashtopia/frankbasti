<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*
* Author: Allan Wrethman
*/

require_once('library/Atmail/Abook/AbookAbstract.php');
require_once('library/Atmail/Vcard.php');

class Atmail_Abook_SyncML_OLDNOLONGERUSED extends Atmail_Abook_Abstract
{
	private $username		= '';
	private $password		= '';
	private $server			= 'localhost';
	private $port			= '80';
	private $url			= '';
	private $url_protocol		= "http";
	private $constructed_url	= '';
	private $_datastore;
	private $server_type		= 'default';
	private $_contacts = null; //local temporary copy of contacts from server for session-wide get, edit, add, delete, search data
	
	public function __construct(array $args = null)
	{
		
		//Zend_Registry::get('log')->debug( __METHOD__ . ' #' . __LINE__ );
		//Zend_Registry::get('log')->debug( "\n" . print_r($args, true) . "\n" . __METHOD__ . ' #' . __LINE__ . ": \$args \n");
		if( 	!isset($args['username']) 
			|| 	!isset($args['password'])
			|| 	!isset($args['url'])
		)
			throw new Atmail_Exception('CardDav Contacts constructor requires full carddav fields in arguments array');
		
		$this->username 	= $args['username'];
		$this->password		= $args['password'];
		$this->url			= $args['url'];
		
		if( isset($args['server']) )
			$this->server = $args['server'];
		if( isset($args['port']) )
			$this->port = $args['port'];
		if( isset($args['url_protocol']) ) 
			$this->url_protocol = $args['url_protocol'];
		
		$this->constructed_url	= $this->url_protocol . "://" . $this->server . ":" . $this->port . $this->url;
		
	    
		$this->_datasource = new Atmail_SyncML_SyncMLClient( array('url' => $this->constructed_url , 'username' => $this->username, 'password' => $this->password) );
		
		$this->_vcard_processor = new Vcard();
		$this->allowedFields = array('UserEmail', 'UserEmail2', 'UserEmail3', 'UserEmail4', 'UserEmail5', 'UserFirstName', 'UserMiddleName', 'UserLastName', 'UserTitle', 'UserGender', 'UserDOB', 'UserHomeAddress', 'UserHomeCity', 'UserHomeState', 'UserHomeZip', 'UserHomeCountry', 'UserHomePhone', 'UserHomeMobile', 'UserHomeFax', 'UserURL', 'UserWorkCompany', 'UserWorkTitle', 'UserWorkDept', 'UserWorkOffice', 'UserWorkAddress', 'UserWorkCity', 'UserWorkState', 'UserWorkZip', 'UserWorkCountry', 'UserWorkPhone', 'UserWorkMobile', 'UserWorkFax', 'UserType', 'UserInfo', 'EntryID', 'UserInfo', 'DateModified', 'UserPhoto', 'Global', 'Shared');
		return true;
		
	}
	
	private function getAllContacts()
	{
		
		$response = $this->_datasource->sendCommand('status');
		Zend_Registry::get('log')->debug( "\n" . print_r($response, true) . "\n" . __METHOD__ . ' #' . __LINE__ . ": \$response \n");
		$this->_contacts = array();
		
		
	}
	
	//SyncML Client should handle the following events - status/connect/ping, getAll, add, edit, delete
	
	public function TestServer()
	{
		
		return $this->_datastore->testAccount();
		
	}

	public function Count($groupID = '')
	{	
		//return count($this->_datastore->GetVcards(null, null, $this->url . '/'));	
	}
	
	public function populate_contact(array $contact)
	{
		return false;
		foreach($this->allowedFields as $requiredField)
		{
			if(!isset($contact[$requiredField]))
			{
				$contact[$requiredField] = '';		
			}	
		}	
		return $contact;	
	}
	
	public function GetPhoto(array $arguments = null)
	{
		return false;
		$contact = NULL;
		if(isset($arguments['id']))
		{
			// requesting a single contact
			$contact = $this->Get($arguments);	
		}
		$contacts[0] = $contact;
		
		return $contacts;
	}
	
	public function StorePhoto(array $arguments = null)
	{
		return false;
		$contact = null;
		if(isset($arguments['id']))
		{
			// requesting a single contact
			$contact = $this->Get($arguments);	
		}
		
		if($contact == null)
			return FALSE;
		
		$contact['UserPhoto'] = $arguments['UserPhoto'];

		return $this->Modify($contact);
	}
	
	public function Get(array $args = array() )
	{
		
		if( $this->_contacts == null )
		{
			
			$response = $this->_datasource->sendCommand('getAll');
			Zend_Registry::get('log')->debug( "\n" . print_r($response, true) . "\n" . __METHOD__ . ' #' . __LINE__ . ": \$response \n");
			$this->_contacts = array();
			
		}
		if( array_key_exists('id', $args) )
		{
		
			foreach( $this->_contacts as $k => &$contact )
				if( $contact['id'] == $args['id'] )
					return $contact;
			return false;
		
		}
		else
			return $this->_contacts;
			
	}
	
	public function Put(array $arguments = null)
	{
		return false;
		$data = array();
		foreach($arguments['contact'] as $k => $v ) 
		{
			
			if($k == 'UserDOB' && empty($v))
				continue;
				
			if( in_array($k, $this->allowedFields ) )
				$data[$k] = $v;		
		}

		$data["UID"] = create_guid();
		$contact_vcard = $this->_vcard_processor->exportPart($data);
		$contact_vcard = $this->_vcard_processor->build('', $contact_vcard);
	
		$id = $this->_datastore->DoPUTRequest($this->url . '/' . $data["UID"] . ".vcf" , $contact_vcard, '', "text/vcard; charset=utf-8");
		
		return $data["UID"];
	}

	public function Delete(array $arguments = null)
	{
		return false;
		if(!isset($arguments['serverID']) || !isset($arguments['id']))
		{
			throw new Atmail_Exception('CardDav::Delete requires id and serverID fields.');
		}

		// requesting a single contact
		$contact = $this->_datastore->GetVcardByUid($arguments['id'], $this->url . '/');	
		
		// store the contact
		$id = $this->_datastore->DoDELETERequest($this->url . '/'. $contact[0]['href'], $contact[0]['etag']);
				
	}

	public function Modify(array $arguments = null)
	{
		parent::Modify($arguments);
		return false;
		
		if(!isset($arguments['serverID']) || !isset($arguments['id']))
		{
			throw new Atmail_Exception('CardDav::Modify requires id and serverID fields.');
		}

		// requesting a single contact
		$contact = $this->_datastore->GetVcardByUid($arguments['id'], $this->url . '/');	

		// perform the required modifications
		$contact_vcard = $this->_vcard_processor->exportPart($arguments, $contact[0]['data']);
		$contact_vcard = $this->_vcard_processor->build('', $contact_vcard);

		// store the contact
		$id = $this->_datastore->DoPUTRequest($this->url . '/'. $contact[0]['href'], $contact_vcard, $contact[0]['etag'], "text/vcard; charset=utf-8");

		return $id;
	}

	public function Search(array $arguments = null)
	{
		return false;
		if(!isset($arguments['serverID']))
		{
			throw new Atmail_Exception('CardDav::Search requires serverID fields.');
		}
		
		if(isset($arguments['fuzzy']) && $arguments['fuzzy'] == 1)
		{
			$fuzzysearch = $arguments['UserEmail'];
			$filters = array(
					array("search" => 'contains', 'property' => 'FN', 'test' => $fuzzysearch),
					array("search" => 'contains', 'property' => 'NICKNAME', 'test' => $fuzzysearch),
					array("search" => 'contains', 'property' => 'N', 'test' => $fuzzysearch),				
					array("search" => 'contains', 'property' => 'EMAIL', 'test' => $fuzzysearch),
					array("search" => 'contains', 'property' => 'ADR', 'test' => $fuzzysearch),
					array("search" => 'contains', 'property' => 'TEL', 'test' => $fuzzysearch),
					array("search" => 'contains', 'property' => 'ORG', 'test' => $fuzzysearch)
					);
			$contacts = $this->_datastore->SearchEntry($filters, $this->url . '/');	
			foreach($contacts as &$contact)
			{
				$contact_temp = $this->_vcard_processor->viewPart($contact['data']);
				$contact_temp['id'] = $contact_temp['contactId'] = $contact_temp['UID'];
				$contact_temp['etag'] = $contact['etag'];
				$contact_temp['serverID'] = $arguments['serverID'];
				$contact_temp['href'] = $contact['href'];
				$contact_temp = $this->populate_contact($contact_temp);
				$contact = $contact_temp;
			}
			return $contacts;
		}
		else
		{
			$contacts = $this->_datastore->SearchEntry(array(array("search" => 'equals', "property" => 'FN', "test" => $arguments['fullname'])), $this->url . '/');	
			foreach($contacts as &$contact)
			{
				$contact_temp = $this->_vcard_processor->viewPart($contact['data']);
				$contact_temp['id'] = $contact_temp['contactId'] = $contact_temp['UID'];
				$contact_temp['etag'] = $contact['etag'];
				$contact_temp['serverID'] = $arguments['serverID'];
				$contact_temp['href'] = $contact['href'];
				$contact_temp = $this->populate_contact($contact_temp);
				$contact = $contact_temp;
			}
			if( empty($contacts[0]['id']) )
			{
				return 0;
			}
			else
			{
				return $contacts[0]['id'];
			}
		}
	}
}
	
