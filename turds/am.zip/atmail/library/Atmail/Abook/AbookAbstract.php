<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*
* Author: Brett Embery
*/

abstract class Atmail_Abook_Abstract
{
	protected	$_admin		= 0;		// administration mode, no further authorization required
	protected 	$_account	= '';		// account in use
	protected	$_domain	= '';		// domain of the account provided
	protected	$allowedFields 	= array();
	protected	$protocol	= SQL_MODE;
	protected	$_abook;	// addressbook class in use


	public function __construct(array $args = null)
	{

		if( !isset($args['Account']))
			throw new Atmail_Exception('Missing Account field in arguments array');

		$this->protocol = $args['protocol'];
		$this->_account = $args['Account'];               

		if( array_key_exists('admin', $args) && $args['admin'] == true ) 
		{
			//CONSIDER: moving user email1 as metadata for owner rather to a private field as causing problems with referential integrity and ownership 
			$this->_admin = true;
			$this->GroupwareZone = '';
		}
		else
		{
			$userDataComplete = users::getAllUserData( $this->_account );
			$this->GroupwareZone = $userDataComplete['Groups']['GroupwareZone'];
			unset($userDataComplete);
		}

		$email = explode('@', $this->_account);
		
		if(!empty($email['1']))
		{
			$this->_domain = $email['1'];
		}
		else
		{			
			$this->_domain = '';	
		}

		//CONSIDER: adding an instance of this class to the session/cache will include all the data, however is all the data needed, possilby if common (shared/global) contacts being hit alot
		/*$this->_tableNames = new dbTables();
		$this->AbookTableName = $this->_tableNames->Abook;
		$this->AbookGroupTableName = $this->_tableNames->AbookGroup;
		$this->AbookGroupNames = $this->_tableNames->AbookGroupNames;
		$this->AbookPermissions = $this->_tableNames->AbookPermissions;
		
		$this->view->global = Zend_Registry::get('config')->global;
        	if( isset($args['namespaceName']) )
			$this->_namespaceName = $args['namespaceName'];
		$this->_session = new Zend_Session_Namespace($this->_namespaceName); // session used as seperate persistent store for if caching disabled
		//_session mostly used to store session sort field, order, filter
		//CONSIDER moving session related stuff into application level and out of business logic
		if( !isset($this->_session->contactsSort) ) $this->_session->contactsSort = 'UserFirstName';
		if( !isset($this->_session->contactsOrder) ) $this->_session->contactsOrder = 'ASC';
		if( !isset($this->_session->groupsSort) ) $this->_session->groupsSort = 'GroupName';
		if( !isset($this->_session->groupsOrder) ) $this->_session->groupsOrder = 'ASC';
		if( !isset($this->_session->currentGroup) ) $this->_session->currentGroup = 'All';
		*/
		
		$this->dbAdapter = Zend_Registry::get('dbAdapter');
		//$this->dbAdapter->getProfiler()->setEnabled(true); //link to enable debug for performance 
		
		$this->allowedFields = array('UserEmail', 'UserEmail2', 'UserEmail3', 'UserEmail4', 'UserEmail5', 'UserFirstName', 'UserMiddleName', 'UserLastName', 'UserTitle', 'UserGender', 'UserDOB', 'UserHomeAddress', 'UserHomeCity', 'UserHomeState', 'UserHomeZip', 'UserHomeCountry', 'UserHomePhone', 'UserHomeMobile', 'UserHomeFax', 'UserURL', 'UserWorkCompany', 'UserWorkTitle', 'UserWorkDept', 'UserWorkOffice', 'UserWorkAddress', 'UserWorkCity', 'UserWorkState', 'UserWorkZip', 'UserWorkCountry', 'UserWorkPhone', 'UserWorkMobile', 'UserWorkFax', 'UserType', 'UserInfo', 'EntryID', 'UserInfo', 'DateModified', 'UserPhoto', 'Global', 'Shared');
		$this->log = Zend_Registry::get('log');
	}
	
	public function ChangeServer($serverId = null)
	{
		
		if($serverId == null)
		{
			$this->ChangeProtocol(array('Account' => $this->Account, 'protocol' => 'sql'));
			return TRUE;
		}
		
		// its a server group
		$abookServers = new Atmail_Abook_Servers( array('Account' => $this->Account) );
		$servers = $abookServers->GetServers();

		foreach($servers as $server)
		{
			if($serverId == $server['id'])
			{
				$this->ChangeProtocol($server);
				return TRUE;
			}	
		}
		return FALSE;
		
	}
	
	public function ChangeProtocol($args)
	{
		
		
		if( $args['protocol'] == SQL_MODE )
			$this->_abook = new Atmail_Abook_SQL($args);
		elseif( $args['protocol'] == CARDDAV_MODE )
			$this->_abook = new Atmail_Abook_CardDav($args);
		elseif( $args['protocol'] == SYNCML_MODE )
			$this->_abook = new Atmail_Abook_SyncML($args);
		else
			throw new Atmail_Exception('Contacts constructor received invalid procotol.');
		$this->protocol = $args['protocol'];
		
	}
	abstract public function TestServer();
	abstract public function GetPhoto(array $arguments = null);
	abstract public function StorePhoto(array $arguments = null);
	
	/**
	* Get the count of all contacts
	*
	* @param return array
	*/
	abstract public function Count($groupID = '');

	
	/**
	* Get a specific contact
	*
	* Minimum arguments:
	* id or GroupName
	*
	* if no id provide, will return all contacts for given GroupName
	* @param return array
	* NULL on error
	*/
	public function Get(array $arguments = null)
	{
		// argument verfication
		//if(!isset($arguments['id']) && !isset($arguments['GroupName']) && !isset($arguments['GroupID']))
		//	throw new Atmail_Exception('Abook::Get - requires id, GroupName or GroupID field in arguments array');		
	}

	/**
	* Put all data
	*
	* @param return array
	*/
	abstract public function Put(array $arguments = null);

	/**
	* Delete a record
	*
	* @param return array
	*/
	public function Delete(array $arguments = null)
	{
		if( !isset($arguments['id']) )
			throw new Atmail_Exception ('Abook::Delete - id field not found in arguments');		
	}

	/**
	* Modify data
	*
	* @param return array
	*/
	public function Modify(array $arguments = null)
	{
		if( !isset($arguments['id']) )
			throw new Atmail_Exception ('Abook::Modify - id field not found in arguments');
	}
	
	/**
	* Search data
	*
	* @param return array
	*/
	abstract public function Search(array $arguments = null);
}

