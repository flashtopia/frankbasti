<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*
* Author: Brett Embery
*/


/*

Methods:

* Get
* Put
* Delete
* Modify
* Search

To init object, sql:

$abook = new Atmail_Abook(array('protocol' => 'sql'));
$abook->new(array('Email' => 'test@test.com', 'UserFirstName' => 'test'));

To init object, carddav

$abook = new Atmail_Abook(
			array(	'protocol' => 'carddav', 
				'username' => 'test', 
				'password' => 'test', 
				'server' => 'test.com',
				'port' => '8800',
				'url' => '/addressbooks/users/test@test.com/addressbook'
				)
	);
$abook->new(array('Email' => 'test2@test.com', 'UserFirstName' => 'test'));


Also, I think we need to make a generic Abook.php that contains the "wrapper" classes that match fields.

e.g


Since, in the Atmail UI, we want to reference all our var names, like $EmailEmail, $UserFirstName, etc. And the backend code, provides the mapping, our var style, to what the CardDAV server or LDAP server use and return.

$sqlAbookFields = array('UserFirstName' => 'UserFirstName', 'UserEmail' => 'UserEmail');

This would match exactly, since the SQL format, is what we built the PHTML on. 

*/

// $cardDavAbookFields = array('UserFirstName' => 'FirstName.Attr', 'UserEmail' => 'Email1.Attr');

// define all constants
if(!defined('SQL_MODE'))						define('SQL_MODE', 						'sql');
if(!defined('CARDDAV_MODE'))					define('CARDDAV_MODE', 					'carddav');
if(!defined('LDAP_MODE'))						define('LDAP_MODE', 					'ldap');
if(!defined('SYNCML_MODE'))						define('SYNCML_MODE', 					'syncml');
if(!defined('GROUPWARE_SYSTEM_ZONE'))			define('GROUPWARE_SYSTEM_ZONE', 		'System');
if(!defined('GROUPWARE_DOMAIN_ZONE'))			define('GROUPWARE_DOMAIN_ZONE', 		'Domain');
if(!defined('GROUPWARE_PERSONAL_ZONE'))			define('GROUPWARE_PERSONAL_ZONE', 		'');
if(!defined('GROUPWARE_DISABLED'))				define('GROUPWARE_DISABLED', 			'Off');
if(!defined('GROUP_GLOBAL'))					define('GROUP_GLOBAL', 					'-1');
if(!defined('GROUP_SHARED'))					define('GROUP_SHARED', 					'-2');
if(!defined('GROUP_AUTO'))						define('GROUP_AUTO', 					'-3');
if(!defined('GROUP_FAV'))						define('GROUP_FAV', 					'-4');
if(!defined('GROUPWARE_SHARED_ABOOK_ENABLED'))	define('GROUPWARE_SHARED_ABOOK_ENABLED', '1');
if(!defined('CONTACT_INVALID_ID'))				define('CONTACT_INVALID_ID', 			'-1');
if(!defined('CONTACT_INVALID_GROUP_ID'))		define('CONTACT_INVALID_GROUP_ID', 		'-999');
if(!defined('CONTACT_UNDEFINED_GROUP'))			define('CONTACT_UNDEFINED_GROUP', 		'ungrouped');
if(!defined('ABOOK_SERVER_GROUP_TAG'))			define('ABOOK_SERVER_GROUP_TAG', 		'server');

require_once('Atmail/Abook/AbookAbstract.php'); //need this manual include because not following naming standard
class Atmail_Abook extends Atmail_Abook_Abstract
{	
	public function __construct(array $args = null)
	{

		if( !isset($args['protocol']) || !isset($args['Account']))
			throw new Atmail_Exception('Contacts constructor requires protocol field in arguments array');

		$this->ChangeProtocol($args);
		
		$this->dbAdapter = Zend_Registry::get('dbAdapter');
	}

	public function Count($groupID = '')
	{

		if(strstr($groupID, ABOOK_SERVER_GROUP_TAG) != NULL)
		{

			if( !$this->ChangeServer($groupID) )
				return FALSE;	
			$total = $this->_abook->Count($groupID);
			$this->ChangeServer();

		}
		else
			$total = $this->_abook->Count($groupID);

		return $total;

	}
	
	public function GetPhoto(array $arguments = null)
	{

		if(isset($arguments['serverID']))
		{
			if( !$this->ChangeServer($arguments['serverID']) )
				return FALSE;	
			$data = $this->_abook->GetPhoto($arguments);
			$this->ChangeServer();
		}
		else
			$data = $this->_abook->GetPhoto($arguments);
		
		return $data;

	}
	
	public function StorePhoto(array $arguments = null)
	{
		if( !isset($arguments['groupID']) && isset($arguments['GroupID']) )
			$arguments['groupID'] = $arguments['GroupID'];	
		
		if(isset($arguments['groupID']) && strstr($arguments['groupID'], ABOOK_SERVER_GROUP_TAG) != NULL)
		{
			$arguments['serverID'] = $arguments['groupID'];
			if(!$this->ChangeServer($arguments['serverID']))
			{
				return FALSE;	
			}
			$result = $this->_abook->StorePhoto($arguments);
			$this->ChangeServer();
		}
		else
		{
			$result = $this->_abook->StorePhoto($arguments);
		}
				
		return $result;	
	}
	
	public function Get(array $arguments = null)
	{
		if(!isset($arguments['groupID']) && isset($arguments['GroupID']))
		{
			$arguments['groupID'] = $arguments['GroupID'];	
		}
		
		if(isset($arguments['groupID']) && strstr($arguments['groupID'], ABOOK_SERVER_GROUP_TAG) != NULL)
		{
			$arguments['serverID'] = $arguments['groupID'];
			if(!$this->ChangeServer($arguments['serverID']))
			{
				return FALSE;	
			}
			$contacts = $this->_abook->Get($arguments);
			$this->ChangeServer();
		}
		else
		{
			$contacts = $this->_abook->Get($arguments);
		}
				
		return $contacts;
	}
	
	public function Put(array $arguments = null)
	{
		if(!isset($arguments['groupID']) && isset($arguments['GroupID']))
		{
			$arguments['groupID'] = $arguments['GroupID'];	
		}
		
		if(isset($arguments['groupID']) && strstr($arguments['groupID'], ABOOK_SERVER_GROUP_TAG) != NULL)
		{
			$arguments['serverID'] = $arguments['groupID'];
			if(!$this->ChangeServer($arguments['serverID']))
			{
				return FALSE;	
			}
			$result = $this->_abook->Put($arguments);
			$this->ChangeServer();
		}
		else
		{
			$result = $this->_abook->Put($arguments);
		}
		
		return $result;
	}

	public function Delete(array $arguments = null)
	{
		if(!isset($arguments['groupID']) && isset($arguments['GroupID']))
		{
			$arguments['groupID'] = $arguments['GroupID'];	
		}
		
		if(isset($arguments['groupID']) && strstr($arguments['groupID'], ABOOK_SERVER_GROUP_TAG) != NULL)
		{
			$arguments['serverID'] = $arguments['groupID'];
			if(!$this->ChangeServer($arguments['serverID']))
			{
				return FALSE;	
			}
			$result = $this->_abook->Delete($arguments);
			$this->ChangeServer();
		}
		else
		{
			$result = $this->_abook->Delete($arguments);
		}
		
		return $result;
	}

	public function Modify(array $arguments = null)
	{
		if(isset($arguments['serverID']) && !empty($arguments['serverID']))
		{
			if(!$this->ChangeServer($arguments['serverID']))
			{
				return FALSE;	
			}
			$modification = $this->_abook->Modify($arguments);
			$this->ChangeServer();
		}
		else
		{
			$modification = $this->_abook->Modify($arguments);
		}
		
		return $modification;
	}

	public function Search(array $arguments = null)
	{		
		if(!isset($arguments['groupID']) && isset($arguments['GroupID']))
		{
			$arguments['groupID'] = $arguments['GroupID'];	
		}
		
		if(isset($arguments['groupID']) && strstr($arguments['groupID'], ABOOK_SERVER_GROUP_TAG) != NULL)
		{
			$arguments['serverID'] = $arguments['groupID'];
			if(!$this->ChangeServer($arguments['serverID']))
			{
				return FALSE;	
			}
			$result = $this->_abook->Search($arguments);
			$this->ChangeServer();
		}
		else
		{
			$result = $this->_abook->Search($arguments);
		}
		
		return $result;
	}
	
	public function TestServer()
	{
		
		return $this->_abook->TestServer();
		
	}
	
}

