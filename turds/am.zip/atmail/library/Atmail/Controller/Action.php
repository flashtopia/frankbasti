<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

abstract class Atmail_Controller_Action extends Zend_Controller_Action {

	public function init() 
	{
		
		$this->view->setEncoding('UTF-8');
		
		$this->view->requestParams = $this->_request->getParams();
		$this->request = $this->getRequest();
		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		$this->view->appBaseUrl = $this->_request->getBaseUrl() . (strpos($this->_request->getBaseUrl(),'index.php')?'':'/index.php');
		$this->view->moduleBaseUrl = $this->view->appBaseUrl . ($this->view->requestParams['module']=='default'?'':DIRECTORY_SEPARATOR . $this->view->requestParams['module']);
		$this->log = Zend_Registry::get('log');
		
		$this->view->addHelperPath('library/Atmail/View/Helper/', 'Atmail_View_Helper');
		
		// check is an XML request or not only allow index to be rendered normally (i.e. full page load)
		if ( $this->getRequest()->isXmlHttpRequest() ) {
			$this->_helper->viewRenderer->setNoRender();
			if( !isset($this->view->errors) )    
				$this->view->errors = array();
			if( !isset($this->view->notices) )    
				$this->view->notices = array();
		 	if( !isset($this->view->jsonIdsToRender) )    
				$this->view->jsonIdsToRender = array();
			require_once 'library/jQuery/jQuery.php';
		} 

		// Call the locale library - This handles all the translations, side wide
		Atmail_Locale::setupLocaleAndTranslation( Zend_Registry::get('Zend_Locale')->toString() );
		
	}
	
    /**
     * Render a view
     *
     * Renders a view. By default, views are found in the view script path as
     * <controller>/<action>.phtml. You may change the script suffix by
     * resetting {@link $viewSuffix}. You may omit the controller directory
     * prefix by specifying boolean true for $noController.
     *
     * By default, the rendered contents are appended to the response. You may
     * specify the named body content segment to set by specifying a $name.
     *
     * @see Zend_Controller_Response_Abstract::appendBody()
     * @param  string|null $action Defaults to action registered in request object
     * @param  string|null $name Response object named path segment to use; defaults to null
     * @param  bool $noController  Defaults to false; i.e. use controller name as subdir in which to search for view script
     * @return void
     */
    /*
    public function render($action = null, $name = null, $noController = false)
    {
        if ($resp = $this->_helper->pluginCall("setViewRenderAction")) {
            $action = $resp;
        }
        
        if (!$this->getInvokeArg('noViewRenderer') && $this->_helper->hasHelper('viewRenderer')) {
            //return $this->_helper->viewRenderer->render($action, $name, $noController);
        }

        $view   = $this->initView();
        if ($resp = $this->_helper->pluginCall("setViewRenderScript")) {
            $script = $resp;
        } else {
            $script = $this->getViewScript($action, $noController);
        }
        
        $data = $view->render($script);
        
        if ($resp = $this->_helper->pluginCall("preAppendToResponse", $data)) {
            $data = $resp;
        }
        
        $this->getResponse()->appendBody($data, $name);
    }
    */
    	
}
