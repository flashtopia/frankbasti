<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

class Atmail_Controller_Action_Helper_PluginCall extends Zend_Controller_Action_Helper_Abstract
{
	public function direct($call, $args=array())
	{
		return $this->pluginCall($call, $args);
	}
	
	public function pluginCall($call, $args=array())
	{
		$return = '';
		
		foreach (Zend_Controller_Front::getInstance()->getPlugins() as $plugin)  {
			// Only call custom events on Atmail_Controller_Plugin based plugins
			if ($plugin instanceof Atmail_Controller_Plugin && method_exists($plugin, $call)) {
				// Set the current controller
				$plugin->setActionController($this->getActionController());
                $return .= $plugin->$call($args);
			}
		}		
		return $return;
	}
}
		