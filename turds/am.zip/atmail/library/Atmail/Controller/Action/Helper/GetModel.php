<?php
 /**
 * @category   Atmail
 * @package    Atmail_Controller
 * @author     Allan Wrethman allan@staff.atmail.com
 * @license    Copyrighted by Atmail 2008
 */
 
/**
 * @category   Atmail
 * @package    Atmail_Controller
 * @author     Allan Wrethman allan@staff.atmail.com
 * @license    Copyrighted by Atmail 2008
 */
class Atmail_Controller_Action_Helper_GetModel extends Zend_Controller_Action_Helper_Abstract
{
    /**
     * Zend_Registry instance
     * @var Zend_Registry
     */
    protected $_container;
 
    /**
     * Handle helper as broker method
     * @param string $class Class name.
     * @param null|string $module Module name.
     * @return object
     */
    public function direct($class)
    {
        return $this->getModel($class);
    }

	/**
     * Return a single instance of the model object
     * @param string $filename Filename.
     * @param null|string $module Module name.
	 * @throws Zend_Controller_Action_Exception 
     * @return requested object
     */
	public function getModel($filename)
    {
         $className = (string) $filename;
        if (!$this->getContainer()->isRegistered($className)) {
            $completeFilename = $filename . '.php';
            Zend_Loader::loadFile('application/models/' . $completeFilename);
			$this->getContainer()->set($className, new $className);
        }
        return $this->getContainer()->get($className);
    }
 
    /**
     * Returns _container
     * @return Zend_Registry
     */
    public function getContainer()
    {
        if ($this->_container === null)
            $this->_container = Zend_Registry::getInstance();
        return $this->_container; 
    }
 
    /**
     * Set _container instance
     * @param Zend_Registry $container
     * @return Atmail_Controller_Action_Helper_GetModel
     */
    public function setContainer(Zend_Registry $container)
    {
        $this->_container = $container;
        return $this;
    }
}