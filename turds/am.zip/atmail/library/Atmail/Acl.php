<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

class Atmail_Acl extends Zend_Acl
{
    public function __construct(Zend_Auth $auth)
    {
        //In2Naos: This is a dummy ACL profile until abstracted to db model
		
		$roleGuest = new Zend_Acl_Role('guest');

		$this->add(new Zend_Acl_Resource('index'));
		$this->add(new Zend_Acl_Resource('main'));
		$this->add(new Zend_Acl_Resource('mail'));
		$this->add(new Zend_Acl_Resource('contacts'));
		$this->add(new Zend_Acl_Resource('calendar'));
		$this->add(new Zend_Acl_Resource('subadmin'));
		$this->add(new Zend_Acl_Resource('webadmin'));  

        $this->addRole(new Zend_Acl_Role('guest')); 
        $this->addRole(new Zend_Acl_Role('user'), 'guest');
        $this->addRole(new Zend_Acl_Role('subadmin'), 'user');
        $this->addRole(new Zend_Acl_Role('webadmin'), 'subadmin');

        // Guest may only view index (login logout ... basic help etc.)
        $this->allow('guest', 'index');
        $this->deny('user', 'mail', 'delete'); // sample deny user delete priv
        $this->allow('user', 'main');
		$this->allow('user', 'mail');
		$this->allow('user', 'contacts');
		$this->allow('subadmin', 'subadmin');
        $this->allow('webadmin'); // unrestricted access

    }
}
