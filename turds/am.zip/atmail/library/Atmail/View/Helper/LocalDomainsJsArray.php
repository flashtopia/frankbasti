<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

class Atmail_View_Helper_LocalDomainsJsArray extends Zend_View_Helper_Abstract
{
    public function localDomainsJsArray()
    {
        $js = "var localDomains = new Array();\n";
	    foreach (domains::getList() as $dom) {
	        $js .= "localDomains['$dom'] = 1;\n";
	    }
	    
	    return $js;
    }
}
