<?php

require_once('library/Atmail/DepCheck.php');

/************************************************* 6.20.4 *******************************************************/
function _upgrade_6_20_4($client)
{
	// copy the clean-logs.php script into the daily cron
	foreach (array("/etc/cron.daily", "/etc/periodic/daily") as $cronDir) {	
		if (is_dir($cronDir)) {
			echo "Copying new log-rotation scripts to $cronDir ...\n";
			copy(APP_ROOT . "/utilities/tools/clean-logs.php", $cronDir . "/clean-logs.php");
			exec('chown root ' . $cronDir . '/clean-logs.php; chmod u+x ' . $cronDir . '/clean-logs.php');
			echo "New log-rotation enabled. Specify log rotation date-range via the Webadmin > Settings > Global Settings\n\n";
			break;
		}
	}
	
	if(!$client) {
		
		// call the dep checker
		echo "Checking new dependancy requirements..\n";
		check_deps( array('--install=1', '--upgradecli=1' ) );
		
		echo "Rebuilding Exim for security patch ...\n";
		_republishExim(array('rebuild' => 1));		
		
		echo "Updating ClamAV version ...\n";
		_republishAv(array('rebuild' => 1));
		
	}

}

/************************************************* 6.20.3 *******************************************************/
function _upgrade_6_20_3($client)
{
	// 6.20.3 upgrade
	if(!$client)
	{
		echo "Correcting directory permissions..\n";
		if(file_exists('/usr/local/atmail/webmail/config'))
		{
			system('chown atmail /usr/local/atmail/webmail/config');	
		}
		if(file_exists('/usr/local/atmail/webmail/log'))
		{
			system('chown -R atmail /usr/local/atmail/webmail/log');	
		}
		if(file_exists('/usr/local/atmail/webmail/library/HTMLPurifier/DefinitionCache/Serializer/HTML'))
		{
			system('chown -R atmail /usr/local/atmail/webmail/library/HTMLPurifier/DefinitionCache/Serializer/HTML');	
		}
	}
}

/************************************************* 6.20.2 *******************************************************/
function _upgrade_6_20_2($client)
{
	// 6.20.2 upgrade	
	_patchCalendarServer();
}

/************************************************* 6.20.1 *******************************************************/
function _upgrade_6_20_1($client)
{
	// NO UPDATE REQUIRED
}

/************************************************* 6.20 *******************************************************/
function _upgrade_6_20_0($client)
{
	_upgrade_6_20($client);
}

function _upgrade_6_20($client)
{
	if(!$client)
	{
		echo "Adding Atmail automation script for AV/Spam updates..\n";
		system('php /usr/local/atmail/server_source/scripts/buildav.php');
	}
}

/************************************************* 6.1.9 *******************************************************/
function _upgrade_6_1_9($client)
{
	_patchCalendarServer();
}

/************************************************* 6.1.8 *******************************************************/
function _upgrade_6_1_8($client)
{
	_patchCalendarServer();

	if(!$client)
	{
		echo "Correcting spam assassin permissions..\n";
		if(file_exists('/usr/local/atmail/spamassassin/etc/sqlsettings.cf'))
		{
			system('chown -R atmail /usr/local/atmail/spamassassin');	
		}
		
		_republishDovecot(array('updateAuth'=>1, 'updateDB'=>1));
				
		echo "Updating user creation files..\n";
		$output = `cp /usr/local/atmail/server_source/etc/create-imap.sh /usr/local/atmail/mailserver/etc/create-imap.sh`;
		echo $output . "\n";
		$output = `cp /usr/local/atmail/server_source/etc/create-pop.sh /usr/local/atmail/mailserver/etc/create-pop.sh`;
		echo $output . "\n";

		_republishExim();
	}
}

/************************************************* 6.1.7 *******************************************************/
function _upgrade_6_1_7($client)
{
	if(!$client)
	{
		_republishExim();
	}
}

/************************************************* 6.1.6 *******************************************************/
function _upgrade_6_1_6($client)
{
	// NOTHING TO DO
}

/************************************************* 6.1.5 *******************************************************/
function _upgrade_6_1_5($client)
{
	// NOTHING TO DO
}

/************************************************* 6.1.4 *******************************************************/
function _upgrade_6_1_4($client)
{
	_patchCalendarServer();
	
	if(!$client)
	{
		echo "Correcting spamassassin sql settings config permissions..\n";
		system("chown atmail:atmail /usr/local/atmail/spamassassin/etc/sqlsettings.cf");
		
		_republishDovecot(array('updateAll'=>1, 'updateDB'=>1));
	} 
}

/************************************************* 6.1.3 *******************************************************/
function _upgrade_6_1_3($client)
{
	if(!$client)
	{
		// call the dep checker
		echo "Checking new dependancy requirements..\n";
		check_deps( array('--install=1', '--upgradecli=1' ) );
		
		// depcheck has already installed mysql ( I HOPE SO! ) so no need to check for sql restart
		if(file_exists('/usr/local/atmail/webmail/library/Atmail/.mysqlrestart'))
		{
			unlink('/usr/local/atmail/webmail/library/Atmail/.mysqlrestart');
		}
		
		_republishExim(array('rebuild'=>1));
		_republishDovecot(array('rebuild'=>1, 'updateAll'=>1));
	
		echo "Updating Spamassassin configuration file..\n";
		$output = `cp /usr/local/atmail/server_source/etc/local.cf /usr/local/atmail/spamassassin/etc/local.cf`;
		system("chown atmail /usr/local/atmail/spamassassin/etc/local.cf");
		system("mkdir /usr/local/atmail/spamassassin/bayes");
		system("chown atmail /usr/local/atmail/spamassassin/bayes");
		config::publishServerConfigFiles('spamassassin');
		system("chown atmail:atmail /usr/local/atmail/spamassassin/etc/sqlsettings.cf");
		
		echo "Updating SQL settings to configuration files..\n";
		config::publishDbConfigChangesToServerConfigFiles($global);
	}
}

/************************************************* 6.1.2 *******************************************************/
function _upgrade_6_1_2($client)
{
	_patchCalendarServer();
}

/************************************************* 6.1.1 *******************************************************/
function _upgrade_6_1_1($client)
{
	if(!$client)
	{
		_republishExim();
		_republishDovecot(array('rebuild'=>1, 'publishDB'=>1, 'updateAuth'=>1));
		
		echo "Changing ownership of /usr/local/atmail/users to chmod 700 for security..\n";
		for ($i=97; $i <= 123; $i++)
    	{
            if ($i == 123)
			{
                    $a = 'other';
            }
			else
			{
                    $a = chr($i);
			}			
            system("chmod -R 700 /usr/local/atmail/users/$a");
			echo ".";
    	}
		echo "\n";
	}
}

/************************************************* 6.1.0 *******************************************************/
function _upgrade_6_1_0($client)
{
	if(!$client)
	{
		_republishDovecot(array('rebuild'=>1));
	    $output = `chown -R atmail /usr/local/atmail/webmail/log/`;
	  	echo $output . "\n";
	}
	
	_patchCalendarServer();
}


/************************************************* 6.0.11 *******************************************************/
function _upgrade_6_0_11($client)
{
	if(!$client)
	{
		echo "Updating Atmail service startup script\n";	
		if (file_exists('/etc/init.d'))
		{
		    system("cp -f /usr/local/atmail/server_source/scripts/atmailserver.sysvinit /etc/init.d/atmailserver");
		    system("chmod 755 /etc/init.d/atmailserver");           
		}
		elseif (file_exists('/etc/rc.d/'))
		{
			system("cp /usr/local/atmail/server_source/scripts/atmailserver.sysvinit /etc/rc.d/atmailserver");
			system("chmod 755 /etc/rc.d/atmailserver");
		}
		elseif (file_exists("/usr/local/etc/rc.d/"))
		{
			system("cp /usr/local/atmail/server_source/scripts/atmailserver.sysvinit /usr/local/etc/rc.d/z-atmailserver.sh");
			system("chmod 755 /usr/local/etc/rc.d/z-atmailserver.sh");
		}
		else
		{
			fwrite(STDOUT, "Please copy the /usr/local/atmail/server_source/scripts/atmailserver.sysvinit to your system startup file");
		}
	}
}


/************************************************* 6.0.10 *******************************************************/
function _upgrade_6_0_10($client)
{
	if(!$client)
	{	
		_republishExim();
	}
}

/************************************************* 6.0.9 *******************************************************/
function _upgrade_6_0_9($client)
{
	if(!$client)
	{
		_republishExim();

		_republishAv(array('rebuild' => 1));
	
		echo "Adding Atmail automation script for AV/Spam updates\n";
		if (file_exists("/etc/cron.daily/"))
		{
			copy("/usr/local/atmail/server_source/scripts/atmail-automation.php", "/etc/cron.daily/atmail-automation.php");
			system("chmod 755 /etc/cron.daily/atmail-automation.php");
			system("php /etc/cron.daily/atmail-automation.php");
		}
		elseif (file_exists("/etc/periodic/daily/"))
		{
			copy("/usr/local/atmail/server_source/scripts/atmail-automation.php", "/etc/periodic/daily/502.atmail-automation.php");
			system("chmod 755 /etc/periodic/daily/502.atmail-automation.php");
			system("php /etc/periodic/daily/502.atmail-automation.php");
		}
		else
		{
			echo "NOTE: Daily cron directory not detected on system. Please configure the system\ncrontab to automatically run the:\n\n/usr/local/atmail/server_source/scripts/atmail-automation.php command on a daily basis.\n\nThis is required to download the latest AV and Anti-Spam files.\n";
		}
	}
	
	_reinstallCalendarServer();
}

/************************************************* 6.0.8 *******************************************************/
function _upgrade_6_0_8($client)
{
	_reinstallCalendarServer();
}

/************************************************* 6.0.7 *******************************************************/
function _upgrade_6_0_7($client)
{
	if(!$client)
	{
		_republishExim();
	}
}

/************************************************* 6.0.6 *******************************************************/
function _upgrade_6_0_6($client)
{
	// NOTHING TO DO
}

/************************************************* 6.0.5 *******************************************************/
function _upgrade_6_0_5($client)
{
	if(!$client)
	{
		_republishExim(array('rebuild'=>1));
		_republishDovecot(array('updatessl'=>1));
	}
	
	_patchCalendarServer();
}

function _republishDovecot($opts)
{
	if(isset($opts['updatessl']))
	{
		if(file_exists("/usr/local/atmail/mailserver/ssl/private/dovecot.pem"))
		{
			echo "Updating IMAP SSL key..\n";
			rename("/usr/local/atmail/mailserver/ssl/private/dovecot.pem", "/usr/local/atmail/mailserver/ssl/private/dovecot.key");

			$dovecot['imapssl_key'] = "/usr/local/atmail/mailserver/ssl/private/dovecot.key";
			config::save('dovecot', $dovecot);
		}
	}
	
	if(isset($opts['updateAuth']))
	{
		echo "Copying new Dovecot Auth configuration file over old..\n";
		$output = `cp /usr/local/atmail/server_source/etc/dovecot-users-sql.conf /usr/local/atmail/mailserver/etc/dovecot-users-sql.conf`;
		echo $output . "\n";	
	}
	
	if(isset($opts['rebuild']))
	{
		echo "Rebuilding Dovecot..\n";
		system("php /usr/local/atmail/server_source/scripts/buildpop3imap.php");
	}
	
	echo "Publishing POP3/IMAP settings..\n";
	
	echo "Copying new Dovecot configuration file(s)..\n";
	$output = `cp /usr/local/atmail/server_source/etc/dovecot.conf /usr/local/atmail/mailserver/etc/dovecot.conf`;
	system("chown atmail /usr/local/atmail/mailserver/etc/dovecot.conf");

	if(isset($opts['updateAll']))
	{
		$output = `cp /usr/local/atmail/server_source/etc/dovecot-ldap.conf /usr/local/atmail/mailserver/etc/dovecot-ldap.conf`;
		system("chown atmail /usr/local/atmail/mailserver/etc/dovecot-ldap.conf");	
		$output = `cp /usr/local/atmail/server_source/etc/dovecot-sql.conf /usr/local/atmail/mailserver/etc/dovecot-sql.conf`;
		system("chown atmail /usr/local/atmail/mailserver/etc/dovecot-sql.conf");
		$output = `cp /usr/local/atmail/server_source/etc/dovecot-users-sql.conf /usr/local/atmail/mailserver/etc/dovecot-users-sql.conf`;
		system("chown atmail /usr/local/atmail/mailserver/etc/dovecot-users-sql.conf");
	}
	if(isset($opts['updateSQL']))
	{
		echo "Publishing Dovecot settings to new configure file..\n";
		config::publishServerConfigFiles('dovecotsql');	
	}
	
	config::publishServerConfigFiles('dovecot');	
	
	if(isset($opts['publishDB']))
	{
		config::publishDbConfigChangesToServerConfigFiles($global);
	}
}

function _republishExim($opts)
{
	if(isset($opts['rebuild']))
	{
		echo "Rebuilding Exim..\n";
		system("php /usr/local/atmail/server_source/scripts/buildexim.php");
	}
	
	echo "Copying new configuration file template over old..\n";
	$output = `cp /usr/local/atmail/server_source/etc/configure.a6 /usr/local/atmail/mailserver/configure`;
	system("chown atmail /usr/local/atmail/mailserver/configure");
	echo $output . "\n";

	echo "Publishing EXIM settings to new configure file..\n";
	config::publishServerConfigFiles('exim');	
}

function _republishAv($opts)
{
	if(isset($opts['rebuild']))
	{
		echo "Rebuilding ClamAV ...\n";
		system('php /usr/local/atmail/server_source/scripts/buildav.php');
	}
	
	echo "Copying new ClamAV configuration files ...\n";
	$output = `cp /usr/local/atmail/server_source/etc/clamd.conf /usr/local/atmail/av/etc/clamd.conf`;
	system("chown atmail /usr/local/atmail/av/etc/clamd.conf");

	$output = `cp /usr/local/atmail/server_source/etc/freshclam.conf /usr/local/atmail/av/etc/freshclam.conf`;
	system("chown atmail /usr/local/atmail/av/etc/freshclam.conf");
	
	if(file_exists("/etc/cron.daily/atmail-automation.php"))	{
		echo "Updating AV signatures ...\n";
		system("/etc/cron.daily/atmail-automation.php");
		
	} elseif( file_exists("/etc/periodic/daily/502.atmail-automation.php"))	{
		echo "Updating AV signatures ...\n";
		system("/etc/periodic/daily/502.atmail-automation.php");
		
	}
	
}

function _sanityCheckInstallation($versionCurrentlyConfigured, $versionCurrentLocalCodebase)
{
	if($versionCurrentlyConfigured == false)
	{
	    exit("Cannot determine previous version ($versionCurrentlyConfigured), please run: php update.php [old-version-number]\n");
	}
	else
	{
		echo "Installed version detected as: " . $versionCurrentlyConfigured . "\n";
	}

	if($versionCurrentLocalCodebase == false)
	{
	    exit("Cannot determine new version ($versionCurrentLocalCodebase). Aborting.\n");
	}
	else
	{
		echo "New version detected as: " . $versionCurrentLocalCodebase . "\n";
	}

	if( $versionCurrentlyConfigured == $versionCurrentLocalCodebase )
	{
		echo "Latest version already installed!\n\n";
		echo "To re-run migration scripts from a previous version, run\n";
		echo "php server-update.php [old-version-number]\n\n";
		echo "This will execute the update commands from the version specified\n";
		exit;
	}

	if ( version_compare(PHP_VERSION, '5.1.6', '<') )
	{
		//TODO: can we update php as part of the process
		// you may beed to drop this into future updates requiring newer version of PHP. might be better to update to highest version needed, but then cant gracefully handle failing half way through update (wont have a clear, expected fail point)
	    exit ('PHP must be updated to 5.1.6 or newer, currently running version of PHP is: ' . PHP_VERSION . "\n");
	}	
}

function _findCalendarServerSource()
{
	if( is_dir('/usr/local/atmail/server_source/calendar_server/src/') )
	{
		$calendarSrcPath = '/usr/local/atmail/server_source/calendar_server/src/';
	}
	else if( is_dir('../server_sources/calendar_server/src/') )
	{
		$calendarSrcPath = '../server_source/calendar_server/src/';
	}
	else
	{
		exit("Unable to find calendar server source directory. Aborting.\n");
	}
	
	$calendarSrcPath = realpath($calendarSrcPath) .'/';
	echo "Found calendar server installation at : " . $calendarSrcPath;
	
	return $calendarSrcPath;	
}

function _mountCalendarServer($mount = true)
{
	if( file_exists('/usr/local/atmail/calserver.img') )
	{
		// calendar is special
		if($mount)
		{
			echo "Mounting calendar server image..";
			system("mount -o rw,loop,user_xattr /usr/local/atmail/calserver.img /usr/local/atmail/calendarserver");
		}
		else
		{
			echo "Unmounting calendar server image..";
			system("umount -rd /usr/local/atmail/calendarserver");
		}
	}	
}

function _patchCalendarServer()
{
	$output=false;
	
	_mountCalendarServer();	
	$calendarSrcPath = _findCalendarServerSource();
	
	if (file_exists('/usr/local/atmail/calendarserver/server/run'))
	{
		echo "Patching calendar server\n";
		foreach(array('aggregate.py', 'calendar.py', 'directory.py', 'md5crypt.py', 'principal.py', 'sqldb.py', 'sql.py') as $file)
		{
			copy($calendarSrcPath . 'patches/' . $file, '/usr/local/atmail/calendarserver/server/patches/' . $file);
		}
		
		echo "Warning : Replacing calendar server configuration file. If you have a custom setup you may need to merge your changes.\n";
		echo "Old configuration file is found at /usr/local/atmail/calendarserver/server/conf/caldavd-dev.plist\n";
		copy('/usr/local/atmail/calendarserver/server/conf/caldavd-dev.plist', '/usr/local/atmail/calendarserver/server/conf/caldavd-dev.plist.old');
		copy($calendarSrcPath . 'conf/caldavd-dev.plist', '/usr/local/atmail/calendarserver/server/conf/caldavd-dev.plist');
		copy ($calendarSrcPath . 'patch_server.sh', '/usr/local/atmail/calendarserver/server/patch_server.sh');
		
		chdir('/usr/local/atmail/calendarserver/server');
		$output = `sh patch_server.sh`;
		echo $output . "\n";
	}
	else
	{
		echo "Warning : Unable to find calendar server to patch.";
	}
	
	_mountCalendarServer(false);
	
	return $output;
}

function _reinstallCalendarServer()
{
	$output = false;
	_mountCalendarServer();
	$calendarSrcPath = _findCalendarServerSource();
		
	if( file_exists('/usr/local/atmail/calendarserver/server/run') || file_exists('/usr/local/atmail/calserver.img') )
	{	
	
		echo "Updating Calendar Server\n";
		chdir('/usr/local/atmail/server_source/calendar_server');
	
		$path = realpath("../../webmail/config");
	
		// reset the installation
		system("sh /usr/local/atmail/server_source/calendar_server/reset_installation.sh");

		// Auto install
		if( file_exists($path) )
		{
			system("sh calserver-install.sh $path /usr/local/atmail/calendarserver 8008 1");
		}
		else
		{
			$path = "/var/www/html/";		
			// Prompt the user where to find dbconfig.ini
			system("sh calserver-install.sh $path /usr/local/atmail/calendarserver 8008 1 1");
		}
		
		$output=true;
	}
	_mountCalendarServer(false);
	
	return $output;
}

function _controlServerServices($start = true)
{
	if($start)
	{
		echo "Starting Atmail services\n";
	}
	else
	{
		echo "Stopping Atmail services\n";
	}
	
	if( file_exists("/etc/init.d/atmailserver") )
	{
		if($start)
		{
			$output = `/etc/init.d/atmailserver start`;
		}
		else
		{
			$output = `/etc/init.d/atmailserver stop`;
		}
		echo $output . "\n";
	}
	else if ( file_exists("/etc/init.d/atmailcalendarserver") )
	{
		if($start)
		{
			$output = `/etc/init.d/atmailcalendarserver start`;
		}
		else
		{
			$output = `/etc/init.d/atmailcalendarserver stop`;
		}
		echo $output . "\n";
	}
}
	
/**
 * Fetches the latest version string from the remote server
 *
 * return String|False
 */
function _getVersionCurrentLocalCodebase() {
	
	if ($versionFileContents = file_get_contents( APP_ROOT . '.VERSION') )
		return trim( $versionFileContents );
	else
		return false;
	
}
