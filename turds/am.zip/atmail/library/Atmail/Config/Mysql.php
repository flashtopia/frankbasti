<?php
/**
 * Atmail
 *
 * LICENSE
 *
 * This source file is copyrighted by Atmail, full details in LICENSE.txt.
 * It is also available through the Internet at this URL:
 * http://atmail.com/license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the Internet, please send an email
 * to license@atmail.com so we can send you a copy immediately.
 *
 * @category   Atmail
 * @package    Atmail_Config_mysql
 * @copyright  Copyright (c) 2008 Atmail (http://www.atmail.com)
 * @license    http://atmail.com/license.php     Atmail Software License
 * @version    $Id: Mysql.php 2008-09-01 20:16:44Z In2Naos $
 * 
 */

/**
 * @category   Atmail
 * @package    Atmail_Config
 * @copyright  Copyright (c) 2008 Atmail (http://www.atmail.com)
 * @license    http://atmail.com/license.php     Atmail Software License
 */
class Atmail_Config_Mysql extends Zend_Config
{

    /**
     * Loads the section $section from the config table using database credentials from $filename
     *
     * Basic table structure: section, key, value, type
     * If the $section is null, then all sections in the ini file are loaded.
     *
     * example table data:
     *      section	key	 	value		type
     *		global	debug	true		boolean
	 *		domains host	localhost	string
     *
     * after calling $data = new Zend_Config_Mysql($file, 'staging'); then
     *      $data->hostname === "staging"
     *      $data->db->connection === "database"
     *
     * The $options parameter may be provided as either a boolean or an array.
     * If provided as a boolean, this sets the $allowModifications option.
     * @param  string        $filename
     * @param  string|null   $section
     * @param  boolean		 $allowModifications
     * @throws Zend_Config_Exception
     * @return void
     */
	public function __construct($dbconfig, $allowModifications)
    {
		parent::__construct(array(), $allowModifications);        
		//$this->_allowModifications = $allowModifications;
        if (!($dbconfig instanceof Zend_Config_Ini))
            throw new Zend_Config_Exception('DB Config must be of type Zend_Config_Ini');
		$db = Zend_Db::factory($dbconfig->database);
        $q = "SELECT * FROM " . $dbconfig->database->params->configtable;
		$DbConfigArray = $db->FetchAll($q); //consider abstracting this into Zend objects to make protable to other DBMS
        
       // Check if there was a error while loading file
        if (count($DbConfigArray) == 0)
		{
		
		   Zend_Registry::get('log')->info("Warning: No Config data found in database.");
		   
		}
		foreach ($DbConfigArray AS $row)
       	{
			switch ($row['keyType']) {
			 	case 'Boolean':
					$sectionsArray[$row['section']][$row['keyName']] = (bool) ($row['keyValue'] == 'true' || $row['keyValue'] === true || $row['keyValue'] == 1)? true : false;
					break;
				case 'Array' :
					if(!isset($sectionsArray[$row['section']][$row['keyName']]) || !is_array($sectionsArray[$row['section']][$row['keyName']]))
						$sectionsArray[$row['section']][$row['keyName']] = array( $row['keyValue'] );
				    else
						$sectionsArray[$row['section']][$row['keyName']][] = $row['keyValue'];
					break;
				default :
					$sectionsArray[$row['section']][$row['keyName']] = $row['keyValue'];
			}
			foreach ($sectionsArray AS $sectionName => $section)
				$this->_data[$sectionName] = $section;
        	//$this->{$sectionName} = new Zend_Config($section, $allowModifications); // disabled this cos recursive Zend_Config more trouble than worth
		} 
	}
}