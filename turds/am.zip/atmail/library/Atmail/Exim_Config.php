<?php

// +----------------------------------------------------------------+
// | Exim_Config.php												|
// +----------------------------------------------------------------+
// | Setup the Exim Configuration based on set preferences			|
// +----------------------------------------------------------------+
// | Source-code (C) CalaCode.com 1998-2006 . All rights reserved	|
// | See http://calacode.com/license.ehtml for license agreement	|
// +----------------------------------------------------------------+
// | Date: January 2006												|
// +----------------------------------------------------------------+

//
// setup some variables
//

$dbConfig = Zend_Registry::get('dbConfig');
$dbAdapter = Zend_Registry::get('dbAdapter');
$select = $dbAdapter->select()
					->from($dbConfig->database->params->configtable)
					->where("section = 'exim'");
$query = $select->query();
$rows = $query->fetchAll();

// TODO: Temporary workaround to get the latest config changes from the DB rather then Zend_Registry ( old values )
foreach($rows as $row) 
{
	$configExim[$row['keyName']] = $row['keyValue'];	
}

// Next, retrieve the Global specific settings
$query = null;	// Zend DB bug workaround
$select = $dbAdapter->select()
					->from($dbConfig->database->params->configtable)
					->where("section = 'global'");
$query = $select->query();
$rows = $query->fetchAll();

// TODO: Temporary workaround to get the latest config changes from the DB rather then Zend_Registry ( old values )
foreach($rows as $row) 
{
	
	$configGlobal[$row['keyName']] = $row['keyValue'];
	
}

// Next, retrieve the Dovecot specific settings
$query = null;	// Zend DB bug workaround
$select = $dbAdapter->select()
					->from($dbConfig->database->params->configtable)
					->where("section = 'dovecot'");
$query = $select->query();
$rows = $query->fetchAll();

// TODO: Temporary workaround to get the latest config changes from the DB rather then Zend_Registry ( old values )
foreach($rows as $row) 
{

	$configDovecot[$row['keyName']] = $row['keyValue'];

}

$split_pool_directory = ($configExim['split_spool_directory'])? 'true' : 'false';
$smtp_enforce_sync = ($configExim['smtp_enforce_sync'])? 'true' : 'false';
$queue_run_in_order = ($configExim['queue_run_in_order'])? 'true' : 'false';

//
// Start defining the associative array that
// contains the Exim Configuration info
//

$exim_conf = array(
'SMTPLOAD' => "#<SMTPLOAD>
# Stop the SMTP if load > X
smtp_load_reserve = {$configExim['smtp_load_reserve']}
",

'SMTPQUEUELOAD' => "#<SMTPQUEUELOAD>
# Avoid mail-delivery, queue messages if load > X
queue_only_load = {$configExim['smtp_load_queue']}
",

'SMTPDELIVERLOAD' => "#<SMTPDELIVERLOAD>
# Don't run the queue if load > X
deliver_queue_load_max = {$configExim['smtp_load_queue_delivery']}
",

'SMTPMAXPERHOST' => "#<SMTPMAXPERHOST>
# Allow only X connections per IP to the mail-server, spam trap
smtp_accept_max_per_host = {$configExim['smtp_max_connections_perip']}
",

'SMTPMAXCONNECTIONS' => "#<SMTPMAXCONNECTIONS>
# Allow only X connections at once to throttle the load
smtp_accept_max = {$configExim['smtp_max_connections']}
",

'MAXRECIPIENTS' => "#<MAXRECIPIENTS>
# The maximum number of recipients per email-message
recipients_max = {$configExim['smtp_max_rcpt']}
recipients_max_reject = true
",

'SMTPENFORCESYNC' => "#<SMTPENFORCESYNC>
# This forces exim to run through the queue sequentially, the default of randomly selecting mails in the queue is not recommended for large userbases
smtp_enforce_sync = $smtp_enforce_sync
",

'QUEUERUNMAX' => "#<QUEUERUNMAX>
# Specify the maximum number of processes that handle the inbound and outbound emails waiting in the queue.
queue_run_max = {$configExim['queue_run_max']}
",

'REMOTEMAXPARALLEL' => "#<REMOTEMAXPARALLEL>
# Maximum Parallel queue proccesses - This setting forces outbound messages to only be delivered to the specified number of destinations simultaneously
remote_max_parallel = {$configExim['remote_max_parallel']}
",

'QUEUERUNINORDER' => "#<QUEUERUNINORDER>
# This forces exim to run through the queue sequentially, the default of randomly selecting mails in the queue is not recommended for large userbases
queue_run_in_order = $queue_run_in_order
",

'SPLITQUEUEDIR' => "#<SPLITQUEUEDIR>
# Split the Exim queue directory - This is only recommended for large installations. Small installations with low-volume emails will suffer a minimal performance hit when this is activated.
# This setting creates 62 subdirectories for your Exim spool - prefixed by uppercase and lowercase alphanumeric characters and digits. The spool contents are distributed according to the sixth letter of their message ID
split_spool_directory = $split_pool_directory
"
);


//
// Add some more config values to $exim_conf
// These values are not added above as their
// value needs to be determined/constructed
//

// Atmail Mailserver specific configuration values ( non archive )	
if (strpos($configExim['virus_msg'], 'Virus $malware_name detected') === false)
$configExim['virus_msg'] = "Virus \$malware_name detected {$configExim['virus_msg']}";

// Escape new line characters
$configExim['virus_msg'] = str_replace(array("\n", "\r"), '', $configExim['virus_msg']);

if ($configExim['smtp_popimaprelay'])
{
	$exim_conf['MYSQLRELAY'] = <<<END
#<MYSQLRELAY>
MYSQL_RELAY = SELECT IPaddress from MailRelay where ( IPaddress='\${sender_host_address}' and Account='User' and DateAdded > DATE_SUB(NOW(), INTERVAL {$configExim['smtp_popimaprelay_timeout']} MINUTE) ) or ( IPaddress='\${sender_host_address}' and Account='System')

END;
}
else
{
	$exim_conf['MYSQLRELAY'] = <<<END
#<MYSQLRELAY>
MYSQL_RELAY = localhost

END;
}

if ($configExim['mail_group_support'])
{
	$exim_conf['MAILGROUPSUPPORT'] = <<<END
#<MAILGROUPSUPPORT>
groupmail_lists:
driver = redirect
local_part_suffix = -group
data = \${lookup mysql {MYSQL_GROUPLOOKUP}}
forbid_file
forbid_pipe
skip_syntax_errors

END;
}
else
{
	$exim_conf['MAILGROUPSUPPORT'] = <<<END
#<MAILGROUPSUPPORT>
#groupmail_lists:
# driver = redirect
# local_part_suffix = -group
# data = \${lookup mysql {MYSQL_GROUPLOOKUP}}
# forbid_file
# forbid_pipe
# skip_syntax_errors

END;
}

//
// define config values for DKIMVER and DKIMVER2
//
if ($configExim['dkim_enable'] && _checkEximSupport('DKIM') )
{
$exim_conf['DKIMVER'] = <<<END
#<DKIMVER>
dkim_verify_signers = \$sender_address_domain

END;
}
else
{
$exim_conf['DKIMVER'] = <<<END
#<DKIMVER>
#dkim_verify_signers = \$sender_address_domain

END;
}


if ($configExim['dkim_enable'] && _checkEximSupport('DKIM') )
{
$exim_conf['DKIMVER2'] = <<<END
#<DKIMVER2>
acl_check_dkim:

deny message = Invalid DKIM
     dkim_status = fail

accept

END;
}
else
{
$exim_conf['DKIMVER2'] = <<<END
#<DKIMVER2>
#acl_check_dkim:
#
#deny message = Invalid DKIM
#     dkim_status = fail
#
#accept

END;
}

// Enable DKIM outbound mail signing

if ($configExim['dkim_enable_outbound'] && _checkEximSupport('DKIM') )
{
		
$exim_conf['DKIMOUTBOUND'] = <<<END
#<DKIMOUTBOUND>
#Optionally sign outgoing messages with a selected DKIM key
dkim_domain={$configExim['dkim_domain']}
dkim_selector=mail
dkim_private_key=/usr/local/atmail/mailserver/ssl/private/dkim.key

END;
}
else
{
$exim_conf['DKIMOUTBOUND'] = <<<END
#<DKIMOUTBOUND>
#Optionally sign outgoing messages with a selected DKIM key
#dkim_domain=
#dkim_selector=
#dkim_private_key=

END;
}

//
// Smarthost configuration
//

if (!empty($configExim['smarthost_ip']))
{
$exim_conf['smarthost_ip'] = <<<END
#<SMARTHOST>
divertnonlocal:
driver = manualroute
domains = ! +local_domains
transport = remote_smtp
route_list = * {$configExim['smarthost_ip']}
ignore_target_hosts = 0.0.0.0 : 127.0.0.0/8
no_more

END;
}
else
{
$exim_conf['smarthost_ip'] = <<<END
#<SMARTHOST>
#divertnonlocal:
#driver = manualroute
#domains = ! +local_domains
#transport = remote_smtp
#route_list = * localhost 
#ignore_target_hosts = 0.0.0.0 : 127.0.0.0/8
#no_more

END;
}

//
// define config values for TLSSMTP
//
if ($configExim['tlssmtp'] && (file_exists("/usr/local/atmail/mailserver/ssl/certs/smtpserver.pem") && file_exists("/usr/local/atmail/mailserver/ssl/private/smtpserver.key")))
{
        $exim_conf['TLSSMTP'] = <<<END
#<TLSSMTP>
# Enable Exim TLS
tls_advertise_hosts = *
log_selector = +tls_peerdn
tls_certificate={$configDovecot['imapssl_cert']}
tls_privatekey={$configDovecot['imapssl_key']}

END;
}
else
{
        $exim_conf['TLSSMTP'] = <<<END
#<TLSSMTP>
# Enable Exim TLS
#tls_advertise_hosts = *
#log_selector = +tls_peerdn
#tls_certificate=/usr/local/atmail/mailserver/ssl/certs/smtpserver.pem
#tls_privatekey=/usr/local/atmail/mailserver/ssl/private/smtpserver.key

END;
}

//
// define config values for TLSSMTPREMOTE
//
if ($configExim['tlssmtp_remote'] && (file_exists("/usr/local/atmail/mailserver/ssl/certs/smtpserver.pem") && file_exists("/usr/local/atmail/mailserver/ssl/private/smtpserver.key")))
{
        $exim_conf['TLSSMTPREMOTE'] = <<<END
#<TLSSMTPREMOTE>
# Enable Exim TLS for remote_smtp
tls_certificate=/usr/local/atmail/mailserver/ssl/certs/smtpserver.pem
tls_privatekey=/usr/local/atmail/mailserver/ssl/private/smtpserver.key

END;
}
else
{
        $exim_conf['TLSSMTPREMOTE'] = <<<END
#<TLSSMTPREMOTE>
# Enable Exim TLS for remote_smtp
#tls_certificate=/usr/local/atmail/mailserver/ssl/certs/smtpserver.pem
#tls_privatekey=/usr/local/atmail/mailserver/ssl/private/smtpserver.key

END;
}

//
// define config values for SMTPRATELIMIT
//
if ($configExim['smtp_throttle'])
{
	$exim_conf['SMTPRATELIMIT'] = <<<END
#<SMTPRATELIMIT>
# Slow the SMTP session down if receiving larger amount of recipients per IP
smtp_ratelimit_mail = 5,0.5s,1.05,1m
smtp_ratelimit_rcpt = 10,0.25s,1.015,1m

END;
}
else
{
	$exim_conf['SMTPRATELIMIT'] = <<<END
#<SMTPRATELIMIT>
# Slow the SMTP session down if receiving larger amount of receipients per IP
#smtp_ratelimit_mail = 5,0.5s,1.05,1m
#smtp_ratelimit_rcpt = 10,0.25s,1.015,1m

END;
}

// Define LDAP servers in Exim configure file ( optional )
if($configDovecot['authType'] == 'ldap')
{
	$exim_conf['LDAPCONFIG'] = <<<END
#<LDAPCONFIG>
# LDAP Host config. Separated by double-colons when specifying ports.
ldap_default_servers = {$configDovecot['ldap_host']}::389

END;
}
else
{
	$exim_conf['LDAPCONFIG'] = <<<END
#<LDAPCONFIG>
# LDAP Host config. Separated by double-colons when specifying ports.
#ldap_default_servers = 127.0.0.1::389

END;
	
}

//
// define config values for SMTPAUTH for Crypt and Plain
//
if( $configExim['smtp_auth'] && $configDovecot['authType'] == 'ldap' )
{
	
// Activedirectory
	if($configDovecot['ldapType'] == 'activedirectory') 
	{
		
		$exim_conf['SMTPAUTH'] = <<<END
#<SMTPAUTH>
# AUTH LOGIN authentication method with LDAP (Activedirectory) support
auth_login:
driver = plaintext
public_name = PLAIN
server_condition = \${if ldapauth {user="\${quote_ldap_dn:\$2}" pass=\${quote:\$3} ldap:///}{1}{0}}
server_set_id = \$2
server_prompts = :

END;
	
	} 
	else
	{
		
		// OpenLDAP schema / other schema
		$exim_conf['SMTPAUTH'] = <<<END
#<SMTPAUTH>
# AUTH LOGIN authentication method with LDAP
auth_login:
driver = plaintext
public_name = PLAIN
server_condition = \${if ldapauth {user="cn=\${quote_ldap_dn:\$2},{$configDovecot['ldap_basedn']}" pass=\${quote:\$3} ldap:///}{1}{0}}
server_set_id = \$2
server_prompts = :

END;
	
	}

}
elseif( $configExim['smtp_auth'] ) //$configDovecot['authType'] != 'ldap'
{

	if( $configGlobal['userPasswordEncryptionType'] == 'MD5-CRYPT')
	{
		
		$exim_conf['SMTPAUTH'] = <<<END
#<SMTPAUTH>
# AUTH LOGIN authentication method with MySQL support
auth_login:
driver = plaintext
public_name = LOGIN
server_condition = "\${if crypteq{\$2}{\${lookup mysql{ SELECT Password FROM UserSession WHERE Account = '\${quote_mysql:$1}'}}}{1}{0}}" 
server_prompts = "Username:: : Password::"
server_set_id = \$1

END;
	}
	elseif( $configGlobal['userPasswordEncryptionType'] == 'MD5')
	{
		
		$exim_conf['SMTPAUTH'] = <<<END
#<SMTPAUTH>
# AUTH LOGIN authentication method with MySQL support
auth_login:
driver = plaintext
public_name = LOGIN
server_condition = "\${if eq{\$1}{\${lookup mysql{SELECT Account FROM UserSession WHERE Account='\$1' and Password=MD5('\$2')}{\$value}fail}}{1}{0}}"
server_prompts = "Username:: : Password::"
server_set_id = \$1

END;
		
	}   
	else
	{
		
		$exim_conf['SMTPAUTH'] = <<<END
#<SMTPAUTH>
# AUTH LOGIN authentication method with MySQL support
auth_login:
driver = plaintext
public_name = LOGIN
server_condition = \${if eq{\$1}{\${lookup mysql{SELECT Account FROM UserSession WHERE Account='\$1' and Password='\$2'}{\$value}fail}}{1}{0}}
server_prompts = "Username:: : Password::"
server_set_id = \$1
		
END;
		
	}

}
else
{

	$exim_conf['SMTPAUTH'] = <<<END
#<SMTPAUTH>
# AUTH LOGIN authentication method with MySQL support.
#auth_login:
#driver = plaintext
#public_name = LOGIN
#server_condition = \${if eq{\$1}{\${lookup mysql{SELECT Account FROM UserSession WHERE Account='\$1' and Password='\$2'}{\$value}fail}}{1}{0}}
#server_prompts = "Username:: : Password::"
#server_set_id = \$1

END;

}


//
// define config values for SENDLIMIT
//
if ($configExim['smtp_sendlimit_enable'])
{
	$exim_conf['SENDLIMIT'] = <<<END
#<SENDLIMIT>
deny   condition = \${if > {\${lookup mysql{MYSQL_SENDLIMIT}}}{{$configExim['smtp_sendlimit']}}}
message = Maximum recipient quota exceeded

END;
}
else
{
	$exim_conf['SENDLIMIT'] = <<<END
#<SENDLIMIT>
# deny   condition = \${if > {\${lookup mysql{MYSQL_SENDLIMIT}}}{50}}
# message = Maximum recipient quota exceeded

END;
}


//
// define config values for VERIFYSENDERS
//
if ($configExim['smtp_verify_senders'])
{
	$exim_conf['VERIFYSENDERS'] = <<<END
#<VERIFYSENDERS>
# Deny unless the sender address can be verified.
require verify = sender

END;
}
else
{
	$exim_conf['VERIFYSENDERS'] = <<<END
#<VERIFYSENDERS>
# Deny unless the sender address can be verified.
#require verify = sender

END;
}


//
// define config values for AVSETUP
//
if ($configExim['virus_enable'] == '1')
{
	$exim_conf['AVSETUP'] = <<<END
#<AVSETUP>
deny  message = {$configExim['virus_msg']}
malware = */defer_ok

END;
}
else
{
	$exim_conf['AVSETUP'] = <<<END
#<AVSETUP>
#deny  message = {$configExim['virus_msg']}
#malware = *

END;
}


//
// define config values for SPAMASSASSIN and SPAMASSASSIN2
//
if ($configExim['filter_sa_enable'])
{
	$spamreject = $configExim['filter_required_hits_reject'] * 10;

	if(!$spamreject)
	$spamreject = '100';

$exim_conf['SPAMASSASSIN2'] = <<<END
#<SPAMASSASSIN2>
mysql_blacklist:
 driver = manualroute
 condition = "\${lookup mysql{MYSQL_BLACKLIST}{1}{0}}"
 route_list = "* localhost byname"
 transport = devnull
 verify = false

mysql_purgespam:
 driver = manualroute
 domains = \${lookup mysql {MYSQL_PURGESPAM}{\$value}}
 senders = !+whitelist_user
 condition = \${if >{\$spam_score_int}{\${lookup mysql{MYSQL_SPAMHIT}{\$value}fail}} {yes}{no}}
 route_list = "* localhost byname"
 transport = devnull
 verify = false

mysql_spamfolder:
 driver = manualroute
 domains = \${lookup mysql {MYSQL_MOVESPAMFOLDER}{\$value}}
 senders = !+whitelist_user
 condition = \${if >{\$spam_score_int}{\${lookup mysql{MYSQL_SPAMHIT}{\$value}fail}} {yes}{no}}
 route_list = "* localhost byname"
 transport = mysql_delivery_spamfolder
 verify = false
 headers_remove = subject
 headers_add = Subject: \${lookup mysql {MYSQL_SPAMSUBJECT}} \$h_subject

END;

if($configExim['filter_sa_enable'] && !preg_match('/Win/', PHP_OS)  && isset($configExim['filter_skip_trusted']) )	{

$exim_conf['SPAMASSASSIN'] = <<<END
#<SPAMASSASSIN>
# Accept outgoing messages from authenticated users, no need to scan as spam
accept  authenticated = *

# Skip scanning messages from users that are trusted
accept hosts = +relay_from_hosts

# Skip if message over size
accept condition = \${if > {\$message_size}{{$configExim['filter_max_bodysize']}k} }

# Pass the email via Spamassassin and don't scan messages over the specified size to save CPU
# Append the X-Spam-Score and X-Spam-Report for all messages
warn  message = X-Spam-Score: \$spam_score
 condition = \${if < {\$message_size}{{$configExim['filter_max_bodysize']}k} }
 hosts = ! +relay_from_hosts
 spam = nobody:true/defer_ok

warn  message = X-Spam-Report: \$spam_report
 condition = \${if < {\$message_size}{{$configExim['filter_max_bodysize']}k} }
 hosts = ! +relay_from_hosts
 spam = nobody:true/defer_ok

# Reject message if Spam-score is too high ( avoid wasted disk/CPU on obvious Spam messages)
drop message = This message is rejected by the Anti-Spam System. Spam-score too high : \$spam_score spam points - Please reformat your email and send again
 spam = nobody:true/defer_ok
 hosts = ! +relay_from_hosts
 condition = \${if < {\$message_size}{{$configExim['filter_max_bodysize']}k} }
 condition = \${if > {\$spam_score_int}{{$spamreject}}{1}{0}}

END;
} else {

$exim_conf['SPAMASSASSIN'] = <<<END
#<SPAMASSASSIN>
# Accept outgoing messages from authenticated users, no need to scan as spam
#accept  authenticated = *

# Skip if message over size
accept condition = \${if > {\$message_size}{{$configExim['filter_max_bodysize']}k} }

# Pass the email via Spamassassin and don't scan messages over the specified size to save CPU
# Append the X-Spam-Score and X-Spam-Report for all messages
warn  message = X-Spam-Score: \$spam_score
 condition = \${if < {\$message_size}{{$configExim['filter_max_bodysize']}k} }
 spam = nobody:true/defer_ok

warn  message = X-Spam-Report: \$spam_report
 condition = \${if < {\$message_size}{{$configExim['filter_max_bodysize']}k} }
 spam = nobody:true/defer_ok

# Reject message if Spam-score is too high ( avoid wasted disk/CPU on obvious Spam messages)
drop message = This message is rejected by the Anti-Spam System. Spam-score too high : \$spam_score spam points - Please reformat your email and send again
 condition = \${if < {\$message_size}{{$configExim['filter_max_bodysize']}k} }
 condition = \${if >{\$spam_score_int}{{$spamreject}}{1}{0}}
 spam = nobody:true/defer_ok

END;
}

} else
{
	$exim_conf['SPAMASSASSIN'] = <<<END
#<SPAMASSASSIN>
# Accept outgoing messages from authenticated users, no need to scan as spam
#accept  authenticated = *
#
# Pass the email via Spamassassin and don't scan messages over the specified size to save CPU
#warn	condition = \${if < {\$message_size}{{$configExim['filter_max_bodysize']}k} }
#	!hosts = 127.0.0.1:mysql;MYSQL_RELAY
#	spam      = nobody/defer_ok
#	message   = X-Spam_score: \$spam_score

END;

	$exim_conf['SPAMASSASSIN2'] = <<<END
#<SPAMASSASSIN2>
#mysql_blacklist:
#  driver = manualroute
#  condition = "\${lookup mysql{MYSQL_BLACKLIST}{1}{0}}"
#  route_list = "* localhost byname"
#  transport = devnull
#  verify = false
#
#mysql_purgespam:
#  driver = manualroute
#  domains = \${lookup mysql {MYSQL_PURGESPAM}{\$value}}
#  senders = ! \${lookup mysql {MYSQL_WHITELIST}{\$value}}
#  condition = \${if >{\$spam_score_int}{\${lookup mysql{MYSQL_SPAMHIT}{\$value}fail}} {yes}{no}}
#  route_list = "* localhost byname"
#  transport = devnull
#  verify = false
#
#mysql_spamfolder:
#  driver = manualroute
#  domains = \${lookup mysql {MYSQL_MOVESPAMFOLDER}{\$value}}
#  senders = ! \${lookup mysql {MYSQL_WHITELIST}{\$value}}
#  condition = \${if >{\$spam_score_int}{\${lookup mysql{MYSQL_SPAMHIT}{\$value}fail}} {yes}{no}}
#  route_list = "* localhost byname"
#  transport = mysql_delivery_spamfolder
#  verify = false
#  headers_remove = subject
#  headers_add = Subject: \${lookup mysql {MYSQL_SPAMSUBJECT}} \$h_subject

END;
}

if( $configExim['enableMailFilters'] == '1' )
{
	
	$exim_conf['ENABLEMAILFILTERS'] = <<<END
#<ENABLEMAILFILTERS>
sieve_deliver:
  driver = redirect
  domains = \${lookup mysql {MYSQL_CHECKSIEVE}{\$value}}
  local_part_suffix = "-*"
  local_part_suffix_optional
  sieve_subaddress = "\${sg{\$local_part_suffix}{^-}{}}"
  sieve_useraddress = "\$local_part"
  require_files = \${lookup mysql{SELECT MailDir from Users where Account='\${local_part}@\${domain}'}}/sievefilter
  file = \${lookup mysql{SELECT MailDir from Users where Account='\${local_part}@\${domain}'}}/sievefilter
  check_ancestor
  user = atmail
  allow_filter
  file_transport = sieve_user
  reply_transport = mysql_autoreply
  verify = false

END;

	$exim_conf['ENABLEMAILFILTERS2'] = <<<END
#<ENABLEMAILFILTERS2>
sieve_user:
  driver = appendfile
  directory = \${lookup mysql{SELECT MailDir from Users where Account='\${local_part}@\${domain}'}}/\${sg{\$address_file}{^inbox}{}}
  maildir_format
  delivery_date_add
  envelope_to_add
  return_path_add
  mode = 0600

END;

}
else
{
	
	$exim_conf['ENABLEMAILFILTERS'] = <<<END
#<ENABLEMAILFILTERS>
#sieve_deliver:
#  driver = redirect
#  domains = \${lookup mysql {MYSQL_CHECKSIEVE}{\$value}}
#  local_part_suffix = "-*"
#  local_part_suffix_optional
#  sieve_subaddress = "\${sg{\$local_part_suffix}{^-}{}}"
#  sieve_useraddress = "\$local_part"
#  require_files = \${lookup mysql{SELECT MailDir from Users where Account='\${local_part}@\${domain}'}}/sievefilter
#  file = \${lookup mysql{SELECT MailDir from Users where Account='\${local_part}@\${domain}'}}/sievefilter
#  check_ancestor
#  user = atmail
#  allow_filter
#  file_transport = sieve_user
#  reply_transport = mysql_autoreply
#  verify = false

END;

	$exim_conf['ENABLEMAILFILTERS2'] = <<<END
#<ENABLEMAILFILTERS2>
#sieve_user:
#  driver = appendfile
#  directory = \${lookup mysql{SELECT MailDir from Users where Account='\${local_part}@\${domain}'}}/\${sg{\$address_file}{^inbox}{}}
#  maildir_format
#  delivery_date_add
#  envelope_to_add
#  return_path_add
#  mode = 0600

END;
	
}


//
// define config values for AVPATHNAME
//
if ($configExim['virus_enable'] == '1')
{

	$exim_conf['AVPATHNAME'] = <<<END
#<AVPATHNAME>
av_scanner = clamd:/usr/local/atmail/av/clamdsocket

END;
}
else
{
	$exim_conf['AVPATHNAME'] = <<<END
#<AVPATHNAME>
#av_scanner = clamd:/usr/local/atmail/av/clamdsocket

END;
}


//
// define config values for RBLSERVER
//

// Escape new line characters
$configExim['filter_rbl_servers'] = str_replace(array("\n", "\r"), '', $configExim['filter_rbl_servers']);

if ($configExim['filter_rbl_servers'] && $configExim['filter_rbl_support'])
{
	$hosts = explode(',', $configExim['filter_rbl_servers']);
	$rblservers = '';

	// Loop through the hostnames seperated by a comma, remove any whitespace
	foreach ($hosts as $host)
	{
		$host = preg_replace('/\s+/', '', $host);
		$rblservers .= "$host:";
	}

	// Take away the last :
	$rblservers = preg_replace('/:$/', '', $rblservers);

	$exim_conf['RBLSERVER'] = <<<END
#<RBLSERVER>
deny    message       = Rejected message because \$sender_host_address is in a black list at \$dnslist_domain
hosts = !+relay_from_hosts
dnslists = $rblservers

END;

}
else
{
	$exim_conf['RBLSERVER'] = <<<END
#<RBLSERVER>
#deny    message       = Rejected message because \$sender_host_address is in a black list at \$dnslist_domain
#hosts = !+relay_from_hosts
#dnslists      = black.list.example

END;
}


//
// define config values for BLOCKATTACHMENT
//
if ($configExim['filter_attach_check'] && $configExim['filter_blocked_attachments'])
{
	$types = explode(",", $configExim['filter_blocked_attachments']);
	$attachments = '';

	// Loop through the hostnames seperated by a comma, remove any whitespace
	foreach ($types as $type)
	{
		$type = preg_replace('/\s+/', '', $type);
		if (!$type)
			continue;
		$attachments .= "\\$type|";
	}

	// Take away the last |
	$attachments = preg_replace('/\|$/', '', $attachments);

	$exim_conf['BLOCKATTACHMENT'] = <<<END
#<BLOCKATTACHMENT>
# File extension filtering.
acl_check_mime:
# Decode MIME parts to disk. This will support virus scanners later.
warn decode = default
deny message = Blacklisted file extension detected
condition = \${if match \\
{\${lc:\$mime_filename}} \\
{\\N($attachments)\$\\N} \\
{1}{0}}
accept

END;

}
else
{
	$exim_conf['BLOCKATTACHMENT'] = <<<END
#<BLOCKATTACHMENT>
acl_check_mime:
# Decode MIME parts to disk. This will support virus scanners later.
warn decode = default
accept

END;
}

$dbConfig = Zend_Registry::get('dbConfig');

if( isset($dbConfig->database->params->dbname) ) {

$host = $dbConfig->database->params->host;
if(!$host)
	$host = 'localhost';

$exim_conf['MYSQLCONFIG'] = <<<END
#<MYSQLCONFIG>
hide mysql_servers = $host/{$dbConfig->database->params->dbname}/{$dbConfig->database->params->username}/{$dbConfig->database->params->password}

END;

}


//
// Dovecot configuration values
//

if($configGlobal['userPasswordEncryptionType'] == "MD5-CRYPT")
{

	$dovecotsql_conf['PASS_SCHEME'] = <<<END
#<PASS_SCHEME>
default_pass_scheme = MD5-CRYPT 

END;

} 
else if( $configGlobal['userPasswordEncryptionType'] == "MD5" )
{

	$dovecotsql_conf['PASS_SCHEME'] = <<<END
#<PASS_SCHEME>
default_pass_scheme = MD5

END;

}
else
{
	
	$dovecotsql_conf['PASS_SCHEME'] = <<<END
#<PASS_SCHEME>
default_pass_scheme = PLAIN

END;

}

// ArchiveVault router and transport toggle
if ($configExim['smtp_archivevault_enable'] == '1')
{

	$exim_conf['ARCHIVEVAULT'] = <<<END
#<ARCHIVEVAULT>
traffic_tap:
self = send
unseen
no_expn
no_verify
transport = remote_smtp_arch
driver = manualroute
require_files = /usr/local/atmail/mailserver/MAIL_TAP_HOST
route_data = \${readfile{/usr/local/atmail/mailserver/MAIL_TAP_HOST}{:}}

END;

	$exim_conf['ARCHIVEVAULTDELIVER'] = <<<END
#<ARCHIVEVAULTDELIVER>
remote_smtp_arch:
driver = smtp
port = {$configExim['smtp_archivevault_port']}
hosts = {$configExim['smtp_archivevault_hostname']}
hosts_override
allow_localhost

END;

}
else
{
	$exim_conf['ARCHIVEVAULT'] = <<<END
#<ARCHIVEVAULT>
#traffic_tap:
#self = send
#unseen
#no_expn
#no_verify
#transport = remote_smtp_arch
#driver = manualroute
#require_files = /usr/local/atmail/mailserver/MAIL_TAP_HOST
#route_data = \${readfile{/usr/local/atmail/mailserver/MAIL_TAP_HOST}{:}}

END;

	$exim_conf['ARCHIVEVAULTDELIVER'] = <<<END
#<ARCHIVEVAULTDELIVER>
#remote_smtp_arch:
#driver = smtp
#port = {$configExim['smtp_archivevault_port']}
#hosts = {$configExim['smtp_archivevault_hostname']}
#hosts_override
#allow_localhost

END;
}


//
// Dovecot SSL toggle
//

if($configDovecot['pop3imap_enable'])
$protocols = "pop3 imap";

if($configDovecot['imapssl_enable'] && (file_exists($configDovecot['imapssl_cert']) && file_exists($configDovecot['imapssl_key']))) {
$dovecot_conf['DOVECOT_SSL'] = <<<END
#<DOVECOT_SSL>
# Enable SSL
ssl = yes
protocols = $protocols pop3s imaps
ssl_cert_file = {$configDovecot['imapssl_cert']}
ssl_key_file = {$configDovecot['imapssl_key']}

END;

}
else {
$dovecot_conf['DOVECOT_SSL'] = <<<END
#<DOVECOT_SSL>
# Disable SSL
ssl = no
protocols = $protocols
#ssl_cert_file = /usr/local/atmail/mailserver/ssl/certs/dovecot.pem
#ssl_key_file = /usr/local/atmail/mailserver/ssl/private/dovecot.pem

END;

} 


//
//
// Spamassassin settings
//

if ($configExim['filter_sa_enable'])
{
$sa_conf['SA_SETS'] = <<<END
#<SA_SETS>
# Settings that can be changed via the Webadmin
rewrite_header Subject {$configExim['filter_subject_tag']}
required_score {$configExim['filter_required_hits']} 
report_safe 1

END;

if($configExim['filter_use_bayes']) {
$sa_conf['SA_LEARN'] = <<<END
#<SA_LEARN>
# Bayesian Filtering Settings
loadplugin Mail::SpamAssassin::Plugin::AutoLearnThreshold
bayes_path /usr/local/atmail/spamassassin/bayes/bayes
bayes_file_mode 0755
use_bayes {$configExim['filter_use_bayes']} 
bayes_auto_learn_threshold_spam {$configExim['filter_bayes_auto_learn_threshold_spam']}
bayes_auto_learn_threshold_nonspam {$configExim['filter_bayes_auto_learn_threshold_nonspam']} 
bayes_min_ham_num {$configExim['filter_bayes_min_ham_num']} 

END;
	
} else {
$sa_conf['SA_LEARN'] = <<<END
#<SA_LEARN>
# Bayesian Filtering Settings
#loadplugin Mail::SpamAssassin::Plugin::AutoLearnThreshold
#bayes_path /usr/local/atmail/spamassassin/bayes/bayes
#bayes_file_mode 0755
#use_bayes {$configExim['filter_use_bayes']} 
#bayes_auto_learn_threshold_spam {$configExim['filter_bayes_auto_learn_threshold_spam']}
#bayes_auto_learn_threshold_nonspam {$configExim['filter_bayes_auto_learn_threshold_nonspam']} 
#bayes_min_ham_num {$configExim['filter_bayes_min_ham_num']} 

END;
	
}

$sa_conf['SA_TRUSTED'] = <<<END
#<SA_TRUSTED>
# The IP's which are trusted
trusted_networks {$configExim['filter_trusted_networks']}

END;

}
else {
$sa_conf['SA_SETS'] = <<<END
#<SA_SETS>
# Settings that can be changed via the Webadmin
#rewrite_header {$configExim['filter_subject_tag']}
#required_score {$configExim['filter_required_hits']}
#report_safe 1

END;

$sa_conf['SA_LEARN'] = <<<END
#<SA_LEARN>
# Bayesian Filtering Settings
#loadplugin Mail::SpamAssassin::Plugin::AutoLearnThreshold
#bayes_path /usr/local/atmail/spamassassin/bayes/bayes
#bayes_file_mode 0755
#use_bayes {$configExim['filter_use_bayes']} 
#bayes_auto_learn_threshold_spam {$configExim['filter_bayes_auto_learn_threshold_spam']}
#bayes_auto_learn_threshold_nonspam {$configExim['filter_bayes_auto_learn_threshold_nonspam']}
#bayes_min_ham_num {$configExim['filter_bayes_min_ham_num']}

END;

$sa_conf['SA_TRUSTED'] = <<<END
#<SA_TRUSTED>
# The IP's which are trusted
#trusted_networks {$configExim['filter_trusted_networks']}

END;

}

if($configExim['filter_uridns_support'] && !empty($configExim['filter_uridnsbl_servers']) ) {

$uridnsservers = "";

// Split by comma for multiple
$uriarray = split(",", $configExim['filter_uridnsbl_servers']);
foreach($uriarray as $server) {
	$server = trim($server);
	$uridnsservers .= "uridnsbl      URIBL_SBLXBL    $server.   TXT\n";
}

$sa_conf['SA_URIBL'] = <<<END
#<SA_URIBL>
# Enable URI-DNS-BL support
loadplugin    Mail::SpamAssassin::Plugin::URIDNSBL
$uridnsservers

END;

}
else {
$sa_conf['SA_URIBL'] = <<<END
#<SA_URIBL>
# Enable URI-DNS-BL support
#loadplugin    Mail::SpamAssassin::Plugin::URIDNSBL
#uridnsbl      URIBL_SBLXBL    multi.surbl.org.   TXT

END;

}

if($configExim['filter_spf_support']) {
$sa_conf['SA_SPF'] = <<<END
#<SA_SPF>
# Optional SPF support
loadplugin     Mail::SpamAssassin::Plugin::SPF
internal_networks       127.0.0.1
spf_timeout 3

END;

}
else {
$sa_conf['SA_SPF'] = <<<END
#<SA_SPF>
# Optional SPF support
#loadplugin     Mail::SpamAssassin::Plugin::SPF
#internal_networks       127.0.0.1
#spf_timeout 3

END;

}

if($configExim['filter_awl_support']) {
$sa_conf['SA_AWL'] = <<<END
#<SA_AWL>
# Auto-white list support
loadplugin     Mail::SpamAssassin::Plugin::AWL
auto_whitelist_factory Mail::SpamAssassin::SQLBasedAddrList
user_awl_dsn DBI:mysql:{$dbConfig->database->params->dbname}:{$dbConfig->database->params->host}
user_awl_sql_username {$dbConfig->database->params->username} 
user_awl_sql_password {$dbConfig->database->params->password}

END;

}
else {
$sa_conf['SA_AWL'] = <<<END
#<SA_AWL>
# Auto-white list support
#loadplugin     Mail::SpamAssassin::Plugin::AWL
#auto_whitelist_factory Mail::SpamAssassin::SQLBasedAddrList
#user_awl_dsn DBI:mysql:atmail:127.0.0.1
#user_awl_sql_username root

END;

}


//
// LDAP Settings
// for Dovecot
//

if($configDovecot['authType'] == 'ldap') {
$dovecot_conf['DOVECOT_LDAPAUTH'] = <<<END
#<DOVECOT_LDAPAUTH>
# LDAP Password Authentication
passdb ldap {
    args = /usr/local/atmail/mailserver/etc/dovecot-ldap.conf
}

userdb static {
  args = uid=3000 gid=3000
}

END;

$dovecot_conf['DOVECOT_NAMESPACE'] = <<<END
#<DOVECOT_NAMESPACE>
# Courier legacy support
#namespace private {
#  prefix = INBOX.
#  inbox = yes
#}

END;

$dovecot_conf['DOVECOT_SQLAUTH'] = <<<END
#<DOVECOT_SQLAUTH>
# SQL Password Authentication
#passdb sql {
#    args = /usr/local/atmail/mailserver/etc/dovecot-sql.conf
#}
#
# SQL User Settings. Can be turned as a fallback, always keep on
#userdb sql {
#    args = /usr/local/atmail/mailserver/etc/dovecot-users-sql.conf
#}

END;

$dovecot_conf['LDAP_CREATE1'] = <<<END
#<LDAP_CREATE1>
  mail_executable = /usr/local/atmail/mailserver/etc/create-imap.sh 

END;

$dovecot_conf['LDAP_CREATE2'] = <<<END
#<LDAP_CREATE2>
  mail_executable = /usr/local/atmail/mailserver/etc/create-pop.sh 

END;

$dovecot_conf['DOVECOT_PLUGINSIMAP'] = <<<END
#<DOVECOT_PLUGINSIMAP>
#mail_plugins = quota imap_quota

END;

$dovecot_conf['DOVECOT_PLUGINSPOP3'] = <<<END
#<DOVECOT_PLUGINSPOP3>
#mail_plugins = quota

END;

}
else 
{
$dovecot_conf['DOVECOT_LDAPAUTH'] = <<<END
#<DOVECOT_LDAPAUTH>
# LDAP Password Authentication
#  passdb ldap {
#    args = /usr/local/atmail/mailserver/etc/dovecot-ldap.conf
#  }
#
#userdb static {
#  args = uid=3000 gid=3000
#}

END;

$dovecot_conf['DOVECOT_NAMESPACE'] = <<<END
#<DOVECOT_NAMESPACE>
# Courier legacy support
namespace private {
  prefix = INBOX.
  inbox = yes
}

END;

$dovecot_conf['DOVECOT_SQLAUTH'] = <<<END
#<DOVECOT_SQLAUTH>
# SQL Password Authentication
passdb sql {
    args = /usr/local/atmail/mailserver/etc/dovecot-sql.conf
}

# SQL User Settings. Can be turned as a fallback, always keep on
userdb sql {
    args = /usr/local/atmail/mailserver/etc/dovecot-users-sql.conf
}

END;

$dovecot_conf['LDAP_CREATE1'] = <<<END
#<LDAP_CREATE1>
#  mail_executable = /usr/local/atmail/mailserver/etc/create-imap.sh

END;

$dovecot_conf['LDAP_CREATE2'] = <<<END
#<LDAP_CREATE2>
#  mail_executable = /usr/local/atmail/mailserver/etc/create-pop.sh

END;

$dovecot_conf['DOVECOT_PLUGINSIMAP'] = <<<END
#<DOVECOT_PLUGINSIMAP>
mail_plugins = quota imap_quota

END;

$dovecot_conf['DOVECOT_PLUGINSPOP3'] = <<<END
#<DOVECOT_PLUGINSPOP3>
mail_plugins = quota

END;

}

//
// LDAP Special Settings
//

if($configDovecot['ldap_bindauth']) {
$dovecotldap_conf['LDAP_BINDAUTH'] = <<<END
#<LDAP_BINDAUTH>
# Toggle for bind authentication
base = {$configDovecot['ldap_basedn']}
user_attrs = uid=3000,gid=3000
auth_bind = yes
auth_bind_userdn = {$configDovecot['ldap_bindauthdn']}

END;

$dovecotldap_conf['LDAP_HOST'] = <<<END
#<LDAP_HOST>
hosts = {$configDovecot['ldap_host']}

END;

$dovecotldap_conf['LDAP_DNAUTH'] = <<<END
#<LDAP_DNAUTH>
# The username and password used to login to the LDAP server.
#dn = 
#dnpass = 
# Base search
#base = ou=people,dc=juno,dc=com
#user_attrs = 3000=uid,3000=gid
# Password Query. %n for username-only. If using username@domain, put %u
#pass_attrs = userPassword=password
#pass_filter = (&(objectClass=inetOrgPerson)(uid=%n))
#user_filter = (&(objectClass=inetOrgPerson)(uid=%n))

END;

}
else {
$dovecotldap_conf['LDAP_BINDAUTH'] = <<<END
#<LDAP_BINDAUTH>
# Toggle for bind authentication
#base = {$configDovecot['ldap_basedn']}
#user_attrs = uid=3000,gid=3000
#auth_bind = yes
#auth_bind_userdn = 

END;

$dovecotldap_conf['LDAP_HOST'] = <<<END
#<LDAP_HOST>
hosts = {$configDovecot['ldap_host']}

END;

$dovecotldap_conf['LDAP_DNAUTH'] = <<<END
#<LDAP_DNAUTH>
# The username and password used to login to the LDAP server.
dn = {$configDovecot['ldap_binddn']}
dnpass = {$configDovecot['ldap_bindpass']}
# Base search
base = {$configDovecot['ldap_basedn']}
user_attrs = 3000=uid,3000=gid
# Password Query. %n for username-only. If using username@domain, put %u
pass_attrs = {$configDovecot['ldap_passwdfield']}=password
pass_filter = (&(objectClass={$configDovecot['ldap_passfilter']})(uid=%n))
user_filter = (&(objectClass={$configDovecot['ldap_passfilter']})(uid=%n))

END;

}

//
// Additional Dovecot settings
//

$dovecot_conf['MAX_DOVECOT_CONN'] = <<<END
#<MAX_DOVECOT_CONN>
max_mail_processes = {$configDovecot['dovecot_max']}

END;

$dovecot_conf['MAX_DOVECOT_PERIP'] = <<<END
#<MAX_DOVECOT_PERIP>
mail_max_userip_connections = {$configDovecot['dovecot_maxperip']}

END;

$dovecot_conf['DEFAULT_DOMAIN'] = <<<END
#<DEFAULT_DOMAIN>
auth_default_realm = {$configDovecot['default_domain']}

END;
