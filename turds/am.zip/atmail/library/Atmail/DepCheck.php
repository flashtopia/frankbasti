<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

function check_deps($input_args)
{

	ini_set('memory_limit', "64M");
	error_reporting(E_ALL & ~E_NOTICE);

	try
	{

		require_once('/usr/local/atmail/webmail/library/utility.php');

	}
	catch(Exception $e)
	{

		require_once('library/utility.php');

	}
/*
	 * Automated installation configuration vars
	 */

	$args = array();
	$argsError = 0;

	// Build a list of arguments
	foreach($input_args as $arg)
	{
		$arr = split("=", $arg);
		$arr[0] = str_replace('--', '', $arr[0]);
	
		if(empty($arr[1]))
		{

			$arr[1] = "";		

		}
	
		$args[$arr[0]] = $arr[1];
	
	}

// Check suse requirements
// If we are running a system with zypper, install the requirements
	if(file_exists('/etc/SuSE-release') || file_exists('/etc/SuSE-version'))
	{

		$suse = 1;
	
		fwrite(STDOUT, "\n\033[1;32mInstall Dependencies \033[0;39m\n--------------------\n");

		fwrite(STDOUT, "
Before installing Atmail, the utility will check your system has the correct
system dependencies and packages installed to compile, setup and configure
the software. If any packages are missing these can be automatically
installed via the network and ready to continue with the installation.\n\n");

		fwrite(STDOUT, "Required Dependencies:\n\n");

		$packages = `rpm -qa`;
		$deplist = "";
		$depcheck = 0;

		foreach(array('pcre', 'pcre-devel', 'rsync', 'php5', 'php-dom', 'php5-dom', 'php5-imap', 'php5-mysql', 'php5-xmlrpc', 'php5-openssl', 'php5-gd', 'php5-ctype', 'php5-mbstring', 'apache', 'mysql-', 'libmysqlclient-devel', 'zlib', 'zlib-devel', 'gcc', 'gcc-c++', 'gcc-locale', 'make', 'libdb-4_5', 'libdb-4_5-devel', 'libgda', 'openssl', 'libopenssl-devel', 'expect', 'libstdc++-devel', 'autoconf', 'automake', 'bison', 'flex', 'gdb', 'subversion', 'krb5', 'krb5-devel', 'sqlite3', 'sqlite3-devel', 'patch', 'attr', 'findutils-locate', 'apache2-mod_php5', 'openldap2-devel', 'libldap-2_4-2') as $dep)
		{

			$depquote = preg_quote($dep);

			/*if(!preg_match("/^$depquote/", $packages))*/
			{

				if(strstr($dep, "ii  ")!=null)
				{

					$dep = trim($dep, "ii  ");

				}
				if(strstr($dep, "mysql-")!=null)
				{

					$dep = "mysql";

				}
			
				if (preg_match('/^php5-/', $dep))
				{

					if (extension_loaded(str_replace('php5-', '', $dep)))
					{

						continue;

					}	

				}		
			
				$deps[$dep] = $dep;
				fwrite(STDOUT, " * Required $dep\n");
				$deplist .= "$dep ";
				$depcheck++;
				if($dep == 'php5-mysql')
				{
					
					system('touch .mysqlrestart');
					$mysqlrestart = 1;
					
				}   
				
			}   
			
		}

		if($depcheck > 0)
		{

			if (!isset($args['install']))
			{
				$a = strtolower(prompt("Install dependencies automatically? [Y/n]", "Y"));
			}
			else
			{
				$a = 'y';
			}
		
			if ($a == 'y' || $a == 'yes')
			{
	
				fwrite(STDOUT, "\n\033[1;32mInstalling Packages \033[0;39m\n-------------------\n");
	
				fwrite(STDOUT, "\nInstalling packages via the system 'zypper' installer, please standby\nthis process make take several minutes depending the speed of your network\n\n");
	
				foreach($deps as $dep)
				{
					if($dep == 'libldap-2_4-2')
					{
						// if suse 64, patch
						if (file_exists('/usr/lib64/libldap-2.4.so.2.2.0'))
						{
							system('ln -s /usr/lib64/libldap-2.4.so.2.2.0 /usr/lib64/libldap.so');
							system('export LDFLAGS=-L/usr/lib64');
						}		
					}
					$deplist .= $dep . " ";
				}
			
				system("zypper -n install $deplist");
	
				fwrite(STDOUT, "\n");
			
				// TODO: check suse package success
				{
					fwrite(STDOUT, "\nDependencies successfully installed, proceeding with Atmail configuration.\n");
	
					if (!isset($args['install']))
						prompt('[Press Enter to Continue]');	
				}
				$restart_b = true;
			}
		}
		else
		{
			fwrite(STDOUT, "* All Dependencies are correctly installed.\n");
		}

		// End suse requirements

		if (!file_exists("/etc/apache2/sysconfig.d/include.conf")) 
		{ 
			system("touch /etc/apache2/sysconfig.d/include.conf");
		}
	
		system('/etc/init.d/mysql restart');
	}

	// Check Ubuntu requirements/version 
	// If we are running a system with apt-get, install the requirements

	if((file_exists('/etc/debian_version') || file_exists('/etc/debian_release')) && file_exists('/etc/lsb-release'))
	{

		// Check for lsb-release version
		preg_match('/DISTRIB_RELEASE=(.*)/', file_get_contents("/etc/lsb-release"), $m);

		// Ubuntu 10.4 
		if(version_compare($m[1], '10', '>=')) 
		{
	
			$debian = 1;
	
			fwrite(STDOUT, "\n\033[1;32mInstall Dependencies \033[0;39m\n--------------------\n");

			fwrite(STDOUT, "
Before installing Atmail, the utility will check your system has the correct
system dependencies and packages installed to compile, setup and configure
the software. If any packages are missing these can be automatically
installed via the network and ready to continue with the installation.\n\n");

			fwrite(STDOUT, "Required Dependencies:\n\n");
	
			$packages = `dpkg -l | grep ii`;
			$deplist = "";
			$depcheck = 0;
	    
			foreach(array('libpcre3', 'libpcre3-dev', 'rsync', 'php5-common', 'php5-imap', 'apache2', 'apache2-mpm-prefork', 'apache2-utils', 'apache2.2-common', 'mysql-server-5.1', 'php5-mysql', 'zlib1g', 'zlib1g-dev', 'gcc', 'g++', 'libmysqlclient-dev', 'make ', 'libdb4.7', 'libdb4.7-dev', 'libgdbm-dev', 'libgdbm3', 'openssl', 'libssl-dev', 'expect', 'binutils-doc', 'expectk', 'g++-multilib', 'g++-4.4-multilib', 'gcc-4.4-doc', 'libstdc++6-4.4-dbg', 'autoconf', 'automake1.9', 'bison', 'flex', 'gcc-doc', 'gcc-multilib', 'gdb', 'libtool', 'manpages-dev', 'gcc-4.4-locales', 'gcc-4.4-multilib', 'subversion', 'krb5-config', 'sqlite3', 'libsqlite3-dev', 'patch', 'libkrb5-dev', 'php5-xmlrpc', 'ii  attr', 'php5-ctype', 'php5-dom', 'libldap2-dev') as $dep)
			{		

				$depquote = preg_quote($dep);
	
				if(!preg_match("/$depquote/", $packages))
				{
					if(strstr($dep, "ii  ")!=null)
					{
						$dep = trim($dep, "ii  ");
					}
			
					if(strstr($dep, "mysql") != null)
					{
						system('touch .mysqlrestart');
						$mysqlrestart = 1;
					}
	
					
					if (preg_match('/^php5-/', $dep))
					{
						if (extension_loaded(str_replace('php5-', '', $dep)))
						{
							continue;
						}	
					}		
			
					$deps[$dep] = $dep;
					fwrite(STDOUT, " * Missing $dep\n");
					$deplist .= "$dep ";
					$depcheck++;
					if($dep == 'php5-mysql')
					{
						system('touch .mysqlrestart');
						$mysqlrestart = 1;
					}
				}
			}
	
			if($depcheck > 0)
			{
				if (!isset($args['install']))
				{
					$a = strtolower(prompt("Install missing dependencies automatically? [Y/n]", "Y"));
				}
				else
				{
					$a = 'y';
				}
			
				if ($a == 'y' || $a == 'yes')
				{
					fwrite(STDOUT, "\n\033[1;32mInstalling Packages \033[0;39m\n-------------------\n");
					fwrite(STDOUT, "\nInstalling missing packages via the system 'apt-get' installer, please standby\nthis process make take several minutes depending the speed of your network\n\n");
	
					foreach($deps as $dep)
					{
						$deplist .= $dep . " ";
					}
			
					system("apt-get -y install $deplist");
	
					fwrite(STDOUT, "\n");
			
					// Check packages again
					$packages = `dpkg -l`;
					$faildep = "";
			
					foreach($deps as $dep)
					{
						$depquote = preg_quote($dep);
						if(preg_match("/$depquote/", $packages))
						{
							fwrite(STDOUT, " * Installed successfully: $dep\n");	
						}
						else
						{
							fwrite(STDOUT, " * Failed install: $dep\n");
							$faildep++;
						}
					}
	
					if($faildep)
					{
						fwrite(STDOUT, "\n\nCould not successfully install the missing dependencies, please check your connection to the\nnetwork is active and the system 'apt-get' command is installed correctly\n\n");
	
						if (!isset($args['install']))
						{
							prompt('[Press Enter to Continue]');
						}	
					}
					else
					{
						fwrite(STDOUT, "\nMissing dependencies successfully installed, proceeding with Atmail configuration.\n");
	
						if (!isset($args['install']))
						{
							prompt('[Press Enter to Continue]');
						}	
					}
					$restart_b = true;
				}
			}
			else
			{
				fwrite(STDOUT, "* All Dependencies are correctly installed.\n");
			}
			// End Ubuntu 10.4 requirements
		}
		else
		{
		// Ubuntu 9.10 or older	
			$debian = 1;

			fwrite(STDOUT, "\n\033[1;32mInstall Dependencies \033[0;39m\n--------------------\n");

			fwrite(STDOUT, "
	Before installing Atmail, the utility will check your system has the correct
	system dependencies and packages installed to compile, setup and configure
	the software. If any packages are missing these can be automatically
	installed via the network and ready to continue with the installation.\n\n");

			fwrite(STDOUT, "Required Dependencies:\n\n");
	
			$packages = `dpkg -l | grep ii`;
			$deplist = "";
			$depcheck = 0;
	
			foreach(array('libpcre3', 'libpcre3-dev', 'rsync', 'php5-common', 'php5-imap', 'apache2', 'apache2-mpm-prefork', 'apache2-utils', 'apache2.2-common', 'mysql-client-5.0', 'mysql-server-5.0', 'mysql-server-core-5.0', 'php5-mysql', 'zlib1g', 'zlib1g-dev', 'gcc', 'g++', 'libmysqlclient15-dev', 'make ', 'libdb4.2', 'libdb4.2-dev', 'libgdbm-dev', 'libgdbm3', 'openssl', 'libssl-dev', 'expect', 'binutils-doc', 'expectk', 'g++-multilib', 'g++-4.2-multilib', 'gcc-4.2-doc', 'libstdc++6-4.2-dbg', 'autoconf', 'automake1.9', 'bison', 'flex', 'gcc-doc', 'gcc-multilib', 'gdb', 'libtool', 'manpages-dev', 'gcc-4.2-locales', 'gcc-4.2-multilib', 'subversion', 'krb5-config', 'sqlite3', 'libsqlite3-dev', 'patch', 'libkrb5-dev', 'php5-xmlrpc', 'ii  attr', 'php5-ctype', 'php5-dom', 'libldap2-dev') as $dep)
			{		

				$depquote = preg_quote($dep);
	
				if(!preg_match("/$depquote/", $packages))
				{
					if(strstr($dep, "ii  ")!=null)
					{
						$dep = trim($dep, "ii  ");
					}
			
					if(strstr($dep, "mysql") != null)
					{
						system('touch .mysqlrestart');
						$mysqlrestart = 1;
					}
	
					
					if (preg_match('/^php5-/', $dep))
					{
						if (extension_loaded(str_replace('php5-', '', $dep)))
						{
							continue;
						}	
					}		
			
					$deps[$dep] = $dep;
					fwrite(STDOUT, " * Missing $dep\n");
					$deplist .= "$dep ";
					$depcheck++;
					if($dep == 'php5-mysql')
					{
						system('touch .mysqlrestart');
						$mysqlrestart = 1;
					}
				}
			}
	
			if($depcheck > 0)
			{
				if (!isset($args['install']))
				{
					$a = strtolower(prompt("Install missing dependencies automatically? [Y/n]", "Y"));
				}
				else
				{
					$a = 'y';
				}
			
				if ($a == 'y' || $a == 'yes')
				{
					fwrite(STDOUT, "\n\033[1;32mInstalling Packages \033[0;39m\n-------------------\n");
					fwrite(STDOUT, "\nInstalling missing packages via the system 'apt-get' installer, please standby\nthis process make take several minutes depending the speed of your network\n\n");
	
					foreach($deps as $dep)
					{
						$deplist .= $dep . " ";
					}
			
					system("apt-get -y install $deplist");
	
					fwrite(STDOUT, "\n");
			
					// Check packages again
					$packages = `dpkg -l`;
					$faildep = "";
			
					foreach($deps as $dep)
					{
						$depquote = preg_quote($dep);
						if(preg_match("/$depquote/", $packages))
						{
							fwrite(STDOUT, " * Installed successfully: $dep\n");	
						}
						else
						{
							fwrite(STDOUT, " * Failed install: $dep\n");
							$faildep++;
						}
					}
	
					if($faildep)
					{
						fwrite(STDOUT, "\n\nCould not successfully install the missing dependencies, please check your connection to the\nnetwork is active and the system 'apt-get' command is installed correctly\n\n");
	
						if (!isset($args['install']))
						{
							prompt('[Press Enter to Continue]');
						}	
					}
					else
					{
						fwrite(STDOUT, "\nMissing dependencies successfully installed, proceeding with Atmail configuration.\n");
	
						if (!isset($args['install']))
						{
							prompt('[Press Enter to Continue]');
						}	
					}
					$restart_b = true;
				}
			}
			else
			{
				fwrite(STDOUT, "* All Dependencies are correctly installed.\n");
			}
			// End Ubuntu 9.10 requirements
		}
	}



	// Check Debian requirements
	// If we are running a system with apt-get, install the requirements
	if((file_exists('/etc/debian_version') || file_exists('/etc/debian_release')) && !file_exists('/etc/lsb-release'))
	{
		$debian = 1;
	
		fwrite(STDOUT, "\n\033[1;32mInstall Dependencies \033[0;39m\n--------------------\n");

		fwrite(STDOUT, "
Before installing Atmail, the utility will check your system has the correct
system dependencies and packages installed to compile, setup and configure
the software. If any packages are missing these can be automatically
installed via the network and ready to continue with the installation.\n\n");

		fwrite(STDOUT, "Required Dependencies:\n\n");
	
		$packages = `dpkg -l | grep ii`;
		$deplist = "";
		$depcheck = 0;
	
		foreach(array('libpcre3', 'libpcre3-dev', 'rsync', 'php5-common', 'php5-imap', 'apache2', 'apache2-mpm-prefork', 'apache2-utils', 'apache2.2-common', 'mysql-server-5.0', 'php5-mysql', 'zlib1g', 'zlib1g-dev', 'gcc', 'g++', 'libmysqlclient15-dev', 'make ', 'libdb4.2', 'libdb4.2-dev', 'libgdbm-dev', 'libgdbm3', 'openssl', 'libssl-dev', 'expect', 'binutils-doc', 'expectk', 'g++-multilib', 'g++-4.2-multilib', 'libstdc++6-4.2-dbg', 'autoconf', 'automake1.9', 'bison', 'flex', 'gcc-multilib', 'gdb', 'libtool', 'manpages-dev', 'gcc-4.2-locales', 'gcc-4.2-multilib', 'subversion', 'krb5-config', 'sqlite3', 'libsqlite3-dev', 'patch', 'libkrb5-dev', 'php5-xmlrpc', 'ii  attr', 'php5-ctype', 'php5-dom', 'libldap2-dev') as $dep)
		{		

			$depquote = preg_quote($dep);
	
			if(!preg_match("/$depquote/", $packages))
			{
				if(strstr($dep, "ii  ")!=null)
				{
					$dep = trim($dep, "ii  ");
				}
			
				if(strstr($dep, "mysql") != null)
				{
					system('touch .mysqlrestart');
					$mysqlrestart = 1;
				}
	
					
				if (preg_match('/^php5-/', $dep))
				{
					if (extension_loaded(str_replace('php5-', '', $dep)))
					{
						continue;
					}	
				}		
			
				$deps[$dep] = $dep;
				fwrite(STDOUT, " * Missing $dep\n");
				$deplist .= "$dep ";
				$depcheck++;
				if($dep == 'php5-mysql')
				{
					system('touch .mysqlrestart');
					$mysqlrestart = 1;
				}
			}
		}
	
		if($depcheck > 0)
		{
			if (!isset($args['install']))
			{
				$a = strtolower(prompt("Install missing dependencies automatically? [Y/n]", "Y"));
			}
			else
			{
				$a = 'y';
			}
			
			if ($a == 'y' || $a == 'yes')
			{
				fwrite(STDOUT, "\n\033[1;32mInstalling Packages \033[0;39m\n-------------------\n");
				fwrite(STDOUT, "\nInstalling missing packages via the system 'apt-get' installer, please standby\nthis process make take several minutes depending the speed of your network\n\n");
	
				foreach($deps as $dep)
				{
					$deplist .= $dep . " ";
				}
			
				system("apt-get -y install $deplist");
	
				fwrite(STDOUT, "\n");
			
				// Check packages again
				$packages = `dpkg -l`;
				$faildep = "";
			
				foreach($deps as $dep)
				{
					$depquote = preg_quote($dep);
					if(preg_match("/$depquote/", $packages))
					{
						fwrite(STDOUT, " * Installed successfully: $dep\n");	
					}
					else
					{
						fwrite(STDOUT, " * Failed install: $dep\n");
						$faildep++;
					}
				}
	
				if($faildep)
				{
					fwrite(STDOUT, "\n\nCould not successfully install the missing dependencies, please check your connection to the\nnetwork is active and the system 'apt-get' command is installed correctly\n\n");
	
					if (!isset($args['install']))
					{
						prompt('[Press Enter to Continue]');
					}	
				}
				else
				{
					fwrite(STDOUT, "\nMissing dependencies successfully installed, proceeding with Atmail configuration.\n");
	
					if (!isset($args['install']))
					{
						prompt('[Press Enter to Continue]');
					}	
				}
				$restart_b = true;
			}
		}
		else
		{
			fwrite(STDOUT, "* All Dependencies are correctly installed.\n");
		}
		// End Debian requirements
	}

	// If we are running a system with yum, prompt to install any missing packages
	if(file_exists("/etc/redhat-release") && file_exists("/usr/bin/yum") || file_exists("/etc/fedora-release") && file_exists("/usr/bin/yum"))
	{

		fwrite(STDOUT, "\n\033[1;32mInstall Dependencies \033[0;39m\n--------------------\n");

		fwrite(STDOUT, "
	Before installing Atmail, the utility will check your system has the correct
	system dependencies and packages installed to compile, setup and configure
	the software. If any packages are missing these can be automatically
	installed via the network and ready to continue with the installation.\n\n");

		fwrite(STDOUT, "Required Dependencies:\n\n");

		$packages = `rpm -qa`;
		$deplist = "";
		$depcheck = 0;
	
		foreach( array('pcre', 'pcre-devel', 'rsync', 'mysql-server', 'mysql-devel', 'httpd', 'db4', 'db4-devel', 'php-mysql', 'php-pdo', 'php-xml', 'php-dom', 'php-gd', 'php-imap', 'ImageMagick', 'php-mbstring', 'php-ctype', 'gcc', 'gcc-c++', 'openssl-devel', 'httpd-devel', 'perl-HTML-Parser', 'perl-Compress-Zlib', 'perl-URI', 'perl-libwww-perl', 'subversion', 'krb5-devel', 'e2fsprogs-devel', 'libidn-devel', 'zlib-devel', 'openssl', 'openssl-devel', 'sqlite-devel', 'autoconf', 'automake', 'ncurses-devel', 'python-devel', 'readline-devel', 'attr-2', 'openldap-devel') as $dep )
		{

			$depquote = preg_quote($dep);
		
			if(!preg_match("/$depquote/", $packages))
			{

				if(strstr($dep, "-2")!=null)
				{

					$dep = trim($dep, "-2");

				}
			
				if (preg_match('/^php-/', $dep))
				{
					if (extension_loaded(str_replace('php-', '', $dep)))
					{

						continue;

					}	

				}
				$deps[$dep] = $dep;
				fwrite(STDOUT, " * Missing $dep\n");
				$deplist .= "$dep ";
				$depcheck++;
			
				if($dep == 'mysql')
				{
				
					system('touch .mysqlrestart');
					$mysqlrestart = 1;
				
				}   
			
			}   
	
		}
	
		if($depcheck > 0)
		{
			if (!isset($args['install']))
			{
				$a = strtolower(prompt("Install missing dependencies automatically? [Y/n]", "Y"));
			}
			else
			{
				$a = 'y';
			}
		
			if ($a == 'y' || $a == 'yes')
			{
				fwrite(STDOUT, "\n\033[1;32mInstalling Packages \033[0;39m\n-------------------\n");
				fwrite(STDOUT, "\nInstalling missing packages via the system 'yum' installer, please standby\nthis process make take several minutes depending the speed of your network\n\n");

				foreach($deps as $dep)
				{
					system("yum -y install $dep 2>&1");
				}
	
				//Make sure MySQL is started and does so on boot as we may have just started it
				system("/etc/init.d/mysqld start");
				system("chkconfig mysqld on");
	
				// Check packages again
				$packages = `rpm -qa`;
				$faildep = "";
				foreach($deps as $dep)
				{
					//ignore php-dom - complains until php session restarted - can prob safely proceed without checking else will have to restart server-install.php
					$depquote = preg_quote($dep);
					if(preg_match("/$depquote/", $packages) )
					{
						fwrite(STDOUT, " * Installed successfully: $dep\n");
					}
					elseif( $dep == 'php-dom' )
					{
					
						fwrite(STDOUT, " * Unable to detected without restart: $dep (Should be safe to proceed if showed as successful above, else CTRL-C this install and restart it to re-detect)\n");
					
					}
					else
					{
						fwrite(STDOUT, " * Failed install: $dep\n");
						$faildep++;
					}
				}
	
				if($faildep)
				{
			
					fwrite(STDOUT, "\n\nCould not successfully install the missing dependencies, please check your connection to the\nnetwork is active and the system 'yum' command is installed correctly\n\nSee KB article: http://atmail.com/view_article.php?num=822 for further details.\n");
	
					if( !isset($args['install']) )
					{
			
						exit;
			
					}	
			
				}
				elseif( !isset($args['upgradecli']) )
				{                            
				
					$restartInstaller = true;
			
				}
			
			}	
		}
		else
		{

			fwrite(STDOUT, "* All Dependencies are correctly installed.\n");

		}
	}

	// Debian, restart installer if php5-mysql missing
	if ($mysqlrestart)
	{

		fwrite(STDOUT, "\nMissing PHP mysql module installed, however you must re-run the installation script to initialize PHP correctly\n");
		fwrite(STDOUT, "Please run:\n\nphp server-install.php\nTo continue installation\n\n");
		exit(1); //will exit kill the installer or just the include?

	}

	// Restart installer if deps installed
	if( $restartInstaller )
	{

		fwrite(STDOUT, "\nMissing PHP modules installed, however you must re-run the installation script for the installer to detect and utilise the new modules\n");
		fwrite(STDOUT, "Please run:\n\nphp server-install.php\nTo continue installation\n\n");
		exit(1);
	
	}

}
