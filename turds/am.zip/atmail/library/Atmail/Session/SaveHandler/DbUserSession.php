<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

class Atmail_Session_SaveHandler_DbUserSession implements Zend_Session_SaveHandler_Interface
{
    public static $_sessionStore;
	private static $_Account = null;
	private static $_md5 = array();
	
	public function open($save_path, $name)
    {
		self::$_sessionStore = new Atmail_Db_Table( array('name' => 'UserSession') ); 
		return true;
    }
 
    public function close()
    { 
        return true;
    }
 
    public function read($id)
    {
		$row = self::$_sessionStore->fetchRow( self::$_sessionStore->select()->where('SessionID = ?',$id) );
		//Zend_Registry::get('log')->info('Searching for session record ' . $id);
		if ( isset($row->SessionData) ) {
			//Zend_Registry::get('log')->info('Search for session record found SessionData: ' . $row->Account);
            self::$_Account = $row->Account;
            self::$_md5[$id] = md5($row->SessionData);
    		return $row->SessionData;
		} else {                      
			return ''; 
		}
    }
 
    public function write($id, $SessionData)
    {
        // ignore writing data if it has not changed
        if( isset(self::$_md5[$id]) && self::$_md5[$id] == md5($SessionData) ) 
		{
        
    		//file_put_contents('php://stderr', "skipping session write!\n");
            return true;

        }
        
        //file_put_contents('php://stderr', "writing session!\n");
		$authData = Zend_Auth::getInstance()->getIdentity();
		//if($authData == null)
			//Zend_Registry::get('log')->info('Not writing session data for guest user (No Account)');
		//else
			//Zend_Registry::get('log')->info('writing session data for Account: ' . $authData['Account']);
		if(isset($authData['Account']) && strlen($authData['Account']) > 1) 
		{ 
		
			//only store session for valid Account
			self::$_Account = $authData['Account'];
			self::$_sessionStore->update(	array('SessionID' => $id, 'SessionData' => $SessionData, 'modified' => time()), 
											self::$_sessionStore->getAdapter()->quoteInto( 'Account = ?', self::$_Account) );
		}
		return true;
    }
 
    public function destroy($id)
    {
		//ATMAIL-457 - need to reinsert password on login because cal needs it (could rather store it in session - although unencrypted)
        //self::$_sessionStore->update(	array('SessionID' => 0, 'SessionData' => null, 'Password' => null, 'PasswordMD5' => null, 'modified' => time()), 
		self::$_sessionStore->update(	array('SessionID' => 0, 'SessionData' => null, 'modified' => time()), 
										self::$_sessionStore->getAdapter()->quoteInto( 'Account = ?', self::$_Account) );
		//Zend_Registry::get('log')->info('destroying session data for Account: ' . self::$_Account );
		return true;
    }
 
    public function gc($maxLifetime)
    {
        self::$_sessionStore->update(	array( 'SessionID' => 0, 'SessionData' => null, 'modified' => time() ), 
										'LENGTH(`SessionID`) > 0 AND (' . time() . ' - modified) > ' . intval($maxLifetime) );
    	return true;
	}
}