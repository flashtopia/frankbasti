<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

class Atmail_Session_SaveHandler_DbAdminSession implements Zend_Session_SaveHandler_Interface
{
    public static $_sessionStore;
    
	public function Atmail_Session_SaveHandler_DbAdminSession()
	{
		
		//do sanity check
		$dbTables = new dbTables();
		$adminUsersSchema = Zend_Registry::get('dbAdapter')->describeTable( $dbTables->AdminUsers );
		$requiredNewFields = array('ipAddress', 'modified', 'sessionData');
		foreach( $requiredNewFields as $requiredNewField )
		{
			
			if( !array_key_exists($requiredNewField, $adminUsersSchema) )
			{
				
				throw new Exception('Missing required fields.');
				
			}
		}
		
	}
	
	public function open($save_path, $name)
    {
	   	
		$dbTables = new dbTables();
		self::$_sessionStore = new Atmail_Db_Table( array('name' => $dbTables->AdminUsers) ); 
		return true;
    
	}
 
    public function close()
    { 
    
    	return true;
    
	}
 
    public function read($SessionID)
    {
        
		$row = self::$_sessionStore->fetchRow( self::$_sessionStore->select()->where('SessionID = ?',$SessionID) );
		
		if( $row ) 
		{

            return $row->sessionData;
		
		}
		else
		{
		
			return ''; 
		
		}		
        
    }
 
    public function write($SessionID, $sessionData)
    {

		//for some reason session data is bound to an admin record not just by session id
		//at this point if we are fetching Zend_Auth instance then it is set up for admin auth
		if( !Zend_Auth::getInstance()->hasIdentity() ) 
		{
		
			Zend_Registry::get('log')->debug( "No admin user logged in so not writing admin Session data.");
			return;
			
		}
			
		
		
		$Username = Zend_Auth::getInstance()->getIdentity();
		
		self::$_sessionStore->update( array( 'SessionID' => $SessionID, 'sessionData' => $sessionData, 'modified' => time() ), 
									  self::$_sessionStore->getAdapter()->quoteInto('Username = ?', $Username ) );
		
		Zend_Registry::get('log')->info('Wrote session data for ' . $Username . '.');
		return true;

    }
 
    public function destroy($SessionID)
    {

        self::$_sessionStore->update( array('SessionID' => null, 'sessiondata' => null), 
									  self::$_sessionStore->getAdapter()->quoteInto( 'SessionID = ?', $SessionID) );
		return true;

    }
 
    public function gc($maxLifetime)
    {

        self::$_sessionStore->update( array('SessionID' => null, 'sessionData' => null ), 
									  self::$_sessionStore->getAdapter()->quoteInto( 'LENGTH(`SessionID`) > 0 AND DATE_ADD(modified, INTERVAL ? SECOND) < ' . time(), intval($maxLifetime)) );
    	return true;

	}

}