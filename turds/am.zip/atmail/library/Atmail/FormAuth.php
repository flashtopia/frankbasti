<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

class Atmail_FormAuth
{
	static public function authenticated($requiredLevel = null, $requiredUser = null, $requiredGroup = null, $requiredResourceAccessAuthority = null)
	{
		
		//TODO: finalize implimentation of remaining AC
		if( isset($requiredLevel) || isset($requiredGroup) || isset($requiredUser) || isset($requiredResourceAccessAuthority) ) 
		{
			
			//plugin should set this
			//Zend_Session::setSaveHandler(new Atmail_Session_SaveHandler_DbauthSession());
			//Zend_Session::start();
			$identity = Zend_Auth::getInstance()->getIdentity();
			//if( isset($identity->username) )
			//	Zend_Registry::get('log')->info('Found authenticated: ' . print_r($identity, true) );
			if( !isset($identity->Username) )
			{
				
				Zend_Registry::get('log')->info('No Authenticated user found for session');  
				
			}
			
		} 
		else
		{
		
			//plugin should set this
			//Zend_Session::setSaveHandler(new Atmail_Session_SaveHandler_DbUserSession()); 
			//Zend_Session::start();
			//$identity = Zend_Auth::getInstance()->getStorage()->read();
			$identity = Zend_Auth::getInstance()->getIdentity();
			//Zend_Registry::get('log')->info('id ' . print_r($identity,true) );
			//if( isset($identity['Account']) )
			//	Zend_Registry::get('log')->info('Found authenticated user: ' . $identity['Account'] );
			//if( !isset($identity['Account']) )
			//	Zend_Registry::get('log')->info('No Authenticated Account found for session');  
			
		}
		//return true;
		
		$dbAdapter = Zend_Registry::get('dbAdapter');
		
		if( !empty($identity['Account']) ) 
		{
			$select = $dbAdapter->select()
								->from("Users")
								->join("UserSettings", "Users.Account = UserSettings.Account")
								->where("Users.Account = " . $dbAdapter->quote($identity['Account'])); 
			
			$userDataRows = $select->query()->fetchAll();
			
			Zend_Registry::set('UserSettings', $userDataRows[0]);	
			Zend_Registry::set('Account', $userDataRows[0]['Account']);	
			
			// Setup the users language environment
			Atmail_Locale::setupLocaleAndTranslation( $userDataRows[0]['Language'] );
	    
			// Load users Timezone
			if(isset($userDataRows[0]['TimeZone']))
			date_default_timezone_set($userDataRows[0]['TimeZone']);
		}	
		return Zend_Auth::getInstance()->hasIdentity();  
	}
} 
