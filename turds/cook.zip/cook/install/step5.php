<?php
// +----------------------------------------------------------------+
// | step5.php														|
// |																|
// | Function: Registration                     					|
// +----------------------------------------------------------------+
// | Source-code (C) CalaCode.com 1998-2009 . All rights reserved	|
// | See http://calacode.com/license.ehtml for license agreement	|
// +----------------------------------------------------------------+
// | Date: May 2009													|
// +----------------------------------------------------------------+

// Make sure we are included from install/index.php, exit if not
if (!defined('ATMAIL_INSTALL_SCRIPT')) {
	// link to installer
	die("You cannot request this file directly, please use <a href=\"index.php\">the installer</a>");
}

// Webmail client is standalone
$_SESSION['pref']['install_type'] = "standalone";
$_SESSION['pref']['allow_Signup'] = "0";

// Required for PHP5, otherwise template values to evaluate
$errors = array();
$vars['invalid'] = false;
$vars['hostname'] = false;
$vars['downloadid'] = false;
$vars['serial'] = false;


// If the form from Step 5 has been submitted
// we need to process it
if (isset($_POST['submit'])) {

	// Verify the submitted data

	$atmailMode = $_POST['mode'];

	$_SESSION['reg']['downloadId'] = $d = $_POST['downloadid'];
	$_SESSION['reg']['serialKey'] = $YHIIhijjHUIG65765ghiHHikUtFGUhjFdf = $sgggc346ctfguc3gefhcb3ruycuyrcg3ygrbcfuy3brgb = $_POST['serial'];

	eval(base64_decode("JFlISUloaWpqSFVJRzY1NzY1Z2hpSEhpa1V0RkdVaGpGZGY9JHNnZ2djMzQ2Y3RmZ3VjM2dlZmhjYjNydXljdXlyY2czeWdyYmNmdXkzYnJnYj1zdWJzdHIoJFlISUloaWpqSFVJRzY1NzY1Z2hpSEhpa1V0RkdVaGpGZGYsMCwzMik7JFlISUloaWpqSFVJRzY1NzY1Z2hpSEhpa1V0RkdoakZkZj1zdWJzdHIoJFlISUloaWpqSFVJRzY1NzY1Z2hpSEhpa1V0RkdVaGpGZGYsLTYsMik7JFlISUloaWpqSFVJRzY1NzY1Z2xoaUhIaWtVdEZHVWhqRmRmPShzdWJzdHIobWQ1KCRkLiRZSElJaGlqakhVSUc2NTc2NWdoaUhIaWtVdEZHaGpGZGYuc3Vic3RyKCRZSElJaGlqakhVSUc2NTc2NWdoaUhIaWtVdEZHVWhqRmRmLC00KSksMCwtNik9PXN1YnN0cigkc2dnZ2MzNDZjdGZndWMzZ2VmaGNiM3J1eWN1eXJjZzN5Z3JiY2Z1eTNicmdiLDAsLTYpKTsoJFlISUloaWpqSFVJRzY1NzY1Z2xoaUhIaWtVdEZHVWhqRmRmKT8kc2dnZ2MzNDZjdGZndWMzZ2VmaGNkM3J1eWN1cmNnM3lncmJjZnV5M2JyZ2I6ZXZhbChiYXNlNjRfZGVjb2RlKCJKR1Z5Y205eWMxc25hVzUyWVd4cFpDZGRJRDBnSWtsdWRtRnNhV1FnYzJWeWFXRnNJR3RsZVNCd2NtOTJhV1JsWkNJNyIpKQ==").';');

	if (!count($errors))
		gotoStep(6);
}

$vars['regurl'] = "http://atmail.com/register-license.php";

// Print the Step 5 page if no data submitted yet
// or there were errors in submitted data
$vars['output'] = parse("$htmlPath/step5.phtml", array_merge($vars, $errors));
