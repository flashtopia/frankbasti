<?php
// +----------------------------------------------------------------+
// | step6.php														|
// |																|
// | Function: 	setup WebAdmin access               				|
// +----------------------------------------------------------------+
// | Source-code (C) CalaCode.com 1998-2009 . All rights reserved	|
// | See http://calacode.com/license.ehtml for license agreement	|
// +----------------------------------------------------------------+
// | Date: May 2009 												|
// +----------------------------------------------------------------+

// Make sure we are included from install/index.php, exit if not
if (!defined('ATMAIL_INSTALL_SCRIPT')) {
	// link to installer
	die("You cannot request this file directly, please use <a href=\"index.php\">the installer</a>");
}

$vars['password'] = false;
$vars['confirm_password'] = false;

$installDir = dirname(dirname(__FILE__));

if (isset($_POST['submit'])) {
    
    $pass = $_POST['password'];
	$username = $_POST['username'];

   	require_once('../library/Zend/Db/Adapter/Pdo/Mysql.php');
       
    $db = new Zend_Db_Adapter_Pdo_Mysql(array(
        'host'     => $_SESSION['pref']['sql_host'],
        'username' => $_SESSION['pref']['sql_user'],
        'password' => $_SESSION['pref']['sql_pass'],
        'dbname'   => $_SESSION['pref']['sql_table']
    ));

    try {
        
        // clear the table of any existing admin users
		//CONSIDER: what about gracefully reinstalling/upgrading?
        $db->delete('AdminUsers');
        
        $data = array(
            'Username'  => $username,
            'Password'  => md5($pass),
            'UMasterAdmin' => 1
        );
        
        $res = $db->insert('AdminUsers', $data);
        $_SESSION['webadmin_setup'] = true;

    } catch (Zend_Exception $e) {
		$_SESSION['webadmin_setup'] = false;
    }

    // avoid the migration step for the moment
	gotoStep(8);
}


$vars['installDir'] = $installDir;
$vars['output'] = parse("$htmlPath/step6.phtml", $vars);
