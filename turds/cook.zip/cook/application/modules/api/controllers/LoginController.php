<?php
class Api_LoginController extends Zend_Controller_Action 
{
	
	public function init()
	{
		
		$this->view->baseUrl = $this->_request->getBaseUrl();
		$this->view->appBaseUrl = $this->_request->getBaseUrl() . (strpos($this->_request->getBaseUrl(),'index.php')?'':'/index.php');
		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		$this->view->moduleBaseUrl = $this->view->appBaseUrl . ($this->_request->module == 'default'?'':DIRECTORY_SEPARATOR . $this->_request->module);
		
		$this->_helper->viewRenderer->setNoRender();
		
		require_once 'application/models/api.php';
		$this->api = new api();
		
		$this->restserver = new Zend_Rest_Server();
		$this->restserver->setClass('api');
		 
		//this handles ACL
		if( !Atmail_HttpAuth::authenticated(3, null, 'admin', null) )
     		$this->_forward('authenticationfailed');
        
	}

	
    
	public function indexAction() {
    
		$this->restserver->handle( array('method' => 'index') );
		
	}
	
	public function authenticateAction() {
		
		$this->restserver->handle( array('method' => 'authenticate') );

	}
	
	public function authenticationfailedAction() {
		
		//just an empty deadend so failed XML responses are uniform
		$this->restserver->handle( array('method' => 'authenticationFailed') );

	}
	
	public function __call( $methodName, $args ) {
		
		$this->restserver->handle( array('method' => 'error', 'message' => substr($methodName,0,-6) . ' does not exist. Refer to documentation.') );
		
	}
		
}
