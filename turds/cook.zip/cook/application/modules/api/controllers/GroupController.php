<?php
/**
 * Created by James
 * Date: 14/05/12
 * Time: 2:17 PM
 * To change this template use File | Settings | File Templates.
 */

class Api_GroupController extends Atmail_Controller_Base
{
	public function preDispatch()
	{
		$this->userData = Zend_Auth::getInstance()->getStorage()->read();
		$this->userData = Atmail_Password::processUser($this->userData);
		$this->account = $this->userData['Account'];
		$this->_contacts = new contacts( array('Account' => $this->account, 'largeInstall' => '0') );
	}

    public function indexAction()
    {
    }

	public function listAction()
	{
		$groups = $this->_contacts->getGroups();

		$this->renderJson($groups);
	}

	public function deleteAction()
	{
		$param = $this->getRequest()->getParams();

		try{
			$this->_contacts->deleteGroup($param);
			$this->renderSuccess();
		}
		catch(Atmail_Exception $e) {
			$this->renderFail($e);
		}
	}

	public function createAction()
	{
		$param = $this->getRequest()->getParams();
		try{
			$id = $this->_contacts->createGroup($param);
			$this->renderJson(array(
				'result' => 'success',
				'data' => array(
					'GroupName' => $param['newGroupName'],
					'id' => $id,
				)
			));
		}
		catch(Atmail_Exception $e) {
			$this->renderFail($e);
		}
	}

}
