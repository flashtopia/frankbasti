<?php
class Api_UnifyController extends Zend_Controller_Action 
{
	
	public function init()
	{
		//TODO: extend authentication to support multiple user levels/roles/groups 
		require_once 'application/models/api.php';
		$this->api = new api();
		
		$this->baseUrl = $this->_request->getBaseUrl();
		$this->appBaseUrl = $this->_request->getBaseUrl() . (strpos($this->_request->getBaseUrl(),'index.php')?'':'/index.php');
		$this->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		$this->moduleBaseUrl = $this->appBaseUrl . ($this->_request->module == 'default'?'':DIRECTORY_SEPARATOR . $this->_request->module);
		
		$this->_helper->viewRenderer->setNoRender();
		
		$this->restserver = new Zend_Rest_Server();
		$this->restserver->setClass('api');

		// Load all the params
		$this->requestParams = $this->getRequest()->getParams();
        
		if( !Atmail_FormAuth::authenticated() )
			throw new Exception( "Access denied" );

		// Read from Zend-Auth
		$this->userData = Zend_Auth::getInstance()->getStorage()->read();
		$this->userData = Atmail_Password::processUser($this->userData);
			
		// Load the session
		$this->session = new Zend_Session_Namespace(ATMAIL_NAMESPACE);

		// Load the system settings
		$this->_globalConfig = Zend_Registry::get('config')->global;

		// Find the users settings ( used for theme )
		$this->UserSettings = Zend_Registry::get('UserSettings');

		$this->log = Zend_Registry::get('log');
		
		// Used to determine the contact in the global addressbook
		$this->Account = $this->userData['Account'];

		// Load the mail class
		//handle folder change requests here (allowing change from all actions/events) so that correct cache can be loaded (correct folder)
		$this->_currentConfig = array();
        
		$this->_mailStoreConfig = array_merge($this->_globalConfig, $this->userData, $this->_currentConfig, $this->UserSettings);
		
		//check if SSL enabled in UserSettings
		$this->_mailStoreConfig['ssl'] = ($this->_mailStoreConfig['UseSSL']=='1'?'SSL':'');

		$this->AtmailMailStorage = Atmail_Mail_Storage::getInstance($this->_mailStoreConfig);
		$this->AtmailMailStorageMain = &$this->AtmailMailStorage->getMailStore($this->_mailStoreConfig['namespaceName']);

		$this->carrier = new carrierapi( array('Account' => $this->Account) );
		$this->mobileAccounts = $this->carrier->listAccounts();
		
		//TODO: dynamically build list supported services from services folder having models to access such services
		$this->servicesAvailable = array('SMS' => false, 'Voicemail' => false, 'SIP' => false);
		foreach( $this->mobileAccounts as $mobileAccount )
			$this->servicesAvailable[$mobileAccount['Type']] = true;
		
		//at least one service must be avaialble to current user to use Unify
		if( count($this->mobileAccounts) == 0 )
			throw new Exception('No Unify services abailable for this account');
			
		$this->mobileAccount = null;
		//pid = providerid or null
		$this->pid = null;
		if( array_key_exists('pid', $this->requestParams) )
		{
			
			$this->pid = $this->requestParams['pid'];
			foreach( $this->mobileAccounts as $mobileAccount )
			{
				
				if( $mobileAccount['id'] == $this->pid )
					$this->mobileAccount = $mobileAccount;
			}
			if( $this->mobileAccount === null )
				throw new Exception('invalid pid specified');
			
		}

		//if type specified
		$this->type = null;
		if( array_key_exists('type', $this->requestParams) )
		{
			
			
			if( !array_key_exists($this->requestParams['type'], $this->servicesAvailable) )
				throw new Exception('service type not available');
			
			if( $this->pid !== null )
			{
				
				if( $this->mobileAccount['Type'] == $this->requestParams['type'] )
					$this->type = $this->requestParams['type'];
				else
					throw new Exception('Error: Specified pid does not support specified type');
				
			}
			else // no specific pid mentioned so find first matching provider providing type
			{
				$matchingTypeC = 0;
				$firstMatchedAccount = null;
				foreach( $this->mobileAccounts as $mobileAccount )
				{
				
					if( $mobileAccount['Type'] == $this->requestParams['type'] )
					{
						
						$this->type = $this->requestParams['type'];
						if( $matchingTypeC == 0 )
							$firstMatchedAccount = $mobileAccount;
						$matchingTypeC++;
						
					}
				}
				if( $matchingTypeC == 0 )
					throw new Exception("Error: No matching provider found for specified type");
				else if( $matchingTypeC == 1 )
				{
					$this->pid = $firstMatchedAccount['id'];
					$this->mobileAccount = $firstMatchedAccount;
				}
				
			}
			
		}

			
		
		//by the end of init you have validated or default $this->pid, $this->mobileAccount, and $this->type or Exception
		//if pid is null then not restricted to single pid
		//if type = null then not restricted to specific type (e.g. Unified timeline requests)
		//if a specific pid or type is specified then instantiate providers with only that account, else instantiate with all users' available accounts
		$providerAccounts = array();
		if( $this->pid !== null ) 
			$providerAccounts[] = $this->mobileAccount;
		else if( $this->type !== null )
		{
			
			foreach( $this->mobileAccounts as $account )
				if( $account['Type'] == $this->type )
					$providerAccounts[] = $account;
			
		}
		else 
			$providerAccounts = $this->mobileAccounts;
				
		$this->providers = new Atmail_Providers($providerAccounts);
		
		
		$this->dbAdapter = Zend_Registry::get('dbAdapter'); //TMP until moved into propper models

	} 
	
	public function indexAction() { throw new Exception('Invalid Call'); }
	
	public function listservicesAction() {
	
		$data = array();
		foreach( $this->mobileAccounts as $v )
		{
			if( $this->type !== null && $v['Type'] != $this->type)
				continue;
			if( $this->pid !== null && $v['id'] != $this->pid)
				continue;
			
			unset($v['Account']);
			unset($v['Password']);
			$data[] = $v;
			
		}
		echo Zend_Json::encode($data);
	
	}
	
	public function __call( $name, $arguments )
	{
		
		
		$args = $this->requestParams;
		unset($args['module']);
		unset($args['controller']);
		unset($args['action']);
		if( $this->type !== null )
			$args['type'] = $this->type;
		if( $this->pid !== null )
			$args['pid'] = $this->pid;
		Zend_Registry::get('log')->debug( "\n" . print_r($args, true) . "\n" . __METHOD__ . ' #' . __LINE__ . ": \$args \n");
		//if arguments specifies service type and provider then instantiate object and pass the requested action over to class if if impliments the requested method, else fail
		$methodName = substr($name,0,-6);
		$results = $this->providers->$methodName($args);
		echo Zend_Json::encode($results);
	}
	
}
