<?php

class Api_PlugininterfaceController extends Atmail_Controller_PluginInterface 
{

}
