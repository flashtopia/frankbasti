<?php
class Mail_IndexController extends Atmail_Controller_Action 
{

	public function indexAction() 
	{
		$this->_forward('index', 'mail');
	}
	
	public function jstranslateAction()
	{
	
		$this->view->setEncoding('UTF-8');
		if(!Atmail_FormAuth::authenticated())
		{
			// we have most probably timed out, so lets kick them to the timeout bootstrap page
			// this will poison json responses, which will fire the php.error ( or ajax.error ) which can detect the special page
			$this->_forward('timeout', 'index', 'default');
			return;
		}
		//This renders a translated js array (cached by browser)
		$this->getResponse()->setHeader('Content-Type','text/javascript; charset=utf-8');
		
	}
	
}
