<?php
class Mail_SearchController extends Atmail_Controller_Action
{

  	public function preDispatch() 
	{
		// check if we have been authenticated... and redirect if not
		if(!Atmail_FormAuth::authenticated())
		{
			// we have most probably timed out, so lets kick them to the timeout bootstrap page
			// this will poison json responses, which will fire the php.error ( or ajax.error ) which can detect the special page
			$this->_forward('timeout', 'index', 'default');
			return;
		}
	    
		$this->_userData = Zend_Auth::getInstance()->getStorage()->read();
		$this->_userData = Atmail_Password::processUser($this->_userData);
		
		$this->_globalConfig =& Zend_Registry::get('config')->global;
		$this->_mailStoreConfig = array_merge($this->_globalConfig, $this->_userData);
		
		if( isset($this->view->requestParams['folder']) )
		{
		
			$this->_mailStoreConfig['folder'] = urldecode( urldecode( $this->view->requestParams['folder'] ) );
		
		}
		else
		{
			throw new Exception('Illegal call to Search: folder parameter missing');
			
		}
		$this->AtmailMailStorage = Atmail_Mail_Storage::getInstance($this->_mailStoreConfig);  
		$this->AtmailMailStorageMain = &$this->AtmailMailStorage->getMailStore($this->_mailStoreConfig['namespaceName']);
	}
	
	public function searchAction()
	{
		
		if(!$this->AtmailMailStorageMain)
		{
			// our storage has gone away, an indication of session timeout - bail
			return;	
		}
		
		$search_type = $this->view->requestParams['searchType'];
		if ($search_type == undefined || $search_type == '')
		{
			
			$search_type = 'email';
			
		}
			
		if ($search_type == 'calendar')
		{
		
			$this->view->searchTitle = 'Calendar';			
		
		}
		else if ($search_type == 'email')
		{		
				
			$preparedSearchQuery = array( );
			//$preparedSearchQuery[] = array('field' => 'from', 'value' => $this->view->requestParams['searchQuery']);	
			//$preparedSearchQuery[] = array('field' => 'subject', 'value' => $this->view->requestParams['searchQuery']);
			//$preparedSearchQuery[] = array('field' => 'to', 'value' => $this->view->requestParams['searchQuery']);
			$searchQueryUTF8 = urldecode( urldecode( $this->view->requestParams['searchQuery'] ) ); //POSTed (UT uses GET)
			$words = preg_split("[ ]", $searchQueryUTF8);
			
			foreach($words as $word)
			{
				$preparedSearchQuery[] = array('field' => 'text', 'value' => $word);
			}
			
			$searchResults = $this->AtmailMailStorageMain->search($preparedSearchQuery);
			if( is_array($searchResults) ) 
			{
			 
				$searchResults = array_reverse($searchResults);
				$searchResultsChunks = array_chunk($searchResults,50);
				$searchResults = $searchResultsChunks[0];				
			
			} 
			else 
			{
				
				$searchResults = array();
				
			}
		
			//get headers for the list of results
			if( count($searchResults) > 0 )
			{
				
				$this->view->results = $this->AtmailMailStorageMain->getBasicHeaders($searchResults);
				
			}
			else
			{
				
				$this->view->results = array();
				
			}

			$this->view->searchTitle = $this->AtmailMailStorageMain->decodeUTF7( $this->AtmailMailStorageMain->getCurrentFolderObject()->getLocalName() );
			$this->view->currentFolder = $this->AtmailMailStorageMain->getCurrentFolder();
		}		
		
		//TODO: cache the search result so can page
		//jQuery sends the .load( request as XML and Atmail_Controller_Action switches offrendering, so have to switch rendering on again
		$this->_helper->viewRenderer->setNoRender(false);
	}
}
