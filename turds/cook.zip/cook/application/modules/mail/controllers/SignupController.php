<?php
//CONSIDER: revise message view to enable viewing messge id linked to folder, compound key to guarantee found
class Mail_SignupController extends Atmail_Controller_Action
{
	
	public function signupAction()
	{
		
		$requestParams = $this->getRequest()->getParams();
		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		$this->configGlobal = Zend_Registry::get('config')->global;
		$this->view->appBaseUrl = $this->getRequest()->getBaseUrl() . (strpos($this->getRequest()->getBaseUrl(),'index.php')?'':'/index.php');
		$this->view->moduleBaseUrl = $this->view->appBaseUrl . DIRECTORY_SEPARATOR . ($requestParams['module']=='default'?'':$requestParams['module'] . DIRECTORY_SEPARATOR);
		
		$signupAllowed = Zend_Registry::get('config')->global['allow_Signup'];
		if( $this->configGlobal['install_type'] == 'server' && $signupAllowed == '1' || $signupAllowed == 'true' )
		{
			
			$this->view->signupAllowed = true;
			
		}
		else
		{
			
			$this->view->signupAllowed = false;
			
		}


		if (!empty(Zend_Registry::get('config')->global['cssStyle']))
		        $this->view->cssStyle = Zend_Registry::get('config')->global['cssStyle'];
		else
		        $this->view->cssStyle = 'original';
		
		$this->view->defaultLanguage = Zend_Registry::get('config')->defaultUserSettings['Language'];
		
		$dbTables = new dbTables();
		$dbAdapter = Zend_Registry::get('dbAdapter');
		$result = $dbAdapter->select()
							->from($dbTables->AdminUsers, array('Username'))
							->where("`UMasterAdmin` = '1'")
							->query()
							->fetchAll();
		
		require_once('api.php');
		$api = new api( array('directApi' => 1, 'Username' => $result[0]['Username']) );
		$this->view->domains = $api->domainList();
		
		// Which languages are available?
		$this->view->localeString = Atmail_Locale::getLocaleString();
		$this->view->availableLocales = Atmail_Locale::getAvailableLocales();
		
	}
	
	public function signupprocessAction()
	{
		$requestParams = $this->getRequest()->getParams();
		
		// You can use this event to trigger some other processing and you can 
		// stop the signup by setting $this->blockSignup to true
		$this->_helper->pluginCall('preSignupProcess', $requestParams);
		
		if($this->blockSignup || ($this->configGlobal['install_type'] == 'server' && !isset($this->configGlobal['allow_Signup']) || $this->configGlobal['allow_Signup'] == '0' ))
		{
			
			$signupAllowed = false;

		}                          
		else
		{
			
			$signupAllowed = true;
			require_once 'library/jQuery/jQuery.php';
		
			$dbTables = new dbTables();
			$dbAdapter = Zend_Registry::get('dbAdapter');
			$result = $dbAdapter->select()
								->from($dbTables->AdminUsers, array('Username'))
								->where("`UMasterAdmin` = '1'")
								->query()
								->fetchAll();
		
			require_once('api.php');
			$api = new api( array('directApi' => 1, 'Username' => $result[0]['Username']) );
			$requestParams['name'] = $requestParams['username'] . '@' . $requestParams['hostname'];
			$this->view->result = $api->userSignup($requestParams);
		}
		
		if( $signupAllowed && (!isset($this->view->result['status']) || $this->view->result['status'] != 'failed') )
		{
			
			$this->view->signupAccepted = true;
			$this->getRequest()->setPost('module', 'mail');
			$this->getRequest()->setPost('controller', 'auth');
			$this->getRequest()->setPost('action', 'processlogin');
			$this->getRequest()->setPost('emailName', $requestParams['username']);
			$this->getRequest()->setPost('emailDomain', $requestParams['hostname']);
			$this->getRequest()->setPost('email', $requestParams['username'] . '@' . $requestParams['hostname']);
			$this->getRequest()->setPost('password', $requestParams['Password']);
			$this->getRequest()->setPost('requestedServer', '');
			$_REQUEST['emailName'] = $requestParams['username'];
			$_REQUEST['emailDomain'] = $requestParams['hostname'];
			$_REQUEST['password'] = $requestParams['Password'];
			$_REQUEST['requestedServer'] = '';
			$_POST['emailName'] = $requestParams['username'];
			$_POST['emailDomain'] = $requestParams['hostname'];
			$_POST['password'] = $requestParams['Password'];
			$_POST['requestedServer'] = '';
			jQuery::addMessage( $this->view->translate('Signup has been accepted. Logging you into your new account.') ); 
			jQuery('#accountLoginEmailName')->attr('value', $requestParams['username']);
			jQuery('#accountLoginPassword')->attr('value', $requestParams['Password']);
			jQuery('#accountLoginDomain')->attr('value', $requestParams['hostname']);
			jQuery('#accountLoginForm')->submit();
		}                                
		else
		{
			
			$this->view->signupAccepted = false;
			jQuery::addError( $this->view->translate('The signup has not been accepted. Please contact your administrator.') . " " . $this->view->result['response']['message'] ); 
			jQuery('#username')->focus();
			//jQuery::evalScript("location.href='" . $this->view->moduleBaseUrl . "/index'" );
			//push back to signup form
			
		}
		$this->view->requestParams = $requestParams;
		$this->_helper->viewRenderer->setNoRender();
		$this->render('global/jsonresponse', null, true);
	}

}
