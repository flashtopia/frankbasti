<?php

class Mail_PlugininterfaceController extends Atmail_Controller_Plugininterface 
{

}
