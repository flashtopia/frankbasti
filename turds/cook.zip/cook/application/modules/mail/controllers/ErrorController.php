<?php
require_once 'Zend/Controller/Action.php';

class ErrorController extends Zend_Controller_Action
{
    public function init()
    {
        $this->view->appBaseUrl = $this->_request->getBaseUrl();
		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		$this->_globalConfig = Zend_Registry::get('config')->global;
		$this->brandname = $this->_globalConfig['brandname'];
		$this->company_url = $this->_globalConfig['company_url'];
		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		$this->view->appBaseUrl = $this->_request->getBaseUrl() . (strpos($this->_request->getBaseUrl(),'index.php')?'':'/index.php');
		$this->view->moduleBaseUrl = $this->view->appBaseUrl . ($this->view->requestParams['module']=='default'?'':DIRECTORY_SEPARATOR . $this->view->requestParams['module']) . 'mail';
		unset($this->_globalConfig);
    }

    public function errorAction() 
    { 
        $errors = $this->_getParam('error_handler'); 
        $this->exception = $errors->exception;
        switch ($errors->type) { 
            case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_CONTROLLER: 
            case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_ACTION: 

                // 404 error -- controller or action not found 
                $this->getResponse()->setHttpResponseCode(404); 
                $this->view->error = 'Page not found'; 
                break; 
            default: 
                // application error 
                if($errors->exception->getMessage() == 'Access denied')
				{
					$this->getResponse()->setHttpResponseCode(403);
				}
				else
				{
					$this->getResponse()->setHttpResponseCode(500); 
                	$this->view->error = 'Application error'; 
            	}
				break; 
        }

 		Zend_Registry::get('log')->info($this->view->error . ': ' . $this->exception->getMessage() . 
										"\nThrown in: " . $this->exception->getFile() . ', Line #:' . $this->exception->getLine() . ', Code #: ' . $this->exception->getCode() .
										"\nStack trace: \n----------\n" . $errors->exception->getTraceAsString() .
										"\n-------------------end of exception ---------------\n");
		
        $this->view->exception = $errors->exception; 
        //$this->view->env       = $this->getInvokeArg('env'); 
        //$this->view->request   = $this->_request; 
        //$this->view->response  = $this->_response; 
        //$this->view->errors  = $errors;          
        $this->view->company_url = $this->company_url;
        $this->view->brandname = $this->brandname;
              
		
		if($this->getRequest()->isXmlHttpRequest() )
		{
			$this->_helper->viewRenderer->setNoRender();
			$this->getResponse()->setHttpResponseCode(200);
			require_once 'library/jQuery/jQuery.php';
			jQuery('#errors')->html( $errors->exception->getMessage() );
			//jQuery('#debug')->html( '<pre>Exception: ' . $errors->exception->getTraceAsString() . '</pre>' );
			
			if( !isset(jQuery::$jQuery) )
			 	jQuery::$jQuery = new jQuery(); //should only be needed for empty requests
			echo Zend_Json::encode(jQuery::$jQuery->response);
			return;
		} else {
        	
		}
    }  
}