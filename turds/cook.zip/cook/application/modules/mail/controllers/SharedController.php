<?php
class Mail_SharedController extends Atmail_Controller_Action
{
	
	private $_settings;

	public function init()
	{
	
	}

	public function preDispatch()
	{
		// Setup filters
		$this->filter = ''; //Atmail_Filter_Input_Controller::filterInput($this->_request);

		require_once 'library/jQuery/jQuery.php';
		
		/*
		if( $this->getRequest()->isXmlHttpRequest() || $this->getRequest()->isAjax )
		{
			$this->view->jsonIdsToRender = array();
			Zend_Registry::get('log')->info(__METHOD__ . ' isAJAX request');//show a hidden dialog box and include desired content
			$this->isAjax = true;
		}
		else
		{
			Zend_Registry::get('log')->info(__METHOD__ . ' normal HTML request');//show a hidden dialog box and include desired content
			$this->isAjax = false;
		}

		// check if we have been authenticated... and redirect if not
		if(!Atmail_FormAuth::authenticated())
		{
			// we have most probably timed out, so lets kick them to the timeout bootstrap page
			// this will poison json responses, which will fire the php.error ( or ajax.error ) which can detect the special page
			$this->_forward('timeout', 'index', 'default');
			return;
		}
		else
		{
			$this->view->UserSettings = Zend_Registry::get('UserSettings');
			$this->view->requestParams = $this->_request->getParams();
			$this->view->setEncoding('UTF-8');
			$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
			$this->view->appBaseUrl = $this->_request->getBaseUrl() . (strpos($this->_request->getBaseUrl(),'index.php')?'':'/index.php');
			$this->view->moduleBaseUrl = $this->view->appBaseUrl . ($this->view->requestParams['module']=='default'?'':DIRECTORY_SEPARATOR . $this->view->requestParams['module']);
			$this->view->thisActionURL = $this->view->moduleBaseUrl . '/' . $this->view->requestParams['controller'] . '/' . $this->view->requestParams['action'];
			$this->view->notices = array();
			$this->view->errors = array();
			$this->session = new Zend_Session_Namespace('defaultNamespace');
			$this->userData = Zend_Auth::getInstance()->getStorage()->read();
			$this->_globalConfig = Zend_Registry::get('config')->global;
			$this->_currentConfig = array();			
		}
			
		list($junk, $domain) = explode('@', $this->userData['Account']);	
		
		$this->view->localDomain = (in_array($domain, domains::getList()) ? true : false); 
		$this->view->group = groups::get($this->view->UserSettings['Ugroup']);
		
		$this->fileAdapter = Atmail_Files_Factory::instance($this->userData['Account']);
		*/
		
		// Setup the auth object, which will fail, since shared links are without user/sessionID auth
		Atmail_FormAuth::authenticated();
		$this->dbAdapter = Zend_Registry::get('dbAdapter');
		
		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		$this->view->requestParams = $this->_request->getParams();
		
	}

	public function dlAction()
	{
	
		$fileRow = $this->dbAdapter->fetchAll("select FileName, FilePath, Account from SharedFiles where FileMD5=?", array($this->view->requestParams['f']));

		if(empty($fileRow['0']['Account'])) {
			exit;
		} else {

			// Attach the "shared class" from the users
			$this->fileAdapter = Atmail_Files_Factory::instance($fileRow['0']['Account']);

			$this->view->Filename = $fileRow['0']['FileName'];
			$this->view->Directory = $fileRow['0']['FilePath'];			
		}
		
		if( empty($this->view->requestParams['dl']) ) {
			
		} else {
		
			$this->_helper->viewRenderer->setNoRender();

			$fileName = $this->view->Directory . '/' . $this->view->Filename;

			$this->view->extension = strtolower(substr($filenameOriginal, (strrpos($filenameOriginal,'.')+1) ));

			$fileInfo = $this->fileAdapter->getFileInfo($fileName);

			// Set headers
		    header("Cache-Control: public");
		    header("Content-Description: File Transfer");
		    header("Content-Disposition: attachment; filename=" . urlencode($this->view->Filename));

		    header("Content-Type: " . $fileInfo->contentType);
			//header("Content-Length: " . $fileInfo->size);
		    header("Content-Transfer-Encoding: binary");	

			fpassthru($this->fileAdapter->getFile($fileName));
				
		}

			
	}
	
}
