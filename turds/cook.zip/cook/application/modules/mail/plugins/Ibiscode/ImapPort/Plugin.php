<?php

class Ibiscode_ImapPort_Plugin extends Atmail_Controller_Plugin
{
    private $loginPage = false;
    
    protected $_pluginVersion = "1.0.0";
    protected $_pluginModule = 'mail';
    protected $_pluginName   = 'ImapPort';
    protected $_pluginCompany = 'Ibiscode';
    protected $_pluginAuthor = 'Brad Kowalczyk <brad@staff.atmail.com>';
    protected $_pluginDescription = 'Adds ability to specify port for IMAP connection on login page';
    protected $_pluginCopyright = 'Brad Kowalczyk';
    protected $_pluginCompat = '6.1.2 6.1.3';
    protected $_pluginUrl = '';
    protected $_pluginNotes = '';
    
    
    public function __construct()
    {
    }

    public function dispatchLoopStartup()
    {
        $request = $this->getRequest();
        if (($request->getControllerName() == 'index' && $request->getActionName() == 'index') ||
            ($request->getControllerName() == 'auth' && $request->getActionName() == 'logout')) {
            $this->_loginPage = true;
        }
    }

    public function postDispatch(Zend_Controller_Request_Abstract $request)
    {
        if ($this->_loginPage && !$called) {
            $page = $this->getResponse()->getBody();
            $path = $this->_makeUrl('images/boo.png');
            $portSelection = <<<EOF
<tr id="port">
<td height="40">Port:</td>
<td><input type="text" name="port" class="protocol" value="143"></td>
<td>&nbsp;</td>
<td>&nbsp;</td>
</tr>
EOF;

            $page = str_replace('<!-- LANGUAGE -->', "$portSelection\n\n<!-- LANGUAGE -->", $page);
            $this->getResponse()->setBody($page);
        }
    }
}
