<?php
class IndexController extends Zend_Controller_Action 
{

	//point user to correct ui on first hit (application may only have certain startingpoints installed/available)
	//e.g. could also be used to catch mobile devices and redirect to other module 
	
	public function indexAction() 
	{
    	
		$requestParams = $this->getRequest()->getParams();
		if( isset($requestParams['signup']) )
		{

			$this->_request->setParam('module', 'mail');
			$this->_forward('signup', 'signup', 'mail');
			
		}
		else
		{
			
			//forward to correct starting point depending on what modules installed, i.e. archive
			$this->_request->setParam('module', 'mail');
			$this->_forward('index', 'mail', 'mail');
			
		}
	
	}
	
	public function blankAction()
	{
		$response = $this->getResponse();
		$response->setHeader('Cache-Control', 'public', true);
		$response->setHeader('Cache-Control', 'max-age=3800');
		$response->setHeader('Pragma', '', true);
	}


	public function sessiontimeoutAction() 
	{
	
		$auth = Zend_Auth::getInstance();
		$auth->clearIdentity();
		$this->_session = new Zend_Session_Namespace(ATMAIL_ADMIN_NAMESPACE);
		$this->_session->Username = null;
		$this->_session->Password = null;
		Zend_Session::expireSessionCookie();
		session_destroy();
		
		$requestParams = $this->getRequest()->getParams();
		
		if( isset($requestParams['admin']) || $requestParams['module'] == 'admin' )
		{

			$this->view->admin = true;

		}
		$this->view->version = generateVersionString(getVersionCurrentLocalCodebase());
		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');

	}
	
	/**
	 * timeoutAction sends a mini response that will work as expected for html and json expected responses (additional logic to detect the timeout on response string)
	 */
	public function timeoutAction() 
	{

		$auth = Zend_Auth::getInstance();
		$auth->clearIdentity();
		$this->_session = new Zend_Session_Namespace(ATMAIL_ADMIN_NAMESPACE);
		$this->_session->Username = null;
		$this->_session->Password = null;
		Zend_Session::expireSessionCookie();
		session_destroy();
		
		$requestParams = $this->_request->getParams();
		if( isset($requestParams['admin']) || $requestParams['module'] == 'admin' )
		{
			
			$this->view->admin = true;
			
		}
    	$this->view->version = generateVersionString(getVersionCurrentLocalCodebase());
		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');

	}
	
	public function dberrorAction() 
	{
	
		$request = $this->getRequest();
    	$this->view->version = generateVersionString(getVersionCurrentLocalCodebase());
		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		$this->view->error = $request->error;	

	}
	
	public function ie6Action() 
	{
	    $this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		//nothing to do but render
	}
	
}
