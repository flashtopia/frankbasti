<?php
/**
 * Created by James
 * Date: 14/05/12
 * Time: 2:17 PM
 * To change this template use File | Settings | File Templates.
 */

class Mobile_IndexController extends Atmail_Controller_Base
{

    public function indexAction()
    {

		$appBaseUrl = $this->_request->getBaseUrl() . (strpos($this->_request->getBaseUrl(),'index.php')?'':'/index.php');
		$global = Zend_Registry::get('config')->global;
		$this->view->mobileUIEnabled = (array_key_exists('mobileui', $global) && $global['mobileui'] == '1') ? true : false;
        $this->view->setEncoding('UTF-8');
        $this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
        $this->view->appBaseUrl = $this->_request->getBaseUrl() . (strpos($this->_request->getBaseUrl(),'index.php')?'':'/index.php');
        $this->view->moduleBaseUrl = $this->view->appBaseUrl . ($this->view->requestParams['module']=='default'?'':DIRECTORY_SEPARATOR . $this->view->requestParams['module']);
        $this->view->thisActionURL = $this->view->moduleBaseUrl . '/' . $this->view->requestParams['controller'] . '/' . $this->view->requestParams['action'];
		$this->view->mobileTheme = $global['mobilecssTheme'];
		
		// Use default theme if set theme is invalid
		if (empty($this->view->mobileTheme) || !file_exists(APP_ROOT . "css/themes/" . $this->view->mobileTheme)) {
			$this->view->mobileTheme = "original";
		}
		
		unset($global);
		$this->_helper->pluginCall('preMobileUiRender');
    }

    public function checkauthAction()
    {
        $arr = array( "auth" => Atmail_FormAuth::authenticated()? "success" : "failed" );

        if($arr['auth'] === 'success')
        {
	        $settings = Zend_Registry::get('UserSettings');
	        $arr['settings'] = $settings;
        }

        $json = Zend_Json::encode($arr);
        $this->getResponse()->setHeader('Content-Type','application/x-javascript')->appendBody($json);
        $this->_helper->viewRenderer->setNoRender();
    }

    public function html2textAction()
    {
        require_once('class.html2text.inc');

        $requestParams = $this->getRequest()->getParams();

        // Add the HTML and text parts
        $html2text = new html2text($requestParams['html']);
        $emailBodyText = $html2text->get_text();

        $this->renderJson(array('text' => $emailBodyText));
    }

}
