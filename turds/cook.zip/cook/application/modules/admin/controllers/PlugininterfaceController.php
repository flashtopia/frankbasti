<?php

class Admin_PlugininterfaceController extends Atmail_Controller_Plugininterface 
{

}
