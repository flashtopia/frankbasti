<?php
class Admin_UpdateController extends Zend_Controller_Action
{

	public function init()
	{
        $this->view->addHelperPath('library/Atmail/View/Helper/', 'Atmail_View_Helper');
		$this->log = Zend_Registry::get('log');

		$this->_helper->pluginCall('initAdminController', $this);
		 
		$this->request  = $this->getRequest();

		$this->view->baseUrl = $this->request->getBaseUrl();

		$this->view->appBaseUrl = $this->request->getBaseUrl() . (strpos($this->request->getBaseUrl(),'index.php')?'':'/index.php');

		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		$this->view->moduleBaseUrl = $this->view->appBaseUrl . ($this->request->module == 'default'?'':DIRECTORY_SEPARATOR . $this->request->module);
		$this->config = Zend_Registry::get('config');
		$this->dbAdapter = Zend_Registry::get('dbAdapter');
		$this->dbTables = new dbTables();

		require_once 'application/models/admin.php';
		$this->admin = new admin();

		if ($this->request->action == 'index' )
		{
			return;
		}

		$this->_helper->viewRenderer->setNoRender();

		if( !isset($this->view->errors) )
		{
			$this->view->errors = array();
		}

		if( !isset($this->view->notices) )
		{
			$this->view->notices = array();
		}

		if( !isset($this->view->jsonIdsToRender) )
		{
			$this->view->jsonIdsToRender = array();
		}

		require_once 'library/jQuery/jQuery.php';
		// TODO: Get the Username, Password and server API, pass to admin API
	}

	public function preDispatch()
	{

		// Check the session is active, otherwise redirect to the login page
		$this->view->userData = $this->admin->getCurrentAdminData();

		if( empty($this->view->userData) ) 
		{

			$this->_forward( 'timeout', 'index', 'default' );
			return;

		}

		$this->downloadFilename = 'atmail6.mailserver.tgz';
		$this->downloadMD5Filename = 'atmail6.mailserver.tgz.md5';
		$this->tmpDownloadLocation = '/tmp/';
		$this->updateHostBaseUrl = 'http://atmail.com/download/';


	}

	/**
	* Display version and available update info
	*/
	public function indexAction()
	{
		$expiry = Zend_Registry::get('config')->reg['expiry'];
		if(time() > strtotime($expiry) && !empty($expiry))
			$this->view->licenseExpired = 1;

		//first check if new update code has already been unpacked over old code
		$this->view->versionCurrentDBSchema = generateVersionString($this->_getVersionCurrentDBSchema(), true);
		$this->view->availableVersion = generateVersionString($this->_getAvailableVersion(), true);
		$this->view->reg = $this->config->reg;
		$cliUpdater = new Atmail_Update_Cli($this->dbAdapter);
		$this->view->cliUpdateAvailable = $cliUpdater->isUpdateAvailable();
		// If we're an appliance, the update script should already have been automatically
		// run!

		if($this->view->cliUpdateAvailable && !file_exists("/usr/local/atmail/mailserver/bin/atmail-update-version"))
		{
			if( $this->config->global['install_type'] == 'server')
			{
					$this->view->updatePage = 'update/updateserverinstructions.phtml';
			}
			else
			{
					$this->view->updatePage = 'update/updateclientinstructions.phtml';
			}
		}
	}

	public function updatestatusAction()
	{
		$this->_helper->viewRenderer->setNoRender();
		
		$this->request  = $this->getRequest();
		$this->requestParams = $this->request->getParams();

		$stamp = is_numeric($this->requestParams['stamp']) ? $this->requestParams['stamp'] : '000';
		$filename = rtrim(APP_ROOT . 'log', '/') . '/atmail.update.' . $stamp . '.log';
		
		if(is_file($filename))
		{
			echo str_replace("\n", "<br>", file_get_contents($filename));	
		}
		
	}

	/** 
	* Update the system to the latest version 
	*/ 
	public function doversionupdateAction() 
	{ 
		$error = false;
		
		require_once('library/Atmail/Update.php');
		
		
		if( isset($this->config->global['demo']) &&  $this->config->global['demo'] == 1) 
		{ 
			throw new Exception('Disabled in demo');  
		}
		$updater = new Atmail_Update_Db($this->dbAdapter);
		
		$this->request  = $this->getRequest();
		$this->requestParams = $this->request->getParams();

		$stamp = is_numeric($this->requestParams['stamp']) ? $this->requestParams['stamp'] : '000';

		// set the log file for this update attempt (trunc)
		$updater->setLogFile(rtrim(APP_ROOT . 'log', '/') . '/atmail.update.' . $stamp . '.log');

		$expiry = Zend_Registry::get('config')->reg['expiry'];
		if(time() > strtotime($expiry) && !empty($expiry))
		{
			throw new Exception('Unable to complete version update as your current license has expired.'); 
		}
		
		// If we're an appliance, run the CLI script to fetch and extract the tgz
        if (file_exists("/usr/local/atmail/mailserver/bin/atmail-update-version"))
        {
			if ($this->config->global['install_type'] == 'server')
			{
				`/usr/local/atmail/mailserver/bin/atmail-update-version fetch server`;
			}
			else
			{
				`/usr/local/atmail/mailserver/bin/atmail-update-version fetch client`;
			}

            if (file_exists("/usr/local/atmail/webmail/log/.installFailed"))
            {
                throw new Exception('New version failed MD5 checksum verification, downloaded package possibly corrupted. Please try again');
            }
		}

		//first check if new update code has already been unpacked over old code
		$this->view->versionCurrentDBSchema = generateVersionString($this->_getVersionCurrentDBSchema(), true);
		$this->view->versionCurrentLocalCodebase = generateVersionString(getVersionCurrentLocalCodebase(), true);
		$this->view->versionOrig = $this->view->versionCurrentDBSchema;

		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentDBSchema \n" . print_r($this->view->versionCurrentDBSchema, true) );
		$this->log->debug( __METHOD__ . ' #' . __LINE__ . ": \$this->view->versionCurrentLocalCodebase \n" . print_r($this->view->versionCurrentLocalCodebase, true) );

		//local code is unpacked as latest version so ready to proceed with db schema update prior to serving server-update script (if server install)

		/* db schema changes start here */
		//CONSIDER only upgrading one chunk at a time, and ending hit so ui get updated with each chunk complete.
		// this will allow easier diagnosis of chunk update failers and will stop gracefully at a specific version
		// NB do schema changes inside a transaction to allow gracefull failure without half updated schema for a specific version chunk

		// ***** USE THE NEW UPDATER HERE ******
		try
		{
			$this->view->cliRequired = $updater->updateAll();
		}
		catch(Exception $e)
		{
			// some sort of error.
			$error = true;
			$updater->log( $this->view->translate('Database update ran into issues while trying to update to') . " " . generateVersionString($this->view->versionCurrentLocalCodebase, true) . "<br>" . "Error details : " . $e->getMessage() . "<br>" . $this->view->translate("Please see") . " "  . $updater->getLogFile() . " " . $this->view->translate("for more further details."));
			jQuery::addError( $this->view->translate('Database update ran into issues while trying to update to') . " " . generateVersionString($this->view->versionCurrentLocalCodebase, true) . "<br>" . "Error details : " . $e->getMessage() . "<br>" . $this->view->translate("Please see") . " "  . $updater->getLogFile() . " " . $this->view->translate("for more further details."));
		}
		$versions[] = $this->view->versionCurrentLocalCodebase;
		
		$this->view->versionCurrentDBSchema = generateVersionString($this->dbAdapter->fetchOne("select keyValue from Config where keyName = 'version'"), true);

		/* end db schema changes */
		if( !$error && version_compare($this->view->versionCurrentDBSchema, $this->view->versionCurrentLocalCodebase, '==' ) )
		{
			
			jQuery::addMessage( $this->view->translate('Database schema update complete.') );
			jQuery('#versionCurrentDBSchema')->html(generateVersionString($this->view->versionCurrentDBSchema, true));
			jQuery('#versionUpdateButtonArea')->html('<p>' . $this->view->translate('You are up to date with the latest version available.') . '</p>');
			
			//give additional instructions if server install
			
			if( $this->config->global['install_type'] == 'server' && $this->view->cliRequired == 1 )
			{
                // If we're an appliance, just auto run the CLI script
                if (file_exists("/usr/local/atmail/mailserver/bin/atmail-update-version")) {
                	`/usr/local/atmail/mailserver/bin/atmail-update-version {$this->view->versionOrig} server`;

					// Check return code
					jQuery::addMessage( $this->view->translate('New version downloaded, database schema updated and new version installed') );
					
               	} else {
					$this->view->jsonIdsToRender['updateProcessInstructions'] = 'update/updateserverinstructions.phtml';
				}
			}
			elseif( $this->view->cliRequired )
			{
				
				// If we're an appliance, just auto run the CLI script
                if (file_exists("/usr/local/atmail/mailserver/bin/atmail-update-version")) {
                	`/usr/local/atmail/mailserver/bin/atmail-update-version {$this->view->versionOrig} client`;
				} else {
					$this->view->jsonIdsToRender['updateProcessInstructions'] = 'update/updateclientinstructions.phtml';
				}
			}

		}
		else if(!$error)
		{
			$error = true;
			jQuery::addError( $this->view->translate('Database update did not complete.') . ' Current version: ' . generateVersionString($this->view->versionCurrentDBSchema, true) . ' Available version: ' . generateVersionString($this->view->versionCurrentLocalCodebase, true) . "<br>" . $this->view->translate("Please see") . " "  . $updater->getLogFile() . " " . $this->view->translate("for more details."));
		}

		// Close the dialog-box on the update window
		if($error)
		{
			// make dialog RED
			jQuery('.ui-dialog, .ui-dialog-titlebar, .ui-dialog-title, .ui-dialog-titlebar-close')->addClass('errorUpdate');
			/*
			jQuery('.ui-dialog')->css('border', '4px solid #FF0000');
			jQuery('.ui-dialog-titlebar')->css('color', '#FF0000');
			jQuery('.ui-dialog-titlebar')->css('background', '#FFBABA');
			jQuery('.ui-dialog-titlebar')->css('border-color', '-moz-use-text-color -moz-use-text-color #FF0000');
			*/
			jQuery('.ui-dialog-title')->text("Update Atmail - Failed");
			
		}
		jQuery('#dialog #details')->html(str_replace("\n", "<br>", file_get_contents($updater->getLogFile())) . '<br>' . $this->view->translate("You may dismiss this dialog box now."));
		jQuery('#dialog #details')->scrollTo(10000);
		jQuery::evalScript("clearInterval($('#dialog').data('intervalHandle'))");
		$this->render('global/jsonresponse', null, true);

	}

	/**
	* Get current version number
	*
	* @return String|False
	*/
	private function _getVersionCurrentDBSchema()
	{

		return $this->config->global['version'];

	}


	/**
	 * Get current available Atmail version
	 *
	 * @return String
	 */
	 
	private function _getAvailableVersion()
	{
		// If an appliance we want to get latest version available via SVN
		if (file_exists("/usr/local/atmail/mailserver/bin/atmail-update-version")) {
			return $this->_getLatestReleasedVersion();
		} else {
			return getVersionCurrentLocalCodebase();
		}
	}


	/**
	 * Get latest released version (for appliances only)
	 *
	 * @return String
	 */
	private function _getLatestReleasedVersion()
	{
		$resp = `curl -s http://atmail.com/store/index.php/registration/latestversion`;
		list($latestVersion,) = explode("|", $resp);
		return $latestVersion;
	}

}
