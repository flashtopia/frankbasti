<?php
class Admin_DashboardController extends Atmail_Controller_Action 
{
	
	public function init()
	{
	    $this->view->addHelperPath('library/Atmail/View/Helper/', 'Atmail_View_Helper');
		$this->_helper->pluginCall('initAdminController', $this);
		$this->request = $this->getRequest();
		
		$this->view->baseUrl = $this->request->getBaseUrl();
		$this->view->appBaseUrl = $this->request->getBaseUrl() . (strpos($this->request->getBaseUrl(),'index.php')?'':'/index.php');
		$this->view->moduleBaseUrl = $this->view->appBaseUrl . ($this->request->module == 'default'?'':DIRECTORY_SEPARATOR . $this->request->module);
		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		$this->view->global = Zend_Registry::get('config')->global;
		
		require_once 'library/jQuery/jQuery.php';
		require_once 'application/models/admin.php';
		$this->admin = new admin();
		
	}
	
	public function preDispatch() 
	{
		
		// Check the session is active, otherwise redirect to the login page
		$this->view->userData = $this->admin->getCurrentAdminData();
		
		if( $this->view->userData == null || empty($this->view->userData) ) 
		{

			$this->_forward( 'timeout', 'index', 'default' );
			return;			

		}
		
		Atmail_Locale::setupLocaleAndTranslation( $this->view->userData['Language'] );

		// Setup filters
		$this->filter = Atmail_Filter_Input_Controller::filterInput($this->_request);
		// grab another copy of the parsams
		$this->requestParams = $this->getRequest()->getParams();

		
	}
	
	public function indexAction() 
	{

	}

	public function loginAction() 
	{
		
		$this->view->dlid = Zend_Registry::get('config')->reg['downloadId'];	
		$this->view->userData = $this->admin->getCurrentAdminData();
		
		// Select day, month, year
		if(empty($this->request->view))
		{
			
			$this->view->view = "day";
			
		}
		else
		{
			
			$this->view->view = $this->request->view;
			
		}
		
	}
	
	public function recvAction() 
	{
		
		// Select day, month, year
		if(empty($this->request->view))
		{
			
			$this->view->view = "day";
			
		}
		else
		{
			
			$this->view->view = $this->request->view;
			
		}
		
	}

	public function sentAction() 
	{
		
		// Select day, month, year
		if(empty($this->request->view))
		{
			
			$this->view->view = "day";
			
		}
		else
		{
			
			$this->view->view = $this->request->view;
			
		}
		
	}

	public function spamAction() 
	{
		
		// Select day, month, year
		if(empty($this->request->view))
		{
			
			$this->view->view = "day";
			
		}
		else
		{
			
			$this->view->view = $this->request->view;
			
		}

	}

	public function virusAction() 
	{
	
		
		// Select day, month, year
		if( empty($this->request->view) )
		{
			
			$this->view->view = "day";
			
		}
		else
		{
			
			$this->view->view = $this->request->view;
			
		}

	}
	
	public function subadminAction()
	{
		
		// Check the user account quota is not exceeded
		$this->view->activeUsers = count( $this->admin->getDomainAndGroupUsers() );
		$this->view->availUsers = $this->view->userData['NumUsers'] - $this->view->activeUsers;
		if( $this->view->availUsers < 0 )
		{
			
			$this->view->availUsers = 0;
			
		}
		$this->view->availUserPercentage = round( ($this->view->availUsers / $this->view->userData['NumUsers']) * 100, 1 );
		$this->view->usedUserPercentage = round( 100 - $this->view->availUserPercentage, 1 );
        if( $this->view->usedUserPercentage > 100 )
		{
			
			$this->view->usedUserPercentage = '100';
			
		}
		
		//$this->view->userData['NumQuota'] ambiguous = disk space allowed for this subadmin (MB)
		$this->view->currentQuota = $this->admin->getCurrentQuota(); //allocated to users (MB)
		$this->view->availQuota = round($this->view->userData['NumQuota'] - $this->view->currentQuota, 1);
		if( $this->view->availQuota < 0 )
		{
			
			$this->view->availQuota = 0;
			
		}	
		if( $this->view->userData['NumQuota'] > 0 ) 
		{
		
			$this->view->availDiskPercentage = round( ($this->view->availQuota / $this->view->userData['NumQuota']) * 100, 1);
			$this->view->usedDiskPercentage = round(100 - $this->view->availDiskPercentage, 1);
			
			if( $this->view->usedDiskPercentage > 100 )
			{
				
				$this->view->usedDiskPercentage = '100';
				
			}
		
		}

		$this->render('subadmin');
		
	}
	
	public function versionAction() 
	{
	    require_once("Atmail/General.php");
	    
	    try {
	        $res = fetchLatestVersion();
	    } catch (Exception $e) {
	        if( $e->getMessage() == 'cache_dir is not writable' ) {
				Zend_Registry::get('log')->debug($e->getMessage() . ' : ' . $backendOptions['cache_dir'] . ' Cache disabled.');
				jQuery::addError('Unable to activate cache. Make sure tmp folder is owned by the web server user and has sufficient permissions: ' . APP_ROOT . 'tmp/' );
		    } else {
		        throw $e;
		    }
		}
        
		// Check the response
		if ($res) 
		{
			$res = trim($res);
			$versions = explode("\n", $res);
			
			$latestVersion = '0.0';
			$priority = 0;
			$majorUpdate = false;
			if(count($versions) == 1)
			{
				$test = explode("|", $versions[0]);
				if(count($test) == 3)
				{
					$majorUpdate = true;
					$message = "<br>";	
				}
			}
			if(!$majorUpdate)
			{
				sort($versions, SORT_NUMERIC);
				$patches_available = false;

				foreach($versions as $version)
				{
					$versionArray = explode('|', $version);
					$versionTestNumber = $versionArray[0];
					$versionTestMessage = $versionArray[1];
					$versionTestExpiryDate = $versionArray[2];
					$versionPriority = 1;	// always crit unless specified
					if( isset($versionArray[3]))
					{
						$patches_available = true;
						$versionPriority = $versionArray[3];
					}
					if($patches_available)
					{
						if($versionPriority == 1)
						{
							$type = "Critical";	
						}
						else
						{
							$type = "Minor";	
						}
						$message .= $versionTestNumber . " : " . $type . " - " . $versionTestMessage . "<br>";
					}
					else
					{
						$message = $versionTestMessage;	
					}
					
					if(version_compare($latestVersion, $versionTestNumber)==-1)
					{
						$latestVersion = $versionTestNumber;
						$expiryDate = $versionTestExpiryDate;
					}				
		
					if($versionPriority > $priority)
					{
						$priority = $versionPriority;
					}
				}
			}
			else
			{
				list($latestVersion, $message, $expiryDate) = explode("|", $versions[0]);
			}
			
			// Update the expiry date
			if( empty($expiry) || strtotime($expiryDate) != strtotime($expiry) )
			{
				$arr = array('expiry' => $expiryDate);
				require_once 'application/models/config.php';
				config::save('reg', $arr);
			}
			
			$showDownload = false;
			$showDiv = 0;
			// Load version string from webmail root
			$myVersion = trim(file_get_contents('.VERSION'));
			$storeUrl = "http://atmail.com/store/index.php?Type=" . (Zend_Registry::get('config')->global['install_type']=='server'?'Server':'Webmail');
			if (version_compare($latestVersion, $myVersion) == 1) 
			{
				if(!$patches_available)
				{	
					$message = 'Your Atmail version is out of date. Atmail ' . $latestVersion . ' is now available. ' . $message;
				}
				else
				{
					$showDownload=true;
					// patches available
					if($priority == 1)
					{
						//critical
						$message = 'Your Atmail version is out of date. A critical patch ' . $latestVersion . ' is now available. It is HIGHLY recommend that you apply this version.<br><br>' . $message . "<br>";
					}
					else
					{
						$message = 'Your Atmail version is out of date. A minor patch ' . $latestVersion . ' is now available. It is optional that you apply this version.<br><br>' . $message . "<br>";
					}	
				}
				$showDiv = 1;
			} 
			elseif( time() > strtotime($expiryDate) ) 
			{
				
			    $message = $this->admin->getLicenseStatusExpired();
			
				$showDiv = 1;
			}
			elseif( Zend_Registry::get('YHIIhijjKUIG65765gihiHHikUtFGUhjFd') == true )
			{
			    $message = "Trial period has expired. Purchase a license via the <a href=\"" . $storeUrl . "\" target=\"_blank\">Atmail store</a>.";
				$showDiv = 1;
			}
			elseif( Zend_Registry::get('YHIIhijjHUIG65765gihiHHikUtFGUhjFd') == 5 )
			{
			    $message = "Free 5 User License registered. Purchase a commercial license for more seats and support anytime via the <a href=\"" . $storeUrl . "\" target=\"_blank\">Atmail store</a>.";
				$showDiv = 1;
			}
			

			if( version_compare($latestVersion, Zend_Registry::get('config')->global['version']) == -1 )
			{
				$showDiv = 0;	
			}
			
			if( !empty($showDiv) )
			{
				if($priority == 1)
				{
					// critical Update
					jQuery::evalscript("$('.versionDiv').addClass('critical');");	
				} 
				if($showDownload)
				{
					$message .= '<strong><a target="_blank" href="http://atmail.com/portal/?DownloadID=' . $dlid . '">Download Now</a></strong><br><br>';
				}
				if($patches_available)
				{
					jQuery::evalscript("$('.versionDiv').addClass('licence-expanded');$('.versionDiv SPAN:first').addClass('licence-expanded');");	
				}
			    jQuery::evalscript("$('.versionDiv SPAN:first').html('$message')");
				jQuery::evalscript("$('.versionDiv').show()");

			}

		}
		$this->render('global/jsonresponse', null, true);                                                                                                 

	}

	// Verbose log view
	public function logAction()
	{
		
		$this->view->filter = $this->requestParams['filter'];		
		$this->view->log = $this->requestParams['log'];
		$this->view->type = $this->requestParams['type'];
		$this->view->view = $this->requestParams['view'];
		$this->view->index = $this->requestParams['index'];
		
		// Defaults
		if( empty($this->view->log) )
			$this->view->log = 'Log_Login';

		if( empty($this->view->view) )
			$this->view->view = 'week';
		
			
	}
	
	public function logsearchAction()
	{
		
		// Feature for master admin or subadmin ( if enabled ) only
		if( $this->view->userData['UMasterAdmin'] != '1' )
		{
			
		//	if( $this->view->userData['ULogs'] != '1')
		//		throw new Exception('MasterAdmin rights required.');
			
		}
				
		$this->view->filter = $this->requestParams['filter'];		
		$this->view->log = $this->requestParams['log'];
		$this->view->type = $this->requestParams['type'];
		$this->view->view = $this->requestParams['view'];
		$this->view->index = $this->requestParams['index'];
		
		$this->view->logs = $this->admin->logsearch( array('filter' => $this->requestParams['filter'], 'log' => $this->view->log, 'type' => $this->view->type, 'view' => $this->view->view, 'Range' => $this->requestParams['LogRange'], 'index' => $this->requestParams['index'] )); 
		
		// Next, build the select box
		$count = $this->view->logs[0];
		
		$pages = $count / 100;
		$arr = array();
		for($i = 0; $i < $pages; $i++)	{
			$index = $i * 100;
			$page = $i + 1;
			$arr[] = "<option value='$index'>Page $page</option>";
		}
		
		$this->view->pagination = implode("\n", $arr);	
		
	}
	
	public function logexportAction()
	{
		$this->_helper->viewRenderer->setNoRender();
		
		$csv = $this->admin->logsearch( array('all' => 1, 'log' => $this->requestParams['log'], 'type' => $this->requestParams['type'], 'view' => $this->requestParams['view'] )); 

		// Output the VCF file
		$this->getResponse()->setHeader('Content-Type','text/csv')
			->setHeader('Content-Disposition', "attachment; filename=atmail-" . $this->requestParams['log'] . "-" . $this->requestParams['view'] . ".csv");		
		
		// Export the header ( Account, id, etc )
		echo( $this->array_to_csv_header($csv[1][0]) );
		
		// Export each line
		foreach($csv[1] as $line)	{
			echo( $this->array_to_csv($line) );
		}
		
	}
	
	private function array_to_csv($data, $delim = ",", $newline = "\n", $enclosure = '"') {
	        if(!is_array($data))
	                return;

	        $footer = array_values($data);

	        $output = $enclosure . implode($footer, ($enclosure . $delim . $enclosure)) . $enclosure . $newline;

	        return $output;
	}

	private function array_to_csv_header($data, $delim = ",", $newline = "\n", $enclosure = '"') {
	        if(!is_array($data))
	                return;

	        $header = array_keys($data);

	        $output = $enclosure . implode($header, ($enclosure . $delim . $enclosure)) . $enclosure . $newline;

	        return $output;
	}	

}
