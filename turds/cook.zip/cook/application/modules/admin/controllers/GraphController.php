<?php
class Admin_GraphController extends Zend_Controller_Action 
{
	
	public function init()
	{
	    
		$this->view->addHelperPath('library/Atmail/View/Helper/', 'Atmail_View_Helper');
	    $this->_helper->pluginCall('initAdminController', $this);
		//TODO: extend authentication to support multiple user levels/roles/groups 
		$this->view->baseUrl = $this->_request->getBaseUrl();
		$this->view->appBaseUrl = $this->_request->getBaseUrl() . (strpos($this->_request->getBaseUrl(),'index.php')?'':'/index.php');
		$this->view->siteBaseUrl = Zend_Registry::get('siteBaseUrl');
		$this->view->moduleBaseUrl = $this->view->appBaseUrl . ($this->_request->module == 'default'?'':DIRECTORY_SEPARATOR . $this->_request->module);
		$this->view->global = Zend_Registry::get('config')->global;
		
		require_once 'application/models/admin.php';
		require_once 'application/models/graph.php';
		$this->admin = new admin();
		$this->graph = new graph();
		$this->dbAdapter = Zend_Registry::get('dbAdapter');
		
		$this->_helper->viewRenderer->setNoRender();
		if( !isset($this->view->errors) )
		{
			    
			$this->view->errors = array();
			
		}
		if( !isset($this->view->notices) )    
		{
			
			$this->view->notices = array();
			
		}
	 	if( !isset($this->view->jsonIdsToRender) )    
		{
			
			$this->view->jsonIdsToRender = array();
			
		}
		require_once 'library/jQuery/jQuery.php';
			
	}
	
	public function preDispatch() 
	{
		
		// Check the session is active, otherwise redirect to the login page
		$this->view->userData = $this->admin->getCurrentAdminData();
		
		if( empty($this->view->userData) ) 
		{

			$this->_forward( 'timeout', 'index', 'default' );
			return;			

		}
		
		Atmail_Locale::setupLocaleAndTranslation( $this->view->userData['Language'] );
		
	}
	
	// Load the contact creation page, using the existing editcontact for code re-use
	public function jsonAction() 
	{
		
		$fieldFilters = array(

			'account'		=> array('StripTags'),
			'view'			=> array('StripTags'),
			'log'			=> array('StripTags'),
			'type'   		=> array('StripTags', 'Int'),

		);
		$fieldValidators = array (
			
			'type'			=> array('Int'),
			'log'			=> array(),
			'view'			=> array(), 
			'account'			=> array()
			
		);
		$filter = new Atmail_Filter_Input($fieldFilters, $fieldValidators, $this->_request);	
		$request = $filter;
		$logAllowedValues = array('Log_Login', 'Log_SendMail', 'Log_RecvMail', 'Log_Spam', 'Log_Virus');
		
		if( !in_array($request->log, $logAllowedValues) )
			throw new Exception('Illegal log value');
		$viewAllowedValues = array('day','week', 'month','year');
		if( !in_array($request->view, $viewAllowedValues) )
			throw new Exception('Illegal view value');
		
		
		$this->view->adminDomains = $this->dbAdapter->fetchCol("select Domain from AdminGroup where Username = " . $this->dbAdapter->quote( Zend_Auth::getInstance()->getIdentity() ) );
		$adminInfo = $this->admin->getCurrentAdminData();
		
		if( 
			$adminInfo['UMasterAdmin'] != '1' && 
			(
				count($this->view->adminDomains) == 0 || 
				(
					count($this->view->adminDomains) == 1 &&
					$this->view->adminDomains[0] == ''
				)
			)
		)
		{
			
			$points = array();
			
		}                     
		else
		{
			
			$points = $this->graph->getLog($request->view, $request->log, $request->account, $request->type, $this->view->adminDomains);
			
		}
		$data = Zend_Json::encode( $points );

$template = <<<_EOF
{
    data: $data,
	color: '#0073ca',
	lines: { show: true, fill: true, fillColor: "rgba(229, 242, 250, 0.8)", lineWidth: 3 }
}
_EOF;

		$this->getResponse()->setHeader('Content-Type','application/json');
		$this->getResponse()->appendBody($template);		
		
	}
	
}
