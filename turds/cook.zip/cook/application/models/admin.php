<?php
/**
 * @category 	Atmail
 * @package 	Models
 * @subpackage	Admin
 * @copyright 	Copyright (c) 2009-2011 ATMAIL. All rights reserved
 * @license 	See http://atmail.com/license.php for license agreement
 * @author		Ben Duncan ben@staff.atmail.com
 * @author		Atmail (http://atmail.com)
 */

class admin
{

	private $_session;
	private $_account;
	private $_tableNames;
	private $_namespaceName = 'admin';

	public function __construct()
	{

		$this->dbAdapter = Zend_Registry::get('dbAdapter');

		$this->log = Zend_Registry::get('log');

		//CONSIDER not being dependant on admin Controller config (can change) - should rather accept config args for own session namespace
		//this REST client shares session namespace with the admin controllers
		$this->_session = new Zend_Session_Namespace(ATMAIL_ADMIN_NAMESPACE);

		$this->_session->server = "";

		// If local server being admind then access the api class direct and dont go through the REST service
		if( empty($this->_session->server) )
		{

			require_once('api.php');
			$this->api = new api(array('Username' => $this->_session->Username, 'Password' => $this->_session->Password));

		}
		else
		{

			Zend_Rest_Client::getHttpClient()->setAuth($this->_session->Username, $this->_session->Password);
			$this->client = new Zend_Rest_Client( $this->_session->serverURI );
		}

	}

/**
 * Domain Methods
*/
	public function domainCheck( $name )
	{

		if( empty($this->_session->server) )
		{

			$result = $this->api->domainCheck($name);
		    return array('response' => (string)$result['response']['message'], 'status' => (string)$result['status']);

		}
		else
		{

			$result = $this->client->get($this->_session->serverBasePath . "/api/domain/check/name/" . $name);
			return array('response' => (string)$result->response->message, 'status' => (string)$result->status);

		}

	}

	public function domainCreate( $name )
	{

		if( empty($this->_session->server) )
		{

			$result = $this->api->domainCreate($name);
			return array('response' => (string)$result['response']['message'], 'status' => (string)$result['status']);

		}
		else
		{

			$result = $this->client->get( $this->_session->serverBasePath . "/api/domain/create/name/" . $name );
		    return array('response' => (string)$result->response->message, 'status' => (string)$result->status);

		}

	}

	public function domainDelete( $name )
	{

		if( empty($this->_session->server) )
		{

			$result = $this->api->domainDelete($name);
            return array('response' => $result['response']['message'], 'status' => $result['status']);

		}
		else
		{
			$method = $this->_session->serverBasePath . "/api/domain/delete/name/" . $name;
			$result = $this->client->get($method);
            return array('response' => (string)$result->response->message, 'status' => (string)$result->status);

		}

	}

	public function domainList($optionalArgs = null)
	{

		if( empty($this->_session->server) )
		{

			$hostnames = $this->api->domainList($optionalArgs);
			if( isset($hostnames['status']) && $hostnames['status'] == 'failed' )
			{

				throw new Exception('Failed fetching domain list: ' . (string)$hostnames['response']['message'] );

			}

		}
		else
		{

			$result = $this->client->get( $this->_session->serverBasePath . '/api/domain/list' );

			if( !$result->isSuccess() )
			{

				throw new Exception('Failed fetching domain list: ' . (string)$result->response->message);

			}

			$hostnames = array();
			$i = 0;
			foreach ($result->domainList->children() as $child)
			{

				$added = 0;
				foreach ($child->children() as $field)
				{

					$name = $field->getName();
					if( (string)$field != '' )
					{

						// Use (string) else an object is returned if row is null
						$hostnames[$i][$name] = (string)$field;
						$added = 1;

					}

				}
				if($added == 1)
				{

					$i++;

				}
			}
		}

		return $hostnames;

	}

	public function groupCreate( $args = array() )
	{

		if( empty($this->_session->server) )
		{

			$result = $this->api->groupCreate($args);
			return array('response' => (string)$result['response']['message'], 'status' => (string)$result['status']);

		}
		else
		{

			$method = $this->_session->serverBasePath . "/api/groups/create";
			//NB: $this->client->args = $args; //doesnt work
			$result = $this->client->post($method, $args);
		    return array('response' => (string)$result->response->message, 'status' => (string)$result->status, );

		}

	}

	public function groupGet( $groupName )
	{

		if( empty($this->_session->server) )
			return $this->api->groupGet( $groupName );
        else
		{

			$method = $this->_session->serverBasePath . "/api/groups/get";
			//NB: $this->client->args = $args; //doesnt work
			$result = $this->client->post( $method, array('groupName' => $groupName) );
			$status = (string)$result->status;
			if( $status == 'success' )
				return array('response' => array('results' => (string)$result->response->results), 'status' => (string)$result->status );
            else
				return array('response' => array('message' => (string)$result->response->message), 'status' => (string)$result->status );
            
		}

	}

	public function groupsList( $type = 'all' )
	{

		if( empty($this->_session->server) )
		{

			$result = $this->api->groupsList( $type );

			if( $result['status'] == 'failed' )
			{

				throw new Exception('Failed fetching groups list: ' . (string)$result['response']['message'] );

			}
			$result = $result['response']['results'];

		}
		else
		{

			$response = $this->client->get( $this->_session->serverBasePath . '/api/group/list/type/' . $type );

			if( !$response->isSuccess() )
			{

				throw new Exception('Failed fetching groups list: ' . (string)$response->response->message);

			}

			$result = array();
			$i = 0;
			foreach ($response->response->results->children() as $child)
			{

				foreach ($child->children() as $field)
				{

					// Use (string) else an object is returned if row is null
					$result[$i][$field->getName()] = (string)$field;

				}
				$i++;

			}
		}

		return $result;

	}
	
	public function groupTotal( $groupName )
	{
		
		if( empty($this->_session->server) )
		{

			$result = $this->api->groupTotal( $groupName );

			if( $result['status'] == 'failed' )
			{

				throw new Exception('Failed fetching group total: ' . (string)$result['response']['message'] );

			}
			$result = $result['response']['total'];

		}
		else
		{

			$response = $this->client->get( $this->_session->serverBasePath . '/api/group/total/groupName/' . $groupName );

			if( !$response->isSuccess() )
			{

				throw new Exception('Failed fetching group total: ' . (string)$response->response->message);

			}

			$result = $response->response->total;
		}

		return $result;
		
	}

	public function groupsListTotals( $type = 'user')
	{

		if( empty($this->_session->server) )
		{

			$result = $this->api->groupsListTotals( $type );

			if( $result['status'] == 'failed' )
			{

				throw new Exception('Failed fetching groups list: ' . (string)$result['response']['message'] );

			}
			$result = $result['response']['results'];

		}
		else
		{

			$response = $this->client->get( $this->_session->serverBasePath . '/api/group/listtotals/type/' . $type );

			if( !$response->isSuccess() )
			{

				throw new Exception('Failed fetching groups list: ' . (string)$response->response->message);

			}

			$result = array();
			$i = 0;
			foreach ($response->response->results->children() as $child)
			{

				foreach ($child->children() as $field)
				{

					// Use (string) else an object is returned if row is null
					$result[$i][$field->getName()] = (string)$field;

				}
				$i++;

			}
		}

		return $result;

	}

	public function groupUpdate( $groupName, $data )
	{

		if( empty($this->_session->server) )
			return $this->api->groupUpdate( $groupName, $data);
		else
		{

			$method = $this->_session->serverBasePath . "/api/groups/update";
			$result = $this->client->post( $method, array('groupName' => $groupName, 'data' => $data) );
			object2array($response);
			return $response;

		}

	}
	
	public function groupUserAdd( $groupName, $Account )
	{
		
		if( empty($this->_session->server) )
		{

			$result = $this->api->groupUserAdd( $groupName, $Account );
			return array('response' => (string)$result['response']['message'], 'status' => (string)$result['status']);

		}
		else
		{

			$method = $this->_session->serverBasePath . "/api/groups/useradd";
			//NB: $this->client->args = $args; //doesnt work
			$result = $this->client->post($method, array('groupName' => $groupName, 'name' => $Account) );
		    return array('response' => (string)$result->response->message, 'status' => (string)$result->status, );

		}
		
	}
	
	public function groupUsersAdd( $groupName, $Accounts )
	{
		
		if( empty($this->_session->server) )
			return $this->api->groupUsersAdd( $groupName, $Accounts );
		else
		{

			$method = $this->_session->serverBasePath . "/api/groups/usersadd";
			//NB: $this->client->args = $args; //doesnt work
			$result = $this->client->post($method, array('groupName' => $groupName, 'Accounts' => $Accounts) );
		    object2array($result);
			return $result;

		}
		
	}
	
	public function groupUserDelete( $groupName, $name )
	{
		
		if( empty($this->_session->server) )
		{

			$result = $this->api->groupUserDelete( $groupName, $name );
			return array('response' => (string)$result['response']['message'], 'status' => (string)$result['status']);

		}
		else
		{

			$method = $this->_session->serverBasePath . "/api/groups/userdelete";
			//NB: $this->client->args = $args; //doesnt work
			$result = $this->client->post($method, array('groupName' => $groupName, 'Account' => $name) );
		    return array('response' => (string)$result->response->message, 'status' => (string)$result->status, );

		}
		
		
	}

	public function groupUsersDelete( $groupName, $Accounts )
	{
		
		if( empty($this->_session->server) )
		{

			$result = $this->api->groupUsersDelete( $groupName, $Accounts );
			return $result;

		}
		else
		{

			$method = $this->_session->serverBasePath . "/api/groups/usersdelete";
			//NB: $this->client->args = $args; //doesnt work
			$result = $this->client->post($method, array('groupName' => $groupName, 'Accounts' => $Accounts) );
			return object2array($result);

		}
		
		
	}

	public function groupDelete( $groupName )
	{

		if( empty($this->_session->server) )
		{

			$result = $this->api->groupDelete( $groupName );
			return array('response' => (string)$result['response']['message'], 'status' => (string)$result['status']);

		}
		else
		{

			$method = $this->_session->serverBasePath . "/api/groups/delete";
			//NB: $this->client->args = $args; //doesnt work
			$result = $this->client->post($method, array('groupName' => $groupName) );
		    return array('response' => (string)$result->response->message, 'status' => (string)$result->status, );

		}

	}



/**
 * User Admin API calls
*/
	public function userCreate( $args = array() )
	{

		if( empty($this->_session->server) )
		{

			$result = $this->api->userCreate($args);
			return array('response' => (string)$result['response']['message'], 'status' => (string)$result['status']);

		}
		else
		{

			$method = $this->_session->serverBasePath . "/api/users/create";
			//NB: $this->client->args = $args; //doesnt work
			$result = $this->client->post($method, $args);
		    return array('response' => (string)$result->response->message, 'status' => (string)$result->status, );

		}

	}

	public function userList( $domain=false, $limit=null, $searchQuery=null, $group = false, $args = false)
	{

		if( empty($this->_session->server) )
		{

			$users = $this->api->userList($domain, $limit[0], $limit[1], $searchQuery, $group, $args);
			if(isset($users['status']) && $users['status'] == 'failed')
			{

				throw new Exception('Failed fetching users list: ' . (string)$users['response']['message'] );

			}

		}
		else
		{

			$method = $this->_session->serverBasePath . "/api/users/list";
			if( $domain != false )
				$method .= "/domain/" . $domain;

			if ( is_array($limit) )
			    $method .= "/start/" . $limit[0] . "/volume/" . $limit[1];

			if ( !empty($searchQuery) )
				$method .= "/searchQuery/" . urlencode($searchQuery) . "/";

			if ( $group !== false )
				$method .= "/group/" . urlencode($group) . "/";

			$result = $this->client->get($method);

			if( !$result->isSuccess() )
				throw new Exception('Failed fetching users list: ' . (string)$result->response->message);

			$i=0;
			foreach ($result->userList->children() as $child)
			{

				foreach ($child->children() as $field)
				{
					$name = $field->getName();
					// Use (string) else an object is returned if row is null
					$users[$i][$name] = (string)$field;
				}
			    $i++;

			}

		}

		return $users;
	}

	public function userView($name = '', $id = '')
	{

		if( empty($this->_session->server) )
		{
			$user = $this->api->userView($name, $id);

			if($user['status'] == 'failed')
				throw new Exception('Failed fetching user: ' . (string)$user['response']);

		}
		else
		{
			if( !empty($id) )
				$method = $this->_session->serverBasePath . "/api/users/view/id/" . $id;
			else
				$method = $this->_session->serverBasePath . "/api/users/view/name/" . $name;

			$result = $this->client->get($method);

			if( !$result->isSuccess() )
				throw new Exception('Failed fetching user: ' . (string)$result->response->message);

			$user = array();
			foreach ($result->userView->children() as $field)
			{

				$name = $field->getName();
		    	$user[$name] = (string)$field;

			}
		}

		return $user;
	}

	public function userUpdate( $args = array() )
	{

		if( array_key_exists('Account', $args) )
		{
			
			$args['name'] = $args['Account'];
			
		}
		elseif( array_key_exists('id', $args) )
		{
			
			$args['userId'] = $args['id'];
			
		}
		else
		{
			
			throw new Exception('Account or id argument missing');
			
		}

		if( empty($this->_session->server) )
		{

			$result = $this->api->userUpdate($args);
			if($result['status'] == 'failed')
				throw new Exception('Failed updating user: ' . (string)$result['response']['message'] );
			return array('response' => $result['response']['message'], 'status' => $result['status']);

		}
		else
		{

			$method = $this->_session->serverBasePath . '/api/users/update';
		    $result = $this->client->post( $method, $args);
			return array('response' => (string)$result->response->message, 'status' => (string)$result->status);

		}

	}

	public function userDelete($name)
	{
		if( empty($this->_session->server) )
		{
			$result = $this->api->userDelete($name);
			return array('response' => $result['response']['message'], 'status' => $result['status']);
		}
		else
		{
			$url = $this->_session->serverBasePath . '/api/users/delete/name/' . $name;
			$hostnames = array();
		    $result = $this->client->get($url);
			return array('response' => (string)$result->response->message, 'status' => (string)$result->status);
		}
	}

	// General functions for users
	public function generateUserPassword($length=8)
	{
		// start with a blank password
		$password = "";

		// define possible characters
		$possible = "0123456789abcdefghijkmnopqrstuvwxyz";

		// set up a counter
		$i = 0;

		// add random characters to $password until $length is reached
		while ($i < $length)
        {
			// pick a random character from the possible ones
			$char = substr($possible, mt_rand(0, strlen($possible)-1), 1);

			// we don't want this character if it's already in the password
			if (!strstr($password, $char))
			{
				$password .= $char;
			  	$i++;
			}
		}

		return $password;
	}

	// Sub Admin user CRUD

	public function subadminCreate( $args = array() )
	{

		if( empty($this->_session->server) )
	    {
			
			$result = $this->api->subadminCreate($args);
            return array('status' => $result['status'], 'response' => $result['response']['message']);

		}
		else
		{

			$method = $this->_session->serverBasePath . "/api/subadmin/create";
			$result = $this->client->post($method, $args);
			return array('response' => (string)$result->response->message, 'status' => (string)$result->status);

		}

	}

	public function subadminView( $args = array() )
	{

		if( empty($this->_session->server) )
		{
			$subadmin = $this->api->subadminView($args);
            if($subadmin['status'] == 'failed')
				throw new Exception('Failed fetching Subadmin record: ' . (string)$subadmin['response']['message'] );
		}
		else
		{
			$method = $this->_session->serverBasePath . "/api/subadmin/view";

			$result = $this->client->post($method, $args);

			if( !$result->isSuccess() )
				throw new Exception('Failed fetching Subadmin record: ' . (string)$result->response->message);

			$subadmin = array();

			foreach ($result->subadminView->children() as $field)
			{
				$name = $field->getName();
				// Use (string) else an object is returned if row is null
				//unpack Domains if found else string
				if( $name == 'Domains' )
	{
					$subadmin['Domains'] = array();
					foreach ($field->children() as $domain)
						$subadmin['Domains'][] = (string)$domain;
				} else
					$subadmin[$name] = (string)$field;

			}

		}

		return $subadmin;
	}

	public function subadminList( $args = array() )
	{

		if( empty($this->_session->server) )
		{
			
			$subadmins = $this->api->subadminList($args);
			if( $subadmins['status'] == 'failed' && $subadmins['response']['message'] == 'No matches found' )
			{
			
				$subadmins = array();
			
			}
			elseif( $subadmins['status'] == 'failed' )
			{
			
				throw new Exception('Failed fetching Subadmins record: ' . (string)$subadmin['response']['message'] );
				
			}
			
		}
		else
		{
			$method = $this->_session->serverBasePath . "/api/subadmin/list";
			$result = $this->client->post($method, $args);

			if( !$result->isSuccess() )
				throw new Exception('Failed fetching Subadmin list: ' . (string)$result->response->message);

			$subadmins = array();
			$i = 0;
			foreach ($result->subadminList->children() as $child)
	{

				foreach ($child->children() as $field)
	{

					$name = $field->getName();
					// Use (string) else an object is returned if row is null
					$subadmins[$i][$name] = (string)$field;

				}
	 		    $i++;
			}
		}

		return $subadmins;
	}

	public function subadminUpdate( $args = array() )
	{

		if( empty($this->_session->server) )
	{
			$result = $this->api->subadminUpdate($args);
			return array('status' => $result['status'], 'success' => $result['success']);

		}
		else
		{
			$method = $this->_session->serverBasePath . "/api/subadmin/update";
			$result = $this->client->post($method, $args);
			return array('status' => (string)$result->status, 'response' => (string)$result->response->message);
		}

	}

	public function subadminDelete( $args = array() )
	{

		if( empty($this->_session->server) )
		{

			$result = $this->api->subadminDelete($args);
			if($result['status'] == 'failed')
				throw new Exception('Failed deleting Subadmin(s): ' . (string)$result['response']['message'] );
			return array('status' => $result['status'], 'success' => $result['success']);

		}
		else
		{

			$method = $this->_session->serverBasePath . "/api/subadmin/delete";
			$result = $this->client->post($method, $args);
			if( !$result->isSuccess() )
				throw new Exception('Failed deleting Subadmin(s): ' . (string)$result->response->message);
			return array('status' => (string)$result->status, 'response' => (string)$result->response->message);

		}

	}

// Admin functions
    public function adminSetPassword( $args = array() )
	{

		if( empty($this->_session->server) )
		{
			$result = $this->api->setPassword($args['id'], $args['Username'], $args['PasswordOld'], $args['PasswordNew']);
			return array('response' => $result['response']['message'], 'status' => $result['status']);

		}
		else
		{
			$method = $this->_session->serverBasePath . "/api/admin/setpassword";
			$result = $this->client->post($method, $args);
			return array('response' => (string)$result->response->message, 'status' => (string)$result->status);

		}

	}

// Aliases
	public function aliasesCreate( $args = array() )
	{

		if( empty($this->_session->server) )
		{

			$result = $this->api->aliasesCreate($args);
			//return array('response' => array('message' => $result['response']['message']), 'status' => $result['status']);
			return $result;
		}
		else
		{

			$method = $this->_session->serverBasePath . "/api/aliases/create";
		    $result = $this->client->get($method, $args);
            return array('response' => array('message' => (string)$result->response->message), 'status' => (string)$result->status);

		}

	}

	public function aliasesList($args = null)
	{

		if( empty($this->_session->server) )
		{

			$result = $this->api->aliasesList($args);
			if( is_array($result) && array_key_exists('status', $result) && $result['status'] == 'failed' )
				throw new Exception('Failed fetching aliases list: ' . $result['response']['message']);
			else
				return $result;

		}
		else
		{

			$method = $this->_session->serverBasePath . "/api/aliases/list";
		    $result = $this->client->get($method, $args);

			if( !$result->isSuccess() )
				throw new Exception('Failed fetching Aliases list: ' . (string)$result->response->message);

			$aliasesList = array();
			$i = 0;
			foreach ($result->aliasesList->children() as $child)
			{

				foreach ($child->children() as $field)
				{
					$name = $field->getName();
					// Use (string) else an object is returned if row is null
					$aliasesList[$i][$name] = (string)$field;

				}
	 		    $i++;

			}

			return $aliasesList;

		}

	}

	public function aliasesDelete( $id )
	{

		if( empty($this->_session->server) )
		{

			$result = $this->api->aliasesDelete(array("id" => $id));
			return $result;

		}
		else
		{

			$method = $this->_session->serverBasePath . "/api/aliases/delete/id/" . $id;
			$result = $this->client->get($method);
            return array('response' => array('message' => (string)$result->response->message), 'status' => (string)$result->status);

		}

	}

// MailRelay
	public function mailrelayCreate( $args = array() )
	{

		if( empty($this->_session->server) )
		{

			$result = $this->api->mailrelayCreate($args);
            return array('response' => array('message' => $result['response']['message']), 'status' => $result['status']);

		}
		else
		{

			//$method = $this->_session->serverBasePath . "/api/aliases/create";
		    //$result = $this->client->get($method, $args);
			//return array('status' => (string)$result->status);

		}

	}

	public function mailrelayDelete( $id )
	{

		if( empty($this->_session->server) )
		{
			$result = $this->api->mailrelayDelete($id);

			return array('status' => $result['status']);
		}
		else
		{
			//$method = $this->_session->serverBasePath . "/api/aliases/delete/id/" . $id;
			//$result = $this->client->get($method);

			//return array('status' => (string)$result->status);
		}

	}

	public function getCurrentAdminData()
	{

		if( empty($this->_session->server) )
		{

			$result = $this->api->getCurrentAdminData();
			return $result;

		}
		else
		{

			$method = $this->_session->serverBasePath . "/api/getcurrentadmindata";
			$result = $this->client->get($method);
            return $result;

		}

	}

	public function getDomainStatus($domain)
	{
		if( empty($this->_session->server) ) {
			$result = $this->api->getDomainStatus($domain);
			return array('response' => (string)$result['response']['message'], 'status' => (string)$result['status']);
		} else {
			$method = $this->_session->serverBasePath . "/api/domain/status";
			//NB: $this->client->args = $args; //doesnt work
			$result = $this->client->post($method, $args);
		    return array('response' => (string)$result->response->message, 'status' => (string)$result->status, );
		}
	}

	public function domainLock($domain)
	{
		if( empty($this->_session->server) ) {
			$result = $this->api->domainLock($domain);
			return array('response' => (string)$result['response']['message'], 'status' => (string)$result['status']);
		} else {
			$method = $this->_session->serverBasePath . "/api/domain/lock";
			//NB: $this->client->args = $args; //doesnt work
			$result = $this->client->post($method, $args);
		    return array('response' => (string)$result->response->message, 'status' => (string)$result->status, );
		}
	}

	public function domainUnlock($domain)
	{
		if( empty($this->_session->server) ) {
			$result = $this->api->domainUnlock($domain);
			return array('response' => (string)$result['response']['message'], 'status' => (string)$result['status']);
		} else {
			$method = $this->_session->serverBasePath . "/api/domain/unlock";
			//NB: $this->client->args = $args; //doesnt work
			$result = $this->client->post($method, $args);
		    return array('response' => (string)$result->response->message, 'status' => (string)$result->status, );
		}
	}
	
	public function getCurrentQuota()
	{
		
		if( empty($this->_session->server) )
		{

			$result = $this->api->getCurrentQuota();
			return $result;

		}
		else
		{

			$method = $this->_session->serverBasePath . "/api/subadmin/getcurrentquota";
			$result = $this->client->get($method);
            return $result;

		}
		
	}
	
	public function getDomainAndGroupUsers( $optionalFilters = null )
	{
		
		if( empty($this->_session->server) )
		{

			return $this->api->getDomainAndGroupUsers( $optionalFilters );

		}
		else
		{

			return $this->client->get( $this->_session->serverBasePath . "/api/domain/getdomainandgroupusers" );
            
		}
		
	}
	
	public function logsearch( $args = array() )
	{
	
		if( empty($this->_session->server) )
		{

			return $this->api->logsearch($args);

		}
		else
		{

			// Required to implement
			//return $this->client->get( $this->_session->serverBasePath . "/api/domain/getdomainandgroupusers" );
            
		}
			
	}
	
	public function getLicenseStatusExpired()
	{
		$dlid = Zend_Registry::get("config")->reg['downloadId'];
	    if (strlen(Zend_Registry::get('config')->reg['serialKey']) == 64) {
	        $message = "License Expired. Renew anytime via the Atmail Store for continued ActiveSync functionality, software patches, new versions and support. <a href=\"https://secure.atmail.com/store/index.php/index/renewalinfo?clientId=$dlid\" target=\"_blank\">Renew now</a>";
	    } else {
		    $message = 'License Expired. Renew anytime via the Atmail Store for continued software patches, new versions and support. <a href="https://secure.atmail.com/store/index.php/index/renewalinfo?clientId=' . $dlid . '" target="_blank">Renew now</a>';
		}
		
		return $message;
	}

}
