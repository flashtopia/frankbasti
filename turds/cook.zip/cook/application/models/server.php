<?php
/**
 * @category 	Atmail
 * @package 	Models
 * @subpackage	Server
 * @copyright 	Copyright (c) 2009-2011 ATMAIL. All rights reserved
 * @license 	See http://atmail.com/license.php for license agreement
 * @author		Allan Wrethman allan@staff.atmail.com
 * @author		Atmail (http://atmail.com)
 */
class server
{
	
	public function restart_exim()
    {
        $configGlobal = Zend_Registry::get('config')->global;
        system("{$configGlobal['serverDir']}/mailserver/bin/exim -C {$configGlobal['serverDir']}/mailserver/configure.new > {$configGlobal['serverDir']}/mailserver/eximrestart.out 2>&1");
        $error = file_get_contents("{$configGlobal['serverDir']}/mailserver/eximrestart.out");

        unlink("{$configGlobal['serverDir']}/mailserver/eximrestart.out");

        if (strpos($error, 'Exim configuration error') !== false)
        catcherror("The SMTP server could not be restarted. Please check the syntax of the SMTP server settings via the Webadmin are correct. Error message follows: $error");
        else
        {
            // First, check the new configuration file is valid, dont restart if configuration wrong!
            if (!rename("{$configGlobal['serverDir']}/mailserver/configure.new", "{$configGlobal['serverDir']}/mailserver/configure"))
            catcherror("Cannot rename {$configGlobal['serverDir']}/mailserver/configure.new to {$configGlobal['serverDir']}/mailserver/configure");

            $pid = trim(file_get_contents("{$configGlobal['serverDir']}/mailserver/spool/exim-daemon.pid"));

            if ($pid > 0 && strpos(PHP_OS, 'WINNT') === false)
            {
                if (!posix_kill($pid, 'SIGHUP'))	{
                    $return = system("/bin/kill -HUP $pid", $return);
                    if($return)
                    print "<font color='red'>Cannot restart SMTP process (PID $pid) - Please manually restart the Atmail services by running the following command as root on the terminal. <b>/etc/init.d/atmailserver restart</b></font>";
                }

            }
        }
    }


    function restart_atmail_services()
    {

        if(file_exists('/etc/init.d/atmailserver'))
            system('/etc/init.d/atmailserver restart');
        
		else if(file_exists('/etc/rc.d/atmailserver'))
            system('/etc/rc.d/atmailserver restart');
        
		else if(file_exists('/usr/local/etc/rc.d/z-atmailserver.sh'))
            system("/usr/local/etc/rc.d/z-atmailserver.sh restart");
        
		else
			throw new Atmail_Server_Exception('Failed restarting Atmail server, no suitable service controller found');
        
		echo 'Cannot determine startup script for Atmail. Manually:
    1: Stop Atmail Services
    2: Start Atmail Services
    ';
    }

    function stop_atmail_services()
    {

        if(file_exists('/etc/init.d/atmailserver'))
            system('/etc/init.d/atmailserver stop');
        
		else if(file_exists('/etc/rc.d/atmailserver'))
            system('/etc/rc.d/atmailserver stop');
        
		else if(file_exists('/usr/local/etc/rc.d/z-atmailserver.sh'))
            system("/usr/local/etc/rc.d/z-atmailserver.sh stop");
        
		else
            throw new Atmail_Server_Exception('Failed stopping Atmail server, no suitable service controller found'); 
	   	echo 'Cannot determine startup script for Atmail. Manually:
    1: Stop Atmail Services
    2: Start Atmail Services
    ';
    }
    

	public static function uptime($uptime_file = "/proc/uptime")
    {

        // Should use uptime command, if that fails try /proc/uptime, platform friendly
        if ($uptime = @exec('uptime')) {

            $uptime = explode(' up ', $uptime);
            $uptime = explode(',', $uptime[1]);
            list($hours, $minutes) = explode(':', $uptime[1]);
            $server_uptime = $uptime[0].' ';
            if ($hours > 0)
                $server_uptime .= (int) $hours.' hours ';

            if ($minutes > 0)
                $server_uptime .= (int) $minutes.' minutes ';

            return $server_uptime;

        } else {

            $uptime = @file($uptime_file);
            $uptime = $uptime[0];


            $uptime = substr($uptime, 0, strpos($uptime, " "));

            $server_uptime = '';
            $sec_years = 31536000;
            $sec_months = 2592000;
            $sec_days = 86400;
            $sec_hours = 3600;
            $sec_minutes = 60;

            $years = floor($uptime / $sec_years);
            if ($years > 0)
                $server_uptime .= $years.' years ';
            $uptime = $uptime % $sec_years;

            $months = floor($uptime / $sec_months);
            if ($months > 0)
                $server_uptime .= $months.' months ';
            $uptime = $uptime % $sec_months;

            $days = floor($uptime / $sec_days);
            if ($days > 0)
                $server_uptime .= $days.' days ';
            $uptime = $uptime % $sec_days;

            $hours = floor($uptime / $sec_hours);
            if ($hours > 0)
                $server_uptime .= $hours.' hours ';
            $uptime = $uptime % $sec_hours;

            $minutes = floor($uptime / $sec_minutes);
            if ($minutes > 0)
                $server_uptime .= $minutes.' minutes ';
            $seconds = $uptime % $sec_minutes;

            return $server_uptime;
        }

    }



}                                               

