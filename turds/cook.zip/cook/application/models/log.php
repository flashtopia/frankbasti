<?php
/**
 * @category 	Atmail
 * @package 	Models
 * @subpackage	Log
 * @copyright 	Copyright (c) 2009-2011 ATMAIL. All rights reserved
 * @license 	See http://atmail.com/license.php for license agreement
 * @author		Ben Duncan ben@staff.atmail.com
 * @author		Atmail (http://atmail.com)
 */
class logEntry
{
    public $Account = '';
	private $_namespaceName = 'log';

	public function __construct($account)
	{
		// check to make sure we have valid arguments!
		if( empty($account) )
		throw new Atmail_Exception('Log constructor required Account field in arguments array');

		$this->Account = $account;

	}

    public static function insert($log, $arr)
    {
        $dbTables = new dbTables();
		$dbAdapter = Zend_Registry::get('dbAdapter');

		//$arr['Account'] = $this->Account;
		$arr['LogDate'] = new Zend_Db_Expr('NOW()');

		$dbAdapter->insert($log, $arr );

    }

}

class AtmailLogType
{
	// valid log table types
	const Log_Login = 'Log_Login';
	const Log_RecvMail = 'Log_RecvMail';
	const Log_SendMail = 'Log_SendMail';
	const Log_Spam = 'Log_Spam';
	const Log_Virus = 'Log_Virus';
	const Log_Error = 'Log_Error';
}
