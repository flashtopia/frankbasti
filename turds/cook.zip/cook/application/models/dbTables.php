<?php
/**
 * @category 	Atmail
 * @package 	Models
 * @subpackage	DB Tables
 * @copyright 	Copyright (c) 2009-2011 ATMAIL. All rights reserved
 * @license 	See http://atmail.com/license.php for license agreement
 * @author		Allan Wrethman allan@staff.atmail.com
 * @author		Atmail (http://atmail.com)
 */
class dbTables
{
	
	//TODO: make singleton and static so that in future is prepend is specified we dont have to go updating dbTables usage all over
	//CONSIDER making this class static for neater code
	public $prepend = '';
	
	public function __construct( $args=array() ) {
		
	    if( array_key_exists('prepend', $args) )
			$this->prepend = $args['prepend'];
        
    	$this->Abook               = "Abook";
    	$this->AbookGroup          = "AbookGroup";
        $this->AbookGroupNames     = 'AbookGroupNames'; 
        $this->AbookPermissions    = 'AbookPermissions';
        $this->Abook_shared        = 'Abook_shared';
        $this->Accounts            = 'Accounts';
        $this->AdminGroup          = 'AdminGroup';
        $this->AdminUsers          = 'AdminUsers';
        $this->Config              = 'Config';
        $this->Domains             = 'Domains';
        $this->Groups              = 'Groups';
        $this->Log_Data            = 'Log_Data';
        $this->Log_Error           = 'Log_Error';
        $this->Log_Incoming        = 'Log_Incoming';
        $this->Log_Login           = 'Log_Login';
        $this->Log_MessageDiskId   = 'Log_MessageDiskId';
        $this->Log_RecvMail        = 'Log_RecvMail';
        $this->Log_SendMail        = 'Log_SendMail';
        $this->Log_Spam            = 'Log_Spam';
        $this->Log_Virus           = 'Log_Virus';
        $this->MailAliases         = 'MailAliases';
        $this->MailRelay           = 'MailRelay';
        $this->SerialConf          = 'SerialConf'; 
        $this->SharedLookup        = 'SharedLookup';
        $this->SpamSettings        = 'SpamSettings';
        $this->UserPermissions     = 'UserPermissions';
        $this->UserSession         = 'UserSession';
        $this->UserSettings        = 'UserSettings';
        $this->Users               = 'Users';
        $this->VideoMail           = 'VideoMail';
        //$this->authSession         = 'authSession';
        //$this->authUsers           = 'authUsers';
        $this->awl                 = 'awl';

		return $this;  

	}
	
	public function __get( $argName ) {
        
		if( isset($this->$argName) )
			return $this->prepend . $this->$argName;
		else
			return $this->prepend . $argName;

	}

}                                           

