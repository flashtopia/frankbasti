<?php
/**
 * Main endpoint
 *
 * @category 	Atmail
 * @package 	Application
 * @subpackage	Main endpoint
 * @copyright 	Copyright (c) 2009-2011 ATMAIL. All rights reserved
 * @license 	See http://atmail.com/license.php for license agreement
 * @author		Atmail (http://atmail.com)
 */
 
// check session.auto_start status
if(ini_get("session.auto_start"))
{
	ini_set('session.auto_start', "0");
	session_write_close();
}

include_once('bootloader.php');
 
if(isset($frontController) && $frontController)
{
	$frontController->dispatch();
	
	Zend_Session::writeClose();
	Zend_Registry::get('log')->debug('Hit closing down. Hit time: ' . round( ( microtime(true) - DEBUG_START_MT ),3 ) . ' seconds. ' . session_id());
}

