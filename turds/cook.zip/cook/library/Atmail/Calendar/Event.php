<?php

/**
 * Atmail Event object
 *
 * This object holds event information. It is a value object, and thus not 
 * responsible for saving/loading.
 * 
 * @package Atmail
 * @subpackage Calendar 
 * @copyright Copyright (C) 2011 Atmail. All rights reserved.
 * @author Evert Pot (http://www.rooftopsolutions.nl/) 
 */
class Atmail_Calendar_Event {

    /**
     * The (caldav-)url to the event.
     *
     * This url may be used as a primary key. 
     * 
     * @var string 
     */
    public $url;

    /**
     * ETag
     *
     * The ETag must change whenever the contents of the event change. This is 
     * done automatically by the server, but it may not be supported by the 
     * server, so be careful. 
     * 
     * @var string 
     */
    public $etag;

    /**
     * Raw icalendar data object 
     * 
     * @var string 
     */
    public $icalendarData;

    /**
     * Parses the iCalendar data and returns a VObject 
     * 
     * @return Sabre_VObject_Component 
     */
    public function getVObject() {

        return Sabre_VObject_Reader::read($this->icalendarData);

    }

    /**
     * Updates the inner iCalendar data with the new VObject data.
     * 
     * @param Sabre_VObject_Component $component 
     * @return void 
     */
    public function setVObject(Sabre_VObject_Component $component) {

        $this->icalendarData = $component->serialize();

    }

}

