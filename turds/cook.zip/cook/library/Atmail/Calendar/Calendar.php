<?php

/**
 * Atmail Calendar object
 *
 * This object holds calendar information. It is a value object, and thus not 
 * responsible for saving/loading.
 * 
 * @package Atmail
 * @subpackage Calendar 
 * @copyright Copyright (C) 2011 Atmail. All rights reserved.
 * @author Evert Pot (http://www.rooftopsolutions.nl/) 
 */
class Atmail_Calendar_Calendar {

    /**
     * The (caldav-)url to the calendar.
     *
     * This url may be used as a primary key. 
     * 
     * @var string 
     */
    public $url;

    /**
     * A name for display purposes 
     * 
     * @var string 
     */
    public $displayName;

    /**
     * The 'ctag'.
     *
     * This property changes whenever anything within the calendar changes. 
     * This allows you to quickly check if the calendar was updated.
     *
     * Implementation of this property is optional 
     * 
     * @var string 
     */
    public $ctag;

    /**
     * A description of the calendar 
     * 
     * @var string 
     */
    public $description;

    /**
     * CalDAV url to principal 
     * 
     * @var string 
     */
    public $principalUrl;

    /**
     * Wether or not the calendar is read-only or read-write 
     * 
     * @var bool 
     */
    public $readOnly = false;
    
    /**
     * Wether or not the calendar is home calendar
     * 
     * @var bool 
     */
    public $isHome = false;

    /**
     * This is an 'order' number
     *
     * The order number is completely arbitrary and can basically be an integer 
     * in any range. It's used so the user can determine the order of 
     * calendars.  
     *
     * @var int 
     */
    public $order;

    /**
     * This is the calendar color.
     *
     * The format is #AABBCCDD (RGBA) 
     *
     * @var string 
     */
    public $color;
    
    /**
    * This is the calendar owner.
    *
    * @var string
    */
    public $owner;
}

?>
