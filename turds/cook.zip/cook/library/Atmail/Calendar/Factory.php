<?php

class Atmail_Calendar_Factory {

    /**
     * Returns an Atmail Calendar adapter. 
     * 
     * @return Atmail_Calendar_Adapter_Abstract 
     */
    static function instance($settings) {

        // Currently a very simple implementation, but could be expanded layer 
        // if features are added for multiple / different calendaring backends.
        return new Atmail_Calendar_Adapter_IntegratedCalDAV($settings); 

    }

}
