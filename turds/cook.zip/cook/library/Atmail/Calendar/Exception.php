<?php

/**
 * Atmail Calendar Exception 
 * 
 * @package Atmail
 * @subpackage Calendar
 * @copyright Copyright (C) 2011 Atmail. All rights reserved.
 * @author Evert Pot (http://www.rooftopsolutions.nl/) 
 */
class Atmail_Calendar_Exception extends Atmail_Exception { }
