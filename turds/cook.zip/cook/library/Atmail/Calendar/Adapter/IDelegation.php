<?php

/**
 * Calendar adapters must implement this interface to advertise they support 
 * calendar delegation.
 * 
 * @package Atmail
 * @subpackage Calendar 
 * @copyright Copyright (C) 2011 Atmail inc. All rights reserved.
 * @author Evert Pot (http://www.rooftopsolutions.nl/) 
 */
interface Atmail_Calendar_Adapter_IDelegation {

    /**
     * Returns a list of members for a specific calendar.
     *
     * The response to this method are two arrays, wrapped in an array.
     * The first array contains members (atmail email addresses) that have 
     * read-only access to the calendar. The second array contains members that 
     * have read-write access.
     *
     * @param Atmail_Calendar_Calendar $calendar 
     * @return array 
     */ 
    public function getMembers(Atmail_Calendar_Calendar $calendar);
    
    /**
     * Updates the list of members for a specific calendar
     *
     * @param Atmail_Calendar_Calendar $calendar
     * @param array $members
     */ 
    public function setMembers(Atmail_Calendar_Calendar $calendar, array $readMembers, array $writeMembers); 
    
}
