<?php
/**
 * Session SyncML Backend - for remotely viewing and manipulating contacts on a SyncML Server via the SyncML protocol as a client.
 * Copyright 2010 Atmail www.atmail.com
 * @author  Allan Wrethman <allan@staff.atmail.com>
 */


class Atmail_SyncML_Backend_Session extends SyncML_Backend 
{


	function isValidDatabaseURI($databaseURI)
    {
        $database = $this->_normalize($databaseURI);

        switch($database) 
		{
			case 'tasks';
			case 'calendar';
			case 'notes';
			case 'contacts';
			case 'events':
			case 'memo':
			    return true;
			
			default:
				Zend_Registry::get('log')->debug( __METHOD__ . ' #' . __LINE__ . 'Invalid database ' . $database . '. Try tasks, calendar, notes or contacts.');
			    return false;
        }
    }

    function getServerChanges($databaseURI, $from_ts, $to_ts, &$adds, &$mods, &$dels)
    {
        $adds = $mods = $dels = array();
        return array();
    }

    function retrieveEntry($databaseURI, $suid, $contentType, $fields)
    {
    	return array();
	}

    function addEntry($databaseURI, $content, $contentType, $cuid = null)
    {
    }

    function replaceEntry($databaseURI, $content, $contentType, $cuid)
    {
    	//return server id
		return 0;
	}

    function deleteEntry($databaseURI, $cuid)
    {
        $database = $this->_normalize($databaseURI);
        return true;
    }

    function _checkAuthentication($username, $password)
    {
		return true;
    }

    function setAuthenticated($username, $credData)
    {
        return $username;
    }

    function writeSyncAnchors($databaseURI, $clientAnchorNext, $serverAnchorNext)
    {
        $database = $this->_normalize($databaseURI);
        return true;
    }

    function readSyncAnchors($databaseURI)
    {
        $database = $this->_normalize($databaseURI);
        return array(0, 0);
    }

    function createUidMap($databaseURI, $cuid, $suid, $timestamp = 0)
    {
        $database = $this->_normalize($databaseURI);
        return true;
    }

    function _getSuid($databaseURI, $cuid)
    {
        return $cuid;
    }

    function _getCuid($databaseURI, $suid)
    {
        return $suid;
    }

    function _getChangeTS($databaseURI, $suid)
    {
        $database = $this->_normalize($databaseURI);
        return 0;
    }

    function close()
    {
    }

    function _generateID()
    {
        return date('YmdHis') . '.'
            . substr(str_pad(base_convert(microtime(), 10, 36),
                             16,
                             uniqid(mt_rand()),
                             STR_PAD_LEFT),
                     -16)
            . '@'
            . (!empty($_SERVER['SERVER_NAME'])
               ? $_SERVER['SERVER_NAME']
               : 'localhost');
    }

    function _checkForError($o)
    {
        if (is_a($o, 'PEAR_Error')) {
            $this->logMessage($o);
            return $o;
        }
        return false;
    }

    function _trackDeletes($databaseURI, $currentSuids)
    {
        $database = $this->_normalize($databaseURI);
        return array();
    }

    function _removeFromSuidList($databaseURI, $suid)
    {
        $database = $this->_normalize($databaseURI);
        return true;
    }

}
