<?php

require_once('library/Atmail/Update/Versions.php');
require_once('library/Atmail/Update/Utils.php');
require_once('library/Atmail/Update/Db.php');

class Atmail_Update
{
	private $dbAdapter;
	public $cliUpdateAvailable;
	public $dbUpdateAvailable;
	public $updateAvailable;

	public function __construct($dbAdapter)
	{
		$this->dbAdapter = $dbAdapter;
		
		$dbUpdater = new Atmail_Update_Db($this->dbAdapter);
		$cliUpdater = new Atmail_Update_Cli($this->dbAdapter);	
		
		$this->cliUpdateAvailable = $cliUpdater->isUpdateAvailable();
		$this->dbUpdateAvailable = $dbUpdater->isUpdateAvailable();
		$this->updateAvailable = (!($this->cliUpdateAvailable || $this->dbUpdateAvailable)) ? false : true;

		if(!$this->updateAvailable)
		{
			// no updates found
			if (version_compare($dbUpdater->currentVersion, $dbUpdater->localCodeBase, '<'))
			{
				// but we are a different version !
				$dbUpdater->pre_update();
				$dbUpdater->post_update($dbUpdater->localCodeBase);
			}
		}
	}
}

