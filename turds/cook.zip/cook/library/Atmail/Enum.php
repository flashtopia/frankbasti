<?php

class Atmail_Enum
{
	// ID's
	const ID_LIMIT				= 'limit';

	// password type
	const PASSWORD_PLAIN		= "PLAIN";
	const PASSWORD_ENCRYPTED 	= "ENCRYPTED";
	const PASSWORD_MD5			= "MD5";
	const PASSWORD_MD5_CRYPT	= "MD5-CRYPT";

	// Auto reload (notification) bit field values
	const AUTORELOAD_ENABLED	= 1;
	const AUTORELOAD_AUDIO		= 2;
	const AUTORELOAD_FAVICON	= 4;
}


class Atmail_Message_Handler_Enum
{

	public static $iconClass = array(
	'default' => 'default',
	'uri' => 'uri',
	'doc' => 'doc',
	'docx' => 'doc',
	'gif' => 'img',
	'gz' => 'zip',
	'html' => 'html',
	'ics' => 'ics',
	'jpeg' => 'img',
	'jpg' => 'img',
	'js' => 'code',
	'message' => 'email',
	'pdf' => 'pdf',
	'cpp' => 'code',
	'c' => 'code',
	'h' => 'code',
	'hpp' => 'code',
	'java' => 'code',
	'php' => 'code',
	'pl' => 'code',
	'plain' => 'txt',
	'png' => 'img',
	'ppt' => 'ppt',
	'psd' => 'img',
	'rar' => 'zip',
	'rtf' => 'txt',
	'sh' => 'code',
	'tar' => 'zip',
	'tgz' => 'zip',
	'txt' => 'txt',
	'xls' => 'default',
	'xlsx' => 'default',
	'zip' => 'zip'
	);

	public static $fileTypeNames = array(
	'ics' => 'Calendar Appointment',
	'pdf' => 'PDF Document',
	'php' => 'PHP file',
	'js' => 'Javascript file',
	'pl' => 'Perl script',
	'sh' => 'Shell script',
	'jpg' => 'JPEG image',
	'jpeg' => 'JPEG image',
	'psd' => 'Photoshop file',
	'gif' => 'GIF image',
	'png' => 'PNG image',
	'ppt' => 'Powerpoint slide',
	'txt' => 'Text file',
	'rtf' => 'Rich text file',
	'html' => 'HTML document',
	'doc' => 'Microsoft Word document',
	'docx' => 'Microsoft Word document',
	'xls' => 'Microsoft Word spreadsheet',
	'xlsx' => 'Microsoft Word spreadsheet',
	'zip' => 'Zip archive',
	'tgz' => 'TGZ archive',
	'gz' => 'Compressed archive',
	'rar' => 'RAR archive',
	'tar' => 'Tar archive',
	'message' => 'Embeded email',
	'default' => 'Downloadable File',
	'uri'	=> 'Network File',
	'eml' => 'Email message',
	'cpp' => 'C++ File',
	'c' => 'C File',
	'h' => 'Header File',
	'hpp' => 'C++ Header File',
	'java' => 'Java File'
	);
}