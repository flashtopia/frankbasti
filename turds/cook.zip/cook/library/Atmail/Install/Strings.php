<?php

$installerStrings = array(

'installerUsage' => <<< EOF

Atmail server-install.php

Usage: php server-install.php [options]
Note: If no arguments are specified the installation will be interactive.

	--interactive	Install Atmail in interactive mode
	--install	Skip prompts during installation
	--dbhost	MySQL hostname (required)
	--dbuser	MySQL username (required)
	--dbtable	MySQL database table (required)
	--dbpass	MySQL password (optional)
	--create-tables		Create the database tables
	--httpdconf		Pathname to httpdconf
	--domain	Default domain ( required )
	--adminemail	Admin email address
	--adminpass		Admin password ( required )
	--skip-dovecot	Create the specified database table automatically
	--skip-exim		Skip Exim compile
	--skip-spamassassin		Skip Spamassassin compile
	--skip-clamav	Skip ClamAV compie
	--skip-diagnostics	Skip server diagnostic report
	--verbose	Verbose output

	Example: php server-install.php --install --dbhost=localhost --dbuser=root --dbpass=mypass --dbtable=atmail6 --create-db --create-tables


EOF
	,

'noWebAccess' => <<< EOF
<h1>Installation Script Error</h1>
<p>The server-install.php script can only be run via the command-line to configure Atmail. Please read
<a href='http://support.atmail.com/'>http://support.atmail.com/</a> for information on
installing.
</p>

EOF
	,

'safeModeOn' => <<< EOF

The server installer must be run with safe_mode Off.
Please edit your php.ini and set safe_mode = Off before re-running server-install.php

EOF
	,

'notRoot' => <<< EOF

The server installer must be run as root.
Please su to root, and consult the installation details for further information.


EOF
	,

'unableToDetectRoot' => <<< EOF

Could not detect what user the server installer is running as.
If you are not running the installation as root please do so.

EOF
	,

'firewallIsActive' => <<<EOF

\033[1;32mFirewall Permissions\033[0;39m
--------------------

The installer has detected the iptables firewall is active on the server.

The following ports have not been detected as open, please alter the iptables rules to allow
the ports below, then continue with the Atmail installer.


EOF
	,

'installerPrerequisites' => <<<EOF

\033[1;32mInstall Prerequisites \033[0;39m
---------------------

The installer will check your system has the required PHP runtime settings.
You can install the optional PHP extensions via your system package manager or
via the PHP pecl system. The installer will also scan your php.ini
configuration file and make the required adjustments for Atmail.


Required Extensions:

EOF
	,

'execCGIPermittedFailed' => <<<EOF

\033[1;32mExecCGI Permitted for /usr/local/atmail/webmail: FAIL\033[0;39m

Solution:
The ExecCGI tag is required to allow PHP scripts to be executed in the
/usr/local/atmail/webmail directory.

-> Add the following to $httpdConf . You must do this manually (for advanced
httpd.conf configurations) or select to automatically edit the configuration
file below.

Append the following to the httpd.conf:

<Directory "/usr/local/atmail/webmail">
	Options ExecCGI FollowSymLinks
	AllowOverride All
	Order allow,deny
	Allow from all
</Directory>


EOF
	,

'modGzipDetected' => <<<EOF

WebServer Gzip compression: \033[1;32mDetected\033[0;39m

Within Apache 2 the mod_deflate module can be used to automatically compress
the output of the Atmail interface to the user's browser.

Compression can increase the performance dramatically for users on a slower
link ( e.g dialup or congested network ) . The mod_deflate feature can
compress between 15-60%+ of HTML output via the Webserver.

This installation utility can automatically configure the Webserver to enable
GZIP compression.

EOF
	,

'modGzipFailed' => <<<EOF

WebServer Gzip compression: \033[1;32mFAIL\033[0;39m

The optional Gzip compression is not available on your Apache configuration.

Within Apache 2.X the mod_deflate module can be used to automatically compress
the output of the Atmail interface to the user's browser for increased
performance.

*The mod_deflate module is not required;  this message can be safely ignored*

EOF
	,

'modExpiresDetected' => <<<EOF

Apache mod_expires module: \033[1;32mDetected\033[0;39m

Within Apache 2 the mod_expires module can be used to force browsers to cache
the images/Javascript and CSS used by the Atmail interface. This can
dramatically increase performance for loading the GUI frontend.

This installation utility can automatically configure Apache to enable the
mod-expires feature for the Atmail application.
EOF
	,

'modExpiresFailed' => <<<EOF

WebServer mod_expires module: \033[1;32mFAIL\033[0;39m

The mod_expires module for Apache could not be loaded.

This is an optional configuration module for Atmail which can force the
users web-browser to cache images/Javascript and CSS files of the UI interface,
improving performance.

*The mod_expires module is not required;  this message can be safely ignored*

EOF
	,

'modRewriteFailed' => <<<EOF

WebServer mod_rewrite module: \033[1;32mFAIL\033[0;39m

The mod_rewrite module for Apache could not be loaded.

This is an optional configuration module for Atmail which would make the
calendar server available via port 8008 for various clients that require it.

*The mod_rewrite module is not required; However various dav clients will not function. *

Solution:

Ensure the following in your webserver configuration
LoadModule rewrite_module modules/mod_rewrite.so

EOF
	,

'davSupportDetected' => <<<EOF

DAV support: \033[1;32mDetected\033[0;39m

Solution:
Atmail includes a complete CalDAV (Calenaring) and CardDAV (Contact)
server. For remote desktop-clients and mobile (iOS) devices to connect,
Apache must be configured to accept connections for *DAV services.

EOF
	,
	
'davSupportFailed' => <<<EOF

DAV support: \033[1;31mFailed\033[0;39m

Solution:
Atmail includes a complete CalDAV (Calenaring) and CardDAV (Contact)
server. For remote desktop-clients and mobile (iOS) devices to connect,
Apache must be configured to accept connections for *DAV services.

Enable the rewrite_module in your Apache configuration, then restart this installer.
See online documentation at http://www.atmail.com/support/index.php/Atmail6ServerInstall/CalendarInstall

EOF
	);