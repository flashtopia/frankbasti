<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

class Atmail_Locale 
{
	
	//TODO: upgrade this to scan the folders for language files and compile the available languages list
	protected static $map = array(
		'ar' => 'العربية',
		'ca' => 'Catalan',
		'da' => 'Danish',
		'de' => 'Deutsch',
		'en' => 'English',
		'el' => 'Ελλάδα',
		'es' => 'Español',
		'fi' => 'Finnish',
		'fr' => 'Français',
		'hu' => 'Hungarian',
		'id' => 'Bahasa Indonesia',
		'it' => 'Italiano',
		'ja' => 'Japanese',
		'nl' => 'Nederlands',
		'pt_Br' => 'Português Brasileiro',
		'no' => 'Norwegian',
		'pl' => 'Polish',
		'pt' => 'Portuguese',
		'po' => 'Polish',
		'ru' => 'Russian',
		'sv' => 'Swedish',
		'th' => 'Thai',
		'zh' => '汉语',
		
	);
	
	public static function getName($code)
	{
		
		return isset(self::$map[$code]) ? self::$map[$code] : '';
		
	}
	
	public static function getAvailableLocales()
	{
		$availableLanguageCodes = self::findAvailableLanguageFolders();
		$availableLocalesHash = array();
		foreach( self::$map as $k => $v )
		{
			
			if( in_array($k, $availableLanguageCodes) )
			{
				
				$availableLocalesHash[$k] = $v;
				
			}
			
		}
		
		return $availableLocalesHash;
	}
	
	public static function getLocaleString()
	{
		
		return Zend_Registry::get('Zend_Locale')->toString();
		
	}
	
	public static function findAvailableLanguageFolders()
	{
		
		//find available languages then try apply them
		$folderList = scandir( APP_ROOT . 'application/modules/' . 'mail' . '/languages' );
		$availableLanguageCodes = array();
		foreach( $folderList as $item )
		{
			
			//ignore reserved folders and folder longer than 5 chars
			if( $item == '.' || $item == '..' || strlen($item) > 5 )
			{
				
				continue;
				
			}
			if( is_dir(APP_ROOT . 'application/modules/' . 'mail' . '/languages/' . $item) && file_exists( APP_ROOT . 'application/modules/' . 'mail' . '/languages/' . $item . '/main.mo') )
			{
				
				$availableLanguageCodes[] = $item;
				
			}
			
		}
		return $availableLanguageCodes;
		
	}
	
	public static function setupLocaleAndTranslation( $localeString = null )
	{
		
		$defaultLanguageString = 'en';
		
		if( $localeString == null )
		{
			$localeString = Zend_Registry::get('Zend_Locale')->toString();
		}
		
		$availableLanguageCodes = self::findAvailableLanguageFolders();

		//force locale to en if no translation present (to eliminate the "Language file missing" warnings)
		if( !in_array($localeString, $availableLanguageCodes) || !file_exists(APP_ROOT . 'application/modules/mail/languages/' . $localeString . '/main.mo') )
		{
			
			Zend_Registry::get('Zend_Locale')->setDefault($defaultLanguageString);
			Zend_Registry::get('Zend_Locale')->setLocale($defaultLanguageString);
			$localeString = $defaultLanguageString;
			                                                                                          
		}
		//too much load so only loading one language
		$translate = new Zend_Translate('gettext', APP_ROOT . 'application/modules/mail/languages/' . $localeString . '/main.mo', $localeString);
		
		$Zend_Locale = Zend_Registry::get('Zend_Locale');
		try 
		{
			
			$Zend_Locale->setLocale($localeString);
			$translate->setLocale( $localeString );
			
		}
		catch ( Exception $e ) 
		{
			
			$Zend_Locale->setLocale($defaultLanguageString);
			$translate->setLocale( $defaultLanguageString);

		}
		
		// Create a global reference, that a library can called direct
		Zend_Registry::set('Zend_Locale', $Zend_Locale);
		Zend_Registry::set('Zend_Translate', $translate);
		Zend_Registry::set('translator', $translate);
		
	}

}
