<?php 


// define all constants
if(!defined('SQL_MODE'))						define('SQL_MODE', 						'sql');
if(!defined('CARDDAV_MODE'))					define('CARDDAV_MODE', 					'carddav');
if(!defined('LDAP_MODE'))						define('LDAP_MODE', 					'ldap');
if(!defined('SYNCML_MODE'))						define('SYNCML_MODE', 					'syncml');
if(!defined('GROUPWARE_SYSTEM_ZONE'))			define('GROUPWARE_SYSTEM_ZONE', 		'System');
if(!defined('GROUPWARE_DOMAIN_ZONE'))			define('GROUPWARE_DOMAIN_ZONE', 		'Domain');
if(!defined('GROUPWARE_PERSONAL_ZONE'))			define('GROUPWARE_PERSONAL_ZONE', 		'');
if(!defined('GROUPWARE_DISABLED'))				define('GROUPWARE_DISABLED', 			'Off');
if(!defined('GROUP_GLOBAL'))					define('GROUP_GLOBAL', 					'-1');
if(!defined('GROUP_SHARED'))					define('GROUP_SHARED', 					'-2');
if(!defined('GROUP_AUTO'))						define('GROUP_AUTO', 					'-3');
if(!defined('GROUP_FAV'))						define('GROUP_FAV', 					'-4');
if(!defined('GROUPWARE_SHARED_ABOOK_ENABLED'))	define('GROUPWARE_SHARED_ABOOK_ENABLED', '1');
if(!defined('CONTACT_INVALID_ID'))				define('CONTACT_INVALID_ID', 			'-1');
if(!defined('CONTACT_INVALID_GROUP_ID'))		define('CONTACT_INVALID_GROUP_ID', 		'-999');
if(!defined('CONTACT_UNDEFINED_GROUP'))			define('CONTACT_UNDEFINED_GROUP', 		'ungrouped');
if(!defined('ABOOK_SERVER_GROUP_TAG'))			define('ABOOK_SERVER_GROUP_TAG', 		'server');