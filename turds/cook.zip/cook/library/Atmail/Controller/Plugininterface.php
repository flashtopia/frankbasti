<?php

class Atmail_Controller_Plugininterface extends Zend_Controller_Action
{

    public function init()
    {
        $this->_helper->viewRenderer->setNoRender(true);  
    }

    public function indexAction()
    {
        $req = $this->getRequest()->getParams();
        
	    unset($req["module"]);
	    unset($req["controller"]);
	    unset($req["action"]);
	    
	    list($plugin) = array_keys($req);
	    $method = $req[$plugin];
	    unset($req[$plugin]);

        $plugin = Zend_Controller_Front::getInstance()->getPlugin($plugin);
        
        if($plugin->authRequired($method) && !Atmail_FormAuth::authenticated()) {
			return;
		}

        if ($plugin instanceof Atmail_Controller_Plugin && method_exists($plugin, $method)) {
            $result = $plugin->$method($req);
            if (is_string($result)) {
                echo $result;
            }
        }
    }
}
