<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

class Atmail_Controller_Plugin_SessionSaveHandler extends Zend_Controller_Plugin_Abstract
{

	public function dispatchLoopStartup(Zend_Controller_Request_Abstract $request)
	{
		
		try 
		{

			$dbTables = new dbTables();
			if($request->getModuleName() == 'admin') 
			{

				Zend_Session::setSaveHandler( new Atmail_Session_SaveHandler_DbAdminSession() );

			}
			else
			{

				Zend_Session::setSaveHandler(new Atmail_Session_SaveHandler_DbUserSession());

			}
			
		}
		catch( Exception $e )
		{

			//ignore - CONSIDER throwing error
			Zend_Registry::get('log')->notice('Setting up ' . $request->getModuleName() . ' session save handler. ' . $e->getMessage() . ' Downgrading to disk based session handling');

		}

	}

}