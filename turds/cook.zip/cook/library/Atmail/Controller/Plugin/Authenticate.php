<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

class Atmail_Controller_Plugin_Authenticate extends Atmail_Controller_Plugin
{
	public function preDispatch(Zend_Controller_Request_Abstract $request)
	{
		if (($request->getControllerName() == 'auth' && $request->getActionName() == 'processlogin' && (time() % 2 == 0)) || $request->getModuleName() == 'admin') {
			license::validate();
		}
		elseif( !defined('ATMAIL_USER_COUNT') ) 
		{ 
		
			define("ATMAIL_USER_COUNT", 1);	
		
		}
	}
	
	public function initAdminController($controller)
	{
		eval(base64_decode('JGNvbnRyb2xsZXItPnZpZXctPmxpY2Vuc2VFcnJvciA9ICEoWmVuZF9SZWdpc3RyeTo6Z2V0KCdZSElJaGlqakhVSUc2NTc2NWdsaGlISGlrVXRGR1VoakZkZicpKTs='));  
	}
}
