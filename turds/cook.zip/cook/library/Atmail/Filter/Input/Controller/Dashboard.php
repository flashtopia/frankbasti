<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

/**
 * Defines filters and validators for the Dashboard controller
 */
class Atmail_Filter_Input_Controller_Dashboard extends Atmail_Filter_Input
{  
    public function __construct($action, $params)
    {
    	$_filters = array(
	        'logsearch' => array(       
				'filter' => 'StripTags',
				'log' => new Zend_Filter_Callback('validateLog'),
				'index' => 'Digits',
				'Range' => 'Digits',
				'type' => 'Digits',
			),
		);
		$_validators = array();
		
        $filters    = (isset($_filters[$action]))? $_filters[$action] : array();
        $validators = (isset($_validators[$action]))? $_validators[$action] : array();
        parent::__construct($filters, $validators, $params);
        
    }
}
