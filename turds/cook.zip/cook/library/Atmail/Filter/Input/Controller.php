<?php
/**
 * Class used to load filters for controllers
 *
 * @category   Atmail
 * @package    Atmail_Filter_Input
 * @copyright  Copyright (c) NetBased Software pty ltd
 * @author     Brad Kowalczyk <brad@staff.atmail.com>
 */

/**
 * @category   Atmail
 * @package    Atmail_Filter_Input
 * @copyright  Copyright (c) NetBased Software pty ltd
 */
 class Atmail_Filter_Input_Controller
 {    
    public function __construct()
    {
		throw new Zend_Exception('Atmail_Filter_Input_Controller cannot be instantiated as an object. Use Atmail_Filter_Input_Controller::filterInput()');
	}
    
    static public function filterInput(&$request)
    {
		if (!($request instanceof Zend_Controller_Request_Abstract)) 
		{
    		throw new Zend_Exception('No request object passed for filter class');
		}
        
        $params = $request->getParams();
		$controller = ucfirst($request->getControllerName());
        $class = "Atmail_Filter_Input_Controller_{$controller}";
        $filter = new $class($request->getActionName(), $params);
        $filter->setDefaultEscapeFilter('StringTrim');
	    //Zend_Registry::get('log')->debug("Setting up filtering for " . $class . " : " . $request->getActionName());
			
        foreach ( $params as $k => $v ) 
		{
			// Avoid messing with module, controller or action values
            if ($k == 'module' || $k == 'controller' || $k == 'action') 
			{
    			continue;
			}
            
            if (is_string($k)) 
			{
    			$params[$k] = $filter->getEscaped($k);
			}                                                                                                                  
        }
        
        $request->setParams($params);
        
        return $filter;

    }
		
 }
 