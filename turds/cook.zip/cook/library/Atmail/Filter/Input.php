<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

class Atmail_Filter_Input extends Zend_Filter_Input
{
	private $debug = false;
	
    public function __construct($filterRules, $validatorRules, &$data = null, array $options = null)
    {
	    if( ($data instanceof Zend_Controller_Request_Abstract) )
		{
			$params = $data->getParams();
			$filter = parent::__construct($filterRules, $validatorRules, $params, $options);
			$params = (Array)$filter;
			$data->setParams($params);
		}
		else
		{
			if($this->debug)
			{
				if(!count($filterRules))
				{
					// no filter rules set !
					Zend_Registry::get('log')->debug("NO FILTER RULES SET FOR " . $data['action'] ." IN " . "Atmail_Filter_Input_Controller_" . $data['controller']);	
				}
				if(!count($validatorRules))
				{
					// no filter rules set !
					Zend_Registry::get('log')->debug("NO VALIDATOR RULES SET FOR " . $data['action'] ." IN " . "Atmail_Filter_Input_Controller_" . $data['controller']);	
				}
			}
			parent::__construct($filterRules, $validatorRules, $data, $options);
		}
    }
    
    /**
     * Get all escaped data
     *
     * @param return array
     */
    public function getEscapedData()
    {
        $escaped = array();
        foreach (array_keys($this->_data) as $k) {
            $escaped[$k] = $this->getEscaped($k);
        }
        
        return $escaped;
    }
}

function validateLog($in)
{
	require_once('log.php');
	$AtmailLogTypes = array( 
		AtmailLogType::Log_Login,
		AtmailLogType::Log_RecvMail,
		AtmailLogType::Log_SendMail,
		AtmailLogType::Log_Spam,
		AtmailLogType::Log_Virus,
		AtmailLogType::Log_Error
	);
	foreach($AtmailLogTypes as $LogType)
	{
		if($in == $LogType)
		{
			return $LogType;
		}	
	}
	return AtmailLogType::Log_Login;	
}