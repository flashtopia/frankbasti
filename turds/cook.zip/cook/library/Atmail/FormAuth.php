<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

class Atmail_FormAuth
{
	static public function authenticated($requiredLevel = null, $requiredUser = null, $requiredGroup = null, $requiredResourceAccessAuthority = null)
	{
		//TODO: finalize implimentation of remaining AC
		if( isset($requiredLevel) || isset($requiredGroup) || isset($requiredUser) || isset($requiredResourceAccessAuthority) ) 
		{
			$identity = Zend_Auth::getInstance()->getIdentity();
			if( !isset($identity->Username) )
			{
				Zend_Registry::get('log')->info('No Authenticated user found for session');  
			}
		} 
		else
		{
			$identity = Zend_Auth::getInstance()->getIdentity();
		}

		$dbAdapter = Zend_Registry::get('dbAdapter');
		
		if( !empty($identity['Account']) ) 
		{
			$select = $dbAdapter->select()
								->from("Users")
								->join("UserSettings", "Users.Account = UserSettings.Account")
								->where("Users.Account = " . $dbAdapter->quote($identity['Account'])); 
			
			$userDataRows = $select->query()->fetchAll();
			if(isset($userDataRows) && isset($userDataRows[0]))
			{
				Zend_Registry::set('UserSettings', $userDataRows[0]);	
				Zend_Registry::set('Account', $userDataRows[0]['Account']);
			
				// Setup the users language environment
				Atmail_Locale::setupLocaleAndTranslation( $userDataRows[0]['Language'] ); //!!!this is in a confusing and hard to find place. this method should ONLY return true or false, NOT set up hard to debug ENV
	    
				// Load users Timezone
				if(isset($userDataRows[0]['TimeZone']))
				{
					date_default_timezone_set($userDataRows[0]['TimeZone']);
				}
			}
		}	
		return Zend_Auth::getInstance()->hasIdentity();  
	}
} 
