<?php

require_once('library/Atmail/Utility.php');
require_once('library/Atmail/Deps/DepCheck.php');

/******************************************* UPDATE UTILITIES **************************************************/

function extract_default_config_spamassassin()
{	
	// Extract and configure the default Spamassassin files 
	if( !is_dir("/usr/local/atmail/spamassassin/etc/") )
	{
		system("mkdir /usr/local/atmail/spamassassin/etc/");
	}
	if( !is_dir("/usr/local/atmail/spamassassin/etc/mail") )
	{
		system("mkdir /usr/local/atmail/spamassassin/etc/mail");
	}
	if( !is_dir("/usr/local/atmail/spamassassin/etc/mail/spamassassin") )
	{
		system("mkdir /usr/local/atmail/spamassassin/etc/mail/spamassassin");
	}
	
	// Config files
	system("cp /usr/local/atmail/server_source/etc/atmail.cf /usr/local/atmail/spamassassin/etc/mail/spamassassin/atmail.cf");
	system("cp /usr/local/atmail/server_source/etc/local.cf /usr/local/atmail/spamassassin/etc/mail/spamassassin/local.cf");
	
	// Configuration .pre files
	system("cp /usr/local/atmail/server_source/etc/init.pre /usr/local/atmail/spamassassin/etc/mail/spamassassin/init.pre");
	system("cp /usr/local/atmail/server_source/etc/v310.pre /usr/local/atmail/spamassassin/etc/mail/spamassassin/v310.pre");
	system("cp /usr/local/atmail/server_source/etc/v312.pre /usr/local/atmail/spamassassin/etc/mail/spamassassin/v312.pre");
	system("cp /usr/local/atmail/server_source/etc/v320.pre /usr/local/atmail/spamassassin/etc/mail/spamassassin/v320.pre");
	system("cp /usr/local/atmail/server_source/etc/v330.pre /usr/local/atmail/spamassassin/etc/mail/spamassassin/v330.pre"); 
	
	// Copy the SA update (signature/rulesets) from a tgz downloaded from saupdates.atmail.com (defaults, sa-updated after if net) 
 	echo "\nExtracting default SA rulesets ..."; 
 	$output = `tar xfvz /usr/local/atmail/server_source/sa-update-config.tgz -C /usr/local/atmail//spamassassin/var/spamassassin/ >/dev/null 2>&1`; 
 	echo "\n"; 	
}

/**
 * Install a module
 */
function install_module($name, $options)
{
	$admin_email = array_key_exists('admin_email', $options) ? $options['admin_email'] : '';
	$verbose = array_key_exists('verbose', $options) ? $options['verbose'] : false;
	$version = array_key_exists('version', $options) ? $options['version'] : '';
	$reinstall_deps = array_key_exists('reinstall_deps', $options) ? $options['reinstall_deps'] : false;

	$results = array();
	$perlmod = $name;
	$perlmod = str_replace('-', '::', $perlmod);

	if($version)
	{
		$perlmod = $perlmod . ' ' . $version;
	}
	if($perlmod == 'MailTools')
	{
		$perlmod = 'Mail::Address';
	}
 	else if($perlmod == 'TimeDate')
	{
		$perlmod = 'Date::Format';
	}
	
	// Check we are installed already, if so, skip
	system("perl -e 'use $perlmod' > /dev/null 2>&1", $return);
	if(!$return && !$reinstall_deps)
	{
		return;
	}
	
	fwrite(STDOUT, "\nInstalling module $name ...\n");

	// Just in case ...
	system("cd /usr/local/atmail/server_source/perlmodules/$name ; make clean >/dev/null 2>&1");

	$extra = '';

	if($name == 'Net-DNS')
	{
		$extra = '--no-online-tests';
	}
	else
	{
		if($name == 'LWP')
		{
			$extra = '-n';
		}
	}

	if($name == 'sa-atmail')
	{
		install_module('Digest-SHA', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('Digest-SHA1', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('LWP', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('IP-Country', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));

		install_module('Package-Constants', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('ExtUtils-CBuilder', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('Digest-HMAC', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('Net-IP', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('Net-DNS', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('IO-Zlib', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps, 'version' => '1.04'));
		install_module('IO-Compress', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('Text-Diff', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('Time-HiRes', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('IO-Compress', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('Net-Ident', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('IO-Socket-SSL', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('Encode-Detect', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('Archive-Tar', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));

		// Install the SPF package
		install_module("Sys-Hostname-Long", array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module("Net-CIDR", array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module("Module-Build", array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));

		// Check DBD::mysql and DBI are setup, get return codes, shell outputs to STDERR so we can't tell if successful
		install_module("DBI", array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('DBD-mysql', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));

		// New dep for SA 3.3.2
		install_module('NetAddr-IP', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		
		// New dep for SA 3.3.2 using the Mail DKIM module
		install_module('Crypt-OpenSSL-Random', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('Crypt-OpenSSL-RSA', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module('TimeDate', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps)); // Dep for MailTools
		install_module('MailTools', array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps)); // Dep for Mail-DKIM
		install_module("Mail-DKIM", array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps, 'version' => '0.39')); // Now we can finally install
		
		// New dep for SA 3.3.2 using Mail SPF module
		install_module("Net-DNS-Resolver-Programmable", array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module("Error", array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps));
		install_module("Mail-SPF", array('admin_email' => $admin_email, 'verbose' => $verbose, 'reinstall_deps' => $reinstall_deps)); // Now we can finally install		
		
		if(strpos(strtolower(PHP_OS), 'freebsd') !== false)
		{
			if($verbose)
			{
				system("export LANG=C ; cd /usr/local/atmail/server_source/perlmodules/sa-atmail ;perl Makefile.PL CONTACT_ADDRESS={$admin_email} PREFIX=/usr/local/atmail/spamassassin/ ; make ; make install");
			}
			else
			{
				print ".";
				system("export LANG=C ; cd /usr/local/atmail/server_source/perlmodules/sa-atmail ;perl Makefile.PL CONTACT_ADDRESS={$admin_email} PREFIX=/usr/local/atmail/spamassassin/ > /dev/null 2>&1;");
				print ".";
				system("export LANG=C ; cd /usr/local/atmail/server_source/perlmodules/sa-atmail; make > /dev/null 2>&1;");
				print ".";
				system("export LANG=C ; cd /usr/local/atmail/server_source/perlmodules/sa-atmail; make install > /dev/null 2>&1;");
				print ".";
			}				
		}
		else
		{
			if($verbose)
			{
				system("export LANG=C ; cd /usr/local/atmail/server_source/perlmodules/$name ; perl Makefile.PL INSTALLDIRS=vendor CONTACT_ADDRESS={$admin_email} PREFIX=/usr/local/atmail/spamassassin/ ; make ; make install");
			}
			else
			{
				print ".";
				system("export LANG=C ; cd /usr/local/atmail/server_source/perlmodules/$name ; perl Makefile.PL INSTALLDIRS=vendor CONTACT_ADDRESS={$admin_email} PREFIX=/usr/local/atmail/spamassassin/ > /dev/null 2>&1;");
				print ".";
				system("export LANG=C ; cd /usr/local/atmail/server_source/perlmodules/$name ; make > /dev/null 2>&1;");
				print ".";
				system("export LANG=C ; cd /usr/local/atmail/server_source/perlmodules/$name ; make install > /dev/null 2>&1;");
				print ".";
			}
		}
		
		extract_default_config_spamassassin();
		// Run sa-update to get the latest signatures 
		echo "\n"; 
		echo "Updating Anti-spam signatures from the network, please standby.\n"; 
		system("/usr/local/atmail/spamassassin/bin/sa-update --channel saupdates.atmail.com --nogpg"); 
		echo "Complete\n";		
	}
	else
	{
		if($verbose)
		{
			system("export LANG=C ; cd /usr/local/atmail/server_source/perlmodules/$name ; perl Makefile.PL $extra ; make ; make install");
		}
		else
		{
			print ".";
			system("export LANG=C ; cd /usr/local/atmail/server_source/perlmodules/$name ; perl Makefile.PL $extra > /dev/null 2>&1;");
			print ".";
			system("export LANG=C ; cd /usr/local/atmail/server_source/perlmodules/$name ; make > /dev/null 2>&1;");
			print ".";
			system("export LANG=C ; cd /usr/local/atmail/server_source/perlmodules/$name ; make install > /dev/null 2>&1;");
			print ".";
		}
	}
	if($name == "Mail-SPF-Query")
	{
		system('perl -e "use DBD::mysql"', $return);
	}
	// Check the library was successfully installed
	else if($name == "DBD-mysql")
	{
		system('perl -e "use DBD::mysql"', $return);
		if($return)
		{
$msg = <<<EOF

** The perl DBD::Mysql module for connecting to the SQL database was not
correctly installed.

This module is needed by SpamAssassin.

Verify you have a valid installation of MySQL on your server. Check you have
the MySQL development librarys available ( the mysql.h , and libmysqlclient
library ) . These can be freely obtained from http://mysql.com/ if missing on
your system. Or use the package manager for your OS to install the mysql-devel
package.

Before proceeding with the installation of the Anti-Spam plugin your MySQL
installation must be updated with the development librarys.

EOF;

			fwrite(STDOUT, $msg);
		}
	}
}

function _republishSA($opts)
{
	if(isset($opts['rebuild']))
	{
		$opts['reinstall_deps'] = false; // Only install the missing deps, from the Perl eval
		install_module("DBI", array('admin_email' => $opts['admin_email'], 'verbose' => $opts['verbose'], 'reinstall_deps' => $opts['reinstall_deps'], 'version' => $opts['version']));
		install_module('DBD-mysql', array('admin_email' => $opts['admin_email'], 'verbose' => $opts['verbose'], 'reinstall_deps' => $opts['reinstall_deps'], 'version' => $opts['version']));
		`tar xfvz /usr/local/atmail/server_source/spamassassinatmail.tgz -C /usr/local/atmail/server_source/perlmodules/ >/dev/null 2>&1`;
		install_module('sa-atmail', array('admin_email' => $opts['admin_email'], 'verbose' => $opts['verbose'], 'reinstall_deps' => $opts['reinstall_deps'], 'version' => $opts['version']));

		// Check DBD::mysql OK
		install_module('DBD-mysql', array('admin_email' => $opts['admin_email'], 'verbose' => $opts['verbose'], 'reinstall_deps' => $opts['reinstall_deps'], 'version' => $opts['version']));
		config::publishServerConfigFiles('spamassassin');
		config::modifyDbConfigInExistingServerConfigFiles();
	}
}

function _republishDovecot($opts)
{
	if(isset($opts['updatessl']))
	{
		if(file_exists("/usr/local/atmail/mailserver/ssl/private/dovecot.pem"))
		{
			echo "Updating IMAP SSL key..\n";
			rename("/usr/local/atmail/mailserver/ssl/private/dovecot.pem", "/usr/local/atmail/mailserver/ssl/private/dovecot.key");

			$dovecot['imapssl_key'] = "/usr/local/atmail/mailserver/ssl/private/dovecot.key";
			config::save('dovecot', $dovecot);
		}
	}
	
	if(isset($opts['updateAuth']))
	{
		echo "Copying new Dovecot Auth configuration file over old..\n";
		$output = `cp /usr/local/atmail/server_source/etc/dovecot-users-sql.conf /usr/local/atmail/mailserver/etc/dovecot-users-sql.conf`;
		echo $output . "\n";	
	}
	
	if(isset($opts['rebuild']))
	{
		echo "Rebuilding Dovecot..\n";
		system("php /usr/local/atmail/server_source/scripts/buildpop3imap.php");
	}
	
	echo "Publishing POP3/IMAP settings..\n";
	
	echo "Copying new Dovecot configuration file(s)..\n";
	$output = `cp /usr/local/atmail/server_source/etc/dovecot.conf /usr/local/atmail/mailserver/etc/dovecot.conf`;
	system("chown atmail /usr/local/atmail/mailserver/etc/dovecot.conf");

	if(isset($opts['updateAll']))
	{
		$output = `cp /usr/local/atmail/server_source/etc/dovecot-ldap.conf /usr/local/atmail/mailserver/etc/dovecot-ldap.conf`;
		system("chown atmail /usr/local/atmail/mailserver/etc/dovecot-ldap.conf");	
		$output = `cp /usr/local/atmail/server_source/etc/dovecot-sql.conf /usr/local/atmail/mailserver/etc/dovecot-sql.conf`;
		system("chown atmail /usr/local/atmail/mailserver/etc/dovecot-sql.conf");
		$output = `cp /usr/local/atmail/server_source/etc/dovecot-users-sql.conf /usr/local/atmail/mailserver/etc/dovecot-users-sql.conf`;
		system("chown atmail /usr/local/atmail/mailserver/etc/dovecot-users-sql.conf");
		config::publishServerConfigFiles('dovecotsql');	
		config::modifyDbConfigInExistingServerConfigFiles();
	}
	
	if(isset($opts['updateSQL']))
	{
		echo "Publishing Dovecot settings to new configure file..\n";
		config::publishServerConfigFiles('dovecotsql');	
		config::modifyDbConfigInExistingServerConfigFiles();
	}
	
	config::publishServerConfigFiles('dovecot');	
	
}

function _republishExim($opts)
{
	if(isset($opts['rebuild']))
	{
		echo "Rebuilding Exim..\n";
		system("php /usr/local/atmail/server_source/scripts/buildexim.php");
	}
	
	echo "Copying new configuration file template over old..\n";
	$output = `cp /usr/local/atmail/server_source/etc/configure.a6 /usr/local/atmail/mailserver/configure`;
	echo $output . "\n";

	echo "Publishing Exim settings to new configure file..\n";
	config::publishServerConfigFiles('exim');
	config::modifyDbConfigInExistingServerConfigFiles();
	system("chown atmail /usr/local/atmail/mailserver/configure");

}

function _republishAv($opts)
{
	if(isset($opts['rebuild']))
	{
		echo "Rebuilding ClamAV ...\n";
		system('php /usr/local/atmail/server_source/scripts/buildav.php');
	}
	
	echo "Copying new ClamAV configuration files ...\n";
	$output = `cp /usr/local/atmail/server_source/etc/clamd.conf /usr/local/atmail/av/etc/clamd.conf`;
	system("chown atmail /usr/local/atmail/av/etc/clamd.conf");

	$output = `cp /usr/local/atmail/server_source/etc/freshclam.conf /usr/local/atmail/av/etc/freshclam.conf`;
	system("chown atmail /usr/local/atmail/av/etc/freshclam.conf");
	
	/* Let cron pick this up, uses Bayes scan and heavier
	if(file_exists("/etc/cron.daily/atmail-automation.php"))	{
		echo "Updating AV signatures ...\n";
		system("/etc/cron.daily/atmail-automation.php");
		
	} elseif( file_exists("/etc/periodic/daily/502.atmail-automation.php"))	{
		echo "Updating AV signatures ...\n";
		system("/etc/periodic/daily/502.atmail-automation.php");
		
	}
	*/
	
}

function _sanityCheckInstallation($versionCurrentlyConfigured, $versionCurrentLocalCodebase)
{
	if($versionCurrentlyConfigured == false)
	{
	    exit("Cannot determine previous version (" . generateVersionString($versionCurrentlyConfigured) . "), please run: php server-update.php [old-version-number]\n");
	}
	else
	{
		echo "Installed version detected as: " . generateVersionString($versionCurrentlyConfigured, true) . "\n";
	}

	if($versionCurrentLocalCodebase == false)
	{
	    exit("Cannot determine new version (" . generateVersionString($versionCurrentLocalCodebase, true) . "). Aborting.\n");
	}
	else
	{
		echo "New version detected as: " . generateVersionString($versionCurrentLocalCodebase, true) . "\n";
	}

	if ( version_compare(PHP_VERSION, '5.1.6', '<') )
	{
		//TODO: can we update php as part of the process
		// you may beed to drop this into future updates requiring newer version of PHP. might be better to update to highest version needed, but then cant gracefully handle failing half way through update (wont have a clear, expected fail point)
	    exit ('PHP must be updated to 5.1.6 or newer, currently running version of PHP is: ' . PHP_VERSION . "\n");
	}	
}

function _findCalendarServerSource()
{
	if( is_dir('/usr/local/atmail/server_source/calendar_server/src/') )
	{
		$calendarSrcPath = '/usr/local/atmail/server_source/calendar_server/src/';
	}
	else if( is_dir('../server_sources/calendar_server/src/') )
	{
		$calendarSrcPath = '../server_source/calendar_server/src/';
	}
	else
	{
		exit("Unable to find calendar server source directory. Aborting.\n");
	}

	$calendarSrcPath = realpath($calendarSrcPath) .'/';
	echo "Found calendar server installation at : " . $calendarSrcPath;

	return $calendarSrcPath;
}

function _mountCalendarServer($mount = true)
{
	if( file_exists('/usr/local/atmail/calserver.img') )
	{
		// calendar is special
		if($mount)
		{
			echo "Mounting calendar server image..";
			system("mount -o rw,loop,user_xattr /usr/local/atmail/calserver.img /usr/local/atmail/calendarserver");
		}
		else
		{
			echo "Unmounting calendar server image..";
			system("umount -rd /usr/local/atmail/calendarserver");
		}
	}	
}

function _patchCalendarServer()
{
	$output=false;

	_mountCalendarServer();
	$calendarSrcPath = _findCalendarServerSource();

	if (file_exists('/usr/local/atmail/calendarserver/server/run'))
	{
		echo "Patching calendar server\n";
		foreach(array('aggregate.py', 'calendar.py', 'directory.py', 'md5crypt.py', 'principal.py', 'sqldb.py', 'sql.py') as $file)
		{
			copy($calendarSrcPath . 'patches/' . $file, '/usr/local/atmail/calendarserver/server/patches/' . $file);
		}

		echo "Warning : Replacing calendar server configuration file. If you have a custom setup you may need to merge your changes.\n";
		echo "Old configuration file is found at /usr/local/atmail/calendarserver/server/conf/caldavd-dev.plist\n";
		copy('/usr/local/atmail/calendarserver/server/conf/caldavd-dev.plist', '/usr/local/atmail/calendarserver/server/conf/caldavd-dev.plist.old');
		copy($calendarSrcPath . 'conf/caldavd-dev.plist', '/usr/local/atmail/calendarserver/server/conf/caldavd-dev.plist');
		copy ($calendarSrcPath . 'patch_server.sh', '/usr/local/atmail/calendarserver/server/patch_server.sh');

		chdir('/usr/local/atmail/calendarserver/server');
		$output = `sh patch_server.sh`;
		echo $output . "\n";
	}
	else
	{
		echo "Warning : Unable to find calendar server to patch.";
	}

	_mountCalendarServer(false);

	return $output;
}

function _reinstallCalendarServer()
{
	$output = false;
	_mountCalendarServer();
	$calendarSrcPath = _findCalendarServerSource();

	if( file_exists('/usr/local/atmail/calendarserver/server/run') || file_exists('/usr/local/atmail/calserver.img') )
	{

		echo "Updating Calendar Server\n";
		chdir('/usr/local/atmail/server_source/calendar_server');

		$path = realpath("../../webmail/config");

		// reset the installation
		system("sh /usr/local/atmail/server_source/calendar_server/reset_installation.sh");

		// Auto install
		if( file_exists($path) )
		{
			system("sh calserver-install.sh $path /usr/local/atmail/calendarserver 8008 1");
		}
		else
		{
			$path = "/var/www/html/";
			// Prompt the user where to find dbconfig.ini
			system("sh calserver-install.sh $path /usr/local/atmail/calendarserver 8008 1 1");
		}

		$output=true;
	}
	_mountCalendarServer(false);

	return $output;
}

function _controlServerServices($start = true)
{
	if( file_exists("/etc/init.d/atmailserver") )
	{
		if($start)
		{
			$output = `/etc/init.d/atmailserver start`;
		}
		else
		{
			$output = `/etc/init.d/atmailserver stop`;
		}
		echo $output . "\n";
	}
	else if ( file_exists("/etc/init.d/atmailcalendarserver") )
	{
		if($start)
		{
			$output = `/etc/init.d/atmailcalendarserver start`;
		}
		else
		{
			$output = `/etc/init.d/atmailcalendarserver stop`;
		}
		echo $output . "\n";
	}
}

function _updateStartupScripts()
{

    echo "Updating Atmail service startup script\n";	
    $locations = array(
        '/etc/init.d/atmailserver',
        '/etc/rc.d/atmailserver',
        '/usr/local/etc/rc.d/z-atmailserver.sh',
    );

    $found = null;
    foreach($locations as $location)
	{
     
        if (file_exists(dirname($location)))
		{
            echo "Using directory $location.\n";
            $found = $location;
            break;
        }
        
    }
    if (!$found)
	{
        echo "Please copy the /usr/local/atmail/server_source/scripts/atmailserver.sysvinit to your system startup file\n";
        return;
    }
  
    system("cp -f /usr/local/atmail/server_source/scripts/atmailserver.sysvinit $found");
    system("chmod 755 $found");

	$locations = array(
		'/etc/init.d/atmailcalendarserver',
		'/etc/rc.d/atmailcalendarserver',
		'/usr/local/etc/rc.d/z-atmailcalendarserver.sh',
	);
	foreach($locations as $location)
	{
		if(is_file($location))
		{
			echo "Removing legacy script $location.\n";
			unlink($location);
		}
	}


}
