<?php

/**
 * This object is used by the LocalClient
 *
 * By overriding the HTTP_Response object, we can capture the entire response. 
 * The standard response object will just output it straight to the browser, 
 * and we don't want this.
 * 
 * @package Atmail
 * @subpackage Dav 
 * @copyright Copyright (C) 2011 Atmail Inc. All rights reserved.
 * @author Evert Pot (http://www.rooftopsolutions.nl/) 
 */
class Atmail_Dav_LocalClientResponse extends Sabre_HTTP_Response {

     public $status;
     public $headers = array();
     public $body;

     public function sendStatus($code) {
        $this->status = $this->getStatusMessage($code);
     }

     public function setHeader($name, $value, $replace = true) {

        if ($replace) {
            
            foreach($this->headers as $k=>$val) {
                if (stripos($val, $name . ':')===0) {
                    unset($this->headers[$k]);
                    break;
                }
            }

        }
        $this->headers[] = $name . ':' . $value;

     }

     public function sendBody($body) {

        $this->body = $body;

     }


}
