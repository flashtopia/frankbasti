<?php

/**
 * Atmail Principals Backend
 *
 * Principals in WebDAV terms are users or groups. We're overriding the default 
 * SabreDAV backend because we need to inject delegation/proxy related stuff. 
 * 
 * @package Atmail
 * @subpackage Dav 
 * @copyright Copyright (C) 2011 Atmail. All rights reserved.
 * @author Evert Pot (http://www.rooftopsolutions.nl/) 
 */
class Atmail_Dav_Backend_Principals extends Sabre_DAVACL_PrincipalBackend_PDO {

    /**
     * Read mode
     */
    const READ = 1;

    /**
     * Read-write mode
     */
    const WRITE = 2;

    /**
     * Returns the list of principals in a group.
     *
     * This is only supported for 
     * calendar-delegation/###/principal/calendar-proxy-* urls.
     * 
     * @param string $principal 
     * @return array 
     */
    public function getGroupMemberSet($principal) {

        // We only ever allow fetching the group-member-set for
        // calendar-delegation principals
        if (!preg_match('|^calendar-delegation/([0-9]+)/principal/calendar-proxy-(read|write)$|', $principal, $matches)) {
            return array();
        }

        $stmt = $this->pdo->prepare('SELECT principals.uri as uri FROM calendarDelegates LEFT JOIN principals ON calendarDelegates.principalid = principals.id WHERE calendarid = ? AND mode = ?');

        $stmt->execute(array(
            $matches[1], 
            $matches[2]==='read'?self::READ:self::WRITE
        ));
        $result = $stmt->fetchAll();

        $response = array();
        foreach($result as $row) {
            $response[] = $row['uri'];
        }

        return $response;

    }

    /**
     * Returns the list of groups a principal belongs to 
     * 
     * @param string $principal 
     * @return array 
     */
    public function getGroupMembership($principal) {
		$principal = $this->getPrincipalByPath($principal);
        if (!$principal) return array();
   		$response = Atmail_Cache::fetch(Atmail_Cache::TYPE_DAV, $principal['uri'] . $principal['id']);
		if($response === false)
		{
	    $stmt = $this->pdo->prepare('SELECT calendarid, mode FROM calendarDelegates WHERE principalid = ?');
        $stmt->execute(array($principal['id']));
        $result = $stmt->fetchAll();

        $response = array();
        foreach($result as $row) {
            if ($row['mode'] == self::READ) {
                $response[] = 'calendar-delegation/' . $row['calendarid'] . '/principal/calendar-proxy-read';
            } else if ($row['mode'] == self::WRITE) {
                $response[] = 'calendar-delegation/' . $row['calendarid'] . '/principal/calendar-proxy-write';
            } else {
                throw new Sabre_DAV_Exception('Incorrect mode for principal in calendarDelegates table');
            }
        }
			// use a _very_ short cache timeout here, delegates can change without warning
			Atmail_Cache::store(Atmail_Cache::TYPE_DAV, $principal['uri'] . $principal['id'], $response, 2);
		}

        return $response;
    }

    /**
     * Updates the list of members for a group-principal
     * 
     * @param string $principal 
     * @param array $groupMembers 
     * @return void
     */
    public function setGroupMemberSet($principal, array $groupMembers) {

        // We only ever allow setting the group-member-set for
        // calendar-delegation principals
        if (!preg_match('|^calendar-delegation/([0-9]+)/principal/calendar-proxy-(read|write)$|')) {
            throw new Sabre_DAV_Exception_Forbidden('We don\'t allow setting the group-member-set for this principal');
        }
        throw new Sabre_DAV_Exception_NotImplemented('This method is currently not implemented');

    }

}
