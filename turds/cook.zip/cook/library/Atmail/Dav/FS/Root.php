<?php

/**
 * Atmail FS Root
 *
 * 
 * @package Atmail
 * @subpackage Dav 
 * @copyright Copyright (C) 2011 Atmail. All rights reserved.
 * @author Allan Wrethman
 */
class Atmail_Dav_FS_Root extends Atmail_Dav_FS_Directory {

function getName() 
{

	return 'webfiles';

}

}