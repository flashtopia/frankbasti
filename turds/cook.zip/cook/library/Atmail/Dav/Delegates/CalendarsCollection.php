<?php

/**
 * Atmail Calendar Delegates 'CalendarHome' node.
 * 
 * This node is responsible for populating the 
 * 'calendar-delegates/[principalname]' node. 
 * 
 * @package Atmail
 * @subpackage Dav 
 * @copyright Copyright (C) 2011 Atmail. All rights reserved.
 * @author Evert Pot (http://www.rooftopsolutions.nl/) 
 */
class Atmail_Dav_Delegates_CalendarsCollection extends Sabre_DAV_Directory implements Sabre_DAV_ICollection {

	private $principalInfo;

	function __construct(array $principalInfo) {

		$this->principalInfo = $principalInfo;

	}

	function getName() {

		list(, $name) = Sabre_DAV_URLUtil::splitPath($this->principalInfo['uri']);
		return $name;

	}

	function getChildren() {

		return array(
            new Atmail_Dav_Delegates_CalendarsReadable($this->principalInfo),
            new Atmail_Dav_Delegates_CalendarsWriteable($this->principalInfo),
        );

	}

}

?>
