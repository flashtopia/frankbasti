=== Calendar Delegation README ===

Calendar delegation is a bit complicated, so it warrants some high-level
documentation.

Calendar delegation support in iCal and iOS is done through the semi-
propriatary caldav-proxy specification. One of it's limitations is that it is
only possible to delegate entire accounts (either as read-only or read-write).

In Atmail it was a requirement to allow for per-calendar delegation, so in
order to achieve this without breaking delegation features in iCal, we needed
to find a workaround.

The solution is to create new principals for every single calendar. Access can
now be given to these 'fake' principals.

This results in a CalDAV directory structure such as:

calendar-delegation/[calendar id]
calendar-delegation/[calendar id]/principal
calendar-delegation/[calendar id]/principal/calendar-proxy-read
calendar-delegation/[calendar id]/principal/calendar-proxy-write
calendar-delegation/[calendar id]/calendar

