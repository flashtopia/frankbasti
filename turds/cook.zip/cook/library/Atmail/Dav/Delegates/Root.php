<?php

/**
 * Atmail Delegates Root Collection
 *
 * This node is responsible for populating the '/calendar-delegation' url. 
 * 
 * @package Atmail
 * @subpackage Dav 
 * @copyright Copyright (C) 2011 Atmail. All rights reserved.
 * @author Evert Pot (http://www.rooftopsolutions.nl/) 
 */
class Atmail_Dav_Delegates_Root extends Sabre_DAV_Directory {

    protected $pdo;

    public $disableListing = false;

    function __construct(PDO $pdo, Sabre_DAVACL_IPrincipalBackend $principalBackend, Sabre_CalDAV_Backend_Abstract $calendarBackend) {

        $this->pdo = $pdo;
        $this->principalBackend = $principalBackend;
        $this->calendarBackend = $calendarBackend;

    }

	function getName() {

		return 'calendar-delegation';

	}

    /**
     *  This method returns a new 'Atmail_Dav_Delegates_CalendarParent for 
     *  every calendar in the system. The body of this method is largly copied 
     *  from Sabre_CalDAV_Backend_PDO::getCalendarsForUser
     * 
     * @return array 
     */
    function getChildren() {

        if ($this->disableListing) {
            throw new Sabre_DAV_Exception_MethodNotAllowed('Listing of items in this collection is not allowed');
        }

        $fields = array_values($this->calendarBackend->propertyMap);
        $fields[] = 'id';
        $fields[] = 'uri';
        $fields[] = 'ctag';
        $fields[] = 'components';
        $fields[] = 'principaluri';

        // Making fields a comma-delimited list 
        $fields = implode(', ', $fields);
        $stmt = $this->pdo->query("SELECT " . $fields . " FROM `calendars`"); 

        $calendars = array();
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

            $components = explode(',',$row['components']);

            $calendar = array(
                'id' => $row['id'],
                'uri' => $row['uri'],
                'principaluri' => $row['principaluri'],
                '{' . Sabre_CalDAV_Plugin::NS_CALENDARSERVER . '}getctag' => $row['ctag']?$row['ctag']:'0',
                '{' . Sabre_CalDAV_Plugin::NS_CALDAV . '}supported-calendar-component-set' => new Sabre_CalDAV_Property_SupportedCalendarComponentSet($components),
            );
        

            foreach($this->calendarBackend->propertyMap as $xmlName=>$dbName) {
                $calendar[$xmlName] = $row[$dbName];
            }
            $calendars[] = new Atmail_Dav_Delegates_CalendarParent($this->pdo, $this->principalBackend, $this->calendarBackend, $calendar);

        }

        return $calendars;

    }

    function getChild($name) {

        $fields = array_values($this->calendarBackend->propertyMap);
        $fields[] = 'id';
        $fields[] = 'uri';
        $fields[] = 'ctag';
        $fields[] = 'components';
        $fields[] = 'principaluri';

        // Making fields a comma-delimited list 
        $fields = implode(', ', $fields);
        $stmt = $this->pdo->prepare("SELECT " . $fields . " FROM `calendars` WHERE id = ?"); 
        $stmt->execute(array($name));

        $calendars = array();
        if(!$row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            throw new Sabre_DAV_Exception_FileNotFound('Calendar with id: ' . $name . ' could not be found');
        }


        $components = explode(',',$row['components']);

        $calendar = array(
            'id' => $row['id'],
            'uri' => $row['uri'],
            'principaluri' => $row['principaluri'],
            '{' . Sabre_CalDAV_Plugin::NS_CALENDARSERVER . '}getctag' => $row['ctag']?$row['ctag']:'0',
            '{' . Sabre_CalDAV_Plugin::NS_CALDAV . '}supported-calendar-component-set' => new Sabre_CalDAV_Property_SupportedCalendarComponentSet($components),
        );
    

        foreach($this->calendarBackend->propertyMap as $xmlName=>$dbName) {
            $calendar[$xmlName] = $row[$dbName];
        }

        return new Atmail_Dav_Delegates_CalendarParent($this->pdo, $this->principalBackend, $this->calendarBackend, $calendar);

    }

}

?>
