<?php

abstract class Atmail_Dav_Logging_Backend_Abstract implements Atmail_Dav_Logging_IBackend
{

}
