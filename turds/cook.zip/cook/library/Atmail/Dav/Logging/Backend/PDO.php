<?php

/**
 * PDO principal backend
 *
 * See the comments for Sabre_DAVACL_PrincipalBackend_PDO for general description.
 * This extended class interfaces atmail logging from the backend.
 *
 * @package Atmail
 * @subpackage DAV
 * @copyright Copyright (C) 2011 Atmail
 * @author Evert Pot (http://www.rooftopsolutions.nl/) (modified by Brett Embery (brett@staff.atmail.com))
 * @license http://code.google.com/p/sabredav/wiki/License Modified BSD License
 */
class Atmail_Dav_Logging_Backend_PDO extends Atmail_Dav_Logging_Backend_Abstract
{

	/**
     * pdo 
     * 
     * @var PDO 
     */
    protected $pdo;

    /**
     * Sets up the backend 
     * 
     * @param PDO $pdo 
     */
    public function __construct(PDO $pdo, $logTable)
    {
        $this->pdo = $pdo;
        $this->logTable = $logTable;
    } 
	
	public function log($username, $method, $url)
    {
      
        list($topPath) = explode('/',strtolower($url)); 
        switch($topPath) {

            default :
            case 'calendars' :
                $logType = 6;
                break;
            case 'addressbooks' :
            case 'directory' :
                $logType = 8;
                break;

        }

        $stmt = $this->pdo->prepare('INSERT INTO ' . $this->logTable . ' (LogDate, LogType, LogIP, Account) select NOW(), ?, ?, ? from dual where not exists(select id from ' . $this->logTable . ' where LogType=? and LogDate > DATE_SUB(NOW(), INTERVAL 1 MINUTE) and Account=?)');
        $stmt->execute(array($logType, $_SERVER["REMOTE_ADDR"], $username, $logType, $username));
    }
}
