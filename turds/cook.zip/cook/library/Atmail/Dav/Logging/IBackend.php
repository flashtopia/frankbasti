<?php

/**
 * This is the base class for any logging performed
 *
 * @package Atmail
 * @subpackage DAV
 * @copyright Copyright (C) 2011 Atmail. All rights reserved.
 * @author Brett Embery (brett@staff.atmail.com)
 * @license http://atmail.com/license
 */
interface Atmail_Dav_Logging_IBackend
{
    /**
     * @return null
     */
    function log( $username, $method, $url );
}

