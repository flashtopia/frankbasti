<?php

/**
 * Atmail Delegates Root Collection
 *
 * This node is responsible for populating the '/calendar-delegation' url. 
 * 
 * @package Atmail
 * @subpackage Dav 
 * @copyright Copyright (C) 2011 Atmail. All rights reserved.
 * @author Evert Pot (http://www.rooftopsolutions.nl/) 
 */
class Atmail_Dav_FSExt_Root extends Atmail_Dav_FSExt_Directory {

	public $_basePath;
	
	public function getName()
	{
		return "webfiles";	
	}
	
	public function getQuotaInfo() {
		$this->updatePath();
		$quotaA = $this->getFolderSize($this->path);
		$quotaB = users::getUserQuota($this->_authPlugin->getCurrentUser())*1024*1024;
		return array(
            $quotaB-$quotaA,
            $quotaB
            );
	}
	
}

?>
