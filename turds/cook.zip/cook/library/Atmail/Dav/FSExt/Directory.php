<?php

/**
 * Atmail Delegates Root Collection
 *
 * This node is responsible for populating the '/calendar-delegation' url. 
 * 
 * @package Atmail
 * @subpackage Dav 
 * @copyright Copyright (C) 2011 Atmail. All rights reserved.
 * @author Evert Pot (http://www.rooftopsolutions.nl/) 
 */
class Atmail_Dav_FSExt_Directory extends Sabre_DAV_FSExt_Directory {

    /**
     * Authentication plugin 
     * 
     * @var Sabre_DAV_Auth_Plugin
     */
    private $_authPlugin;
    private $basePath = '';
    public $disableListing = false;
    private $isRoot = false;

    function __construct(Sabre_DAV_Auth_Plugin $authPlugin, $basePath, $root = false)
    {	
    	parent::__construct($basePath);
		$this->_authPlugin = $authPlugin;		
		$this->basePath = rtrim($basePath, '/');
		$this->isRoot = $root;
    }
	
	private function updatePath()
	{
		$username = $this->_authPlugin->getCurrentUser();
		$tempfolder = $this->basePath . '/' . $username[0] . '/' . $username[1] . '/' . $username . '/';
		if(strpos($tempfolder, '..') === false && is_dir($tempfolder))
		{
			if(is_dir($tempfolder . $this->getName()))
			{
				$this->path = $tempfolder . $this->getName();
			}
		}	
	}
	
	public function createFile($name, $data = null) {
		$this->updatePath();
		$quotaInfo = $this->getQuotaInfo();
  		fseek($data, 0, SEEK_END);
  		$size = ftell($data);
  		fseek($data, 0, SEEK_SET);
		if( ((int)$quotaInfo[0] - $size) < 0 )
		{
			throw new Sabre_DAV_Exception_InsufficientStorage();
		}		
		return parent::createFile($name, $data);
	}

    public function createDirectory($name) {   	
		$this->updatePath();
		$quotaInfo = $this->getQuotaInfo();
  
  		// check directory size
		if( ((int)$quotaInfo[0] - 4) < 0 )
		{
			throw new Sabre_DAV_Exception_InsufficientStorage();
		}
		return parent::createDirectory($name);
    }
    
    public function getChild($name) {
		$this->updatePath();
		
        $path = $this->path . '/' . $name;

        if (!file_exists($path)) throw new Sabre_DAV_Exception_FileNotFound('File could not be located');
        if ($name=='.' || $name=='..') throw new Sabre_DAV_Exception_Forbidden('Permission denied to . and ..'); 

        if (is_dir($path)) {

            return new Atmail_Dav_FSExt_Directory($this->_authPlugin, $path);

        } else {

            return new Sabre_DAV_FSExt_File($path);

        }
	
    }

    public function childExists($name) {
		$this->updatePath();
		return parent::childExists($name);
	}
	
    public function getChildren() {
		$this->updatePath();
		return parent::getChildren();
	}
	
    public function delete() {
		$this->updatePath();
		return parent::delete();
	}
	
	private function getFolderSize($path, $depth = 0)
	{
	    $total_size = 4;
	    $files = scandir($path);
	    foreach($files as $t)
	    {
	        if (is_dir(rtrim($path, '/') . '/' . $t))
	        {
	            if ($t<>"." && $t<>"..")
	            {
	                $size = $this->getFolderSize(rtrim($path, '/') . '/' . $t, $depth++);
	                $total_size += $size;
	            }
	        }
	        else
	        {
	            $size = filesize(rtrim($path, '/') . '/' . $t);
	            $total_size += $size;
	        }
	    }
	    return $total_size;
	}
}

?>
