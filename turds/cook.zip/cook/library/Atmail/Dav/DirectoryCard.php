<?php

/**
 * This class represents a single contact in the global address book.
 * 
 * @package Atmail
 * @subpackage Dav 
 * @copyright Copyright (C) 2011 Atmail Inc. All rights reserved.
 * @author Evert Pot (http://www.rooftopsolutions.nl/) 
 */
class Atmail_Dav_DirectoryCard extends Sabre_DAV_File implements Sabre_CardDAV_ICard {

    /**
     * Contact info
     * 
     * @var array 
     */
    private $_cardInfo;

    /**
     * Constructor
     * 
     * @param array $cardInfo 
     */
    public function __construct(array $cardInfo) {

        $this->_cardInfo = $cardInfo;

    }

    /**
     * Returns the node name
     *
     * @return void
     */
    public function getName() {

        return $this->_cardInfo['uri'];

    }

    /**
     * Returns the vcard 
     * 
     * @return string 
     */
    public function get() {

        return $this->_cardInfo['carddata'];

    }

    /**
     * Returns the last modification timestamp
     * 
     * @return int 
     */
    public function getLastModified() {

        return $this->_cardInfo['lastmodified'];

    }

    /**
     * Returns the size of the vcard
     * 
     * @return int 
     */
    public function getSize() {

        return strlen($this->_cardInfo['carddata']);

    }

}
