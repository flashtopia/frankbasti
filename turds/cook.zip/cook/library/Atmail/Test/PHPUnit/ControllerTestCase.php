<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

abstract class Atmail_Test_PHPUnit_ControllerTestCase extends Zend_Test_PHPUnit_ControllerTestCase
{
    public function setUp() {
        $this->bootstrap = APP_BOOTSTRAP;
		//global $_SESSION;
		//$_SESSION['SID'] = '111111111111';
		//print_r($_SESSION);
        parent::setUp(); 
		$frontController = Zend_Controller_Front::getInstance();
		$frontController->addModuleDirectory( BASE_PATH . '/application/modules');
   		//$frontController->throwExceptions(true);

    }

	public function tearDown() {
		//clear all data that shouldnt persist between hits
		//basically only leave SID
	
	}
}