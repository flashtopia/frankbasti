<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/
class Atmail_Mail_Message_File extends Zend_Mail_Message_File
{
	
	//public function __construct($args)
   	//{
	//	die('<pre>' . print_r($args,true));
	//	parent::__construct($args);
	//}
	
	public function processHeaders($existingDataArray = null)
	{
		if( is_array($existingDataArray) )
			$this->_headers = array_merge($this->_headers,$existingDataArray);
		//NB Zend defines all headers as lower case unless '-' character where it is dropped and next character is Caps. wierd.
		//process headers to arrive at more human friendly headers
		$this->_headers['sizeraw'] = $this->getSize();
		$this->_headers['size'] = bytesToHumanReadable($this->_headers['sizeraw']);
		$this->_headers['dateraw'] = $this->_headers['date'];  
		$this->_headers['date'] = headerDateToLocaleDate($this->_headers['dateraw']);
		$this->_headers['epoch'] = strtotime($this->_headers['date']);
        
		//try flag as has attachment
		$this->_headers['hasattachments'] = 'no';
		$foundPart = null;
		if($this->isMultipart())
			foreach (new RecursiveIteratorIterator($this) as $part)
				if(is_attachment($part))
					$this->_headers['hasattachments'] = 'yes';
		
		//try find return-to address
		if(isset($this->_headers['reply-to']))
		{
			//do nothing
		}	
		elseif(isset($this->_headers['return-path']))
			$this->_headers['reply-to'] = $this->_headers['return-path'];
		elseif(isset($this->_headers['from']))
			$this->_headers['reply-to'] = $this->_headers['from'];
		else
			$this->_headers['reply-to'] = 'unknown';
		
		//try correct from if missing	
		if(!isset($this->_headers['from']) && isset($this->_headers['reply-to']))
			$this->_headers['from'] = $this->_headers['reply-to'];
		//clean up message-id if necessary
		if(isset($this->_headers['message-id']))
		{
			if(is_array($this->_headers['message-id']))
				$this->_headers['message-id'] = implode($this->_headers['message-id'], ', ');
			//$this->_headers['message-id'] = str_replace(array('<', '>'),'',$this->_headers['message-id']);
		}
		//sometimes no header supplied
		if(!isset($this->_headers['subject']))
			$this->_headers['subject'] = '';
		if(isset($this->_headers['to']))
		{
			//do nothing
		}	
		elseif(isset($this->_headers['envelope-to']))
			$this->_headers['to'] = $this->_headers['envelope-to'];
		else
			$this->_headers['to'] = 'unknown';
		
		if(!isset($this->_headers['content-type']))
			$this->_headers['content-type'] = 'text/plain'; //looks like some senders like apache dont define this in their plain text emails
			
		
		//perform any remaining processing that requires searching _headers
		
		//try flag as important
		$this->_headers['priority'] = 'normal';
		
		foreach ($this->_headers as $key => $value)
		{
				if ( strpos($key, 'x-priority') === 0 || strpos($key, 'x-msmail-priority') === 0 || strpos($key, 'importance') === 0)
				{
					$this->_headers['priority'] = $value;
					break; //NB this will break out on first header match
				}
				if(!is_array($value) && substr($value, 0, 1) == '<' && substr($value, -1) == '>')
					$this->_headers[$key] = substr($value, 1, -1);
				
		}
		//decode relevant to UTF-8
		$this->_headers['to'] = iconv_mime_decode($this->_headers['to'],ICONV_MIME_DECODE_CONTINUE_ON_ERROR, 'UTF-8');
		$this->_headers['from'] = iconv_mime_decode($this->_headers['from'],ICONV_MIME_DECODE_CONTINUE_ON_ERROR, 'UTF-8');
		$this->_headers['subject'] = iconv_mime_decode($this->_headers['subject'],ICONV_MIME_DECODE_CONTINUE_ON_ERROR, 'UTF-8');
		return $this->_headers;
	}
	
	//possibly overide the getHeaders function to return _headers and _processedHeaders
	public function getProcessedHeaders()
	{
		return $this->_headers;
	} 
	
	public function send()
	{
		//send via parent
		parent::send();
		//perform specific append tasks
		//TODO: move append task in here
	}
	

}