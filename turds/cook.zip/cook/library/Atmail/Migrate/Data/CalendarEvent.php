<?php

class Atmail_Migrate_Data_CalendarEvent {

	public $account;
	public $calendarName;
	public $ics;
	
	public function __call($name, $args)
    {
        $name = ucfirst($name);
        
        if (!property_exists($this, $name)) {
            throw new Exception("'$name' is an invalid property");
        }
        
        if ($args[0] === null) {
            return $this->$name;
        }
        
        $this->$name = $args[0];
    }
}
