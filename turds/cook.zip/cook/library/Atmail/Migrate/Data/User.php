<?php

class Atmail_Migrate_Data_User {

    public $name;
    public $Password;
    public $Domain;
    public $UserFirstName;
    public $UserLastName;
    public $PasswordQuestion;
    public $UserDOB;
    public $UserHomeAddress;
    public $UserHomeCity;
    public $UserHomeState;
    public $UserHomeZip;
    public $UserHomeCountry;
    public $UserQuota;
    public $Ugroup;
    public $Language;
    public $ReplyTo;
    public $Signature;
    public $TimeZone;
    
    
    public function __construct(Array $user=array())
    {
    	$this->name             = $user[0];
		$this->Password         = $user[1];
		$this->UserFirstName    = (isset($user[2])) ? ucfirst($user[2]) : '';
		$this->UserLastName     = (isset($user[3])) ? ucfirst($user[3]) : '';
		$this->PasswordQuestion = $user[4];
		$this->UserDOB          = $user[5];
		$this->UserHomeAddress  = $user[6];
		$this->UserHomeCity     = $user[7];
		$this->UserHomeState    = $user[8];
		$this->UserHomeZip      = $user[9];
		$this->UserHomeCountry  = $user[10];
		$this->UserHomePhone    = $user[11];
        $this->UserWorkPhone    = $user[12];
        $this->UserHomeMobile   = $user[13];
		$this->UserQuota        = $user[14];
		$this->Ugroup           = (isset($user[15])) ? $user[15] : 'Default';
    }
    
    public function __call($name, $args)
    {
        if ($name != "name") {
            $name = ucfirst($name);
        }
        
        if (empty($args[0])) {
            return $this->$name;
        }
        
        $this->$name = $args[0];
    }
}
