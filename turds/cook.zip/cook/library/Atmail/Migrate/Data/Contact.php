<?php

class Atmail_Migrate_Data_Contact {

	public $UserEmail;
	public $UserEmail2;
	public $UserEmail3;
	public $UserEmail4;
	public $UserEmail5;
	public $UserFirstName;
	public $UserMiddleName;
	public $UserLastName;
	public $UserTitle;
	public $UserGender;
	public $UserDOB;
	public $UserHomeAddress;
	public $UserHomeCity;
	public $UserHomeState;
	public $UserHomeZip;
	public $UserHomeCountry;
	public $UserHomePhone;
	public $UserHomeMobile;
	public $UserHomeFax;
	public $UserUrl;
	public $UserWorkCompany;
	public $UserWorkTitle;
	public $UserWorkDept;
	public $UserWorkOffice;
	public $UserWorkAddress;
	public $UserWorkCity;
	public $UserWorkState;
	public $UserWorkZip;
	public $UserWorkCountry;
	public $UserWorkPhone;
	public $UserWorkMobile;
	public $UserWorkFax;
    public $UserInfo;
    public $GroupName;

	
	public function __call($name, $args)
    {
        $name = ucfirst($name);
        
        if (!property_exists($this, $name)) {
            throw new Exception("'$name' is not a recognized Atmail contact field");
        }
        
        if ($args[0] === null) {
            return $this->$name;
        }
        
        $this->$name = $args[0];
    }
    
    public function get()
    {
        $contact = array();
        foreach (get_object_vars($this) as $p => $v) {
            if ($v === null) {
                continue;
            }
            
            $contact[$p] = $v;
        }
        
        return $contact;
    }

}
