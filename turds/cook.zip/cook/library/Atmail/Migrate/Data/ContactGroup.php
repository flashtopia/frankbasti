<?php

class Atmail_Migrate_Data_ContactGroup
{
    private $_name;
    private $_members = array();
    private $_shared = false;
    
    
    public function name($name=null)
    {
        if (is_null($name)) {
            return $this->_name;
        }
        
        $this->_name = $name;
    }
    
    public function members($members=null)
    {
        if (is_null($members)) {
            return $this->_members;
        }
        
        $this->_members = $members;
    }
}
