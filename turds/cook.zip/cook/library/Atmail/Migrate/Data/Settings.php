<?php

class Atmail_Migrate_Data_Settings {

    public $UserFirstName;
    public $UserLastName;
    public $PasswordQuestion;
    public $UserDOB;
    public $UserHomeAddress;
    public $UserHomeCity;
    public $UserHomeState;
    public $UserHomeZip;
    public $UserHomeCountry;
    public $UserQuota;
    public $Ugroup;
    public $Language;
    public $ReplyTo;
    public $Signature;
    public $TimeZone;
    public $DisplayEmailImages;
    public $SaveDrafts;
    public $RealName;
    public $MsgNum;
    
    
    public function __call($name, $args)
    {
        $name = ucfirst($name);
        
        if (!property_exists($this, $name)) {
            throw new Exception("'$name' is not a recognized Atmail user setting");
        }
        
        if ($args[0] === null) {
            return $this->$name;
        }
        
        $this->$name = $args[0];
    }
    
    public function get()
    {
        $settings = array('UserSettings' => array());
        foreach (get_object_vars($this) as $p => $v) {
            if ($v === null) {
                continue;
            }
            
            $settings['UserSettings'][$p] = $v;
        }
        
        return $settings;
    }
    
}
