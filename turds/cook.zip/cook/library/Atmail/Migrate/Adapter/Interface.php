<?php

/**
 * Defines the interface for Migrate_Adapter classes
 *
 * @author Brad Kowalczyk <brad@staff.atmail.com>
 */
 
interface Atmail_Migrate_Adapter_Interface {

/**
 * Fetch a user for migration
 * 
 * This method should also set $this->currentUser
 * so that it can be used by fetchUser(), 
 * fetchEmail(), fetchContact() and fetchCalEvent()
 *
 * @return Migrate_Data_User | false
 */
public function fetchUser();

/**
 * Fetch an email for migration
 *
 * This method should open the email store
 * for the user contained in $this->currentUser
 * (if not already open) and upon each call
 * return the next email.
 *
 * @return Migrate_Data_Email | false
 */
public function fetchEmail();

/**
 * Fetch a contact for migration
 *
 * This method should connect to/open
 * the contact store for the user contained
 * in $this->currentUser and upon each call
 * return the next contact available.
 *
 * @return Migrate_Data_Contact | false
 */
public function fetchContact();

/**
 * Fetch a calendar event for migration
 *
 * This method should connect to/open
 * the calendar store for the user contained
 * in $this->currentUser and upon each call
 * return the next item available.
 *
 * @return Migrate_Data_CalendarItem | false
 */
public function fetchCalEvent();


/**
 * Fetch a user's settings
 * 
 * This method is only ever called if a live mode migration
 * is done (ie, users are not created by the migration script and data 
 * is migrated at first login).
 * 
 * @return Migrate_Data_Settings | false
 */
public function fetchSettings();

}
