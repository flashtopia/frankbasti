<?php

class Atmail_Files_FileObject {
	
	const TYPE_FILE = 1;
	const TYPE_DIR = 2;
	
	public $path;
	public $fileName;
	public $account;
	
	public $type; // DIR or FILE
	
	public $size;
	
	public $modified;
	public $accessed;
	
	public $contentType;
	
	public $children = array();
	
	public function getContentType()
	{
		$image = 0;

		$extension = strtolower(substr($this->fileName, (strrpos($this->fileName,'.')+1) ));
		
			
		switch( $extension ) {
			case 'doc':
				$contentType = 'application/msword';
				break;
			case 'gif':
				$contentType = 'image/gif';
				$image = 1;
				break;
			case 'ics':
				$contentType = 'text/calendar';
				break;
			case 'jpg':
			case 'jpeg':
				$contentType = 'image/jpeg';
				$image = 1;
				break;
			case 'pdf':
				$contentType = 'application/pdf';
				break;
			case 'png':
				$contentType = 'image/png';
				$image = 1;
				break;
			case 'txt':
				$contentType = 'text/plain';
				break;
			case 'xls':
				$contentType = 'application/x-msexcel';
				break;
			case 'xml':
				$contentType = 'text/xml';
				break;
			case 'zip':
				$contentType = 'application/x-compressed'; //or /x-zip-compressed or /zip or /x-zip
				break;
			case 'wmv':
				$contentType = 'video/x-wmv';
				break;
			case 'xlsx':
				$contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
				break;
			case 'docx':
				$contentType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
				break;
			default:
				$contentType = 'text/plain';
		}
		
		$this->contentType = $contentType;
		return $contentType;
		
	}
	
	public function getIconName()
	{
		$iconClass = array(
			'default' => 'default', 
			'doc' => 'doc',
			'docx' => 'doc',
			'gif' => 'img',
			'gz' => 'zip',
			'html' => 'html',
			'ics' => 'ics',
			'jpg' => 'img',
			'js' => 'code',
			'message' => 'email',
			'pdf' => 'pdf',
			'php' => 'code',
			'pl' => 'code',
			'plain' => 'txt',
			'png' => 'img',
			'ppt' => 'ppt',
			'psd' => 'img',
			'rar' => 'zip',
			'rtf' => 'txt',
			'sh' => 'code',
			'tar' => 'zip',
			'tgz' => 'zip',
			'txt' => 'txt',
			'xls' => 'default',
			'xlsx' => 'default',
			'zip' => 'zip'
		);
		
		if (!preg_match('/\.(\w+)$/', basename($this->fileName), $m)) {
            return false;
        }

		if(isset($iconClass[strtolower($m[1])]))
		    $this->iconName = $iconClass[strtolower($m[1])];
		else
			$this->iconName = $iconClass['default'];
					
		return $this->iconName;
	}	
		
	
}
