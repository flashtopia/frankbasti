<?php

class Atmail_Files_Factory {
	
	static function instance($account) {
		
		return new Atmail_Files_Adapter_FileSystem($account);
		
	}
	
}