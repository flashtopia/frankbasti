<?php

class Atmail_Files_Comment {
	
	public $id;
	public $account;
	public $created;
	public $comment;
		
}