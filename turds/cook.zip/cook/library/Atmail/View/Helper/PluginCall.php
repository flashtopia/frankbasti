<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

class Atmail_View_Helper_PluginCall extends Zend_View_Helper_Abstract
{
	public function pluginCall($call, $args=array())
	{
		$return = '';
		foreach (Zend_Controller_Front::getInstance()->getPlugins() as $plugin) {
			
			// Only call custom events on Atmail_Controller_Plugin based plugins
			if( $plugin instanceof Atmail_Controller_Plugin && method_exists($plugin, $call) ) {
				$return .= (String)$plugin->$call($args);
			}
		}
		return $return;
	}
}
