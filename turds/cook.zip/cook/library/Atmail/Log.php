<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

class Atmail_Log extends Zend_Log
{
    public function __call($method, $params) {
		//superceeded by best practice setup of various loggers and levels in bootloader         
		//TODO: remove this once stabalised and generally understood         
		//hide all details of the exception from the ui and only log details if debug = 1
		//$configGlobal = Zend_Registry::get('config')->global;
		//if( !isset($configGlobal['debug']) || $configGlobal['debug'] == 0 || $configGlobal['debug'] == false || $configGlobal['debug'] == 'false' )
		//	return;		
		
		parent::__call($method, $params);
	}
	
    public function log($message, $priority) {
        //superceeded by best practice setup of various loggers and levels in bootloader
		//TODO: remove this once stabalised and generally understood         
		//hide all details of the exception from the ui and only log details if debug = 1
		//$configGlobal = Zend_Registry::get('config')->global;
		//if( !isset($configGlobal['debug']) || $configGlobal['debug'] == 0 || $configGlobal['debug'] == false || $configGlobal['debug'] == 'false' )
		//	return;		
		
		parent::log($message, $priority);
	}
	
	 
}