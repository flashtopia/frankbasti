<?php 

// Password Encryption/Decryption
//
// In MySQL-ish:
//    HEX(AES_ENCRYPT(password, key))
//    AES_DECRYPT(UNHEX(password), key)
//
// The HEX/UNHEX step allows the password to be stored in the same VARCHAR and charset
// as used by MD5 and CRYPT methods, and means non-PHP services can get at Passwords using
// raw SQL if needs be.
//
// Must use the MCRYPT_RIJNDAEL_128, not 256! MySQL only implements 128...

require_once('Atmail/Enum.php');

class Atmail_Password
{
//	public static $encodingFunction = "strhex";
//	public static $decodingFunction = "hexstr";
	public static $encodingFunction = "base64_encode";
	public static $decodingFunction = "base64_decode";
	private static $tempSecretKey = null;

	private static function hexaes_check_key_defined()
	{
		$dbConfig = Zend_Registry::get('dbConfig');
		return isset($dbConfig->database->params->masterkey) && $dbConfig->database->params->masterkey != '';	
	}
	
	public static function setTempSecretKey($secretKey)
	{
		self::$tempSecretKey = $secretKey;	
	}
	
	public static function hexaes_encrypt($sValue, $sSecretKey = null)
	{	
		if (is_null($sSecretKey))
		{
			if(is_null(self::$tempSecretKey))
			{
				$dbConfig = Zend_Registry::get('dbConfig');
				$sSecretKey = $dbConfig->database->params->masterkey;
			}
			else
			{
				$sSecretKey = self::$tempSecretKey;
			}
		}
		
		return trim(
			call_user_func(self::$encodingFunction,
			@mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $sSecretKey, $sValue, MCRYPT_MODE_ECB,
					@mcrypt_create_iv(
						@mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_ECB),
					MCRYPT_RAND)
				)
			)
		);
	}
	
	public static function hexaes_decrypt($sValue, $sSecretKey=null)
	{
		if (is_null($sSecretKey))
		{
			if(is_null(self::$tempSecretKey))
			{
				$dbConfig = Zend_Registry::get('dbConfig');
				$sSecretKey = $dbConfig->database->params->masterkey;
			}
			else
			{
				$sSecretKey = self::$tempSecretKey;
			}
		}

		return trim(
			@mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $sSecretKey, call_user_func(self::$decodingFunction, $sValue), MCRYPT_MODE_ECB,
				@mcrypt_create_iv(
					@mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_ECB),
				MCRYPT_RAND)
			)
		);
	}

	public static function sessionCryptFunction()
	{
		return function_exists('mcrypt_decrypt') 
			&& self::hexaes_check_key_defined()
			? Atmail_Enum::PASSWORD_ENCRYPTED
			: Atmail_Enum::PASSWORD_PLAIN;
	}
	
	public static function processUser($userData)
	{
		if(Zend_Registry::get('config')->global['externalUserPasswordEncryptionType'] == Atmail_Enum::PASSWORD_ENCRYPTED && users::isExternal($userData['Account']) )
		{
			$userData['password'] = self::hexaes_decrypt($userData['password']);
		}
		
		return $userData;
	}
}

function strhex($string)
{	
	$hex = '';
	for ($i = 0; $i < strlen($string); $i++)
		$hex .= sprintf('%02X', ord($string[$i]));
	return $hex;
}
	
function hexstr($hex)
{
	$string = '';
	for ($i = 0; $i < strlen($hex)-1; $i += 2)
		$string .= chr(hexdec($hex[$i].$hex[$i+1]));
	return $string;
}
	