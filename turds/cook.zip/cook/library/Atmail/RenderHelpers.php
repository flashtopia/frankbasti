<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/


function is(&$variable, $default = '') {
	return isset($variable)?$variable:$default;		
}                                    

function eis(&$variable, $default = '') {
	echo isset($variable)?$variable:$default;		
}

function jsSafe(&$string) {
	return strtr( $string, array('\\'=>'\\\\',"'"=>"\\'",'"'=>'\\"',"\r"=>'\\r', "\n"=>'\\n',+ '<'=>'\\074','>'=>'\\076','&'=>'\\046','--'=>'\\055\\055') );
}

function strip_unsafe_tags( $text )
{
    
	
	$purifier = new Atmail_Filter_HTMLPurifier;
	return $purifier->filter($text);

}

function getFoldersLinear($folders)
{
	$nodeFolders = array();
	foreach($folders AS $folder)
	{
		$nodeFolders[] = $folder;
		$subFolders = getFoldersLinear($folder);
		foreach($subFolders as $subFolder)
			$nodeFolders[] = $subFolder;
	}
	return $nodeFolders;
}

function echoKeyedOptions($array, $selected = null )
{
	foreach($array as $key => $value)
		echo '		<option value="' . $key . '"' . ($key == $selected?' selected':'') . '>' . $value . "</option>\n";
}

function spacifycamelCase($string) // spacify all caps except first and multiple consecutive caps
{
	return preg_replace( '/(\B[A-Z])(?=[a-z])|(?<=[a-z])([A-Z])/sm',' $1$2',str_replace('_', ' ', $string) );
}

function translateHash($fieldNameOrString, $translationsArray, $logMissing = false)
{
	if( array_key_exists($fieldNameOrString, $translationsArray) )
		return $translationsArray[$fieldNameOrString];
	if( $logMissing )
		Zend_Registry::get('log')->info('Translation missing for \'' . $fieldNameOrString . '\' in ' . __FILE__);
    return spacifycamelCase(ucfirst(str_replace('_',' ',$fieldNameOrString)));
}
             

function timeago($from_time, $to_time = 0, $include_seconds = false) {
	if($from_time == 0 && $to_time == 0)
		return '';
		
	if($to_time == 0)
		$to_time = time();
	$distance_in_minutes = round(abs($to_time - $from_time) / 60);
	$distance_in_seconds = round(abs($to_time - $from_time));

	if ($distance_in_minutes >= 0 and $distance_in_minutes <= 1) {
	    if (!$include_seconds) {
	        return '1 ' . Zend_Registry::get('translator')->translate('min');
			//return ($distance_in_minutes == 0) ? 'less than a minute' : '1 minute';
	    } else {
	        if ($distance_in_seconds >= 0 and $distance_in_seconds <= 4) {
	            return 'less than 5 seconds';
	        } elseif ($distance_in_seconds >= 5 and $distance_in_seconds <= 9) {
	            return 'less than 10 seconds';
	        } elseif ($distance_in_seconds >= 10 and $distance_in_seconds <= 19) {
	            return 'less than 20 seconds';
	        } elseif ($distance_in_seconds >= 20 and $distance_in_seconds <= 39) {
	            return 'half a minute';
	        } elseif ($distance_in_seconds >= 40 and $distance_in_seconds <= 59) {
	            return 'less than a minute';
	        } else {
	            return '1 min';
	        }
	    }
	} elseif ($distance_in_minutes >= 2 and $distance_in_minutes <= 44) {
	    return $distance_in_minutes . ' ' . Zend_Registry::get('translator')->translate('mins');
	} elseif ($distance_in_minutes >= 45 and $distance_in_minutes <= 89) {
	    return '1 ' . Zend_Registry::get('translator')->translate('hour');
	} elseif ($distance_in_minutes >= 90 and $distance_in_minutes <= 1439) {
	    return '' . round(floatval($distance_in_minutes) / 60.0) . ' ' . Zend_Registry::get('translator')->translate('hours');
	} elseif ($distance_in_minutes >= 1440 and $distance_in_minutes <= 2879) {
	    return '1 ' . Zend_Registry::get('translator')->translate('day');
	} elseif ($distance_in_minutes >= 2880 and $distance_in_minutes <= 43199) {
	    return '' . round(floatval($distance_in_minutes) / 1440) . ' ' . Zend_Registry::get('translator')->translate('days');
	} elseif ($distance_in_minutes >= 43200 and $distance_in_minutes <= 86399) {
	    return '1 ' . Zend_Registry::get('translator')->translate('month');
	} elseif ($distance_in_minutes >= 86400 and $distance_in_minutes <= 525599) {
	    return round(floatval($distance_in_minutes) / 43200) . ' ' . Zend_Registry::get('translator')->translate('months');
	} elseif ($distance_in_minutes >= 525600 and $distance_in_minutes <= 1051199) {
	    return '1 ' . Zend_Registry::get('translator')->translate('year');
	} else {
	    return '' . round(floatval($distance_in_minutes) / 525600) . ' ' . Zend_Registry::get('translator')->translate('years');
	}   
}

function timeAgo2($timestamp, $granularity=2, $format='Y-m-d H:i:s'){

        $difference = time() - $timestamp;
       
        if($difference < 0) return '0 seconds ago';             // if difference is lower than zero check server offset
        elseif($difference < 864000){                                   // if difference is over 10 days show normal time form
       
                $periods = array('year' => 604800,'month' => 604800,'week' => 604800,'day' => 86400,'hr' => 3600,'min' => 60,'sec' => 1);
                $output = '';
                foreach($periods as $key => $value){
               
                        if($difference >= $value){
                       
                                $time = round($difference / $value);
                                $difference %= $value;
                               
                                $output .= ($output ? ' ' : '').$time.' ';
                                $output .= (($time > 1 && $key == 'day') ? $key.'s' : $key);
                               
                                $granularity--;
                        }
                        if($granularity == 0) break;
                }
                return ($output ? $output : '0 seconds').' ago';
        }
        else return date($format, $timestamp);
}
