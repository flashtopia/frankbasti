<?php
/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

class Atmail_Config_Exception extends Zend_Exception
{
	//do custom error handling here
}

