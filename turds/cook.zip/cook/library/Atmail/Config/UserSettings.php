<?php
/**
 * Atmail
 *
 * LICENSE
 *
 * This source file is copyrighted by Atmail, full details in LICENSE.txt.
 * It is also available through the Internet at this URL:
 * http://atmail.com/license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the Internet, please send an email
 * to license@atmail.com so we can send you a copy immediately.
 *
 * @category   Atmail
 * @package    Atmail_Config_mysql
 * @copyright  Copyright (c) 2008 Atmail (http://www.atmail.com)
 * @license    http://atmail.com/license.php     Atmail Software License
 * @version    $Id: Mysql.php 2008-09-01 20:16:44Z In2Naos $
 * 
 */

/**
 * @category   Atmail
 * @package    Atmail_Config
 * @copyright  Copyright (c) 2008 Atmail (http://www.atmail.com)
 * @license    http://atmail.com/license.php     Atmail Software License
 */
class Atmail_Config_UserSettings extends Zend_Config
{

    /**
     * Loads the section $section from the config table using database credentials from $filename
     *
     * Basic table structure: section, key, value, type
     * If the $section is null, then all sections in the ini file are loaded.
     *
     * example table data:
     *      section	key	 	value		type
     *		global	debug	true		boolean
	 *		domains host	localhost	string
     *
     * after calling $data = new Zend_Config_Mysql($file, 'staging'); then
     *      $data->hostname === "staging"
     *      $data->db->connection === "database"
     *
     * The $options parameter may be provided as either a boolean or an array.
     * If provided as a boolean, this sets the $allowModifications option.
     * @param  string        $filename
     * @param  string|null   $section
     * @param  boolean		 $allowModifications
     * @throws Zend_Config_Exception
     * @return void
     */
	public function __construct()
    {
		$dbAdapter = Zend_Registry::get('dbAdapter');
		$session = new Zend_Session_Namespace(ATMAIL_NAMESPACE);
		$userData = Zend_Auth::getInstance()->getStorage()->read();
	    
		if(Atmail_FormAuth::authenticated()) {
			// Login successful, load the users preferences
			
			$select = $dbAdapter->select()
			->from("Users")
			->join("UserSettings", "Users.Account = UserSettings.Account")
			->where("Users.Account = " .  $dbAdapter->quote($userData['Account']));
			
			$userDataRows = $select->query()->fetchAll();
			
			$this->_data['UserSettings'] = $userDataRows[0];
		} else {
			$this->_data['UserSettings'] = array();
		}
		
	}
	
}