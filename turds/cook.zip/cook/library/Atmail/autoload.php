<?php

/**
 * Atmail PHP autoloader
 *
 * @package Atmail
 * @subpackage DAV
 * @copyright Copyright (C) 2007-2011 Rooftop Solutions. All rights reserved. (modifications Copyright (C) 2011 Atmail)
 * @author Evert Pot (http://www.rooftopsolutions.nl/) (modifications Brett Embery (brett@staff.atmail.com))
 * @license http://code.google.com/p/sabredav/wiki/License Modified BSD License
 */
  
function Atmail_autoload($className) {
	$loaded = false;
    if(strpos($className,'Atmail_')===0 || strpos($className,'Sabre_')===0)
    {
		list($base, $junk) = explode('_', $className, 2);
		
		$includeDirs = get_include_path();
		$currentDir = dirname(__FILE__);
	    if(!strpos($includeDirs, PATH_SEPARATOR))
		{
			$includeDirs = array($includeDirs, $currentDir, $currentDir . '/../');
		}
		else
		{
			$includeDirs = array_merge(array($currentDir, $currentDir . '/../'), explode(PATH_SEPARATOR, $includeDirs));
		}
		

	    foreach($includeDirs as $includeDir)
		{
			$includeFile = $includeDir . '/' . str_replace('_','/',substr($className, strpos($className, $base))) . '.php';
			if( is_file($includeFile))
			{
	    		include $includeFile;
		        $loaded = true;
		        break;
			}
		}
		
		if(!$loaded)
		{
			die('Failed to find ' . $className . "\n");	
		}
	}
}

spl_autoload_register('Atmail_autoload');

