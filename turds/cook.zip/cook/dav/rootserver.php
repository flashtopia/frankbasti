<?php

/*

CalDAV & CardDAV server endpoint

This endpoint assumes the server is running from the root of a domain. 

*/

// Atmail bootloader
include '../bootloader.php';

// Files we need
require_once '../library/DateTime.php';
require_once '../library/DateTimeZone.php';
require_once '../library/Atmail/autoload.php';
require_once '../library/Sabre/autoload.php';

// settings
date_default_timezone_set('GMT');

$pdo = Zend_Registry::get('dbAdapter')->getConnection();

$server = new Atmail_Dav_Server($pdo);
$server->setBaseUri('/');

// fire off the 'preDavExec' event to the plugins
pluginCall('preDavExec');

// And off we go!
$server->exec();
