/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/
// Custom jQuery functions to modify the admin panel

// Disable the edit button on the toolbar
// TODO: Make this function accept the button-name we are to disable, use globally
$.fn.disable = function() {  // :( this genericly named function in the $. scope actually is specific to abook as it does more than it says on the box ( it unbinds bound methods - needing to be rebound again on enable)
	return this.each(function() { 
		$(this).attr("disabled",true); 
		$(this).css('opacity', 0.4);
		$(this).css('cursor', 'not-allowed');
		$(this).unbind("click"); 
	}); 
} 

// Enable the edit toolbar on the abook panel
$.fn.enable = function(func) { 
	return this.each(function() { 
		if($(this).attr("disabled")) {
			$(this).css('cursor', 'pointer');
			$(this).unbind("click");
			$(this).bind("click", func );
			$(this).attr("disabled",false); 
			$(this).css('opacity',1);
		}
     
	}); 
}

//created isDisabled which doesnt strip binding so that event bindings dont get tampered with and also eliminate duplication/errors in rebinding same events
// used method name isDisabled pending finding an unused/unreserved more suitable name
$.fn.isDisabled = function(state) 
{
    
	//NB jQuery stores all attr as string so you must do propper comparison
	//even Boolean('false') returns true
	//use 1 and 0 to halp with sloppy comparison
	$(this).each( function() 
	{
        
		if( state == null || state == undefined )
		{

			if( $(this).attr('disabled') == null || $(this).attr('disabled') == undefined )
				return false
			else
				return ($(this).attr('disabled')=='true'||$(this).attr('disabled')==true)?true:false            

		}
		else if( state == true ) 
		{

			$(this).attr('disabled', 'true' )
					.addClass('disabled')
					.css('opacity', 0.4)
					.css('cursor', 'not-allowed');

		}
	    else
		{

			$(this).attr('disabled', 'false' )
					.removeClass('disabled')
					.css('opacity', 1)
					.css('cursor', 'cursor');

		}

	}) 

	return $(this).attr('disabled')=='true'?true:false

}
 

// Display the updated number of contacts in the view after deletion
$.fn.updateCount = function(count) 
{

	// Load the current count
	var current = $(this).text();
	count = Number(count);

	var groupCount = Number(current) + count;

	if(groupCount > 0) {
		$(this).parent().show();
		$(this).text(groupCount);
	} else {
		$(this).text(groupCount);
		// Hide the count, do not show (0)
		$(this).parent().hide();
	}

}

// Display the updated number of contacts if total specified
$.fn.updateTotal = function(totalCount) {
	// Load the current count

	if(totalCount > 0) {
		$(this).parent().show();
		$(this).text(totalCount);
	} else {
		// Hide the count, do not show (0)
		$(this).parent().hide();
	}

}

// Function to show/hide a settings blocked with the checkbox slider
// This function will automatically hide any form element controls and
// disable/grey out the options within a <label class='settings_label'>
$.fn.enableBox = function( inverted ) 
{
	
	if( inverted == undefined )
		inverted = false
	obj = $(this).parent().parent().parent().parent(); // tbody
	enable = $(this).attr('checked')
	if( inverted )
		enable = !enable
	
	if( enable )
	{
	
		obj.children('tr').not('.globallyDisabled').find(".settings_label").each( function() 
		{ 
		
			$(this).fadeTo("slow", 1);
			$(this).parent().parent().find('INPUT, TEXTAREA, SELECT').removeAttr("disabled")
			$(this).parent().parent().find('.iPhoneCheckContainer').removeClass('iPhoneCheckDisabled')
			
		})
	
	} 
	else
	{
	
		obj.children('tr').not('.globallyDisabled').find(".settings_label").each( function() 
		{ 
			
			$(this).fadeTo("fast", 0.5);
			$(this).parent().parent().find('INPUT, TEXTAREA, SELECT').attr('disabled', 'disabled')
			$(this).parent().parent().find('.iPhoneCheckContainer').addClass('iPhoneCheckDisabled')
			
		}) 
		
	}

}

// Display new contact panel
function userNew() {

	// First, remove rows we have not saved!
	$('.user_row[contactid=]').each(function(){
		$(this).remove();
	});

	var newContact = $('.user_row:first', '#Users').clone();
	newContact.attr('contactid', '');
	newContact.insertBefore('.user_row:first');
    
	//CONSIDER: instead of removing and readding events, just add event to new clone newContact
	// Add the bind
	$('.check .contactRow').unbind('click'); 
	$('.user_row .contact_click').unbind('click');

	$('.check .contactRow').bind('click', function() { if(!$(this).isDisabled()) userToggleSelected(this); });
	$('.user_row .contact_click').bind('click', function() { if(!$(this).isDisabled()) userView(this); });

	// Remove previously selected rows
	$('.contactRow:checked', '#Users').each(function(){ 
		this.checked = false;
		$(this).parent().parent().removeClass('selected');
	});

	newContact.find('.first_name').html('New User');
	newContact.find('.last_name').html('');
	newContact.find('.email').html('');
    newContact.find('.check .contactRow').disable();
    newContact.find('.contact_click').disable();

	$('.contact_icon:first', '#Users').prev('.check').children().each(function() {
		this.checked = true;
		$(this).parent().parent().addClass('selected');
	});

	// Add the bind for viewing contacts again
	$.php(moduleBaseUrl + '/users/create/' )
}

// Import users
// Display new contact panel
function userImport() {

	// Add the bind for viewing contacts again
	$.php(moduleBaseUrl + '/users/import/');
	
}

// Delete a specified contact
function userDeleteSelected( ) 
{

	// Where are we, in the base folder, or a group
	var listType = $('#listType', '#Users').attr('value');
	var listGroup = $('#listGroup', '#Users').attr('value');
	var DomainName = $('li.current', '#Users').attr('DomainName')

 	$.php(moduleBaseUrl + '/users/delete/',$("#listcontacts").serializeArray());

	// Show the next user in the view
	// TODO: If 0 contacts, need to show 'null'
	//TODO: remove oveloading of php.complete and rather use a callback style
	php.complete = function ()
	{
        
		php.complete = function() 
		{ 

			$('.loading').each( function() { $(this).removeClass('loading') } );
            $('#back_button').each( function() { $(this).fadeTo(100, 1) } );
 
		}

		var nextID = $(".user_row:eq(1)", '#Users').attr('contactid');

		// If we have additional contacts, show the next user
		if(nextID > 0) 
		{

			$.php( moduleBaseUrl + '/users/view/name/' + nextID );

			// Select the next row as the "current view"
			$('.contact_icon:first', '#Users').prev('.check').children().each(function() 
			{

				this.checked = true;
				$(this).parent().parent().addClass('selected');

			});

		}
		else
		{

			// Show "empty" contacts otherwise
			if( listType == 'user')
			{
				
				$.php( moduleBaseUrl + '/users/list/type/' + listType + '/group/' + listGroup  );
				
			}
			else
			{
				
				$.php( moduleBaseUrl + '/users/list/domain/' + DomainName );
				
			}

		}

		$('#primary_header').each( function() { $(this).removeClass('loading') } );
		     
	}

}

function userEditFirstSelected() {

	if( $('#action_contact_edituser a').isDisabled() )
		return false                                                  

	var contactID = $('.contactRow:checked:first', '#listcontacts').attr('value');
	$.php(moduleBaseUrl + '/users/edit/name/' + contactID );

}

function userToggleSelected(clickedObject) {

	// Add the selected row if checkbox clicked, else remove
	if( clickedObject != null && clickedObject.checked )
		$(clickedObject).parent().parent().addClass('selected')
	else if( clickedObject != null )
		$(clickedObject).parent().parent().removeClass('selected')

	var checkedRows = $('.contactRow:checked', '#Users').size()

	if(checkedRows == 0)
		$('#action_contact_deleteuser a').attr('disabled', true);
	else
		$('#action_contact_deleteuser a').removeAttr('disabled');

	// Count how many elements exist, disable the edit button, only for the one selected contact
	if( checkedRows == 1 )
		$('#action_contact_edituser a').attr('disabled', true);
	else
		$('#action_contact_edituser a').removeAttr('disabled');

}

function userView(clickedObject) 
{

	// Remove previously selected rows
	$('.contactRow:checked', '#Users').each(function()
	{ 
	
		this.checked = false;
		$(this).parent().parent().removeClass('selected');
	
	});

	// Create a checkbox of the selection
	$(clickedObject).prev('.check').children().each(function() 
	{
	
		this.checked = true;
		this.focus();
		$(this).parent().parent().addClass('selected');
		//$('#action_contact_edituser').enable();
	
	});

	$.php( moduleBaseUrl + '/users/view/group/' + $(clickedObject).parent().parent().children('input#listGroup').attr('value') + '/name/' + $(clickedObject).parent().attr('contactid') );

}

function dragUser(clickedObject) 
{ 

	$(clickedObject).addClass('selected');
	$('.contactRow', $(clickedObject)).attr('checked',true);

	var size = $('.contactRow:checked', '#Users').size();
	if( !size )
	{
		
		size = 1;
		
	}

	return $('<div class="contact_icon_drag"><div class="contact_drag_no"><span class="drag"><strong>' + size + '</strong></span></div></div>');

}

function resetDroppables() 
{
    //NB, this resetDroppables is not to be confused with the webmail Abook resetDroppables.
	//the first purpose s for dragging users into groups.
	
	$("ul#nav_secondary li[grouptype=user]:not('.current')", '#Users').droppable('destroy').droppable(
		{
		
			accept: "div.user_row",
			activeClass: 'droppable-active',
			hoverClass: 'droppable-hover',
			drop: function(ev, ui) 
			{
		
				contactId = $(ui.draggable).attr('contactid')
				GroupID = $(this).attr('groupid');
				groupName = $(this).attr('groupname');
			
				$.php(moduleBaseUrl + '/users/adduserstogroup/groupNameTo/' + groupName, $("#listcontacts:first").serializeArray())
			
			}

		}
	);
	
}

function resetDraggables()
{
	$("#listcontacts div.user_row").draggable('destroy').draggable(
	{

		helper: function() { return dragUser(this); },
		appendTo:'#draggableContactsContainer',
		cursor:'move',
		scroll: false,
		/* containment: '#Users #secondary', */
		/* preventionDistance:"10", */
		cursorAt:{top:15, left:48},
		revert: "invalid",
		revertDuration: 300

	});	
}

/*
Functions used for listGroups.phtml
*/

function listUsersClick(clickedObject) 
{

	var groupType = $(clickedObject).parent().attr('groupType');
	if(!currentlyEditingAGroup) 
	{
	
		$('ul#nav_secondary li', '#Users').removeClass('current')
		$(clickedObject).parent().addClass('current')
			$('#Users #action_contact_newuser a').removeAttr("disabled");
			$('#Users #action_contact_newuser a').fadeTo(0, 1);
			$('#Users #action_contact_deleteuser a').removeAttr("disabled");
			$('#Users #action_contact_deleteuser a').fadeTo(0, 1);
			$('#Users #action_contact_edituser a').removeAttr("disabled");
			$('#Users #action_contact_edituser a').fadeTo(0, 1);
        
		if( $(clickedObject).parent().attr('DomainName') == '' || $(clickedObject).parent().attr('DomainName') == 'external') 
		{

			$('#Users #folder_remove a').removeClass('enabled');           
			$('#Users #folder_remove a').addClass('disabled');
			$('#Users #folder_lock a').addClass('disabled');
			$('#Users #folder_unlock a').addClass('disabled');   

		}
		else
		{

			$('#Users #folder_remove a').removeClass('disabled');
			$('#Users #folder_remove a').addClass('enabled');

			if ($('span span', clickedObject).is('.domain_disabled')) 
			{

			    $('#Users #folder_unlock a').removeClass('disabled');
			    $('#Users #folder_lock a').addClass('disabled');
				$('#Users #action_contact_newuser a').attr('disabled', 'true');
				$('#Users #action_contact_newuser a').fadeTo(0, 0.4);
				$('#Users #action_contact_deleteuser a').attr('disabled', 'true');
				$('#Users #action_contact_deleteuser a').fadeTo(0, 0.4);
				$('#Users #action_contact_edituser a').attr('disabled', 'true');
				$('#Users #action_contact_edituser a').fadeTo(0, 0.4);		    
			}
			else
			{

			    $('#Users #folder_unlock a').addClass('disabled');
			    $('#Users #folder_lock a').removeClass('disabled');

			}

		}

		domain = $(clickedObject).parent().attr('DomainName');
		if( domain == undefined )
		{

			group = $(clickedObject).parent().attr('groupName');
			$.php( moduleBaseUrl + "/users/list/type/user/group/" + group);

		}
		else if(domain == 'All')
		{

			$.php( moduleBaseUrl + "/users/list/");

		}
		else
		{

			$.php( moduleBaseUrl + "/users/list/domain/" + domain);

		}
	}

	return false
}  

function viewDomain(domain) {

	$.php( moduleBaseUrl + "/users/list/domain/" + domain);
}

function editDomainDblClick(clickedObject) {
	a = $(clickedObject)

	if(a.parent().attr('GroupID') == 0)
	return;

	currentlyEditingAGroup = true

	li = a.parent()
	span = a.children('span')
	oldGroupName = li.attr('GroupName')

	// Create a form to specify the new name
	$('<form id="updateGroupForm" method="post" target="_new"><input name="newGroupName" oldGroupName="' + oldGroupName + '" value="' + oldGroupName + '"></form>').insertAfter(a); 

	// Hide the label text
	a.hide();

	form = li.children('form')
	input = form.children('input')
	input.select()

	input.bind('blur', function() {
		$(this).parent().submit()
	})

	form.submit( function() { 
		form = $(this)
		GroupID = $(this).parent().attr('GroupID')
		newGroupName = $(this).children('input').attr('value')

		// Change the text to the new groupname
		$('.groupLink:hidden .label span.labelname', '#Users').text(newGroupName);
		$(this).parent().attr('GroupName', newGroupName);

		// Show the original div
		$('.groupLink:hidden', '#Users').show();
		// Remove from the DOM the html form for editing
		form.remove();

		$.php(moduleBaseUrl + '/contacts/updategroupname/GroupID/' + GroupID + '/newGroupName/' + newGroupName )
		currentlyEditingAGroup = false
		return false
	})
	  
}

function addGroup(type) 
{

	if( type == undefined )
	{

		type = 'domain';

	}
	if( type == 'domain')
	{

		inputInitialValue = jsTranslate('New Domain');

	}
	else
	{

		inputInitialValue = jsTranslate('New Group');

	}

	newGroupFormName = 'new' + type.substr(0, 1).toUpperCase() + type.substr(1) + 'Form';
	
	// TODO: Remove language reference
	if( $('#' + newGroupFormName, '#Users').length == 0 ) 
	{

		$('#nav_secondary', '#Users').append('<li>' + 
											 '<form class="adminAddGroupForm" id="' + newGroupFormName + '" method="post">' + 
											 '<input id="newGroupType" type="hidden" name="type" value="' + type + '">' + 
											 '<input id="newGroupName" name="newGroupName" value="' + inputInitialValue + '" />' + 
											 '</form>' + 
											 '</li>')
		$("#secondary", '#Users').attr({ scrollTop: $("#Users #secondary").attr("scrollHeight") });
		$('#' + newGroupFormName + ' input#newGroupName', '#Users').alphanumeric({allow:".-_"});
		$('#' + newGroupFormName + ' input#newGroupName', '#Users').select()
        alreadySubmitted = false;
		//$('#' + newGroupFormName + ' input#newGroupName', '#Users').bind('focus click', function() { $(this).select() } )
		$('#secondary', '#Users').hover( function() 
		{ 
			if( $('#' + newGroupFormName + ' input#newGroupName', '#Users').attr('value') == inputInitialValue )
				$('#' + newGroupFormName + ' input#newGroupName', '#Users').select()
			
		})
		
		$('#' + newGroupFormName + ' input#newGroupName', '#Users').bind('blur', function() 
		{
			if( !alreadySubmitted )
			{
				alreadySubmitted = true;
				$(this).parent().submit()
				
			}
		})

		$('#' + newGroupFormName, '#Users').submit( function() 
		{
			
			alreadySubmitted = true
			$('#secondary', '#Users').unbind('hover')
			
			var newGroupName = $(this).children('input#newGroupName').attr('value').replace(/[^a-zA-Z0-9._-]/g, '')
			if(type == 'domain') newGroupName = newGroupName.toLowerCase();
			$(this).children('input#newGroupName').attr('value',  newGroupName);
			args = $(this).serializeArray();
			li = $(this).parent()

			newGroupName = htmlentities($(this).children('input#newGroupName').attr('value'), 'ENT_QUOTES');
			groupType = $(this).children('input#newGroupType').attr('value')
			
			// TODO: Remove language string
			if( newGroupName == '' || newGroupName == jsTranslate('New Domain') || newGroupName == jsTranslate('New Group') || newGroupName == jsTranslate('NewDomain') || newGroupName == jsTranslate('NewGroup') ) 
			{

				li.remove();                                          
				return false;

			}
		    
		    	var icontype = "";
			//CONSIDER: use clone instead to transparently cope with html changes to the list
			if( groupType != 'domain')
			{
				
				icontype = " groupIcon";
				li.attr('groupname', newGroupName )
			
			}
			else
			{
				
				li.attr('domainname', newGroupName )
				
			}
			li.attr('grouptype', groupType )
			li.attr('newgroup', '1')
			li.addClass('ui-droppable')
			li.html('<a class="Link" href="#"><span class="label' + icontype + '"><span class="labelname">' + newGroupName + '</span><span class="unread" style="display:none;"><strong>0</strong></span></span></a>');
			a = li.children('a')
			a.addClass('groupLink')
			a.bind('click', function() { return listUsersClick(this) } )     
			//a.bind("dblclick", function() { return editGroupDblClick(this) } )
            resetDroppables() 
			$.php(moduleBaseUrl + '/domain/create', args );
			alreadySubmitted = true
			return false

	    })
  
	}

	return false;

}

function removeDomain(clickedObject) 
{

	if( $('#Users li.current').attr('domainname') == undefined )
	{
		
		var groupName = $('#Users li.current').attr('groupname')
		var deletingDomain = false;
		
	}                              
	else
	{
		
		var domainName = $('#Users li.current').attr('domainname')
		var deletingDomain = true;
		
	}
	//used for deleting domains and groups. closely linked
	// TODO: Remove any english language strings from the JS array
	if( $(clickedObject).attr('class') != 'enabled' )
	{
		
		return false;
		
	}
	else
	{
	              
		if( deletingDomain &&  $('#Users li.current').length > 0 && confirm('Are you sure you want to delete ' + html_entity_decode(domainName)) )
		{
			
			$.php(moduleBaseUrl + '/domain/remove/name/' + domainName )
			listUsersClick($('#Users ul#nav_secondary li:first a'));
			
		}   
		else if( !deletingDomain && $('#Users li.current').length > 0 && confirm('Are you sure you want to delete ' + html_entity_decode(groupName)) )
		{
			
			$.php(moduleBaseUrl + '/domain/removegroup/groupname/' + groupName )
			listUsersClick($('#Users ul#nav_secondary li:first a'));
			
		}
		
	}

	return false;

}

function searchDomain(clickedObject) {

	query = $(clickedObject).attr('value');

	if(query.length > 1)
		$.php(moduleBaseUrl + '/contacts/searchFuzzy/query/' + query);
	else
		$.php(moduleBaseUrl + '/contacts/viewcontacts/GroupID/0/');

	return true;
}

function lockDomain(clickedObject) {
    //if( $(clickedObject).attr('class') == 'disabled' )
	//	return false

    if (confirm("Are you sure you wish to disable logins for " + html_entity_decode($('#Users li.current').attr('DomainName')) + "?")) {
        $.php(moduleBaseUrl + '/domain/disable/name/' + $('#Users li.current').attr('DomainName') )
        //$(clickedObject).addClass('disabled');
        //$('#Users #folder_unlock a').removeClass('disabled');
    }
}

function unLockDomain(clickedObject) {
    //if( $(clickedObject).attr('class') == 'disabled' )
	//	return false

    if (confirm("Are you sure you wish to enable logins for " + html_entity_decode($('#Users li.current').attr('DomainName')) + "?")) {
        $.php(moduleBaseUrl + '/domain/enable/name/' + $('#Users li.current').attr('DomainName') )
        //$(clickedObject).addClass('disabled');
        //$('#Users #folder_lock a').removeClass('disabled');
    }
}

function selectAll(clickedObject) {
    
	$('.contactRow', '#Users').each(function(){ 
		this.checked = true;
		$(this).parent().parent().addClass('selected');
	});
	userToggleSelected(null)

}

function deselectAll(clickedObject) {

	$('.contactRow', '#Users').each(function(){ 
		this.checked = false;
		$(this).parent().parent().removeClass('selected');
	});
	userToggleSelected(null)

}

// Edit addressbook functions
// Functions to handle default states
function changeDefault(formName) {

	if( formName.value == formNames[formName.id] )
		formName.select()

}

function checkDefault(formName) {

	if( !formName.value ) {
		formName.value = formNames[formName.id]
		formName.className='default'
	}

}

function updateDependantSelects(selectorName, allOptions) {

	usedOptions = []

	$("[name='" + selectorName + "']", '#Users').each( function() {

		//with each select check if there is a selected option, else use first (i.e. first field populated but user dod nt need to select/change first option)
		if( $('option:selected', $(this) ).length == 0 )
			usedOptions.push( $('option:first', $(this) ).attr('value') )
		else
			usedOptions.push( $('option:selected', $(this) ).attr('value') )
	})                           
	unusedOptions = {}
	for(item in allOptions)
		unusedOptions[item] = allOptions[item]

	for( item in allOptions) {
		if( usedOptions.indexOf(item) != -1 )
			delete unusedOptions[item]
	}

	$("[name='" + selectorName + "']", '#Users').children('option:not(:selected)').remove()
	appendOptions = ''
	for( item in unusedOptions ) {
		appendOptions += '<option value="' + item + '">' + unusedOptions[item] + '</option>\n'
	}

	$("[name='" + selectorName + "']").each( function() {
		$(this).append(appendOptions)
	})
}

function removeClicked(clickedObject, allOptions) {
	//handle compound fields (i.e. fields/fows that relate to each other, like shouldnt be duplicated

	//remove row then unhide last add button

	parentTable = $(clickedObject).parent().parent().parent()
	//dependantSelectsName = $(clickedObject).parent().parent().children('td:first').children('select').attr('name')
	/*
	if( $(clickedObject).parent().parent().parent().children('tr').length < 3) {
		$(clickedObject).parent().children('input').attr('value', '')
		return
	}
	*/
	//make the last one visible
	//check if previous is related then show + if we are removing this + 



	$(clickedObject).parent().parent().remove()                                                   
	$('tr.dependantNumberFields:not(:last)', '#Users').children('td:last').children('img[alt=add]').hide()
	$('tr.dependantNumberFields:last', '#Users').children('td:last').children('img[alt=add]').show()
	if( $('tr.dependantNumberFields', '#Users').length < 2 )
		$('tr.dependantNumberFields', '#Users').children('td:last').children('img[alt=remove]').hide()

	updateDependantSelects( $(clickedObject).parent().parent().children('td:first').children('select').attr('name'), allOptions )
	//parentTable.children('tr:last').children('td:last').children('img[alt=add]').css('display','')
	//$( '.' + dependantSelectsName + ':last').parent().siblings('td').children('img[alt=add]').css('display','')
}

function addClicked(clickedObject, allOptions) {

	//prevent adding new compound field if current is empty
	if( $(clickedObject).parent().children('input').attr('value') == '' || $(clickedObject).parent().children('input').hasClass('default') ) {
		$(clickedObject).parent().children('input').effect('highlight', {}, 500)
		return false                                            
	}

	newRow = $(clickedObject).parent().parent().clone(true)
	newRow.children('td').children('input').attr('value','')
	newRow.children('td').children('select').children('option:selected').remove()
	newRow.children('td').children('select').children('option:first').attr('selected','selected')

	$(clickedObject).parent().parent().after( newRow )
       
	newRow = $(clickedObject).parent().parent().next()
	if( $(this).parent().parent().children('td:first').children('select').children('option').length < 2 )
	   	$(this).parent().children('img[alt=add]').css('display','none')
	//$(newRow).children('td').children('img[alt=add]').css('display','none')
	//$(newRow).children('td').children('input').attr('value', '')
	//$(newRow).children('td').children('input').keypress( function(e) { 
	//	if($(this).attr('value') == '' && (e.which == 32 || e.which == 8 || e.which == 0 ))
	//   	$(this).parent().children('img[alt=add]').css('display','none') 
	//   else if( $(this).parent().parent().children('td').children('select').children('option').length > 1 )
	//   	$(this).parent().children('img[alt=add]').css('display','')
	//})

	//hide the previous + clicked
	$(clickedObject).css('display','none')

	if( $('tr.dependantNumberFields', '#Users').length > 1 )
		$('tr.dependantNumberFields', '#Users').each( function() {
			$(this).children('td:last').children('img[alt=remove]').show()
		})

	updateDependantSelects( $(clickedObject).parent().parent().children('td:first').children('select').attr('name'), allOptions )
}

function groupEdit( groupType, groupName )
{

	$('#top_right_button').hide();
	$('#contact_info').load(moduleBaseUrl + '/users/groupedit/type/' + groupType + '/groupName/' + groupName ); 

}
