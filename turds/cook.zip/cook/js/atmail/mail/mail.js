/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

var COMPOSER_MINIMUM_HEIGHT = 200;
var REFRESH_EVERY_MS = 3 * 60 * 1000; // 3 mins

$.bytesToHuman = function(bytes) {

	var sign = '';
	var signs = ['KB', 'MB', 'GB', 'TB', 'PB'];
	for(var ii=0; ii<signs.length; ii++) {
		if (bytes > 1024) {
			bytes/=1024;
			sign = signs[ii];
		}
	}

	if(!sign)
		return "1 KB";
	else
		return Math.round(bytes) + ' ' + sign;

}

function checkAutoReload(moduleBaseUrl, currentIdsMd5, resultContext )
{
	// ensure that the timer isn't recreated over and over
	disableAutoReload();
	window.currentIdsMd5 = currentIdsMd5;
	
	window.pnewmailcheck = setInterval( 
		function()
		{
			window.moreThanOneChecked = 'false';
			if($('.messageCheckbox:checked', resultContext).length > 1 )
			{
				window.moreThanOneChecked = 'true';
			}
			window.firstCheckedUID = $('.messageCheckbox:checked:first', resultContext).attr('value');
			
			// make the call
			$.php(moduleBaseUrl + '/mail/listfoldermessages/refresh/true/currentIdsMd5/' + window.currentIdsMd5 + '/moreThanOneChecked/' + window.moreThanOneChecked + '/firstCheckedUID/' + window.firstCheckedUID + '/resultContext/' + urlencode(resultContext), false) 
		}, 
		REFRESH_EVERY_MS);
}

function disableAutoReload()
{
	if( window.pnewmailcheck !== undefined )
	{
		// found the interval timer
		clearInterval(window.pnewmailcheck);
		window.pnewmailcheck = undefined;
	}
}

function periodicDraftSaver( context, uid )
{
    var array_id = context + uid;
    var id_selector = '.' + uid;
    var context_selector = '#' + context;
    var element = $(id_selector, context_selector);
    if(element.length==0) return;

    //regularly save draft
    window.periodicDraftSavers = window.periodicDraftSavers || [] //create the array if it doesnt exist

    if( window.periodicDraftSavers[array_id] != undefined )
        clearInterval(window.periodicDraftSavers[array_id])

    window.periodicDraftSavers[array_id] = setInterval( function() { tryAutoSaveDraft( context, uid ) }, 120000);

    // wait a second or two for rte to load
    setTimeout( function() {  element.data('md5', contentHash( fetchContent( element ), element )); }, 2000);

    //save first draft soon after opening composer
    setTimeout(  function() { tryAutoSaveDraft( context, uid ) }, 30000);
}

function contentHash(str, element)
{
    var hash = 0;
    str = str +
        element.find('#form_to .textboxlist-bits').text() +
        element.find('#form_subject input').val() +
        element.find('#form_cc .textboxlist-bits').text() +
        element.find('#form_bcc .textboxlist-bits').text() +
        element.find('#composerAttachmentsHolder span').text();

    if (str.length == 0) return hash;
    for (i = 0; i < str.length; i++) {
        hash = ((hash<<5)-hash)+str.charCodeAt(i);
        hash = hash & hash; // Convert to 32bit integer
    }

    return hash;
}

function fetchContent( element )
{
    var html = '';
    var rte_selector = element.find('.rte-zone')

    if(rte_selector.length)
    {
        html = rte_selector.rte_html();
    }
    else
    {
        rte_selector = element.find('textarea.rte-zone-reply');
        if(rte_selector.length && rte_selector.css('display') == 'none')
        {
            html = element.find('.rte-zone-reply').rte_html();
        }
    }
    return html;
}

function tryAutoSaveDraft( context, uid )
{
    var id_selector = '.' + uid;
    var context_selector = '#' + context;
    var array_id = context + uid;
    var element = $(id_selector, context_selector);

    if( element.length == 0 || $('.reply:last', context_selector).css('display') == 'none' )
    {
        clearInterval(window.periodicDraftSavers[array_id]);
        window.periodicDraftSavers[array_id] = null;
        delete window.periodicDraftSavers[array_id];
        return
    }

    var html = fetchContent( element );

    if(html != '')
    {
        // we have content to update
        // find either the individual uid, or the context the composer exists in
        var rte_zone = element.find('#id_description_' + context + ',#id_description_' + uid);
        if(rte_zone.length)
        {
            var currentmd5 = element.data('md5');
            var contentmd5 = contentHash(html, element);
            if(contentmd5 != currentmd5)
            {
                var rte_zone_textarea = rte_zone.filter('textarea');
                element.data('md5', contentmd5)

                if(rte_zone_textarea.css('display') == 'none')
                {
                    var html = rte_zone.rte_html();
                    rte_zone_textarea.attr('value', html);
                }

                $.php(moduleBaseUrl + '/composemessage/savedraft/auto/true', element.serializeArray() )
            }
        }
    }
}

$.simpleFlash = function(message, type, modal, buttons, callback) 
{
	if( modal == undefined )
	{
		modal = false;
	}
	
	if( type == undefined )
	{
		type = 'notice';
	}
	
	var navPanel = $('.ui-tabs-selected a', 'div#nav');
	
	if( navPanel.length == 0 || (navPanel.length && navPanel.attr('href') == '#Email') )
	{
		navPanel = $('.ui-tabs-selected a', 'div#navTab');
		if(navPanel.length)
		{
			visiblePanelContext = navPanel.attr('href');
		}
		else
		{
			visiblePanelContext = $('.ui-tabs-selected', 'div#navMessages').attr('name');
		}
	}
	else
	{
		visiblePanelContext = navPanel.attr('href');
	}
	
	var flashPanel = $('#Flash', visiblePanelContext);
	
	if( flashPanel.length == 0 )
	{
		//no #Flash exists so append one
		if( $('#primary_content_inner', visiblePanelContext).length == 0 )
		{
			alert(message);
			return;
		} 
		else if ( $('#mail_info', visiblePanelContext).length != 0 ) 
		{
			//we are inside 3pane to append to mail_info
			$('#mail_info', visiblePanelContext).prepend('<div id="Flash"></div>');
			flashPanel = $('#Flash', visiblePanelContext);
		} 
		else
		{
			$('#primary_content_inner', visiblePanelContext).prepend('<div id="Flash"></div>');
			flashPanel = $('#Flash', visiblePanelContext);
		}
	}
	flashPanel.removeClass('flash_notice_error');
	flashPanel.removeClass('flash_notice');
	flashPanel.removeClass('flash_modal');

	if( type.toLowerCase() == 'notice' ) 
	{
		flashPanel.addClass('flash_notice');
		if(modal)
		{
			flashPanel.addClass('flash_modal');		
		}
	}
	else if( type.toLowerCase() == 'important' )
	{
		flashPanel.addClass('flash_modal');
	} 
	else
	{
		flashPanel.addClass('flash_notice_error');
	}
		
		
	if(buttons != undefined)
	{
		message += '<br>';
		for(var x in buttons)
		{
			message += '<a href="#" onclick="' + callback + '(\'' + x + '\');"><span> ' + buttons[x] + ' </span></a>';
		}
	}
	flashPanel.html(message);	
	$('#primary_content', visiblePanelContext).scrollTo(0,{duration: 'normal', onAfter: function() {	flashPanel.fadeIn();}});
	
	if(flashPanel.data('flashTimeout'))
	{
		clearTimeout(flashPanel.data('flashTimeout'));
	}
			
	if(!modal)
	{
		flashPanel.data('flashTimeout', setTimeout(function() { flashPanel.fadeOut() },5000));
	}
	flashPanel.unbind('click');
	flashPanel.bind('click', function() { $(this).fadeOut(); if($(this).data('flashTimeout')){ clearTimeout($(this).data('flashTimeout')); $(this).data('flashTimeout', null); } });
}

//use this to inspect a processed JSON responce (now a JS object) for failres and throw errors returning false, else returning true
function handleResponseErrors(data, textStatus)
{
	
	if( data.a != undefined )
	{
		if( data.a.addError != undefined )
		{
			
			$.simpleFlash(data.a.addError[0].msg, 'error');
			
		}
		else
		{
			
			$.simpleFlash(data.a.addMessage.msg, 'notice');
			
		}
		return;
		
	}
	else if( data.success == undefined )
	{
		
		$.simpleFlash(data);
		
	}
	var success = data.success;
	if( success != '1' )
	{
		
		$.simpleFlash(data.message, 'error');
		return false;
		
	}
	else
	{
		
		return true;
		
	}

}


function getVisiblePanelContext()
{
	
	if( $('.ui-tabs-selected a', 'div#nav').attr('href') == '#Email' || $('.ui-tabs-selected', 'div#nav').length == 0 )
	{                                                                                                                 
		
		return $('.ui-tabs-selected', 'div#navMessages').attr('name');
		
	}
	else
	{   
		
		return $('.ui-tabs-selected a', 'div#nav').attr('href');
		
	}
	
}

function activeSplit( stringRaw, delim )
{
	
	//to only split on commas outside quotations something like: stringRaw.split(/[,\s]++(?=(?:(?:[^"]*+"){2})*+[^"]*+$)/x);
	
	//intil this tested and working properly just use standard split
	if( stringRaw == undefined || typeof(stringRaw) != 'string')
	{
		
		return new Array('');
		
	}
	return stringRaw.split(',');
	
	/*
	//currently faulty, see PHP version for what needs to be fixed. Opted to just remove commas from personal parts until UI recipient handling fixed.
	
	if( delim == undefined )
	{
		
		delim = ',';
		
	}
	
	if( stringRaw == undefined || stringRaw.length == 0 || typeof(stringRaw) == 'object' )
	{
		
		return '';
		
	}
	
	//split a string on delim so long as delim not inside double inverted commans
	var arrayRaw = stringRaw.split( delim )
	
	//return origionl if no delim found
	if( arrayRaw.length < 2 )
	{
		
		return stringRaw;
		
	}
	var arrayNew = new Array();
	var arrayNewIndex = 0;
	var insideQuotations = false;
	for ( var i in arrayRaw )
	{
	    
		//start if first item
			
		//if quotation not found
		if( arrayRaw[i].indexOf('"') < 0 )
		{
			
			//if inside quotations just add it to current 
			if( insideQuotations )
			{
			
				arrayNew[arrayNewIndex] = arrayNew[arrayNewIndex] + ',' + arrayRaw[i];
				
			}
			else
			{
				
				arrayNew[arrayNewIndex] = arrayRaw[i];
				arrayNewIndex++;
				
			}
			
		}
		else
		{
			//quote found so decide if opening or closing add and incriment to next newArray index
			if( insideQuotations )
			{
				
				arrayNew[arrayNewIndex] = arrayNew[arrayNewIndex] + ',' + arrayRaw[i];
				insideQuotations = false;
				arrayNewIndex++;
				
			}
			else
			{
				
				arrayNew[arrayNewIndex] = arrayRaw[i];
				insideQuotations = true;
				
			}					
			
		}
		
	}
	return arrayNew;
	*/
	
}

function openNewComposerTab(args)
{
	
	lastTabNumber++
	tabLabel = jsTranslate("Compose");
	
	var searchOffset = $("#search_anything").offset();
	var lastTabOffset = $('#navMessages li:last').offset();
	var lastTabWidth =  $('ul#navMessages li:last').width();

	//TODO: browser style non-fitting tabs dropdown, currently oldest tab is dropped/removed
	if( (searchOffset.left - lastTabOffset.left - lastTabWidth) < 190 )
		$('div#navMessages').tabs('remove', 1);

	$('div#navMessages').tabs('add','#viewmessageTab' + lastTabNumber, tabLabel);
	$('#viewmessageTab' + lastTabNumber).addClass('viewmessageTab');
	$('#viewmessageTab' + lastTabNumber).addClass('composemessageTab');
	$('#viewmessageTab' + lastTabNumber).html('<div id="primary_header"><h1>Loading ...</h1></div>');	
	
	var url = moduleBaseUrl + '/composemessage/index/viewmessageTabNumber/' + lastTabNumber;
	
	if( args != undefined && typeof(args['to']) == 'object')
		$('#viewmessageTab' + lastTabNumber).load(url, { 'to[]': args['to'] });
	else {
		if( args != undefined && args.to != undefined )
			url = url + '/to/' + args.to;

		$('#viewmessageTab' + lastTabNumber).load(url);
		
	}
	
	
	//dissable appropriate mainMailActions - depends on content/class of new tab
	enableMailActions()
	
}

function forwardMessagesInNewTab(uniqueIds, folder, forwardAsAttachments) 
{

	lastTabNumber++
	tabLabel = "Forward";

	// Forward inline, or as attachment
	if(!forwardAsAttachments)
	 forwardAsAttachments = 0;
	else
	forwardAsAttachments = 1;
	
	var searchOffset = $("#search_anything").offset();
	var lastTabOffset = $('ul#navMessages li:last').offset();
	var lastTabWidth =  $('ul#navMessages li:last').width()
	//TODO: browser style non-fitting tabs dropdown, currently oldest tab is dropped/removed
	if( (searchOffset.left - lastTabOffset.left - lastTabWidth) < 190 )
		$('div#navMessages').tabs('remove', 1)                                        
	
	$('div#navMessages').tabs('add','#viewmessageTab' + lastTabNumber, tabLabel)
	$('#viewmessageTab' + lastTabNumber).addClass('viewmessageTab')
	$('#viewmessageTab' + lastTabNumber).addClass('forwardmessageTab')
	
	$('#viewmessageTab' + lastTabNumber).html('<div id="primary_header"><h1>' + jsTranslate("Loading...") + '</h1></div>')

    $.php(moduleBaseUrl + '/composemessage/forward', {'viewmessageTabNumber': lastTabNumber, 'uniqueIds[]': uniqueIds, 'folder': folder, 'forwardAsAttachments': forwardAsAttachments})
	
	//dissable appropriate mainMailActions - depends on content/class of new tab
	enableMailActions()
	
}

function replyInNewTab(uniqueId, folder, type) {
	lastTabNumber++
	if( type == undefined )
		type = 'reply'

	tabLabel = "Reply";

	var searchOffset = $("#search_anything").offset();
	var lastTabOffset = $('ul#navMessages li:last').offset();
	var lastTabWidth =  $('ul#navMessages li:last').width()
	//TODO: browser style non-fitting tabs dropdown, currently oldest tab is dropped/removed
	if( (searchOffset.left - lastTabOffset.left - lastTabWidth) < 190 )
		$('div#navMessages').tabs('remove', 1)                                        
	
	$('div#navMessages').tabs('add','#viewmessageTab' + lastTabNumber, tabLabel)
	$('#viewmessageTab' + lastTabNumber).addClass('viewmessageTab')
	$('#viewmessageTab' + lastTabNumber).addClass('replymessageTab')

	$('#viewmessageTab' + lastTabNumber).html('<div id="primary_header"><h1>' + jsTranslate("Loading...") + '</h1></div>')

    $.php(moduleBaseUrl + '/composemessage/reply', {'viewmessageTabNumber': lastTabNumber, 'uniqueId': uniqueId, 'folder': folder, 'type':type})
	
	//dissable appropriate mainMailActions - depends on content/class of new tab
	enableMailActions()
	
}

function convertQuotedToShowQuoted( $domObj ) {
	if( $domObj.data('showQuotedApplied') )
		return
	if( $('BLOCKQUOTE', $domObj.contents() ).size() > 0) {
		if($('.showQuotedText', $domObj.contents()).length == 0)
		{
			$('#bodyWrapper', $domObj.contents()).append('<br/><a class="showQuotedText" href="#">-- Show Quoted Text --</a>');
		}
		$('.showQuotedText', $domObj.contents()).hide();
	    $('.showQuotedText', $domObj.contents()).bind('click', function() {
			$(this).hide();
			$('BLOCKQUOTE:hidden', $(this).parent() ).each( function() {
				$(this).show()
				var target_height = $('#bodyWrapper', $domObj.contents()).height();
				$domObj.animate({height: target_height }, 'fast');
			})
			return false;
		
		});
    	
		$('BLOCKQUOTE', $domObj.contents() ).each(function() { $(this).hide() })
		$('.showQuotedText', $domObj.contents()).show();    
	}
	$domObj.data('showQuotedApplied', true)
}

$.fn.mailmessage = function(text)
{
	
	$('#Email #secondary #folder_actions #error').show();
	$('#Email #secondary #folder_actions #error').bt(text, 
	{
	  width: 190, 
	  fill: 'white', 
	  cornerRadius: 10, 
	  padding: 20,
	  strokeWidth: 1,
	  trigger: ['none']
	});
	setTimeout(function() {	$('#Email #secondary #folder_actions #error').btOn(); }, 100);
	setTimeout(function() { $('#Email #secondary #folder_actions #error').btOff(); }, 4000);
	$('#Email #secondary #folder_actions #error').bind('click', 
		function() {	
			setTimeout(function() {	$('#Calendar #secondary #folder_actions #error').btOn(); }, 100);
			setTimeout(function() { $('#Calendar #secondary #folder_actions #error').btOff(); }, 4000);
		});

}

checkTotalMessages = function(element)
{
	var totalItems = 0;
	
	if(element.parent() == undefined)
		return 0;

	if(element.parent().parent().attr('class') == "messages")
	{
		totalItems = element.parent().children('.messageItem').length;
	}
	else if (element.parent().attr('class') == "messagesListForm")
	{
		totalItems = element.parent().children('.mail_row').length;
	}

	return totalItems;
}

addNoMessageStatus = function(element)
{
	var className = element.attr('class');
	var parent = element;
	
	if(className == '')
	{
		parent = element.parent();
		className = parent.attr('class');
	}
	
	if(className == "messages")
	{
		// 2 pane
		parent = parent.parent().parent();
		if(parent.children('#noMessageDisplay').length) parent.children('#noMessageDisplay').remove();
		parent.append('<div id="noMessageDisplay" style="margin:10px;">&nbsp;' + jsTranslate("No messages in this folder") + '</div>');
	}
	else if (className == "messagesListForm")
	{
		// 3 pane
		if(parent.children('#noMessageDisplay').length) parent.children('#noMessageDisplay').remove();
		parent.append('<div id="noMessageDisplay" style="margin:10px;">&nbsp;' + jsTranslate("No messages in this folder") + '</div>');
	}
}

$.fn.hideMailRow = function(context)
{
	$(this).removeClass('ui-draggable');
	$(this).addClass('removing');
	
	$(this).fadeOut('fast', function() 
	{ 		
		var totalItems = checkTotalMessages($(this)) - 1;
		var parent = $(this).parent();
	
		$(this).remove()
			
		if( !totalItems )
		{
			addNoMessageStatus(parent);
		}
	});
}

$.fn.getMailRow = function(context) 
{
	var item;
	var currentItem;
	var id = false;

	// try the next item
	// but make sure its not being removed!
	currentItem = $(this).next();
	if(!currentItem.is('.removing'))
	{
		id = currentItem.attr('id');
	}
	
	if(!id || id == 0 || id == 'pageNumber')
	{
		var searching = true;
		// next item doesn't exist or is being removed
		// lets find the next item which exists and isn't being removed
		
		while(searching)
		{
			currentItem = currentItem.next();
			if(currentItem == undefined)
			{
				searching = false;
			}
			else if(!currentItem.attr('id'))
			{
				searching = false;
			}
			else
			{
				if(!currentItem.is('.removing'))
				{
					id = currentItem.attr('id');
					searching = false;
				}
			}
		}
	
	}
	
	if(!id || id == 0 || id == 'pageNumber')
	{
		// didn't find anything after the current item, so lets go back up the list
		currentItem = $(this).prev();
		if(!currentItem.is('.removing'))
		{
			id = currentItem.attr('id');
		}
		if(!id || id == 0 || id == 'pageNumber')
		{
			var searching = true;
			// prev item doesn't exist or is being removed
			// lets find the prev item which exists and isn't being removed
			while(searching)
			{
				currentItem = currentItem.prev();
	
				if(currentItem == undefined)
				{
					searching = false;
				}
				else if(!currentItem.attr('id'))
				{
					searching = false;
				}
				else
				{
					if(!currentItem.is('.removing'))
					{
						id = currentItem.attr('id');
						searching = false;
					}
				}
			}
	
		}
		
	}
	
	item = $('#primary_content_inner #' + id, getVisiblePanelContext());
	totalMessagesLeft = checkTotalMessages(item) - item.parent().children(".removing").length;
	
	// No messages are left to display
	if( !totalMessagesLeft || !id || id == 0 || id == 'pageNumber' )
	{
		return $('#mail_info', context).html('');		
	}
		
	if($('#messageListCompact').length != 0) 
	{
		setTimeout(function() { viewMessageCompactClicked($('#primary_content_inner #' + id, getVisiblePanelContext())) }, 200);	
	}
	
}

function updateUIFlags(folder, context)
{
    $item = false
    $icon = false
    if( $('form#messagesListForm').length != 0 ) // 2 pane
    {
        //fetch the last UID found
        UID = $('#relatedMessageUID', context).val(); //$('.message:not(.reply):last', context).find('div[uniqueid]').attr('uniqueid')
        if( $('#listFolder', 'form#messagesListForm').attr('value') == folder )
            $item = $('#messageListTable', 'form#messagesListForm').find('tr#' + UID)
    }
    else if( $('form#messageListCompact').length != 0 )
    {
        UID = $('#relatedMessageUID', context).val(); //$('.message:not(.reply):last', context).find('div[uniqueid]').attr('uniqueid')
        if( $('#listFolder', 'form#messageListCompact').attr('value') == folder )
            $item = $('div#' + UID, 'form#messageListCompact')
    }
    if($item != false)
    {
        $icon = $item.find('#msgIcon')
    }
    if($icon != false)
    {
        // if all are read
        if($('.message:not(.reply) .unread', context).length == 0)
        {
            $icon.removeClass('unread');
            $item.removeClass('unread');
            if( !$icon.hasClass('read') )
                $icon.addClass('read')
            if( !$item.hasClass('read') )
                $item.addClass('read')
        }
        else
        {
            // at least one not read
            $item.removeClass('read');
            if( !$item.hasClass('unread') )
                $item.addClass('unread')
            $icon.removeClass('read');
            if( !$icon.hasClass('unread') )
                $icon.addClass('unread')
        }
        $item.find('.unseenStatus').val($('.message:not(.reply) h3.unread', context).length);
    }
}

function viewMessageClicked(clickedObject) 
{
	var folder = $(clickedObject).parent().parent().parent().children('input#listFolder').attr('value')	

	resultContext = $(clickedObject).parent().parent().parent('form.messagesListForm:first').children('input#resultContext').attr('value');
	toggleSelected2pane(clickedObject);
	enableMailActions();
	messageId = $(clickedObject).attr('id')
	var i = 1;
	var tabMatch = 0;
	
	//select message if already opened, else open message in new tab
	$('#navMessages li').each( function(i, e) 
	{
	    
		if( $(this).data('messageId') == messageId ) 
		{
		
			tabMatch = 1;
			$('#navMessages').tabs( 'select', $(this).attr('name') )
			//ensure read flag set
			flagSelectedMessages('seen');
			return
		
		}
		i++;
	
	})         
	
	// Need to catch return again, return above only breaks out of the .each
	if(tabMatch == 1)
		return;
	
	lastTabNumber++
	tabLabel = $(clickedObject).children('.subject').html().replace(/<\/?[^>]+(>|$)/g, "").substring(0,25)
	
	// TODO: maxTabsPossibleInWindow must be determined from the browser width ( or emulate FF tabs with the < > to cycle)
    var searchOffset = $("#search_anything").offset()
	var lastTabOffset = $('ul#navMessages li:last').offset()
	var lastTabWidth =  $('ul#navMessages li:last').width()

	//TODO: browser style non-fitting tabs dropdown, currently oldest tab is dropped/removed
	if( (searchOffset.left - lastTabOffset.left - lastTabWidth) < 190 )
	{
	
		$('div#navMessages').tabs('remove', 1)
	
	}

	$('div#navMessages').tabs('add','#viewmessageTab' + lastTabNumber, tabLabel)
	$('#viewmessageTab' + lastTabNumber).addClass('viewmessageTab')
	$('#viewmessageTab' + lastTabNumber).html('<div id="primary_header" class="loading"><h1>' + jsTranslate("Loading") + ' ' + tabLabel  +'...</h1></div>');
    
    //add messageId as data to new tab for checking for duplicates to 	
	$('li[name=#viewmessageTab' + lastTabNumber + ']').data('messageId', messageId)
	
	// if tabs are open, assign a class to the actions div
	if ( $(".viewmessageTab").is(":visible")) {
		$('#actions').addClass('viewmessageTabActions');
	} else {
		$('#actions').removeClass('viewmessageTabActions');
	}
	
	//now detect if this context is a search tab then append extra info to request
	postAppend = '';
	if( $('input#searching', '#' + resultContext ).length > 0 && $('input#searching', '#' + resultContext ).attr('value') == 'true' )
	{
		
		postAppend = '/searching/true/searchQuery/' + $('input#searchQuery', '#' + resultContext ).attr('value');
		
	}
	
	if( $(clickedObject).attr('threadChildrenUIDs') != undefined )
	{
		
		postAppend = postAppend + '/threadChildrenUIDs/' + $(clickedObject).attr('threadChildrenUIDs');
		
	}
	
	$.php( moduleBaseUrl + '/viewmessage/index/viewmessageTabNumber/' + lastTabNumber + '/folder/' + folder + '/uniqueId/' + messageId + postAppend )

	// The unread status is handled later

	//decriment folder unread count (??we are not reading all simultaneously, just the latest)
	//unseenDelta = (0 - Number($(clickedObject).children('.checkBox').children('input.unseenStatus').attr('value')));
	if( parseInt($(clickedObject).children('.checkBox').children('input.unseenStatus').attr('value')) > 0 )
	{
		
		$('#Email div[foldernameglobal=' + folder + '] .unread strong').updateCount( -1 );
		
	}
}

function viewMessageCompactClicked(clickedObject) 
{
	//need to know the current tab context so we talking to the correct view
	resultContext = $(clickedObject).parent('form:first').children('input#resultContext').attr('value');

	toggleSelected(clickedObject);
	enableMailActions();
	
	messageId = $(clickedObject).attr('id')
	$('.mail_row.selected', '#' + resultContext).each(function()
	{
	
		$(this).removeClass('selected');
	
	});
		
	$(clickedObject).addClass('selected');

	// The unread status is updated later

	var folder = $(clickedObject).parent().children('input#listFolder').attr('value')
	
	
	//now detect if this context is a search tab then append extra info to request
	postAppend = '';
	if( $('input#searching', '#' + resultContext ).length > 0 && $('input#searching', '#' + resultContext ).attr('value') == 'true' )
	{
		
		postAppend = '/searching/true/resultContext/' + resultContext + '/searchQuery/' + $('input#searchQuery', '#' + resultContext ).attr('value');
		
	}
	
	if( $(clickedObject).attr('threadChildrenUIDs') != undefined )
	{
		
		postAppend = postAppend + '/threadChildrenUIDs/' + $(clickedObject).attr('threadChildrenUIDs');
		
	} 
	
	if(resultContext == undefined)
	{
		// we are ASSUMING that the result context has cleared because a folder became empty
		$('#mail_info', '#messageList').html('');
	    $('#mail_info', '#messageList').block({ message: "<h1 class='loading-text'><img class='loadingimg' src='" + siteBaseUrl + "images/25.gif' width='28' height='28'/><span class='loading'>Loading...</span></h1>", overlayCSS: {backgroundColor: 'transparent', opacity: 0.4}, css: {backgroundColor: 'transparent',color: '#575757',border: '0'} });
	}
	else
	{
		$('#mail_info', '#' + resultContext).html('');
	    $('#mail_info', '#' + resultContext).block({ message: "<h1 class='loading-text'><img class='loadingimg' src='" + siteBaseUrl + "images/25.gif' width='28' height='28'/><span class='loading'>Loading...</span></h1>", overlayCSS: {backgroundColor: 'transparent', opacity: 0.4}, css: {backgroundColor: 'transparent',color: '#575757',border: '0'} });
	}

	if( folder!=undefined && messageId != undefined)
	{
		// IF the folder is now empty, or moved we can't render a preview!
		// Flag the cache for the URL via php.js call
		
		
		$.php( moduleBaseUrl + '/viewmessage/index/compact/1/folder/' + folder + '/uniqueId/' + messageId + postAppend, null, 1 );    
		// Blank out the previous message, make the UI feel like its loading the new message
	}
	else
	{
		// ensure read flag set
		flagSelectedMessages('seen');
		if(resultContext == undefined)
		{
			$('#mail_info', '#messageList').unblock();
		}
		else
		{
			$('#mail_info', '#' + resultContext).unblock();
		}
	}
	
	// Display the subject in the toolbar while the page loads
	var subject = $(clickedObject).find('H4').find('SPAN').text();
	if(subject != '')
	{
		// we have a subject, lets use it !
		$('#viewmessageSubject', '#' + resultContext).text('- ' + subject);
	}
	else
	{
		// no subject for this message so lets clear any existing text
		$('#viewmessageSubject', '#' + resultContext).text('');
	}
	
	//decriment folder unread count
	if( parseInt($(clickedObject).children('.checkBox').children('input.unseenStatus').attr('value')) > 0 )
	{
		$('#Email div[foldernameglobal=' + folder + '] .unread strong').updateCount( -1 );
	}
}


function dragMessages(draggedObj, context) { 
	
	$(draggedObj).addClass('selected')
	$('.messageCheckbox', $(draggedObj)).attr('checked',true);

	UID = $(draggedObj).attr('id')
	var dragMatch = 0;			
	// First, check the contacts we are dragging has been selected on the DnD
	$('.messageCheckbox:checked', context).each( function() {
		var checkedId = $(this).attr('value');
		if(checkedId == UID)
			dragMatch = 1;

		// Opacity out the selection, make it feel like the user action is doing something on screen
		$(this).parent().parent().css('opacity', 0.6);
		
	});
		
	var size = $('.messageCheckbox:checked', context).size()
	if(!size || dragMatch == 0)
		size = 1

	return $('<div class="email_drag"><div class="email_drag_no"><span class="drag"><strong>' + size + '</strong></span></div></div>')
}

function dragMessagesStop(draggedObj, context) { 
	
	// First, check the contacts we are dragging has been selected on the DnD
	$('.messageCheckbox:checked', context).each( function() {

		// Opacity out the selection, make it feel like the user action is doing something on screen
		if($(this).hasClass('nofade') ) {
			
		} else {
			$(this).parent().parent().css('opacity', 1);			
		}
		
	});
}

function dragMailFolder(draggedObj)
{
	draggedObj.css('opacity', 0.4);
	return $('<div class="email_drag_folder"></div>')
}

function dragMailFolderStop(draggedObj)
{
	draggedObj.css('opacity', 1);
}

function isDraggingMailFolder( ui )
{
	var foldername = ui.draggable.parent().attr('foldernameglobal');
	return foldername && foldername.indexOf("INBOX")>=0? true : false;	
}

function moveMailFolder(dragFolder, dropFolder)
{
	if(dragFolder.attr('ismainfolder') == 'true') {
		$.simpleFlash(jsTranslate('Mainfolder cannot be moved!'), 'error');
		return;
	}

	if(dropFolder.attr('ismainfolder') == 'true' && dropFolder.attr('foldernameglobal')!='INBOX') {
		$.simpleFlash(jsTranslate('You cannot drop a folder into Mainfolders'), 'error');
		return;
	}
	var fromFolder = dragFolder.attr('foldernameglobal');
	var toFolder = dropFolder.attr('foldernameglobal');

	$("span.spinner", dragFolder.parent()).show();
	var initial_url = moduleBaseUrl + '/mail/movefolder/from/' + fromFolder + '/to/' + toFolder;
	$.php(initial_url)

	return;
}

function setMessageDroppable( selector, overcallback, dropcallback )
{
	$(selector).droppable({
		accept: ".ui-draggable",
		activeClass: 'droppable-active',
		hoverClass: 'droppable-hover',
		over: overcallback,		
		drop: dropcallback
	})
} 

function setMessageDroppableFolder( selector ) 
{
	return setMessageDroppable( selector, 
		//over
		function () {},
		function(ev, ui) {
			if(isDraggingMailFolder( ui )) {
				moveMailFolder(ui.draggable.parent(), selector.parent());
				return;
			}
			
			// Can't drop to current folder
			if( $(this).parent().hasClass('current') )
				return
			var panelContext = $('.ui-tabs-selected', '#navMessages').attr('name')
			//DnD can currently only happen from list so contextFolder can only be 
			var contextFolder = $('#listFolder', panelContext).attr('value')

			ui.draggable.moveMessages( contextFolder, $(selector).parent().attr('folderNameGlobal'), panelContext )
		
		}
	);	
}

function resetMessagesDroppables() 
{
	
	$("#nav_secondary li a", '#Email').each( function() { if( $(this).parent().attr('isselectable') == 'true') setMessageDroppableFolder( $(this) ); });

	setMessageDroppable( $('#nav_add'), 
		// over
		function() {}, 
		// drop
		function(ev, ui)
		{
			var useremails = new Array();
			ui.draggable.parent().find('div.mail_row.selected,tr.selected').each( function() {
				var userText = $(this).find('.from,.mailFrom h3').attr('title');
				if(userText != '')
				{
					useremails.push(userText);
				}
			});

			if(!useremails.length)
			{
				return;
			}
			// add the email addresses to contacts
			$.php(moduleBaseUrl + '/contacts/addtoaddressbook', $.param({ 'mimeAddresses': useremails.join(',') }) )
			$.jCacher.remove('autocomplete')
			$.jCacher.remove('autocomplete_global')
		}
	);
}

$.fn.moveMessages = function( fromFolder, toFolder, contextIdString, actuallyDelete)
{
	if( contextIdString == undefined )
	{	
		contextIdString = '#messageList';	
	}
	
	var thisMatchedWithChecked = false;
	//warning: $(this).attr('id') makes this method dependant on DOM structure - any changes to DOM will break this
	//WARNING: DOM ID being used to store message UID could cause uniqueness problems with diff folders collectively possibly containing same UIDs
	var thisUID = $(this).attr('id')
    
	var initial_url = moduleBaseUrl + '/mail/movetofolder/fromFolder/' + fromFolder + '/toFolder/' + toFolder;

	if( actuallyDelete != undefined && actuallyDelete )
	{
		initial_url += "/actuallyDelete/1";	
	}

	$('.messageCheckbox:checked', contextIdString).each( function() 
	{
		$(this).addClass('nofade');
	
		if( $(this).attr('value') == thisUID )
		{
			thisMatchedWithChecked = true;			
		}
		
	})
	
	var appendUnseenString = '';
	
	if( $(this).children('.checkBox').children('input.unseenStatus').length > 0 )
	{
		appendUnseenString = '/unseen/' + $(this).children('.checkBox').children('input.unseenStatus').attr('value');	
	}
	
	if( $('.messageCheckbox:checked', contextIdString).size() > 0 && thisMatchedWithChecked )
	{
		$.php(initial_url, $(".messagesListForm", contextIdString).serializeArray())		
	}
	else
	{
		$.php(initial_url + '/UID/' + thisUID + '/resultContext/' + contextIdString.substr(1) + appendUnseenString )	
	}
		
	return false
}

jQuery.extend(
{

	emptyMailFolder:function( folder, contextIdString) 
	{
	
		if( contextIdString == undefined )
			contextIdString = '#messageList';

		$.php( moduleBaseUrl + '/mail/emptyfolder/folder/' + folder + '/contextId/' + contextIdString )

		return false

	}

})

function toggleSelected(clickedObject)
{
	// Remove previously selected rows
	clickedObject.parent().find('.messageCheckbox:checked').each(function(){ 
		this.checked = false;
		$(this).parent().parent().removeClass('selected');
	});
	
	// Create a checkbox of the selection
	$(clickedObject).find(':checkbox').each(function() {
		this.checked = true;
		$(this).parent().parent().addClass('selected');
	});
}

function toggleSelected2pane(clickedObject) {

	// Remove previously selected rows
	$('.messageItem.selected', '#Email').each(function(){

		$(this).find(':checkbox').each(function() {
			this.checked = false;
		});

		$(this).removeClass('selected');
	});
	
	// Create a checkbox of the selection
	$(clickedObject).find(':checkbox').each(function() {
		this.checked = false;
		this.focus()
		$(clickedObject).addClass('selected')
		//$('#action_contact_edit').enable();
	});
	
}

function toggleMail(clickedObject, context) {

	// Add the selected row if checkbox clicked, else remove
	if(clickedObject.checked)
	{
		
		$(clickedObject).parent().parent().addClass('selected')
		
	}
	else
	{
		
		$(clickedObject).parent().parent().removeClass('selected')
		
	}
		
	enableMailActions(context);

}

$.fn.disableActionSimpler = function()
{
		$(this).attr("disabled",true).css('opacity', 0.4).addClass('disabled');
} 

$.fn.enableActionSimpler = function()
{
		$(this).children().children().css('cursor', 'pointer');
		$(this).removeAttr("disabled").css('opacity',1).removeClass('disabled');
}

function enableMailActions(what) 
{
	var disableAll = false;
	var enableAll = false;
	
	context = getVisiblePanelContext();
    if( context == undefined)
    {
		context = '#Email';
    }
			
	// some actions are folder dependant so detect folder
	folderGlobalUTF7 = $('#primary_content #primary_content_inner form:first input#listFolder:first', context).attr('value');
	
	// match an email message tab to allow all actions
	if( context.indexOf('viewmessageTab') != -1)
	{
		enableAll = true;
	}
	
	// if tabs are open, assign a class to the actions div
	if ( $(".viewmessageTab").is(":visible")) {
		$('#actions').addClass('viewmessageTabActions');
	} else {
		$('#actions').removeClass('viewmessageTabActions');
	}
	

	var checkedRows = $('.messageCheckbox:checked:first', context).size();
	
	// check for a Forward tab, disable all if it is
	if( $(context).is('.composemessageTab, .forwardmessageTab, .replymessageTab') ) 
	{
		disableAll = true;
		enableAll = false;
	}
	
	if( context == '#Address_Book' )
	{
		disableAll = false;
		enableAll = true;
	}
	
	var parentObj = $(context).parent().parent();
	if(parentObj.attr('id') == 'header')
	{
		context = '#Email';
		parentObj = $(context);	
	}
	
	if( (!disableAll && enableAll) || (!disableAll && checkedRows >= 1) )	
	{
		$('#action_reply a', parentObj).enableActionSimpler();
		$('#action_reply_all a', parentObj).enableActionSimpler();
		$('#action_forward a', parentObj).enableActionSimpler();
		$('#action_junk a', parentObj).enableActionSimpler();
		$('#action_delete a', parentObj).enableActionSimpler();
		$('#action_more_markselectedasread', parentObj).show();
		$('#action_more_markselectedasunread', parentObj).show();
		$('#action_more_flagselected', parentObj).show();
		$('#action_more_unflagselected', parentObj).show();
		$('#action_more_deselectallmail', parentObj).removeClass('bottom');
	}
	else
	{
		$('#action_reply a', parentObj).disableActionSimpler();
		$('#action_reply_all a', parentObj).disableActionSimpler();
		$('#action_forward a', parentObj).disableActionSimpler();
		$('#action_junk a', parentObj).disableActionSimpler();
		$('#action_delete a', parentObj).disableActionSimpler();
		$('#action_more_markselectedasread', parentObj).hide();
		$('#action_more_markselectedasunread', parentObj).hide();
		$('#action_more_flagselected', parentObj).hide();
		$('#action_more_unflagselected', parentObj).hide();
		$('#action_more_deselectallmail', parentObj).addClass('bottom');
	}
	if( folderGlobalUTF7 == 'INBOX.Trash' || folderGlobalUTF7 == 'INBOX.Spam' || folderGlobalUTF7 == 'Trash' || folderGlobalUTF7 == 'Spam')
	{	
		if(folderGlobalUTF7 == 'INBOX.Spam' || folderGlobalUTF7 == 'Spam')
		{
			$('#action_junk', parentObj).hide();
		}
		$('#action_empty', parentObj).show();
		$('#action_empty a', parentObj).enableActionSimpler();
	}
	else
	{
		$('#action_junk', parentObj).show();

		if(checkedRows) {
			$('#action_junk a', parentObj).enableActionSimpler();
		}
		else {
			$('#action_junk a', parentObj).disableActionSimpler();
		}
		$('#action_empty', parentObj).hide();
	}
}

function folderCreate( folderContext, makeRootFolder ) 
{

	if( makeRootFolder == undefined )
	{
		
		makeRootFolder = false;
		
	}
	
	if( $('#folderFormNew', '#Email').length != 0 ) 
		return false

	var currentObj = $('.current', folderContext);
	var isMainFolder = currentObj.attr('ismainfolder');
			
	if( isMainFolder == 'true' || makeRootFolder == true )
	{
		//create folder at bottom of folder list, else as new subfolder
		$(folderContext).append( 
					'<li><div folderNameGlobal="" id="" >' + 
					'<form id="folderFormNew" method="post" target="_blank">' + 
					'<input name="folderNameNew" value="New Folder">' + 
					'</form>' + 
					'</div></li>'
		);
		
	}                       
	else
	{
		var nodeObj = currentObj.parent().children('ul');
		if(!nodeObj.length)
		{
			currentObj.parent().append('<ul class="subfolder"></ul>');
			nodeObj = currentObj.parent().children('ul');
		}
		nodeObj.append(
					'<li><div folderNameGlobal="" id="" >' + 
					'<form id="folderFormNew" method="post" target="_blank">' + 
					'<input name="folderNameNew" value="New Folder">' + 
					'</form>' + 
					'</div></li>'
		);	
		folderTreeView.expand( nodeObj );
	}   
	
	$("#Email #secondary").scrollTo( $('form#folderFormNew', '#Email #nav_secondary').parent() );

	$('#folderFormNew', '#Email').unbind('blur');
	$('#folderFormNew', '#Email').unbind('submit');

	$('#folderFormNew input', '#Email').bind('blur', function(e) {
		$(this).parent().submit();
		e.stopPropagation();
	}).select()

	$('#folderFormNew', '#Email').submit( function(e) {
	
		div = $(this).parent()
		
		//clean RFC reserved chars out and encode
		var folderNameNew = $(this).children('input').attr('value');
		
		// Detect, do we have the namespace (.) as a folder name?
		var iChars = "#<>."; 
		for (var i = 0; i < folderNameNew.length; i++) {
			if (iChars.indexOf(folderNameNew.charAt(i)) != -1) {
				alert ("Your folder name has special characters. The characters '" + iChars + "' are not allowed for a folder name" );
				$("INPUT[name=folderNameNew]").focus();
				e.stopPropagation();
				return false;
			}
		}
		
		
		// Replace \ + / path with _
		folderNameNew = folderNameNew.replace(/\//g,'_').replace(/\\/g,'_')

        // TODO: Remove language string
		if( folderNameNew == 'New Folder' || folderNameNew == '' ) 
		{
		
			div.parent().remove()                                          
			return false
		
		}

		
		folderNameNewUrlencodedDouble = urlencode( urlencode( folderNameNew ) );
	    
		//CONSIDER: use clone instead to transparently cope with html changes to the list
		div.attr('folderNameGlobal', folderNameNewUrlencodedDouble )
		div.html('<a class="ui-droppable" href=""><span class="label">' + htmlentities(folderNameNew) + '</span><span class="unread" style="display:none;"><strong>0</strong></span></a>')
		$.php(moduleBaseUrl + '/mail/foldercreate/folderNameNew/' + folderNameNewUrlencodedDouble + (makeRootFolder?'/makeRootFolder/1':''));
		
		// setMessageDroppableFolder( div.children('a:first') );
		// only set up treeView on the node if it is the first
		if( !makeRootFolder && $('.current', '#Email #nav_secondary').parent().find('.handle').length == 0)
		{			
			folderTreeView.addNode( $('.current', '#Email #nav_secondary').parent() );
		}
		
		//resetDroppables()
		return false;
		
    })
	return false;

}

function folderRename(clickedAnchor) { //rename folder
	
	if( $('#folderFormUpdate', '#Email').length != 0 )
	{
		
		return false;
		
	}
		
	var div = $(clickedAnchor).parent();
	//do not allow editing names of main folders
	//TODO: A6 specd to allow this, so upgrade to referring from custom folder names from db/translation
	if(div.attr('ismainfolder') == 'true') 
	{       
	
		//$.flash.subtle('Currently not allowed to rename main folders.')
		$.simpleFlash(jsTranslate('This folder can not be renamed.'), 'error');
		return;                           
	
	}

	li = div.parent()
	folderNameOld = div.children('a:first').children('span.label').text();
	
	// Hide the label text
	div.hide();
	//Hide the treeview plus icons so enough space for inut
	li.children('span.handle').hide();
    
    // Create a form to specify the new name
	$('<form id="folderFormUpdate" method="post" target="_blank"><input name="folderNameNew" value="' + htmlentities(folderNameOld) + '"></form>').insertAfter(div); 

	
	form = $('#folderFormUpdate')
	input = form.children('input')
	input.select()

	input.bind('blur', function() 
	{
	
		$(this).parent().submit()
	
	})
	
	form.submit( function() 
	{ 
		form = $(this)
		folderNameGlobalOld = $(this).parent().children('div:first').attr('folderNameGlobal')
		
		folderNameNew = $(this).children('input').attr('value')

		//clean RFC reserved chars out and encode
		var folderNameNew = $(this).children('input').attr('value');
		if( folderNameNew.charAt(0) == '#' )
		{
			
			folderNameNew = folderNameNew.substr(1, (folderNameNew.length-1) );
			
		}
		folderNameNew = folderNameNew.replace(/\//g,'_')
		
		if( $(this).children('input').attr('value') != folderNameNew )
		{
			
		 	$(this).children('input').attr('value', folderNameNew)
		
		}
		
		// TODO: Remove language string
		if( folderNameNew == '' ) 
		{
			form.remove()
			div.show();
			li.children('span.handle').show(); 
			spinner.hide();                                         
			return false
		
		}
		
		folderNameNewEncoded = urlencode( urlencode( folderNameNew ) ); //need to double encode cos ZF decodes then finds / in url and gets confused

        form.html('Saving...');
		
		// Show the original div
		if(folderNameOld != folderNameNew) {
			var spinner = $('span.spinner:first', li);
			spinner.show();
			$.php(moduleBaseUrl + '/mail/folderrename/folderNameGlobalOld/' + folderNameGlobalOld + '/folderNameNew/' + folderNameNewEncoded )
		}
		
		// Remove from the DOM the html form for editing
		form.remove();
		div.show();
		li.children('span.handle').show();
		
		return false
		
	})
	  
}

$.fn.updateChildrenGlobalFolder = function( oldGlobalName, newGlobalName )
{
	//recursive
	//should be executed on the div folder heading, so need ot go up 1 to parent
	if( $(this).parent().children('ul').length > 0 && $(this).parent().children('ul').children('li').length > 0 )
	{
		
		$(this).parent().children('ul').children('li').each( function() 
		{
			
			var nodeFolderNameGlobalCurrent = $(this).children('div:first').attr('folderNameGlobal');
			var nodeFolderNameGlobalNew = nodeFolderNameGlobalCurrent.replace(oldGlobalName, newGlobalName);
			$(this).children('div:first').attr('folderNameGlobal', nodeFolderNameGlobalNew)
			
			//we need to do same with href
			//CONSIDER dropping duplicated href data
			var nodeHrefCurrent = $(this).children('div:first').children('a:first').attr('href');
			var nodeHrefNew = nodeHrefCurrent.replace(oldGlobalName, newGlobalName);
			$(this).children('div:first').children('a:first').attr('href', nodeHrefNew)
			
			//recurse for possible children
			$(this).children('div:first').updateChildrenGlobalFolder( oldGlobalName, newGlobalName ); 
		
		})		
		
	}	                                                                   
	
}

function folderRemove( nodeLi ) {

	// TODO: Remove any english language strings from the JS array
	
    
	//double check not trying to delete main folder
	if( $(nodeLi).children('div:first').attr('ismainfolder') == 'true' ) 
	{
		
		return false;
		
	}
	
	var folderNameUTF8 = html_entity_decode( $('div:first span.label', nodeLi).text() );
	                                                                                                                                       
    var confirmMessage = 'Are you sure you want to delete ' + folderNameUTF8; 

	//check if has children
	if( $(nodeLi).children('ul').length > 0 && $(nodeLi).children('ul').children('li').length > 0 )
	{
		
		confirmMessage = confirmMessage + ' and its sub-folders?';		
		
	}
	else
	{
		
		confirmMessage = confirmMessage + '?';
		
	}

	if( confirm(confirmMessage) ) 
	{
		
		//currentFolderLi = $('.current', '#Email #nav_secondary').parent();
		var folderNameGlobal = $('div:first', nodeLi).attr('folderNameGlobal');
		$.php(moduleBaseUrl + '/mail/folderremove/folderNameGlobal/' + folderNameGlobal )
	    
	}
    
}

$.fn.removeTreeNode = function() 
{
	
 	if( $(this).parent().parent().children('li').length < 2 )
	{
	
		$(this).parent().parent().parent().children('span.handle').remove(); // remove the +- box
		$(this).parent().parent().remove(); //remove parent ul
		
	}
	else
	{
	
		$(this).parent().remove();
		
	}
	
}

function _folderRemoveRecursive( nodeLi )
{
	
	if($(nodeLi).children('ul').length > 0 && $(nodeLi).children('ul').children('li').length > 0)
	{
		$(nodeLi).children('ul').children('li').each( function() {
		
			_folderRemoveRecursive( $(this) );
		
		})
	}  
	$.php(moduleBaseUrl + '/mail/folderremove/folderNameGlobal/' + $(nodeLi).children('div').attr('folderNameGlobal') );
	
}

function removeTab(tabName)
{
	var lastTab = $(tabName).attr('name');
	//search through list to find a match which will reveal the index # so can pass # to jQuery tabs to remove
	$('#navMessages li').each( function(tabIndex) { 
		if( $(this).attr('name') == $(tabName).attr('name') ) {
			$('#navMessages').tabs('remove', tabIndex);
		}
	})

	if( $('#navMessages li').length == 1 && lastTab.indexOf("calendarTab") == -1)
	{
		$('#nav').tabs('select', 0);
	}
	else if( $('#navMessages li').length == 1 && lastTab.indexOf("calendarTab") != -1)
	{
		$('#nav').tabs('select', CALENDAR_TAB_ID);			
	}
	
	return false

}

function prepareEditor(type) 
{	
	//first see if a tab is open to scroll to its own reply section, else open a new tab replying (with a full compose screen)
	var visiblePanelContext = getVisiblePanelContext();
	$('iframe.rte-zone-reply', visiblePanelContext).contents().unbind('click');
	
	//first try focus on the reply block if exists in current context (message view)
	if( $('#composeMessage', visiblePanelContext).length == 0 ) 
	{
		
		//no message open so try use first checked checkbox from currently selected tab
		var relatedMessageFolder = $('#listFolder', visiblePanelContext).attr('value');
		var uniqueId = $('.messageCheckbox:checked:first', visiblePanelContext).attr('value');
		replyInNewTab(uniqueId, relatedMessageFolder, type);
		return;
	
	} 
	else
	{
		// Show the HTML editor, this could be hidden from a previous message send request in 3-pane
		$('.reply', visiblePanelContext).show();

        // perform actions in context of selected tab
		$nodeCheckList = $('#nodeReplyBtnAnchor', visiblePanelContext)
		$nodeReplyAllList = $('#replyall a', visiblePanelContext)
		
		$nodeCheckListLength = $nodeCheckList.length
		var i = $nodeCheckListLength-1;
		while( $($nodeCheckList[i]).parent().parent().parent().parent().parent().children('.body').html().length < 20 && i >= 0  )
			i--

        scrollToComposer();

		if(type == 'replyall')
		{
			//$('#replyAll', visiblePanelContext).attr('checked', true).change();
			if( $($nodeReplyAllList[i]).length != 0)
				$($nodeReplyAllList[i]).trigger('click'); // trigger populating form with correct (last) thread nodes data (in case user had previously clicked reply to other node)
		}
		else if(type == 'reply')
		{
//			$('#replyAll', visiblePanelContext).attr('checked', false).change();
			if( $($nodeCheckList[i]).length != 0)
				$($nodeCheckList[i]).trigger('click'); // trigger populating form with correct (last) thread nodes data (in case user had previously clicked reply to other node)
		}
	}

}

function selectAllMail() {
	
	jsddm_close();
	
	$('.messageCheckbox:checkbox', getVisiblePanelContext()).each(function()
	{ 
	
		this.checked = true;
		$(this).parent().parent().addClass('selected');
	
	});
	
}

function deselectAllMail() {
	
	jsddm_close();
	
	$('.messageCheckbox:checkbox', getVisiblePanelContext()).each(function()
	{ 
	
		this.checked = false;
		$(this).parent().parent().removeClass('selected');
	
	});
	
}

function flagSelectedMessages(flag, appendFlag ) 
{
	
	jsddm_close();
	if( appendFlag == undefined || appendFlag == true || appendFlag == 'true' || appendFlag == '1' )
		appendFlag = 'true'
	else 
		appendFlag == 'false'
		
	var visiblePanelContext = getVisiblePanelContext();
	//need to determine if visible tab context is a message or a list
	if( visiblePanelContext == '#messageList' )
	{
		if (flag == 'flagged')
		{
			$('.messageCheckbox:checkbox:checked', visiblePanelContext).each( function()
			{ 
				if( $(this).parent().children('#msgIcon').length == 0 )
					icon = $(this).parent().parent().find('#msgIcon')
				else
					icon = $(this).parent().children('#msgIcon')
				if( !$(icon).hasClass('flagged') )
					$(icon).addClass('flagged')

			})
		}
		else if (flag == '-flagged')
		{
			$('.messageCheckbox:checkbox:checked', visiblePanelContext).each( function()
			{ 
				if( $(this).parent().children('#msgIcon').length == 0 )
					icon = $(this).parent().parent().find('#msgIcon')
				else
					icon = $(this).parent().children('#msgIcon')
				if( $(icon).hasClass('flagged') )
					$(icon).removeClass('flagged')

			})
		}
		else if( flag == 'seen' )
		{
			$('.messageCheckbox:checkbox:checked', visiblePanelContext).each( function()
			{ 
				if( $(this).parent().children('#msgIcon').length == 0 )
					icon = $(this).parent().parent().find('#msgIcon')
				else
					icon = $(this).parent().children('#msgIcon')
				if( $(icon).hasClass('unread') )
					$(icon).removeClass('unread')
			    if( !$(icon).hasClass('read') )
					$(icon).addClass('read')
				//now mark main div as unread cos also CSS
				if( $(this).parent().parent().hasClass('unread') )
				{
					$(this).parent().parent().removeClass('unread').addClass('read');
				}

			})
			
		}
		else if( flag == 'unseen' )
		{
		
			$('.messageCheckbox:checkbox:checked', visiblePanelContext).each( function()
			{ 
				if( $(this).parent().children('#msgIcon').length == 0 )
					icon = $(this).parent().parent().find('#msgIcon')
				else
					icon = $(this).parent().children('#msgIcon')
				if( !$(icon).hasClass('unread') )
					$(icon).addClass('unread')
				if( $(icon).hasClass('read') )
					$(icon).removeClass('read')
				//now mark main div as unread cos also CSS
				if( $(this).parent().parent().hasClass('read') || !$(this).parent().parent().hasClass('unread') )
				{
					$(this).parent().parent().removeClass('read').addClass('unread');
				}

			})
		
		}
		var folder = $(".messagesListForm", visiblePanelContext).children('#listFolder').attr('value')
		var action = moduleBaseUrl + '/mail/flagmessage/flag/' + flag + '/appendFlag/' + appendFlag + '/selectFolder/' + folder
		$.php(action, $(".messagesListForm", visiblePanelContext).serializeArray())
		
	}
	else
	{

		var folder = $("form#composeMessage #relatedMessageFolder", visiblePanelContext).attr('value')
		var mailId = $('form#composeMessage #relatedMessageUID', visiblePanelContext).attr('value')
		var action = moduleBaseUrl + '/mail/flagmessage/flag/' + flag + '/appendFlag/' + appendFlag + '/selectFolder/' + folder + '/mailId/' + mailId
        $icon = false
		if( $('form#messagesListForm').length != 0 ) //2 pane
		{
			
			if( $('#listFolder', 'form#messagesListForm').attr('value') == folder )
				$icon = $('#messageListTable', 'form#messagesListForm').find('tr#' + mailId).find('#msgIcon')
			
		}
		else if( $('form#messageListCompact').length != 0 )
		{
		
			if( $('#listFolder', 'form#messageListCompact').attr('value') == folder )
				$icon = $('div#' + mailId, 'form#messageListCompact').find('#msgIcon')
		
		}
		if( (flag == 'seen' || flag == 'read') && $icon != false)
		{
			if( $icon.hasClass('unread') )
				$icon.removeClass('unread')
		
			if( !$icon.hasClass('read') )
				$icon.addClass('read')
		}
		else if( (flag == 'unseen' || flag == 'unread') && $icon != false)
		{
			if( $icon.hasClass('read') )
				$icon.removeClass('read')
		
			if( !$icon.hasClass('unread') )
				$icon.addClass('unread')
		}
		else if( (flag == 'flagged') && $icon != false)
		{
			if( !$icon.hasClass('flagged') )
				$icon.addClass('flagged')
		}
		else if( (flag == '-flagged') && $icon != false)
		{
			if( $icon.hasClass('flagged') )
				$icon.removeClass('flagged')
		}
		
		$.php(action)
	}
	
}

function var_dump(element, limit, depth)
{
	depth =	depth?depth:0;
	limit = limit?limit:1;

	returnString = '<ol>';

	for(property in element)
	{
		//Property domConfig isn't accessable
		if (property != 'domConfig')
		{
			returnString += '<li><strong>'+ property + '</strong> <small>(' + (typeof element[property]) +')</small>';

			if (typeof element[property] == 'number' || typeof element[property] == 'boolean')
				returnString += ' : <em>' + element[property] + '</em>';
			if (typeof element[property] == 'string' && element[property])
				returnString += ': <div style="background:#C9C9C9;border:1px solid black; overflow:auto;"><code>' +
									element[property].replace(/</g, '&amp;lt;').replace(/>/g, '&amp;gt;') + '</code></div>';

			if ((typeof element[property] == 'object') && (depth < limit))
				returnString += var_dump(element[property], limit, (depth + 1));

			returnString += '</li>';
		}
	}
	returnString += '</ol>';

	if(depth == 0)
	{
		winpop = window.open("", "debug","width=800,height=600,scrollbars,resizable");
		winpop.document.write('<pre>'+returnString+ '</pre>');
		winpop.document.close();
		if( window.focus )
			winpop.focus();
	}	

	return returnString;
}

function searchHandle() {
	// If we are the 2nd tab ( abook ) search that, else we are a mail action
}

function issetSearch(sanitized_array)
{
	for(var i in sanitized_array) {
		if(sanitized_array[i].value.length && sanitized_array[i].name != 'goBack') {

			if(sanitized_array[i].name == 'searchQuery' && sanitized_array[i].value == 'Search Mail...') {
				continue;
			}

			return true;
		}
	}
	return false;
}

function searchMail() 
{
	
	// If within the abook panel, disable searching mail, we are searching the abook only
	//if($("#Address_Book").css('display') == 'block');
	var sanitized_array = $('#searchForm').serializeArray();
	if(!issetSearch(sanitized_array)) return;
	 	
	lastTabNumber++
	tabLabel = "Search";
	var searchOffset = $("#search_anything").offset();
	var lastTabOffset = $('ul#navMessages li:last').offset();
	var lastTabWidth =  $('ul#navMessages li:last').width()
	//TODO: browser style non-fitting tabs dropdown, currently oldest tab is dropped/removed
	if( (searchOffset.left - lastTabOffset.left - lastTabWidth) < 190 )
		$('div#navMessages').tabs('remove', 1)                                        
	
	$('div#navMessages').tabs('add','#searchResultsTab' + lastTabNumber, tabLabel)
	$('#searchResultsTab' + lastTabNumber).addClass('viewmessageTab')
	$('#searchResultsTab' + lastTabNumber).addClass('searchTab')
    

	$('#searchResultsTab' + lastTabNumber).bind('tabSelected', function() {
        
		enableMailActions();      
	    
	});
    $('#searchResultsTab' + lastTabNumber).trigger('tabSelected')
	$('#searchResultsTab' + lastTabNumber).html('<div id="primary_header" class="loading"><h1>' + jsTranslate("Searching...") + '</h1></div><div id="primary_content"></div>');
	$('#searchResultsTab' + lastTabNumber + ' #primary_content').block({ message: "<h1 class='loading-text'><img class='loadingimg' src='" + siteBaseUrl + "images/25.gif' width='28' height='28'/><span class='loading'>Loading...</span></h1>", overlayCSS: {backgroundColor: 'transparent', opacity: 0.4}, css: {backgroundColor: 'transparent',color: '#575757',border: '0'} });
	 
	
	folderContext = $('ul#nav_secondary div.current').attr('foldernameglobal')

	for ( var i in sanitized_array )
	{
		// do a quick xss sanitize
	 	sanitized_array[i].value = sanitized_array[i].value.replace(/\</g, "");
	 	sanitized_array[i].value = sanitized_array[i].value.replace(/\>/g, "");
	 	sanitized_array[i].value = sanitized_array[i].value.replace(/'/g, "");
	 	sanitized_array[i].value = sanitized_array[i].value.replace(/"/g, "");
	 	sanitized_array[i].value = sanitized_array[i].value.replace(/\\/g, "");
	} 

	$('input[type=text]','#searchForm').each(function(){$(this).val('');});

	$.php(moduleBaseUrl + '/mail/listfoldermessages/searching/true/selectFolder/' + folderContext + '/resultContext/searchResultsTab' + lastTabNumber, sanitized_array);

}

function toggleThread(clickedObj, contentUrl )
{
    var msgIcon = $(clickedObj).find('.meta').find("#msgIcon");
    var relatedFolder = $(clickedObj).find('[folder]').attr('folder');
    // check if the body has been loaded
	if( $(clickedObj).data('bodyLoaded') == null)
	{ 
		// not loaded so fetch the data
		// prepiframemessage will provide caching
        var body = $(clickedObj).siblings('.body');
        body.bind('click', function(e) {e.stopPropagation();});
		body.load( contentUrl, null, function (responseText, textStatus, XMLHttpRequest) {});
		$(clickedObj).data('bodyLoaded', true);
        if($(clickedObj).find('.unread').length)
        {
            // this message was unread before we just loaded it, so update the counter
            $('#Email div[foldernameglobal=' + relatedFolder + '] .unread strong').updateCount( -1 );
        }
	}
	
	// animate the thread show
	var parentObj;
	parentObj = $(clickedObj).parent().parent().parent();
	parentObj.stop(true,true);
	isContracted = parentObj.is('.contracted');
	var msgIcon = $(clickedObj).find('.meta').find("#msgIcon");
    var visibleContext = getVisiblePanelContext();
    if ( isContracted )
	{
		if ( $.browser.mozilla )
		{
			parentObj.removeClass('contracted', 'fast');
		}
		else
		{
			parentObj.removeClass('contracted');
		}
		msgIcon.removeClass('unread')
        $(clickedObj).find('.unread').removeClass('unread');
        resizeImgAttachments(visibleContext);
    }
	else
	{
		if ( $.browser.mozilla )
		{
			parentObj.addClass('contracted', 'fast');
		}
		else
		{
			parentObj.addClass('contracted');
		}
	}

    updateUIFlags(relatedFolder, visibleContext);
}

// Scroll the composer to the current view
function scrollToComposer(animated)
{
	visibleContext = $('.ui-tabs-selected', '#navMessages').attr('name')  

	var element = $("#primary_content", visibleContext);
	if($("#mail_info", visibleContext).length)
	{
		element = $("#mail_info", visibleContext);
	}
	if(animated == undefined || animated)
	{
		element.scrollTo(element.attr('scrollHeight'), "normal");
	}
	else
	{
		element.attr('scrollTop', element.attr('scrollHeight'));
	}
}

function folderListMessages(clickedObject) {

	//return if !isSelectable
	if( $(clickedObject).parent().attr('isselectable') == 'false' )
	{
		
		$(clickedObject).parent().parent().children('span.handle:first').click();
		return false;
		
	}
	
	//return if busy editing folder name
	if( $('#folderFormUpdate', '#Email').length != 0 ) 
	{
		
		return false;
		
	}
    $('#Email #primary #messageList #primary_content').html('');
	$('#Email #primary #messageList #primary_content').block({ message: "<h1 class='loading-text'><img class='loadingimg' src='" + siteBaseUrl + "images/25.gif' width='28' height='28'/><span class='loading'>Loading...</span></h1>", overlayCSS: {backgroundColor: 'transparent', opacity: 0.4}, css: {backgroundColor: 'transparent',color: '#575757',border: '0'} });

	$('#navMessages').tabs('select', 0);
	// when listing a folder, we must ensure the
	$('#nav').tabs('select', 0);


	//$(clickedObject).parent().parent().children('li.current').removeClass('current')
	$('.current', '#Email').removeClass('current');
	$(clickedObject).parent().addClass('current'); 

	if( $(clickedObject).parent().attr('ismainfolder') == 'true' ) 
	{
	    $('#folder_actions #folder_remove a').removeClass('enabled').addClass('disabled')           
	    $('#folder_actions #sub_folder_add a').hide();      	
	}
	else
	{
		$('#folder_actions #folder_remove a').removeClass('disabled').addClass('enabled');
	    $('#folder_actions #sub_folder_add a').show();
	}

	// 2-pane
	$("#messageList .messages").remove();
	$("#messageList .pagingtxt").remove();
	
	// 3-pane
	$(".mail_row", '#messageList').remove();
	$("#composeMessage", '#messageList').remove();
	$(".mail_row_paginator", '#messageList').remove();
	$("#viewmessageSubject").text("");
	folder = $(clickedObject).children('.label').html()
	
	$("#viewFolder", '#Email').html( folder );
	
	// Load the message
	$.php( $(clickedObject).attr('href') )
	return false

}

function applyFolderCustomizations(clickedObject)
{
	var selectedFolder = $(clickedObject).parent().attr('foldernameglobal');
	
	if(selectedFolder == undefined)
	{
		selectedFolder = '';
	}
	// APPLY CUSTOM HANDLING FOR ANY SPECIAL FOLDERS
	switch(selectedFolder.toLowerCase())
	{
		case 'inbox.trash':
		{
			$('strong', '#action_delete', '#Email').text(jsTranslate('Erase'));
		} break;
		default:
		{
			$('strong', '#action_delete', '#Email').text(jsTranslate('Delete'));
		} break;
	}	
}

function resizeImgAttachments(context)
{
    if( $("#mail_info li img", context).length > 0 )
    {
        $("#mail_info li img", context).each(function()
        {
            $(this).css('max-width', ($("#mail_info", context).innerWidth() - 120) + "px");
        });
    }
    else
    {
        $("#primary_content li img", context).each( function()
        {
            $(this).css('max-width', ($("#primary_header", context).innerWidth() - 120) + "px");
        });
    }
}


function resizeComposer(context, scrollToComp, animated) 
{
	// 2-pane	
	// 3 pane
	if(animated == undefined)
	{
		animated = false;
	}
	
	if(scrollToComp == undefined)
	{
		scrollToComp = false;
	}

	var extra = 0;
	if ( $('#replyAttach', '#' + context).css('display') == 'block' )
	{
		extra = 45;
	}
	
	if ( $('#subject', '#' + context).css('display') == 'block' )
	{
		extra += 45;
	}
	
	if ( $('#replyBcc', '#' + context).css('display') == 'block' )
	{
		extra += 45;
	}
	
	if ( $.browser.msie )
	{
		extra = extra + 44;
	}
	
	var total = 60;
	var wrapper_height = 15;
	var details_height = 45;
	var rte_toolbar_height = 45;
	var button_area = 60;

	if ( $.browser.msie )
	{
		extra = extra - 4;
	}

	iframeHeight = ($("#primary_content", '#' + context).height() - details_height - wrapper_height - rte_toolbar_height - button_area - extra - total);

	// Minimum height
	if(iframeHeight < COMPOSER_MINIMUM_HEIGHT)
	{
		iframeHeight = COMPOSER_MINIMUM_HEIGHT;
	}
	
	if(scrollToComp == undefined)
	{
		scrollToComp = false;
	}
	if (scrollToComp && $('iframe.rte-zone-reply:visible', '#' + context).length)
	{
		if(animated)
		{
			$('iframe.rte-zone-reply', '#' + context).stop(true, true).animate({height : iframeHeight }, "normal", function() { scrollToComposer(false); });
		}
		else
		{
			$('iframe.rte-zone-reply', '#' + context).height(iframeHeight);
			scrollToComposer(false);			
		}
	}
	else
	{
		if(animated)
		{	
			$('iframe.rte-zone-reply', '#' + context).stop(true, true).animate({height : iframeHeight}, "normal");
		}
		else
		{
			$('iframe.rte-zone-reply', '#' + context).height(iframeHeight);			
		}
	}

    resizeImgAttachments('#' + context);

    return true;
}

function resizeNewComposer(context, msgTab, scrollToComp)
{
	var animated = false;
	var bodyHeight = $('#primary_content', msgTab).innerHeight();
	if(bodyHeight == undefined)
	{
		// 3 pane
		msgTab = '#messageList';
		bodyHeight = $('#primary_content', msgTab).innerHeight();
	}

	if(bodyHeight == 0)
	{
		// we are probably out of focus, or on a different tab, lets not resize as we dont know the height !
		return;
	}	
	
	
	var extra = 0;
	
	if ( $.browser.msie )
		extra = 244;
	else
		extra = 250;
	
	if ( $('#show-more', msgTab).css('display') == 'block' && $.browser.msie)
		extra = 89 + extra;
	else if ( $('#show-more', msgTab).css('display') == 'block' )
		extra = 68 + extra;
	
	iframeHeight = (bodyHeight - extra);
	if(iframeHeight < COMPOSER_MINIMUM_HEIGHT) iframeHeight = COMPOSER_MINIMUM_HEIGHT;

	if(scrollToComp == undefined)
		scrollToComp = false;
	// Foreach composer tab, resize them ( current view, and others in construction )
	if(animated)
	{
		$('iframe.rte-zone', msgTab).animate({height : iframeHeight}, "normal");
	}
	else
	{
		$('iframe.rte-zone', msgTab).height(iframeHeight);		
	}
}

function removeAttachment(name, path, DOMObject) {
		
	if( confirm('Are you sure you want to remove attachment ' + name ) ) {
	    
		$.getJSON(moduleBaseUrl + '/composemessage/removeattachment', {'filenameFS': path}, function (data, testStatus) {
			if(data.error == 0 ) {
				//fileUniqueId = DOMObject.children('.attachmentName').html().replace(/[^a-zA-Z0-9]+/g,'')
				//$('#' + fileUniqueId).remove()
				DOMObject.remove()
			} else {
				alert('Error removing attachment')
			}
		})
	
	}
	return false
	
}


function openHelp(file) {
	var left = parseInt((screen.availWidth/2) - (700/2));
	var top = parseInt((screen.availHeight/2) - (500/2));
	window.open(moduleBaseUrl + "/settings/help/helpFile/" + file, null, "height=500,width=750,status=yes,toolbar=no,menubar=no,location=no,left=" + left + ",top=" + top);	
}



/*
 * Widget for pagnation control
 * 
 * Brett: consolidated pagnation code from templates into simple(ish) object 
 * 
 */

/*
 * createPagnation
 * - creates the widget under the target selector
 * $('someselector').createPagnation(..)
 */

$.fn.createPagnation = function(context /* '#<?php echo $this->resultContext; ?>' */,
								siteBaseUrl /* $this->siteBaseUrl */, 
								moduleBaseUrl /* $this->moduleBaseUrl */, 
								page /* $this->pageNumber */, 
								total /* $this->totalMessages */, 
								volume /* $this->pageVolume */, 
								currentFolder /* urlencode(urlencode($this->currentFolder)) */, 
								postAppend /* $postAppend */)
{
	var selected;
	
	// ensure input is numeric
	page = Number(page);
	total = Number(total);
	volume = Number(volume);
	
	// remove old pagnation
	$(this).children('#mail_row_paginator').remove();

	// ***** GENERATE PAGNATION HTML ***** //
	// Thought : should create skeleton here, then call updatePagnation to consolidate code
	var html = '<div class="mail_row_paginator">';
	
	// ** create dropdown to enable quickly selecting specific page of list **
	html += '<select name="page" id="pageSelect">';
	for(var a = 1; a < Math.ceil(total/volume) + 1; a++)
	{
		selected = '';
		if(a == page)
		{
			// we found the current page, select it
			selected = ' selected';
		}
			
		html += '<option' + selected + ' value="' + a + '">' + ((a*volume) - volume + 1) + '-' + ((a*volume>total)?total:a*volume) + '</option>';
	}
	html += '</select>';
	html += '<span> of ' + total + ' </span>';
	
	// buttons
	html += '<div class="' + (page>1?'active-prev':'disable-prev') + ' pagingIcon pagingIconLeft" width="25" height="20" alt="Previous page" ' + ((page>1)? ' onclick="$.php(\'' + moduleBaseUrl + '/mail/listfoldermessages/selectFolder/' + currentFolder + '/page/' + (page-1) + postAppend + '\')">' : '>');
	html += '&nbsp;</div>';
	html += '<div class="' + (page<(Math.ceil(total/volume))?'active-next':'disable-next') + ' pagingIcon pagingIconRight" src="' + siteBaseUrl + 'images/paging-next' + (page<(Math.ceil(total/volume))?'':'-grey') + '.png" width="23" height="20" alt="Next page"' + ((page<(Math.ceil(total/volume))) ? ' onclick="$.php(\'' + moduleBaseUrl + '/mail/listfoldermessages/selectFolder/' + currentFolder + '/page/' + (page+1) + postAppend + '\')">' : '>');
	html += '&nbsp;</div></div>';
	$(this).append(html);

	// find new pagnation control and store data
	var newPagnation = $(this).children('.mail_row_paginator');
	newPagnation.data('page', page);
	newPagnation.data('total', total);
	newPagnation.data('volume', volume);
	newPagnation.data('siteBaseUrl', siteBaseUrl);
	newPagnation.data('moduleBaseUrl', moduleBaseUrl);
	newPagnation.data('currentFolder', currentFolder);
	newPagnation.data('postAppend', postAppend);
	newPagnation.data('context', context);
}

// update the pagnation widget
$.fn.updatePagnation = function(adjust)
{
	// make sure we are being called by a valid selector
	if($(this).length == 0)
	{
		return;
	}
	
	// ensure variables in are numeric
	adjust = Number(adjust);
	
	// ****************** SETUP VARIABLES ******************** //
	var pagnationObj = $(this).children('.mail_row_paginator');
	var context = pagnationObj.data('context');	
	var siteBaseUrl = pagnationObj.data('siteBaseUrl');
	var moduleBaseUrl = pagnationObj.data('moduleBaseUrl');	
	var total = pagnationObj.data('total');
	var volume = pagnationObj.data('volume');
	var postAppend = pagnationObj.data('postAppend');
	var page = pagnationObj.data('page');
 	var currentFolder = pagnationObj.data('currentFolder');
	
 	// find our mail row from context
	var mailRow = $(context).find('.mail_row:first');
	if(mailRow.length == 0)
	{
		mailRow = $(context).find('.messageItem:first');
	}
 	
	// grab total messages for above context aware row
	var totalMessages = checkTotalMessages(mailRow) - 1;
	total += adjust;
 	
	var leftBtn = pagnationObj.children('.pagingIconLeft');
	var rightBtn = pagnationObj.children('.pagingIconRight');
	var span = pagnationObj.children('span');
 	var select = pagnationObj.children('select');
	html = '';
	var pageNo = 1;
	var counter = 1;
	var update = true;
	var totalPages = Math.ceil(total/volume);
	var detectedValidPage = false;
	
	// check we are going to exceed total valid pages
	if(page > totalPages)
	{
		page = totalPages;
	}

	// ******************* GENERATE SELECTOR PAGE COUNTS ********************* //
	while( counter < total )
	{
		var actualPage = Math.ceil(counter/volume);

		if(actualPage > totalPages)
		{
			actualPage = totalPages;
		}
		
		selected = '';
		if(pageNo == page)
		{
			// current page found, select it ..
			detectedValidPage = true;
			selected = ' selected';			
			// .. and adjust this count for total amount on screen
			totalForPage = totalMessages + adjust + 1;
			if(totalForPage == 0 && page > 0)
			{
				$(this).html('');
				// no more elements for this page, reload.
				$.php(moduleBaseUrl + '/mail/listfoldermessages/selectFolder/' + currentFolder + '/page/' + actualPage + postAppend);
				update = false;
			}
		}
		else
		{
			totalForPage = volume;
			if(counter + totalForPage > total)
			{
				totalForPage = total - counter + 1;
			}
		}
			
		html += '<option' + selected + ' value="' + actualPage + '">' + counter + '-' + (counter + totalForPage - 1) + '</option>';
		counter+=totalForPage;
		pageNo++;
	}
	if(!detectedValidPage && page > 0)
	{
		$(this).html('');
		// invalid page, lets refresh to last page
		$.php(moduleBaseUrl + '/mail/listfoldermessages/selectFolder/' + currentFolder + '/page/' + totalPages + postAppend);
		update = false;
	}
	if(update)
	{
		// live update dom
		select.html(html);
		span.html(' of ' + total + ' ');	
		leftBtn.attr('src', siteBaseUrl + 'images/paging-prev' + (page>1?'':'-grey') + '.png');
		leftBtn.unbind('click');
		if(page>1)
		{
			leftBtn.bind('click', "$.php(\'' + moduleBaseUrl + '/mail/listfoldermessages/selectFolder/' + currentFolder + '/page/' + (page-1) + postAppend + '\')");
		}
		rightBtn.attr('src', siteBaseUrl + 'images/paging-next' + (page<(Math.ceil(total/volume))?'':'-grey') + '.png');
		rightBtn.unbind('click');
		if(page<Math.ceil(total/volume))
		{
			rightBtn.bind('click', "$.php(\'' + moduleBaseUrl + '/mail/listfoldermessages/selectFolder/' + currentFolder + '/page/' + (page+1) + postAppend + '\')");
		}
	}
	
	// store update vars
	pagnationObj.data('page', page);
	pagnationObj.data('total', total);
	pagnationObj.data('volume', volume);
}
