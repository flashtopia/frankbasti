/**
 * Created with JetBrains PhpStorm.
 * User: atmail
 * Date: 12-6-13
 * Time: 下午1:32
 * To change this template use File | Settings | File Templates.
 */

/**
 * ********************************************
 * Local Cache
 * ********************************************
 */
var $mail = {};
$mail.cache = {};
$mail.curID = null;
$mail.searchTimer = null;
$mail.loaded = false;
$mail.mailFromContact = null;

$mail.clearCache = function() {
	$mail.cache = {};
	$mail.curID = null;
	$mail.searchTimer = null;
	$mail.loaded = false;
	$mail.mailFromContact = null;
}

$mail.getMail = function(UID) {
	if(!UID) {
		UID = this.curID;
	}
	return this.cache['uid'+UID]? this.cache['uid'+UID] : null;
}

$mail.getReplyTo = function() {
	var header = this.getHeader();
	if(!header) {
		return '';
	}
	else {
		return header['reply-to'] || header['from'];
	}
}

$mail.getReplyAllTo = function() {
	var header = this.getHeader();
	if (!header) {
		return '';
	}

	var replyTo = header['reply-to'] || header['from'];
	var to = header['to'];

	var toAll;

	if (replyTo && to) {
		toAll = replyTo + ',' + to;
	}
	else {
		toAll = replyTo || to;
	}

	if(!toAll) {
		return '';
	}

	toAll = toAll.split(',');
	for (var i = 0; i < toAll.length; ++i) {
		toAll[i] = toAll[i].trim();
	}
	return unique(toAll).join(',');
};

$mail.getReplyAllCc = function() {
	var header = this.getHeader();
	if(!header) {
		return '';
	}

	return header['cc'];
}

$mail.setMail = function(UID, data) {
	this.cache['uid'+UID] = data;
}

$mail.getCurID = function() {
	return this.curID;
}

$mail.removeMail = function(UID) {
	this.cache['uid'+UID] = null;
	this.curID = null;
}

$mail.getHeader = function() {
	if(!this.curID) {
		return null;
	}

	return this.cache['uid' + this.curID].headers;
}

$mail.getSubject = function() {
	var header = this.getHeader();
	return header? header['subject'] : null;
}

$mail.MODE_NEW = 0;
$mail.MODE_REPLY = 1;
$mail.MODE_REPLYALL = 3;
$mail.MODE_FORWARD = 4;
$mail.MODE_NEW_FROM_CONTACT = 5;
$mail._composeMode = $mail.MODE_NEW;

$mail.setNewMode = function() {
	$mail._composeMode = $mail.MODE_NEW;
}

$mail.setReplyMode = function() {
	$mail._composeMode = $mail.MODE_REPLY;
}

$mail.setReplyAllMode = function() {
	$mail._composeMode = $mail.MODE_REPLYALL;
}

$mail.setForwardMode = function() {
	$mail._composeMode = $mail.MODE_FORWARD;
}

$mail.setNewFromContactMode = function() {
	$mail._composeMode = $mail.MODE_NEW_FROM_CONTACT;
}

$mail.isModeNew = function() {
	return $mail._composeMode == $mail.MODE_NEW;
}

$mail.isModeReply = function() {
	return $mail._composeMode == $mail.MODE_REPLY;
}

$mail.isModeReplyAll = function() {
	return $mail._composeMode == $mail.MODE_REPLYALL;
}

$mail.isModeForward = function() {
	return $mail._composeMode == $mail.MODE_FORWARD;
}

$mail.isModeNewFromConatct = function() {
	return $mail._composeMode == $mail.MODE_NEW_FROM_CONTACT;
}

/*
 * folders
 */
$mailfolder = {
	_reloadInterval : 1000*60*5, // 5 min

	_folderlistTimestamp : null,

	_folderTimestamp : {},

	updateFolderlistTimestamp : function() {
		this._folderlistTimestamp = Date.now()
	},

	needReloadFolderlist : function() {
		return this._folderlistTimestamp? Date.now()-this._folderlistTimestamp>this._reloadInterval : true;
	},

	updateLoadTimestamp : function(folderGlobalName) {
		if(!folderGlobalName) return;
		this._folderTimestamp[folderGlobalName] = Date.now();
	},

	needReload : function(folderGlobalName) {
		if(!folderGlobalName) return false;
		return this._folderTimestamp[folderGlobalName]? Date.now()-this._folderTimestamp[folderGlobalName]>this._reloadInterval : true;
	}

};
