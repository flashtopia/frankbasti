/*
* Copyright (c) 2009-2010 ATMAIL. All rights reserved
* See http://atmail.com/license.php for license agreement
*/

var calendarCacheItem = function(xml)
{
	this.name = xml.attr("name");
	this.principal_url = xml.attr("principal_url");
	this.relative_href = xml.attr("relative_href");
	this.etag = xml.attr('etag');
	this.color = xml.attr("color");
	this.ctag = xml.attr('ctag');
	this.id = xml.attr("id");
	this.server = xml.attr("server");
	this.owner = xml.attr("calendar_owner");
	this.mode = xml.attr('mode');
	this.enabled = true;

	this.compare = function (a)
	{
		return (	this.name == a.name
				&&	this.principal_url == a.principal_url
				&&	this.relative_href == a.relative_href
				&&	this.etag == a.etag
				&&	this.color == a.color
				&&	this.ctag == a.ctag
				&&	this.server == a.server
				&&	this.owner == a.owner
				&&	this.mode == a.mode );
	};
};

var calendarCacheObj = function(userOptions)
{
	// ***** default options *****
	var options = $.extend(
	{
	}, userOptions);

	// ***** private variables *****
	var CALENDAR_EXISTS = false;
	var CALENDAR_ADDED = 1;
	var CALENDAR_UPDATED = 2;

	// ***** private methods *****
	var privateMethods =
	{
		initalize : function()
		{
		}, // initalize
		createCalendarCacheItem : function (xml)
		{
			var newCalendarCacheItem = new calendarCacheItem(xml);
			return newCalendarCacheItem;
		}
	}; // privateMethods

	// ***** public variables *****
	this.cache = [];

	// ***** public methods *****
	this.add = function(xml)
	{
		var calendarCacheItem = privateMethods.createCalendarCacheItem(xml);
		if(this.cache[calendarCacheItem.id] != undefined)
		{
			// lets update to ensure everything is ok
			this.update(calendarCacheItem.id, calendarCacheItem);
			return CALENDAR_EXISTS;
		}

		this.cache[calendarCacheItem.id] = calendarCacheItem;
		return CALENDAR_ADDED;
	};

	this.update = function(i, object)
	{
		return (this.cache[i] == undefined ? undefined : this.cache[i] = object);
	};

	this.toggle = function(i, setting)
	{
		if(this.cache[i] != undefined)
		{
			this.cache[i].enabled = setting;
		}
	};

	this.refresh = function(xml)
	{	
		var deletedIds = new Array();
		var updatedIds = new Array();
		var xmlCalendarsIds = new Array();
		xml.find("CalName").each(function()
		{
			xmlCalendarsIds[generateCalendarUUID($(this))] = $(this);
		});

		for(var i in this.cache)
		{
			if(xmlCalendarsIds[i] != undefined)
			{
				var calendarCacheItem = privateMethods.createCalendarCacheItem(xmlCalendarsIds[i]);

				if(!calendarCacheItem.compare(this.cache[i]))
				{
					this.update(i, calendarCacheItem);
					updatedIds.push(i);
				}
			}
			else
			{
				deletedIds.push(i);
				delete this.cache[i];
			}
		}

		return {'deleted' : deletedIds, 'updated' : updatedIds};
	};

	this.getActiveCalendars = function()
	{
		var calendarCacheItems = [];

		for (var i in this.cache)
		{
			if(this.cache[i].enabled)
			{
				calendarCacheItems.push(this.cache[i].relative_href);
			}
		}
		return calendarCacheItems;
	};

	// ***** object construction *****
	privateMethods.initalize();
};

// setup global calendar cache object
var calendarCache = new calendarCacheObj();
